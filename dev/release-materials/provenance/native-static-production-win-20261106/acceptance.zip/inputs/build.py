from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,subprocess,time,shutil
b=Path('F:/xlang-validation/native-static-20261106');root=b/'core-source-r6';out=b/'production-win-r3';parentpath=b/'production-win-r2/production-build.json';parent=json.loads(parentpath.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((b/'core-source-r5.json').read_text());frozen=json.loads((b/'core-source-r6.json').read_text());assert set(k for k in frozen['files'] if k.startswith(('src/','lib/','include/','release/')) and frozen['files'][k]!=old['files'].get(k))=={'src/api/xl_api.c','lib/tcc/tccelf.c'}
for k,v in frozen['files'].items():assert sha(root/k)==v,k
assert sha(parent['compiler'])==parent['compilerSha256'];assert all(sha(v['path'])==v['sha256'] for v in parent['objects']+parent['sharedObjects'])
report=dict(scope='Incremental successor of real O2 production profiles; exact source/header/object identities checked, four changed API/TCC units now, two VFS resource units after repack; no release install or TinyCC PE execution',complete=False,passed=False,parent=str(parentpath),parentSha256=sha(parentpath),sourceRoot=str(root),sourceFreezeSha256=sha(b/'core-source-r6.json'),compiler=parent['compiler'],compilerSha256=parent['compilerSha256'],sharedObjects=parent['sharedObjects'],inheritedObjects=[],objects=[],commands=[],shippingInstallation=False)
for row in parent['objects']:
 if not row['source'].endswith(('xl_api.c','libtcc.c','tcc_builtin_resources.c','tcc_builtin_resources_runtime.c')):report['inheritedObjects'].append(row)
assert len(report['inheritedObjects'])==2621
save=lambda:(out/'production-build.json').write_text(json.dumps(report,indent=2)+'\n')
def run(row):
 profile=row['profile'];source='src/api/xl_api.c' if row['index']==0 else str(root/'lib/tcc/libtcc.c');flags=[v.replace((b/'core-source-r5').as_posix(),root.as_posix()) for v in row['flags']];obj=out/'obj'/profile/(str(row['index'])+'.o');obj.parent.mkdir(parents=True,exist_ok=True);args=[report['compiler'],*flags,'-c',source,'-o',str(obj)];t=time.monotonic();r=subprocess.run(args,cwd=root,capture_output=True,timeout=300);log=obj.with_suffix('.log');log.write_bytes(r.stdout+r.stderr);return dict(profile=profile,index=row['index'],source=source,path=str(obj),sha256=sha(obj)if obj.is_file()else None,sourceSha256=sha(root/source),flags=flags,command=args,exitCode=r.returncode,seconds=round(time.monotonic()-t,3),logSha256=sha(log),provenance='recompiled')
save()
with ThreadPoolExecutor(max_workers=4)as pool:
 for future in as_completed([pool.submit(run,r)for r in parent['objects']if r['source'].endswith(('xl_api.c','libtcc.c'))]):
  row=future.result();report['objects'].append(row);save();print(row['profile'],row['index'],row['exitCode'],flush=True)
assert len(report['objects'])==4 and all(not r['exitCode']for r in report['objects']);report['changedCompilerUnitsComplete']=True;save();print('FOUR_UNITS_COMPLETE',flush=True)

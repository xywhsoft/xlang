#include "include/xl.h"
#include <stdio.h>
int main(int argc,char**argv){
 if(argc!=4)return 2;
 XL_ContextOptions options=xlDefaultContextOptions();options.workDir=argv[1];options.tempDir=argv[1];
 options.tccLibPath=argv[2];options.tccDllPath="__invalid_dynamic_provider_static_profile__";
 XL_Context* context=xlCreateContext(&options);if(!context)return 3;
 if(!xlAddIncludePath(context,argv[3]))return 4;
 if(!xlRunScriptString(context,"auto s=NativeSequence::<c_int>()\nassert s.length==0\nvar v=s\nassert (v as NativeSequence<c_int>).count()==0\n"))goto failed;
 XL_Module* module=xlCompileScriptStringToModule(context,"assert 6*7==42\n");
 if(!module||!xlRunModuleMain(context,module,NULL))goto failed;
 xlDestroyModule(module);
 if(xlRunScriptString(context,"assert missingProductionName==0\n"))return 5;
 if(!xlRunScriptString(context,"assert 20+22==42\n"))goto failed;
 xlDestroyContext(context);
 XL_RuntimeDrainResult result=xlRuntimeDrainRetiringChecked(0);
 if(!result.ready||!result.ok)return 6;
 puts("production runtime: PASS");return 0;
failed:fprintf(stderr,"%s\n",xlGetLastError(context));xlDestroyContext(context);return 7;
}

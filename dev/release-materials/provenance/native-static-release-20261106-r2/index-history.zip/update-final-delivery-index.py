from pathlib import Path
import json,hashlib,subprocess,copy
root=Path('D:/GIT/x-lang');b=Path('F:/xlang-validation/native-static-20261106');p=root/'dev/release-materials/provenance/current-delivery.json';before=p.read_bytes();out=b/'final-delivery-index-r1';out.mkdir(exist_ok=False);(out/'previous-current-delivery.json').write_bytes(before);d=json.loads(before);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
git=lambda *args:subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,check=True).stdout.strip()
reference=lambda relative:dict(path=relative,sha256=sha(root/relative),bytes=(root/relative).stat().st_size)
provenance='dev/release-materials/provenance/native-static-release-20261106-r2/receipt.json';r=json.loads((root/provenance).read_text());assert r['complete']and r['passed']
oldCompiler=copy.deepcopy(d['compiler']);codeRevision=git('rev-parse','0c5d524ca');integrationRevision=git('rev-parse','HEAD')
for item in d['products']:
 if item.get('path') in ('release/win_x64/xl.dll','release/win_x64/xlc.dll'):
  item.update(reference(item['path']),origin='native-static-windows-qualified-20261106-r2')
d['compiler'].update(sourceRevision=codeRevision,currentBuildProvenance=provenance,sourceMaterials=reference('dev/release-materials/sources/native-static-core-20261106/manifest.json'),sourceOverlays=[reference(n)for n in r['sourceOverlays']],buildScope='Windows production profiles only; source identity is the frozen core plus exact overlays. Existing Linux production products retain their earlier build evidence.',previousWindowsBuildEvidence=oldCompiler)
priorStatic=copy.deepcopy(d['nativeStaticIntegration']);d['nativeStaticIntegration']=dict(status='windows-production-installed-pe-qualified',provenance=provenance,provenanceSha256=sha(root/provenance),report='docs/reports/native-static-release-20261106-r2.md',optimization='O2',integrationRevision=integrationRevision,nativeBuilderRevision='64a43fcf86b6ac1ecee56264af3fb4d220aa0a60',releaseImagesReplaced=True,sourceIdentity=dict(freezeSha256=r['sourceRoot11ManifestSha256'],sourceMaterials=d['compiler']['sourceMaterials'],overlays=d['compiler']['sourceOverlays']),windowsCandidateDirectory='F:/xlang-validation/native-static-20261106/production-win-r5/release/win_x64',windowsStaticPackages='release/win_x64/static/xge3/packages',staticSdk=dict(files=77,bytes=30412076,selection='Explicit XLANG_PACKAGE_PATH; matching _xge_native/xge/xui triple.',ordinaryDynamicPackagesReplaced=False),windowsPeAotQualified=True,windowsProductionPassedRows=46,installedCliPassedRows=7,fullStaticProgramBytes=1062912,linuxProductionDllRebuilt=False,linuxDevelopmentQualification=r['linuxQualification'],pending=[],scopeLimits=r['scopeLimits'][:3],previousQualification=priorStatic)
d['nativeStaticPublication']=reference(provenance)
header=reference('release/win_x64/include/libtcc.h');readme=reference('release/win_x64/static/xge3/README.md')
assert isinstance(d['dataFiles'],list)
for row in (header,readme):
 found=next((x for x in d['dataFiles']if x.get('path')==row['path']),None)
 if found is None:d['dataFiles'].append(row)
 else:found.update(row)
newline='\r\n'if b'\r\n'in before else'\n';updated=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').replace('\n',newline).encode('utf-8');assert p.read_bytes()==before;p.write_bytes(updated);(out/'current-delivery.json').write_bytes(updated)
result=dict(complete=True,passed=True,previousSha256=hashlib.sha256(before).hexdigest(),currentSha256=sha(p),changedWindowsImages=[row for row in d['products']if row.get('path')in('release/win_x64/xl.dll','release/win_x64/xlc.dll')],scope='Mutable delivery index update only; prior compiler/static qualification records retained. IDE, engine, Linux products and their metadata unchanged.')
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(out/'receipt.json',sha(out/'receipt.json'))

#include "static_xge_aot_math.h"
int main(void){return static_xge_math_probe();}

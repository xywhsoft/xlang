
"""Seal exact gallery sources, immutable raw acceptance, and owned publication."""
from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
root=Path('D:/GIT/x-lang');b=Path('F:/xlang-validation/xui-gallery-20261106')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ref(p):return dict(path=Path(p).relative_to(root).as_posix(),sha256=sha(p),bytes=Path(p).stat().st_size)
win=load(b/'final-win-r2/results.json');assert win['complete']and win['passed']and len(win['rows'])==144
linux=b/'linux-evidence';assert load(linux/'gallery-cgen-r1/results.json')['passed'];assert load(linux/'gallery-build-r1/results.json')['passed']
assert load(b/'installed-acceptance/results.json')['passed']
assert load(b/'production-accept-r1/results.json')['passed'];assert load(b/'owned-proxy-r1/static/member-equivalence.json')['passed']
assert load(b/'static-gallery/results.json')['passed']
source=root/'lib/bindings/xui/examples';catalog=load(source/'gallery.json');assert len(catalog['examples'])==48
# Explicit source files only. Preserve unknown files and hidden IDE state.
files=sorted([p for p in source.iterdir()if p.is_file()and p.suffix in('.xl','.md','.json','.bat')]);assert len([p for p in files if p.suffix=='.xl'and not p.name.startswith('_')])==56
pub=b/'example-publication.json';rows=[]
targets=[root/'release/win_x64/examples/xui',root/'release/linux_x64/examples/xui',root/'release/win_x64/extlibs/xui/examples',root/'release/linux_x64/extlibs/xui/examples',root/'release/win_x64/static/xge3/packages/xui/examples']
for target in targets:
 for p in files:
  t=target/p.name;assert sha(t)==sha(p),(t,'publication was not byte identical');rows.append(ref(t))
write(pub,dict(complete=True,passed=True,files=rows,sourceFiles=len(files),publicPrograms=56))
materials=root/'dev/release-materials';src=materials/'sources/xui-gallery-20261106';prov=materials/'provenance/xui-gallery-20261106';src.mkdir(exist_ok=False);prov.mkdir(exist_ok=False)
# Preserve current predecessor bytes before changing its mutable index.
index=materials/'provenance/current-delivery.json';shutil.copy2(index,prov/'previous-delivery.json')
source_paths=[*files,root/'lib/bindings/xui/src/managed.xl']+[root/'tools'/n for n in('xui_gallery_contracts.py','update_xui_gallery.py','check_xui_gallery.py','run_xui_examples.ps1','check_xge3_bindings.py','gen_tcc_vfs_resources.py')]+[root/'docs/xge3-xui3-example-status.md']
source_entries=[]
with zipfile.ZipFile(src/'overlay.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in source_paths:
  name='xlang/'+p.relative_to(root).as_posix();z.write(p,name);source_entries.append(dict(path=str(p),entry=name,sha256=sha(p),bytes=p.stat().st_size))
 for p,name in [(b/'owned-proxy-r1/source/src/xui/core/xui_core.c','native/src/xui/core/xui_core.c'),(Path('D:/GIT/xge/tests/test_xui_owned_context_proxy.c'),'native/tests/test_xui_owned_context_proxy.c')]:
  z.write(p,name);source_entries.append(dict(path=str(p),entry=name,sha256=sha(p),bytes=p.stat().st_size))
 for p in [b/'rebuild-inline-catalog.py',b/'linux-candidate-r2.py',b/'seal-gallery.py']:
  z.write(p,'recipes/'+p.name);source_entries.append(dict(path=str(p),entry='recipes/'+p.name,sha256=sha(p),bytes=p.stat().st_size))
write(src/'manifest.json',dict(schema=1,scope='Gallery and exact incremental source overlay over preserved Root11 compiler / Native static source materials. Does not incorporate unrelated live workspace changes.',archive=ref(src/'overlay.zip'),nativeFixCommit='a9eb0aa6',nativeBase=ref(materials/'sources/xge-static-20261106-r1/manifest.json'),compilerBase=ref(materials/'sources/native-static-core-20261106/manifest.json'),entries=source_entries))
records=[]
with zipfile.ZipFile(prov/'acceptance.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(b.rglob('*')):
  if p.is_file()and p.suffix in('.json','.log','.py')and not any(part in('source','release','rollback','packages','packages-r2')for part in p.relative_to(b).parts):
   entry=p.relative_to(b).as_posix();z.write(p,entry);records.append(dict(path=str(p),entry=entry,sha256=sha(p),bytes=p.stat().st_size))
 for relative in ('host-candidate-r1/render.png','owned-proxy-r1/static-gui/render.png'):
  p=b/relative;z.write(p,relative);records.append(dict(path=str(p),entry=relative,sha256=sha(p),bytes=p.stat().st_size))
products=[root/'release/win_x64/xl.dll',root/'release/win_x64/xlc.dll']
for platform,native in [('win_x64','xge3_host.dll'),('linux_x64','libxge3_host.so')]:
 base=root/'release'/platform/'extlibs/_xge_native';products +=[base/'native'/native,base/'include/xge.h',base/'include/xge_build_config.h',base/'xlang.package.json']
products +=[root/'release/win_x64/static/xge3/packages/_xge_native/native/libxge3_static.a',root/'release/win_x64/static/xge3/packages/_xge_native/xlang.package.json']
receipt=dict(schema=1,date='2026-11-06',complete=True,passed=True,externalPublishPerformed=False,scope='48 rewritten declarative XUI gallery entrypoints plus 8 retained resource/lifetime examples. Matched private Native Proxy identity fix, resource-only Windows compiler successor, optional static SDK. Linux graphics not executed: WSL has no display.',counts=dict(publicPrograms=56,galleryEntrypoints=48,aggregateScenes=47,windowsGalleryRows=144,linuxGalleryCgenRows=48,linuxGalleryBuildRows=3,windowsCompilerCpuRows=46),sources=ref(src/'manifest.json'),acceptanceArchive=ref(prov/'acceptance.zip'),records=records,products=[ref(p)for p in products],publication=ref(pub)if pub.is_relative_to(root)else dict(path=str(pub),sha256=sha(pub)),nativeCommit='a9eb0aa6',previousIndex=ref(prov/'previous-delivery.json'),limits=['Bounded real Windows windows/render and one synthetic button-click assertion; no exhaustive manual UI or GPU/performance benchmark.','Linux production compiler images unchanged; new matched private Native host passed CPU runs, C generation and AOT builds, without graphical execution.','Only two resource objects replaced in Windows core profiles; remaining compiled objects inherited exactly.','Static Native archive replaces one of 145 members; 144 member bytes verified unchanged.','Existing checked lifetime/errors and O(n) input projections remain; no universal zero-cost claim.','No network, browser, OS clipboard, shell or security tests.'])
write(prov/'receipt.json',receipt)
r=load(index)
for product in r['products']:
 for current in receipt['products']:
  if product['path']==current['path']:product.update(current,origin='xui-gallery-20261106')
r['compiler']['previousGalleryResourceEvidence']=r['compiler']['currentBuildProvenance'];r['compiler']['currentBuildProvenance']=str((prov/'receipt.json').relative_to(root)).replace('\\','/');r['compiler']['buildScope']='Windows resource-only successor: retain selected-XRT inline symbol catalog in runtime/compiler VFS. Two resource objects rebuilt; all core code objects inherited unchanged.'
r['xuiGallery']=dict(status='installed-qualified',provenance=ref(prov/'receipt.json'),sourceMaterials=ref(src/'manifest.json'),publicPrograms=56,galleryEntrypoints=48,aggregateScenes=47,windowsRows=144,linuxCgenRows=48,linuxBuildRows=3,linuxGuiRun=False,report='docs/reports/xui-gallery-20261106.md')
r['sourceMaterials']['xuiGallery']=ref(src/'manifest.json');r['nativeStaticIntegration']['staticSdk'].update(files=sum(p.is_file()for p in(root/'release/win_x64/static/xge3/packages').rglob('*')),bytes=sum(p.stat().st_size for p in(root/'release/win_x64/static/xge3/packages').rglob('*')if p.is_file()));r['nativeStaticIntegration']['gallerySuccessor']=ref(prov/'receipt.json');write(index,r)
write(b/'seal-result.json',dict(complete=True,passed=True,sources=ref(src/'manifest.json'),provenance=ref(prov/'receipt.json'),products=receipt['products']))
print('SEALED',len(files),'source files',len(rows),'publication files',len(records),'evidence files')

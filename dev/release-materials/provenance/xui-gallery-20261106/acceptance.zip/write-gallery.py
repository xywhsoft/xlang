from pathlib import Path
import json,re
root=Path('D:/GIT/x-lang');dest=root/'lib/bindings/xui/examples';specs={}
def demo(name,title,body):specs[name]=dict(title=title,body=body.strip(),className=''.join(p.title()for p in name.split('_'))+'Example')
def simple(name,title,constructor,body,height=260):demo(name,title,f'auto control=context.{constructor}\n demo.Gallery.place(root,control,24,64,640,{height})\n '+body)
simple('button','Button / click and disabled states','buttonNative()', '''control.setText("Click me")
 control.setClick(func(xui.Widget source)
  control.setText("Clicked - callback received")
 end)
 assert control.getText()=="Click me"
 auto disabled=context.buttonNative()
 disabled.setText("Disabled")
 assert disabled.setEnabled(c_int(0))==0
 demo.Gallery.place(root,disabled,24,132,220,44)''',44)
simple('checkbox','Checkbox / three-state selection','checkBoxNative()', '''control.setText("Enable notifications")
 assert control.setChecked(c_int(1))==0
 control.setAutoThreeState(c_int(1))
 assert control.getChecked()!=0''',44)
simple('radio','Radio / exclusive choice','radioNative()', '''control.setText("First option")
 assert control.setChecked(c_int(1))==0
 auto second=context.radioNative()
 second.setText("Second option")
 demo.Gallery.place(root,second,24,124,300,44)
 assert control.getChecked()!=0''',44)
simple('toggle','Toggle / enabled state','toggleNative()', '''control.setText("Enable live preview")
 assert control.setChecked(c_int(1))==0
 assert control.getChecked()!=0''',44)
simple('slider','Slider / drag the knob','slider(xui.SliderDesc())', '''control.setRange(c_float(0),c_float(100))
 assert control.setValue(c_float(35))==0
 assert control.getValue()==c_float(35)''',44)
simple('rangeslider','Range slider / drag both endpoints','rangeSlider(xui.RangeSliderDesc())', '''control.setRange(c_float(0),c_float(100))
 assert control.setValues(c_float(20),c_float(80))==0
 auto first,last=control.getValues()
 assert first==c_float(20) and last==c_float(80)''',44)
simple('scrollbar','Scrollbar / page and position','scrollBar(xui.ScrollbarDesc())', '''control.setRange(c_float(0),c_float(1000),c_float(100))
 assert control.setValue(c_float(150))==0
 assert control.getValue()==c_float(150)''',28)
simple('input','Input / edit UTF-8 text','inputNative()', '''assert control.setText("Hello, xlang - edit this text") ==0
 assert control.getText()=="Hello, xlang - edit this text"''',44)
simple('textedit','Text editor / multiline selection','textEditNative()', '''assert control.setText("Multiline text editor\nSelect, edit, undo and redo.\nUTF-8: 你好，世界！")==0
 assert control.setWordWrap(c_int(1))==0''')
simple('codeedit','Code editor / minimap and syntax','codeEditNative()', '''assert control.setLanguage("xlang")==0
 assert control.setText("func main(...) as int\n println(\"Hello, XUI\")\n return 0\nend\n")==0
 assert control.setMinimap(c_int(1),c_float(100))==0
 assert control.setTabColumns(c_int(4))==0
 assert control.getText()!=null''',360)
simple('taginput','Tag input / add and remove tags','tagInputNative()', '''assert control.addTag("xlang")>=0
 assert control.addTag("native")>=0
 assert control.addTag("UTF-8")>=0''',60)
simple('numericinput','Numeric input / limits and step','numericInputNative()', '''control.setRange(c_float(-100),c_float(100))
 assert control.setValue(c_float(12.5))==0
 assert control.getValue()==c_float(12.5)''',44)
simple('hyperlink','Hyperlink / local click callback','hyperlinkNative()', '''control.setText("Click to report a local action (no browser)")
 control.setClick(func(xui.Widget source)
  println("Hyperlink clicked")
 end)''',40)
simple('qrcode','QR code / UTF-8 content','qrCodeNative()', '''control.setValue("xlang XUI 3")
 control.setColors(c_uint(0xFF000000),c_uint(0xFFFFFFFF))
 assert control.getValue()=="xlang XUI 3"''',280)
simple('panel','Panel / child ownership','panelNative()', '''control.setTitle("Panel with child controls")
 auto child=context.buttonNative()
 child.setText("Owned by this Context")
 demo.Gallery.place(control,child,20,48,260,44)
 assert control.getChildCount()>0''')
simple('progress','Progress / change the value','progressNative()', '''control.setRange(c_float(0),c_float(100))
 control.setValue(c_float(65))
 control.setTextTemplate("{value}%")
 assert control.getValue()==c_float(65)''',44)
simple('stepbar','Step bar / workflow stages','stepBarNative()', '''control.setSteps(["Configure","Build","Run","Finish"])
 control.setCurrent(c_int(1))
 assert control.getStepCount()==c_int(4)''',92)
simple('breadcrumb','Breadcrumb / navigation callbacks','breadcrumbNative()', '''assert control.addItem("Home",c_int(1),c_int(1))>=0
 assert control.addItem("Projects",c_int(1),c_int(2))>=0
 assert control.addItem("xlang",c_int(0),c_int(3))>=0
 assert control.getItemCount()==c_int(3)''',44)
simple('listview','List / selection and scrolling','listViewNative()', '''control.setItems(["First item","Second item","Third item","Fourth item","Fifth item"])
 assert control.setSelected(c_int(1))==0
 assert control.getItemCount()==c_int(5)''')
simple('combobox','Combo box / popup selection','comboBoxNative()', '''control.setItems(["Debug","Release","Profile"])
 assert control.setSelected(c_int(1))==0
 assert control.getItemCount()==c_int(3)''',44)
simple('treeview','Tree / expand and select','treeViewNative()', '''assert control.addNode(c_int(1),c_int(0),"Project")>=0
 assert control.addNode(c_int(2),c_int(1),"Sources")>=0
 assert control.addNode(c_int(3),c_int(2),"main.xl")>=0
 control.setExpanded(c_int(1),c_int(1))
 control.setExpanded(c_int(2),c_int(1))
 assert control.setSelected(c_int(3))==0''')
simple('tabs','Tabs / Context-owned pages','tabsNative()', '''control.setItems(["Overview","Settings"])
 for i in 0..2
  auto page=context.panelNative()
  demo.Gallery.label(context,page,"Page "+string(i+1),20,24,400)
  assert control.addPageChild(c_int(i),page)==0
 end
 assert control.setSelected(c_int(0))==0''')
simple('carousel','Carousel / page navigation','carouselNative()', '''assert control.setPageCount(c_int(3))==0
 for i in 0..3
  auto page=context.panelNative()
  demo.Gallery.label(context,page,"Slide "+string(i+1),40,80,400)
  assert control.addPageChild(c_int(i),page)==0
 end
 assert control.setCurrent(c_int(0),c_int(0))==0''')
simple('page','Pagination / page count','pageNative()', '''assert control.setPageCount(c_int(20))==0
 assert control.setCurrent(c_int(3),c_int(0))==0
 assert control.getCurrent()==c_int(3)''',54)
simple('accordion','Accordion / expand sections','accordionNative()', '''auto first=control.addSection("Project",c_int(1),c_int(1))
 auto button=context.buttonNative()
 button.setText("Build project")
 demo.Gallery.place(first,button,16,16,200,44)
 auto second=control.addSection("Settings",c_int(2),c_int(0))
 demo.Gallery.label(context,second,"Second section",16,16,300)
 assert control.getSectionCount()==c_int(2)''',340)
simple('window','Window / move and resize','windowNative()', '''control.setTitle("Movable child window")
 control.setDragAnywhere(c_int(1))
 auto button=context.buttonNative()
 button.setText("A normal child")
 demo.Gallery.place(control,button,30,64,220,44)''')
simple('dockpanel','Dock panel / owned client windows','dockPanelNative()', '''auto client=context.panelNative()
 demo.Gallery.label(context,client,"Dockable content",20,40,400)
 c_int id=control.addWindow("Inspector",client)
 assert control.getWindowCount()==c_int(1)''',360)
simple('popup','Popup / explicit open and close','popupNative()', '''control.setContentSize(c_float(320),c_float(160))
 auto owner=context.buttonNative()
 owner.setText("Open popup")
 demo.Gallery.place(root,owner,24,64,240,44)
 owner.setClick(func(xui.Widget source)
  control.openAt(source,c_float(24),c_float(120))
 end)''',1)
simple('menu','Menu / command selection','menuNative()', '''control.addItem("New",shortcut="Ctrl+N",value=c_int(1))
 control.addItem("Open",shortcut="Ctrl+O",value=c_int(2))
 assert control.addSeparator()==0
 control.addItem("Save",shortcut="Ctrl+S",value=c_int(3))
 auto owner=context.buttonNative()
 owner.setText("Open menu")
 demo.Gallery.place(root,owner,24,64,240,44)
 owner.setClick(func(xui.Widget source)
  control.openForOwner(source)
 end)
 assert control.getItemCount()==c_int(4)''',1)
simple('toolbar','Toolbar / commands and tooltips','toolbarNative()', '''assert control.addItem("New",c_int(0),c_int(1))>=0
 assert control.addItem("Build",c_int(0),c_int(2))>=0
 assert control.addSeparator()>=0
 assert control.addItem("Run",c_int(0),c_int(3))>=0
 control.setItemTooltip(c_int(1),"Build the current project")
 assert control.getItemCount()==c_int(4)''',48)
simple('statusbar','Status bar / text and progress','statusBarNative()', '''assert control.addText(c_int(0),"Ready",c_float(220),c_int(0),c_int(1))>=0
 assert control.addProgress(c_int(0),c_float(0),c_float(100),c_float(65),c_float(180))>=0
 assert control.getItemCount()==c_int(2)''',40)
simple('colorpicker','Color picker / RGBA popup','colorPickerNative()', '''assert control.setColor(c_uint(0xFF3C9AE8))==0
 assert control.getColor()==c_uint(0xFF3C9AE8)''',44)
simple('datepicker','Date picker / calendar popup','datePickerNative()', '''control.setValue(time.now())
 assert control.getValue()>time(0)''',44)
simple('terminal','Terminal / ANSI text without a child process','terminalNative()', '''assert control.writeText("xlang XUI terminal\r\n\x1b[32mANSI green\x1b[0m\r\nNo shell is started.\r\n")>=0
 assert control.flush()==0''',320)
simple('messagelist','Message list / structured nodes','messageListNative()', '''control.addNode("m1","Hello from xlang",sender="Alice",time="12:00")
 control.addNode("m2","Native XUI message rendering",sender="Bob",time="12:01")
 control.appendNodeText("m2"," - appended text")''',320)
simple('chart','Chart / typed data columns','chartNative()', '''control.setTitle("Measured values")
 c_int line=control.addSeries(xui.XUI_CHART_SERIES_LINE,"Samples")
 control.setSeriesData(line,[c_double(0),c_double(1),c_double(2),c_double(3)],[c_double(2),c_double(5),c_double(3),c_double(7)])
 control.setLegendVisible(c_int(1))
 assert control.getSeriesCount()==c_int(1)''',340)
simple('timeline','Timeline / layers and spans','timeLineViewNative()', '''assert control.setFrameCount(c_int(100))==0
 c_int layer=control.addLayer("Animation")
 c_int span=control.addSpan(layer,c_int(5),c_int(25),c_int(0),"Move")
 assert control.setCurrentFrame(c_int(10))==0
 assert control.getLayerCount()==c_int(1)''',300)
simple('propertygrid','Property grid / editable values','propertyGridNative()', '''c_int category=control.addCategory("general","General",c_int(1))
 control.addProperty(category,"name","Name",description="Project name",value="xlang")
 assert control.getPropertyCount()==c_int(1)''',300)
for name,ctor in [('tableview','tableViewNative()'),('tablegrid','tableGridNative()')]:
 simple(name,name.title()+' / columns and cells',ctor,'''control.setColumns(["Name","Value"],[c_float(250),c_float(220)])
 assert control.getColumnCount()==c_int(2)''',300)
simple('canvas','Canvas / persistent drawing and pen','canvas(xui.CanvasDesc())', '''control.setCanvasSize(c_float(640),c_float(360))
 assert control.clear(c_uint(0xFF302820))==0
 assert control.drawRectFill(demo.Gallery.rect(30,30,160,90),c_uint(0xFFE89632))==0
 assert control.drawCircleFill(c_float(320),c_float(100),c_float(55),c_uint(0xFF50B890))==0
 control.setPen(c_int(1),c_float(3),c_uint(0xFFFFFFFF))''',360)
simple('scrollview','Scroll view / content larger than viewport','scrollView(xui.ScrollViewDesc())', '''assert control.setContentSize(c_float(1200),c_float(1000))==0
 for i in 0..12
  demo.Gallery.label(context,control,"Scrollable row "+string(i+1),20,i*70+20,1000)
 end''',320)
simple('splitlayout','Split layout / draggable divider','splitLayout(xui.SplitLayoutDesc())', '''auto left=context.panelNative()
 auto right=context.panelNative()
 demo.Gallery.label(context,left,"Left pane",16,24,280)
 demo.Gallery.label(context,right,"Right pane",16,24,280)
 assert control.addPaneChild(c_int(0),left)==0
 assert control.addPaneChild(c_int(1),right)==0''',320)
simple('separator','Separator / horizontal rule','separator(xui.SeparatorDesc())', '''control.setColor(c_uint(0xFFB08040))
 demo.Gallery.label(context,root,"Above the separator",24,24,600)
 demo.Gallery.label(context,root,"Below the separator",24,100,600)''',3)
demo('image','Image / generated RGBA resource', '''auto surface=proxy.createSurfaceRGBA(c_int(96),c_int(96),flags=c_uint(xui.XUI_SURFACE_USAGE_TARGET))
 try
  proxy.clearSurface(surface,c_uint(0xFFE8A040))
  auto control=context.imageNative()
  control.setSurface(surface)
  assert control.setSource(demo.Gallery.rect(0,0,96,96))==0
  demo.Gallery.place(root,control,24,64,288,288)
 finally
  // The Image slot retains its real native Surface owner.
  surface.close()
 end''')
demo('richtext','Rich text / current Document View model', '''auto document=xui.createDocument()
 try
  auto transaction=document.beginTransaction()
  try
   uint64 paragraph=transaction.insertNode(uint64(1),xui.XUI_DOCUMENT_APPEND,c_uint(2))
   transaction.insertNode(paragraph,xui.XUI_DOCUMENT_APPEND,c_uint(4),text="Rich text in the current Document model. Select this UTF-8 text: 你好！")
   auto changes=transaction.commit()
   changes.close()
  finally
   transaction.close()
  end
  auto view=xui.createDocumentView(context,document)
  demo.Gallery.place(root,view,24,64,680,320)
 finally
  // The View retains the Document; no legacy RichText wrapper exists.
  document.close()
 end''')
demo('basic','Basic controls / interactive state', '''auto button=context.buttonNative()
 button.setText("Click to change the label")
 demo.Gallery.place(root,button,24,64,300,44)
 auto status=context.labelNative()
 status.setText("Waiting for a click")
 demo.Gallery.place(root,status,24,124,480,32)
 button.setClick(func(xui.Widget source)
  status.setText("The typed callback ran")
 end)
 auto check=context.checkBoxNative()
 check.setText("Enable feature")
 demo.Gallery.place(root,check,24,180,300,44)
 auto toggle=context.toggleNative()
 toggle.setText("Live preview")
 demo.Gallery.place(root,toggle,24,240,300,44)''')
# Layout tracks are pointer-free native records; this example uses actual table layout.
demo('tablegrid_layout_unused','unused','') if False else None
expected={p.stem for p in(root/'dev/release-materials/sources/legacy-ui-examples-20261105/xui').glob('*.xl')}
assert expected-set(specs)=={'all_controls'},expected-set(specs)
for name,item in specs.items():
 body='\n'.join('  '+line.lstrip()for line in item['body'].splitlines());text='// '+item['title']+'. Run from release/<platform>; Escape or close exits.\nimport xui\nimport "./_support.xl" as demo\n\nexport class '+item['className']+'\n static func build(xui.Context context,xui.Panel root,xui.Proxy proxy)\n  demo.Gallery.label(context,root,"'+item['title']+'",24,16)\n'+body+'\n end\nend\n\nfunc main(...) as int\n return demo.Gallery.run("'+item['title']+'",'+item['className']+'.build)\nend\n';(dest/(name+'.xl')).write_text(text,encoding='utf-8')
items=sorted(specs);text='// Complete control gallery: select a tab; each page is also independently runnable.\nimport xui\nimport "./_support.xl" as demo\n'+''.join('import "./'+name+'.xl" as '+name+'Demo\n'for name in items)+'\nexport class AllControlsExample\n static func build(xui.Context context,xui.Panel root,xui.Proxy proxy)\n  auto tabs=context.tabsNative()\n  demo.Gallery.place(root,tabs,12,12,760,490)\n  tabs.setItems(['+','.join(json.dumps(name)for name in items)+'])\n'
for i,name in enumerate(items):text+='  auto page'+str(i)+'=context.panelNative()\n  '+name+'Demo.'+specs[name]['className']+'.build(context,page'+str(i)+',proxy)\n  assert tabs.addPageChild(c_int('+str(i)+'),page'+str(i)+')==0\n'
text+=' end\nend\nfunc main(...) as int\n return demo.Gallery.run("All controls",AllControlsExample.build)\nend\n';(dest/'all_controls.xl').write_text(text)
(dest/'gallery.json').write_text(json.dumps(dict(schema=1,examples=[dict(name=name,**{k:v for k,v in item.items()if k!='body'})for name,item in sorted(specs.items())]+[dict(name='all_controls',title='Complete control gallery',className='AllControlsExample')],helper='_support.xl',interactive=True,frameLimitEnvironment='XUI_EXAMPLE_FRAMES'),ensure_ascii=False,indent=2)+'\n')
print('WROTE',len(specs)+1,'legacy entrypoints plus shared loop')

from pathlib import Path
import shutil,json
b=Path('/home/ubuntu/xlang-validation/xui-gallery-20261106');out=Path('/mnt/f/xlang-validation/xui-gallery-20261106/linux-evidence');out.mkdir();folders=('compiler-inline-r1','compiler-inline-r2','compiler-inline-r3','production-accept-r1','publication-r2','gallery-cgen-r1','gallery-build-r1','gallery-build-r2','final-alias-and-cpu')
for folder in folders:
 for p in(b/folder).rglob('*'):
  if p.is_file()and p.suffix in('.json','.log','.py','.sh')and not any(part in('source','producer','include','release','rollback','obj')for part in p.relative_to(b/folder).parts):
   target=out/p.relative_to(b);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for relative in ('candidate-cpu.json','publication.json','columns-r1/build.log','columns-r1/build-result.json','columns-r1/host/build-report.json','host/build-report.json'):
 p=b/relative;t=out/relative;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t)
for relative in('production-build.json','compiler-source-identity.json'):
 p=Path('/home/ubuntu/xlang-validation/production-final-linux-r1')/relative;t=out/'parent-production'/relative;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t)
print('linux evidence files',sum(p.is_file()for p in out.rglob('*')))

from pathlib import Path
import re,sys
root=Path('D:/GIT/x-lang');source=root/'lib/bindings/xui/examples'
for p in source.glob('*.xl'):
 if p.stem not in {r['name'] for r in __import__('json').loads((source/'gallery.json').read_text(encoding='utf-8'))['examples']} or p.name=='all_controls.xl':continue
 s=p.read_text(encoding='utf-8');s=re.sub(r'for i in 0\.\.(\d+)',r'for i in range(0,\1)',s)
 for getter in ('getText','getValue'):s=s.replace('assert control.'+getter+'()=="','assert (control.'+getter+'() as string)=="')
 s=s.replace('control.setExpanded(', 'control.setNodeExpanded(')
 s=s.replace('assert control.setValue(c_float(150))==0','control.setValue(c_float(150))')
 s=s.replace('control.openAt(source,c_float(24),c_float(120))','control.setOwner(source)\n  assert control.setOpen(c_int(1))==0')
 for ctor,desc in [('slider','SliderDesc'),('rangeSlider','RangeSliderDesc'),('scrollBar','ScrollbarDesc'),('splitLayout','SplitLayoutDesc'),('scrollView','ScrollViewDesc'),('canvas','CanvasDesc'),('separator','SeparatorDesc')]:s=s.replace('context.'+ctor+'(xui.'+desc+'())','context.'+ctor+'()')
 if p.stem in ('codeedit','textedit','terminal'):
  content={'codeedit':'func main(...) as int\n println("Hello, XUI")\n return 0\nend\n','textedit':'Multiline text editor\nSelect, edit, undo and redo.\nUTF-8: 你好，世界！','terminal':'xlang XUI terminal\r\n\x1b[32mANSI green\x1b[0m\r\nNo shell is started.\r\n'}[p.stem]
  import json
  pattern=r'(assert control\.(?:setText|writeText)\()".*?"(\)(?:==0|>=0))'
  s,n=re.subn(pattern,lambda m:m[1]+json.dumps(content,ensure_ascii=False)+m[2],s,count=1,flags=re.S);assert n==1,p
  s=s.replace('assert control.setWordWrap(c_int(1))==0','control.setWordWrap(c_int(1))')
 if p.stem in ('tableview','tablegrid'):
  code='''array<array<string>> rows=[["Alpha","10"],["Beta","20"],["Gamma","30"]]
  control.setAdapter(func(xui.Widget table) as c_int
   return c_int(rows.length)
  end,func(xui.Widget table,c_int row,c_int column,xui.CallbackTableViewCellOutput cell) as c_int
   cell.setText(rows[int(row)][int(column)])
   return c_int(0)
  end'''
  if p.stem=='tablegrid':code+= ''',func(xui.Widget table,c_int row,c_int column,xui.CString value,c_int type)
   rows[int(row)][int(column)]=value.copy()
  end'''
  code+=')'
  s=s.replace('assert control.getColumnCount()==c_int(2)',code)
 p.write_text(s,encoding='utf-8')
sys.path.insert(0,str(root/'tools'));import xui_gallery_contracts as contracts
for native,method,desc,rollback in [('Slider','slider','slider','Slider'),('RangeSlider','rangeSlider','range_slider','RangeSlider'),('ScrollBar','scrollBar','scrollbar','ScrollBar'),('SplitLayout','splitLayout','split_layout','SplitLayout'),('ScrollView','scrollView','scroll_view','ScrollView'),('Canvas','canvas','canvas','Canvas'),('Separator','separator','separator','Separator')]:
 contracts.METHODS['Context'].append('extern "xui'+native+'Create" @no_raise @c_null(2,"const xui_'+desc+'_desc_t*") @c_result("owner_view",0) @factory(1,0,rollback'+rollback+') func '+method+'() as '+rollback)
p=root/'tools/xui_gallery_contracts.py';t=p.read_text(encoding='utf-8');needle='\ndef extend(context,classes,mapped):';assert needle in t;t=t.replace(needle,'\n# Explicit NULL descriptors select authoritative native defaults.\nMETHODS["Context"] += '+repr(contracts.METHODS['Context'][1:])+'\n'+needle);p.write_text(t)
p=root/'lib/bindings/xui/src/managed.xl';t=p.read_text(encoding='utf-8');start=t.index('export extern "xui_context_t*" class Context ');end=t.index('\nend',start);t=t[:end]+'\n'+'\n'.join(' '+row for row in contracts.METHODS['Context'][1:])+t[end:];p.write_text(t)
for target in ('release/win_x64/extlibs/xui/src/managed.xl','release/linux_x64/extlibs/xui/src/managed.xl','release/win_x64/static/xge3/packages/xui/src/managed.xl'):(root/target).write_bytes(p.read_bytes())

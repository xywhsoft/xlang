#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/ubuntu/xlang-validation/production-final-linux-r1/producer"
BUILD_DIR="/home/ubuntu/xlang-validation/xui-gallery-20261106/compiler-inline-r3"
TCC_SOURCE_DIR="/home/ubuntu/xlang-validation/provider-final-core-linux-r1/producer/lib/tcc"
TCC_DIST_DIR="/home/ubuntu/xlang-validation/provider-final-core-linux-r3/build/linux/tcc-dist"
CC=gcc
PYTHON=python3
TCC_CONFIGURED_TRIPLET="x86_64-linux-gnu"
COMMON_FLAGS=(
    -std=c11
    -D_GNU_SOURCE
    -Wall
    -Wno-pointer-sign
    -Wno-unused-function
    -Wno-unused-variable
    -Wno-unused-but-set-variable
    -Wno-format-truncation
    -O2
    -fPIC
    -ffunction-sections
    -fdata-sections
	-DXL_BUILD_DLL
	-DXL_STATIC_TCC
	-DLIBTCC_AS_DLL
	-DCONFIG_TCC_BUILTIN_VFS=1
    -I"$ROOT"
    -I"$ROOT/release/linux_x64"
    -I"$ROOT/release/linux_x64/include"
    -I"$ROOT/src"
    -I"$ROOT/lib/lzma"
    -I"$TCC_SOURCE_DIR"
)
if [[ -n "$TCC_CONFIGURED_TRIPLET" ]]; then
    COMMON_FLAGS+=("-DXL6_TCC_CONFIGURED_TRIPLET=\"$TCC_CONFIGURED_TRIPLET\"")
fi
SHARED_FLAGS=(-shared -s -Wl,--gc-sections -Wl,-z,defs)
SYSTEM_LIBS=(-pthread -ldl -lm)

TCC_SOURCES=(
    "$TCC_SOURCE_DIR/libtcc.c"
    "$TCC_SOURCE_DIR/tcctools.c"
    "$TCC_SOURCE_DIR/tcc_builtin_vfs.c"
    "$ROOT/lib/lzma/LzmaDec.c"
)
# Share Windows' physical translation-unit list, including its source bundles.
# Capture first so a manifest error cannot be hidden by process substitution.
RUNTIME_SOURCE_TEXT="$("$PYTHON" "$ROOT/tools/runtime_sources.py" --root "$ROOT")"
mapfile -t RUNTIME_SOURCES <<< "$RUNTIME_SOURCE_TEXT"
COMPILER_ONLY_SOURCES=(
    "$ROOT/src/abi/xl6_abi_dump.c"
    "$ROOT/src/ast/xl6_ast_dump.c"
    "$ROOT/src/sem/xl6_sem_index.c"
    "$ROOT/src/ir/xl6_ir_dump.c"
    "$ROOT/src/resource/xl6_win_resource.c"
)

"$CC" "${COMMON_FLAGS[@]}" "${SHARED_FLAGS[@]}" \
    "${RUNTIME_SOURCES[@]}" \
    "${COMPILER_ONLY_SOURCES[@]}" \
    "${TCC_SOURCES[@]}" \
    "$BUILD_DIR/tcc_builtin_resources.c" \
    "${SYSTEM_LIBS[@]}" \
    -Wl,-soname,libxlc.so \
    -o "/home/ubuntu/xlang-validation/xui-gallery-20261106/compiler-inline-r3/libxlc.so"


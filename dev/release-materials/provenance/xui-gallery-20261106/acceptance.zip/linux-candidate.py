
from pathlib import Path
import json,shutil,hashlib,subprocess,os,time
root=Path('/mnt/d/GIT/x-lang');b=Path('/home/ubuntu/xlang-validation/xui-gallery-20261106');p=b/'packages';p.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ('xui','xge','_xge_native'):shutil.copytree(root/'release/linux_x64/extlibs'/name,p/name)
shutil.copy2(root/'lib/bindings/xui/src/managed.xl',p/'xui/src/managed.xl')
for name in ('xge.h','xge_build_config.h'):shutil.copy2(b/'source/include'/name,p/'_xge_native/include'/name)
host=b/'host/libxge3_host.so';shutil.copy2(host,p/'_xge_native/native/libxge3_host.so');manifest=p/'_xge_native/xlang.package.json';m=json.loads(manifest.read_text());print('NATIVE',m.get('native'));m['native']['sha256']=sha(host);manifest.write_text(json.dumps(m,indent=2)+'\n')
env=dict(os.environ,XLANG_PACKAGE_PATH=str(p));rows=[]
for name in ('headless_cell','context_graph','data_object','document_model','document_ui_headless','manager_lifetime'):
 cmd=[str(root/'release/linux_x64/xl'),'run',str(root/'lib/bindings/xui/examples'/(name+'.xl'))];start=time.monotonic();r=subprocess.run(cmd,cwd=root/'release/linux_x64',env=env,capture_output=True,timeout=180);(b/(name+'.log')).write_bytes(r.stdout+r.stderr);rows.append(dict(name=name,exitCode=r.returncode,seconds=time.monotonic()-start));print(name,r.returncode,flush=True)
(b/'candidate-cpu.json').write_text(json.dumps(dict(complete=True,passed=all(x['exitCode']==0 for x in rows),rows=rows,hostSha256=sha(host)),indent=2)+'\n')
if not all(x['exitCode']==0 for x in rows):raise SystemExit(1)
# Publish only a qualified matched host/header cohort; rollback copies stay outside release.
backup=b/'publication-backup';records=[]
for name in ('_xge_native/native/libxge3_host.so','_xge_native/include/xge.h','_xge_native/include/xge_build_config.h','_xge_native/xlang.package.json'):
 source=p/name;target=root/'release/linux_x64/extlibs'/name;old=backup/name;old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,old);shutil.copy2(source,target);records.append(dict(path=str(target),previousSha256=sha(old),sha256=sha(target)))
(b/'publication.json').write_text(json.dumps(dict(complete=True,passed=True,files=records),indent=2)+'\n')

from pathlib import Path
import shutil,subprocess,os,json,hashlib,time
BASE=Path('/mnt/d/GIT/x-lang/build/c-owned-async-fix-20261103');WORK=Path('/var/tmp/xlang-async-fix-20261103');ROOT=WORK/'source'
OLD=Path('/var/tmp/xlang-result-fix-20261102-v2');NATIVE=WORK/'native'
def run(name,args,env=None):
 print(name,flush=True);start=time.monotonic()
 with (BASE/(name+'.log')).open('wb') as log:subprocess.run(list(map(str,args)),cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'passed',round(time.monotonic()-start,1),flush=True)
config=NATIVE/'build/linux/tcc-source';config.mkdir(parents=True)
shutil.copy2(OLD/'native-vfs2/build/linux/tcc-source/config.h',config/'config.h')
dist=NATIVE/'build/linux/tcc-dist';shutil.copytree(OLD/'native-vfs2/build/linux/tcc-dist',dist)
pre=WORK/'precompiled';shutil.copytree(OLD/'precompiled',pre)
cc=shutil.which('gcc');bootstrap=OLD/'tcc-bootstrap'
run('linux-precompile',['python3',ROOT/'tools/precompile_builtin.py','--root',ROOT,'--tcc',bootstrap,'--tcc-dist',dist,'--output',pre,'--native-cc',cc,'--triplet','x86_64-linux-gnu'])
common=['python3',ROOT/'tools/gen_tcc_vfs_resources.py','--root',ROOT,'--tcc-dist',dist,'--xrt-obj',pre/'static-native.o','--pack-tool',OLD/'packer','--precompiled',pre/'manifest.json','--packing-order','family']
resource=WORK/'tcc_builtin_resources.c';runtime=WORK/'tcc_builtin_resources_runtime.c'
run('linux-runtime-resource',[*common,'--manifest','tools/tcc_vfs_manifest_linux_runtime.txt','--output',runtime])
run('linux-compiler-resource',[*common,'--manifest','tools/tcc_vfs_manifest_linux_xlc.txt','--output',resource])
provider=NATIVE/'release/libxlc.so';provider.parent.mkdir()
source=OLD/'native/build/linux/tcc-source'
flags=['-std=c11','-D_GNU_SOURCE','-O2','-fPIC','-DCONFIG_TCC_BUILTIN_VFS=1','-DLIBTCC_AS_DLL','-DCONFIG_TCCDIR="'+str(dist)+'"','-I'+str(source),'-I'+str(ROOT/'lib/lzma')]
command=[cc,*flags,'-shared',source/'libtcc.c',source/'tcctools.c',source/'tcc_builtin_vfs.c',ROOT/'lib/lzma/LzmaDec.c',resource,'-ldl','-lm','-pthread','-o',provider]
run('linux-provider',command)
(WORK/'provider-command.json').write_text(json.dumps(list(map(str,command)),indent=2))
run('linux-driver',['python3',ROOT/'tools/build_xlir_public_source_linux.py','--root',ROOT,'--native-root',NATIVE,'--out',WORK/'driver','--runtime-resource',runtime])
env=dict(os.environ,XL6_SOURCE_NATIVE_ROOT=str(NATIVE))
run('linux-acceptance',['python3',ROOT/'tools/check_extern_owned_string.py','--driver',WORK/'driver/public_source','--directory',WORK/'acceptance'],env)

from pathlib import Path
import shutil,subprocess,hashlib,json
base=Path('/mnt/d/GIT/x-lang/build/c-owned-async-fix-20261103');work=Path('/var/tmp/xlang-async-fix-20261103-final');work.mkdir()
root=work/'source';shutil.copytree('/var/tmp/xlang-result-fix-20261102-v2/source',root)
private=Path('/mnt/c/Users/Administrator/.codex/worktrees/c-owned-string-bytes/x-lang')
for rel in (base/'overlay-paths.txt').read_text().splitlines():
 p=private/rel;t=root/rel;t.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():shutil.copy2(p,t)
 elif t.exists():raise RuntimeError('deleted snapshot source requires explicit handling: '+rel)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={str(p.relative_to(root)):sha(p) for folder in ['src','lib','test','tools','release/include','release/extlibs'] for p in (root/folder).rglob('*') if p.is_file()}
(work/'snapshot.json').write_text(json.dumps(manifest,indent=2))
print('snapshot',root,len(manifest),flush=True)

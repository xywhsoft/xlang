from pathlib import Path
import subprocess,json,os,hashlib,sys
WIN=os.name=='nt';ROOT=Path(sys.argv[1]);driver=Path(sys.argv[2]);out=Path(sys.argv[3]);out.mkdir(exist_ok=False)
base=Path('C:/Users/Administrator/.codex/worktrees/c-owned-string-bytes/x-lang/build/owned-result-review-20261102/cases' if WIN else '/mnt/c/Users/Administrator/.codex/worktrees/c-owned-string-bytes/x-lang/build/owned-result-review-20261102/cases')
env=dict(os.environ)
if not WIN:env.setdefault('XL6_SOURCE_NATIVE_ROOT',str(ROOT.parent/'native'))
rows=[]
for source in sorted(base.glob('*.xl')):
 if source.name.startswith('stored-async-'):continue
 prefix=out/source.stem;exe=prefix.with_suffix('.exe') if WIN else prefix
 for mode in ['emit','run','exe','aot']:
  command=[exe] if mode=='aot' else [driver,source,mode,prefix,'test/cases/extern_owned_bound_c_owners_host.c','test/cases/extern_owned_string_host.c']
  r=subprocess.run(list(map(str,command)),cwd=ROOT,env=env,capture_output=True,timeout=180)
  log=out/(source.stem+'-'+mode+'.log');log.write_bytes(r.stdout+r.stderr)
  rows.append(dict(name=source.stem,mode=mode,exit=r.returncode,logSha256=hashlib.sha256(log.read_bytes()).hexdigest()))
  print(source.stem,mode,r.returncode,flush=True)
  (out/'result.json').write_text(json.dumps(dict(complete=False,rows=rows),indent=2))
  assert r.returncode==0,(source,mode,(r.stdout+r.stderr).decode('utf-8',errors='replace'))
assert len(rows)==164
(out/'result.json').write_text(json.dumps(dict(complete=True,passed=True,driver=str(driver),driverSha256=hashlib.sha256(driver.read_bytes()).hexdigest(),rows=rows,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in base.glob('*.xl') if not p.name.startswith('stored-async-')}),indent=2))

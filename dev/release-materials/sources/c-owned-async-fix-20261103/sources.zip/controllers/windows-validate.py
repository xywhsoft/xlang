from pathlib import Path
import subprocess,shutil,json,time,sys
ROOT=Path('C:/Users/Administrator/.codex/worktrees/c-owned-string-bytes/x-lang');BASE=Path('D:/GIT/x-lang/build/c-owned-async-fix-20261103')
def run(name,args):
 print(name,flush=True);start=time.monotonic()
 with (BASE/(name+'.log')).open('wb') as log:subprocess.run(list(map(str,args)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'passed',round(time.monotonic()-start,1),flush=True)
pre=BASE/'precompiled';shutil.copytree('D:/GIT/x-lang/build/c-owned-fix-result-20261102/precompiled',pre)
run('windows-precompile',[sys.executable,ROOT/'tools/precompile_builtin.py','--root',ROOT,'--tcc','D:/GIT/x-lang/build/c-owned-review-alias-generic-20261102/tcc-bootstrap.exe','--tcc-dist',ROOT/'res/tcc/win64/x86_64','--output',pre])
receipt=BASE/'windows-driver/build.json'
while not receipt.exists() or not json.loads(receipt.read_text(encoding='utf-8-sig')).get('Complete'):time.sleep(2)
run('windows-provider',[sys.executable,ROOT/'tools/stage_source_tcc_provider.py','--base',receipt.parent,'--precompiled',pre,'--out',BASE/'windows-provider'])
run('windows-acceptance',[sys.executable,ROOT/'tools/check_extern_owned_string.py','--driver',BASE/'windows-provider/public_source.exe','--directory',BASE/'windows-acceptance'])

from pathlib import Path
import subprocess,sys,os,json,time
win=os.name=='nt'
base=Path('D:/GIT/x-lang/build/c-owned-async-fix-20261103' if win else '/mnt/d/GIT/x-lang/build/c-owned-async-fix-20261103')
root=Path('C:/Users/Administrator/.codex/worktrees/c-owned-string-bytes/x-lang' if win else '/var/tmp/xlang-async-fix-20261103/source')
cohort=base/'windows-final-provider' if win else Path('/var/tmp/xlang-async-fix-20261103/driver')
receipt=cohort/'build.json'
while True:
 try: ready=json.loads(receipt.read_text(encoding='utf-8-sig')).get('Complete',False)
 except (FileNotFoundError,json.JSONDecodeError):ready=False
 if ready:break
 time.sleep(2)
driver=cohort/('public_source.exe' if win else 'public_source');out=base/('windows-final-matrix' if win else 'linux-matrix');log=base/('windows-final-matrix.log' if win else 'linux-matrix.log')
with log.open('wb') as f:subprocess.run([sys.executable,str(base/'matrix.py'),str(root),str(driver),str(out)],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
print('matrix passed',164,flush=True)

from pathlib import Path
import shutil,subprocess,os,json,hashlib,time,copy
BASE=Path('/mnt/d/GIT/x-lang/build/c-owned-async-fix-20261103');WORK=Path('/var/tmp/xlang-async-fix-20261103-final');ROOT=WORK/'source'
PARENT=Path('/var/tmp/xlang-async-fix-20261103');OLD=Path('/var/tmp/xlang-result-fix-20261102-v2');NATIVE=WORK/'native'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,args,env=None):
 print(name,flush=True);start=time.monotonic()
 with (BASE/(name+'.log')).open('wb') as log:subprocess.run(list(map(str,args)),cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'passed',round(time.monotonic()-start,1),flush=True)
config=NATIVE/'build/linux/tcc-source';config.mkdir(parents=True)
shutil.copy2(OLD/'native-vfs2/build/linux/tcc-source/config.h',config/'config.h')
dist=NATIVE/'build/linux/tcc-dist';shutil.copytree(OLD/'native-vfs2/build/linux/tcc-dist',dist)
pre=WORK/'precompiled';shutil.copytree(PARENT/'precompiled',pre)
cc=shutil.which('gcc');bootstrap=OLD/'tcc-bootstrap'
run('linux-final-precompile',['python3',ROOT/'tools/precompile_builtin.py','--root',ROOT,'--tcc',bootstrap,'--tcc-dist',dist,'--output',pre,'--native-cc',cc,'--triplet','x86_64-linux-gnu'])
common=['python3',ROOT/'tools/gen_tcc_vfs_resources.py','--root',ROOT,'--tcc-dist',dist,'--xrt-obj',pre/'static-native.o','--pack-tool',OLD/'packer','--precompiled',pre/'manifest.json','--packing-order','family']
resource=WORK/'tcc_builtin_resources.c';runtime=WORK/'tcc_builtin_resources_runtime.c'
run('linux-final-runtime-resource',[*common,'--manifest','tools/tcc_vfs_manifest_linux_runtime.txt','--output',runtime])
run('linux-final-compiler-resource',[*common,'--manifest','tools/tcc_vfs_manifest_linux_xlc.txt','--output',resource])
provider=NATIVE/'release/libxlc.so';provider.parent.mkdir()
source=OLD/'native/build/linux/tcc-source'
flags=['-std=c11','-D_GNU_SOURCE','-O2','-fPIC','-DCONFIG_TCC_BUILTIN_VFS=1','-DLIBTCC_AS_DLL','-DCONFIG_TCCDIR="'+str(dist)+'"','-I'+str(source),'-I'+str(ROOT/'lib/lzma')]
command=[cc,*flags,'-shared',source/'libtcc.c',source/'tcctools.c',source/'tcc_builtin_vfs.c',ROOT/'lib/lzma/LzmaDec.c',resource,'-ldl','-lm','-pthread','-o',provider]
run('linux-final-provider',command)
# Reuse immutable source-built objects only after checking the whole parent
# cohort and all current C/header inputs. Only sem.c includes the two changed
# compiler C files; public/runtime headers and every other unit are identical.
oldRoot=PARENT/'source';oldOut=PARENT/'driver';receipt=oldOut/'build.json';original=json.loads(receipt.read_text())
assert original['Complete'] and original['InputsUnchanged'] and original['SourceXrt']
for row in original['Inputs']+original['Objects']+original['Headers']:assert sha(row['Path'])==row['Sha256'].lower(),row['Path']
assert sha(original['Driver'])==original['DriverSha256']
changed=[];compared={}
for folder in ['src','lib']:
 for oldPath in (oldRoot/folder).rglob('*'):
  if not oldPath.is_file() or oldPath.suffix not in ['.c','.h','.inc','.def']:continue
  rel=oldPath.relative_to(oldRoot);newPath=ROOT/rel
  assert newPath.is_file(),rel
  if oldPath.read_bytes()!=newPath.read_bytes():changed.append(rel.as_posix())
  compared[rel.as_posix()]=sha(newPath)
assert sorted(changed)==['src/sem/xl6_sem.c','src/sem/xl6_sem_c_owned.c'],changed
out=WORK/'driver';out.mkdir();shutil.copytree(oldOut/'include',out/'include')
report=copy.deepcopy(original);report.update(Complete=False,InputsUnchanged=False)
for row in report['Headers']:
 path=Path(row['Path']);row['Path']=str(out/path.relative_to(oldOut))
 if Path(row['Source']).is_relative_to(oldRoot):
  newSource=ROOT/Path(row['Source']).relative_to(oldRoot)
  shutil.copy2(newSource,row['Path']);row.update(Source=str(newSource),Sha256=sha(newSource))
# The mirrored runtime resource belongs to this actual provider's cohort.
for row in report['Headers']:
 if row['Path'].endswith('/tcc_builtin_resources_runtime.c'):
  shutil.copy2(runtime,row['Path']);row.update(Source=str(runtime),Sha256=sha(runtime))
sem=next(r for r in report['Objects'] if Path(r['Source']).name=='xl6_sem.c')
command=next(r['Command'] for r in original['Rows'] if r['Name']=='xl6_sem')
command=[v.replace(str(oldRoot),str(ROOT)).replace(str(oldOut),str(out)) for v in command]
run('linux-final-sem',command);sem.update(Path=str(out/'xl6_sem.o'),Source=str(ROOT/'src/sem/xl6_sem.c'),Sha256=sha(out/'xl6_sem.o'))
driver=out/'public_source'
link=[cc,*[r['Path'] for r in report['Objects']],'-L'+str(provider.parent),'-lxlc','-Wl,-rpath,'+str(provider.parent),'-Wl,--export-dynamic','-pthread','-ldl','-lm','-o',driver]
run('linux-final-driver-link',link)
files={Path(__file__).resolve(),ROOT/'tools/build_xlir_public_source_linux.py',provider,config/'config.h',receipt,runtime,resource,pre/'manifest.json'}
for folder in ['src','lib','res/tcc','release/include','release/extlibs']:
 files.update(p for p in (ROOT/folder).rglob('*') if p.is_file())
report['Inputs'] += [dict(Path=str(p),Sha256=sha(p)) for p in sorted(files)]
report.update(Driver=str(driver),DriverSha256=sha(driver),NativeRoot=str(NATIVE),TccCore=str(provider),TccCoreSha256=sha(provider),RuntimeLibrary=str(provider),
 ParentBuild=str(receipt),ParentBuildSha256=sha(receipt),CurrentSourceRoot=str(ROOT),RecompiledSources=['src/sem/xl6_sem.c'],ReusedSourceObjects=1408,
 SourceReuseProof=dict(compared=compared,changedInputs=changed,includes='src/sem/xl6_sem.c is the only includer of xl6_sem_c_owned.c'),
 IncrementalBuild=True,IncrementalCompileCommand=command,IncrementalLinkCommand=list(map(str,link)),ProviderBuildCommand=list(map(str,command)),
 Scope='Verified source cohort: 1409 units, 1408 immutable objects reused after complete input comparison; sem.c recompiled with its recorded canonical flags. Current independently rebuilt TinyCC/VFS provider; no shipping library certification.')
report['InputsUnchanged']=all(sha(r['Path'])==r['Sha256'].lower() for r in report['Inputs']+report['Objects']+report['Headers']);assert report['InputsUnchanged']
report['Complete']=True;(out/'build.json').write_text(json.dumps(report,indent=2))
env=dict(os.environ,XL6_SOURCE_NATIVE_ROOT=str(NATIVE))
run('linux-final-acceptance',['python3',ROOT/'tools/check_extern_owned_string.py','--driver',driver,'--directory',WORK/'acceptance'],env)
run('linux-final-matrix',['python3',BASE/'matrix.py',ROOT,driver,BASE/'linux-final-matrix'],env)

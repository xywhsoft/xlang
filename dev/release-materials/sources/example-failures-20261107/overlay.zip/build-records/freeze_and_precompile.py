from pathlib import Path
import shutil,json,hashlib,subprocess
r=Path('D:/GIT/x-lang');out=r/'build/example-failure-audit';base=r/'build/compiler-rebuild-20261106/latest-source';f=out/'final2-source'
for folder in ['src','lib','res','tools','release/win_x64/include','release/win_x64/extlibs/xacme']:
 shutil.copytree(base/folder,f/folder,dirs_exist_ok=True)
owned=['src/ir/xl6_ir.c','src/ir/xl6_ir_lower.c','src/ir/xl6_ir_log_bridge.c','src/ir/xl6_ir_direct_bridge_declarations.inc','src/ir/xl6_ir_direct_bridge_data.inc','src/runtime/xl6_foreign_net.c','src/runtime/xl6_foreign_tcp.c','src/compile/xl6_artifact_runtime.h','src/compile/xl6_compile_unit.c','src/runtime/xl6_foreign_resource.h','src/runtime/xl6_text_symbols.inc','src/cgen/xl6_ir_cgen_export_callback.c','src/cgen/xl6_ir_cgen_module_emit.c','src/stdlib/xl6_stdlib_data.c']
for rel in owned:shutil.copy2(r/rel,f/rel)
sdk=f/'release/win_x64/include';shutil.copy2(r/'release/win_x64/include/xl_foreign_net.h',sdk/'xl_foreign_net.h')
# Matched private copies used by compiler embedding and source-only hosts.
for rel in owned:
 p=f/rel
 if p.suffix=='.h':
  for target in [sdk/'__xl_runtime'/p.name,sdk/'__xl_compiler'/rel]:
   if target.parent.exists():shutil.copy2(p,target)
for target in [sdk/'__xl_compiler/include/xl_foreign_net.h',sdk/'__xl_runtime/xl_foreign_net.h']:shutil.copy2(sdk/'xl_foreign_net.h',target)
(f/'build/tmp').mkdir(parents=True,exist_ok=True)
for name in ['tcc_bootstrap.exe','tcc_vfs_lzma_pack.exe','xrt.o']:shutil.copy2(base/'build/tmp'/name,f/'build/tmp'/name)
(out/'owned-core.json').write_text(json.dumps({rel:hashlib.sha256((f/rel).read_bytes()).hexdigest()for rel in owned},indent=2))
print('Frozen source cohort',f,flush=True)
cmd=['python',str(f/'tools/precompile_builtin.py'),'--root',str(f),'--tcc',str(f/'build/tmp/tcc_bootstrap.exe'),'--tcc-dist',str(f/'res/tcc/win64/x86_64'),'--output',str(out/'final2-precompiled')]
with (out/'final2-precompile.log').open('wb')as log:
 v=subprocess.run(cmd,cwd=f,stdout=log,stderr=subprocess.STDOUT)
assert not v.returncode,(out/'final2-precompile.log').read_text(encoding='utf-8',errors='replace')[-4000:]
print('Windows serialized objects complete',flush=True)

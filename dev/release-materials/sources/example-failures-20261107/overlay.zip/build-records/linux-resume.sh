#!/bin/bash
set -euo pipefail
base=/root/.codex-builds/xlang-example-runtime-20261106-1958
dest=/root/.codex-builds/xlang-example-audit-20261107
for name in test docs dev; do if test -d "$base/$name"; then cp -a "$base/$name" "$dest/"; fi; done
find "$base" -maxdepth 1 -type f -exec cp -t "$dest" {} +
cp /mnt/d/GIT/x-lang/build_linux.sh "$dest/build_linux.sh"
cd "$dest"
JOBS=2 bash build_linux.sh > /mnt/d/GIT/x-lang/build/example-failure-audit/linux-build.log 2>&1

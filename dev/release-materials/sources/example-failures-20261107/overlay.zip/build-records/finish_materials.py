from pathlib import Path
import datetime, hashlib, importlib.util, json, shutil, subprocess, zipfile

root = Path(__file__).resolve().parents[2]
scratch = root / 'build/example-failure-audit'
tag = 'example-failures-20261107'
sources = root / 'dev/release-materials/sources' / tag
provenance = root / 'dev/release-materials/provenance' / tag
sources.mkdir(exist_ok=False)
provenance.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
def describe(path):
    return dict(path=path.relative_to(root).as_posix(), sha256=sha(path), bytes=path.stat().st_size)

revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
owned = json.loads((scratch/'owned-core.json').read_text())
spec = importlib.util.spec_from_file_location('cases', root/'tools/check_example_failure_regressions.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
overlay = {}
categories = {}
def add(source, name=None, category='support'):
    assert source.is_file(), source
    name = name or source.relative_to(root).as_posix()
    overlay[name] = source
    categories[name] = category

for rel, digest in owned.items():
    path = scratch/'final2-source'/rel
    assert sha(path) == digest, rel
    add(path, rel, 'compiled-core')
for rel in ['tools/compiler_dll.rsp.in', 'tools/runtime_dll.rsp.in', 'build_dll.bat',
            'build_linux.sh', 'tools/check_example_failure_regressions.py',
            'tools/check_xge3_bindings.py', 'tools/run_game_examples.ps1',
            'docs/reports/example-failures-20261107.md',
            'test/cases/xlir_destroy_receiver_borrow.xl',
            'test/cases/xlir_nested_array_append_context.xl',
            'test/cases/cgen_destroy_field_assignment.xl']:
    add(root/rel)
sdk_rels = ['xl_foreign_net.h', '__xl_compiler/include/xl_foreign_net.h',
            '__xl_runtime/xl_foreign_net.h', '__xl_compiler/src/compile/xl6_artifact_runtime.h',
            '__xl_compiler/src/runtime/xl6_foreign_resource.h', '__xl_runtime/xl6_foreign_resource.h']
for platform in ['win_x64', 'linux_x64']:
    for rel in sdk_rels:
        add(root/'release'/platform/'include'/rel, category='matched-sdk')
for path in (root/'lib/bindings/xge').rglob('*'):
    if path.is_file():
        add(path, category='canonical-xge-binding')
packages = json.loads((scratch/'linux-source-packages.json').read_text())['packages']
excluded_dirs = {'.git', '.xlang-ide', '__pycache__', 'build', 'out', '.cache'}
excluded_suffixes = {'.exe', '.dll', '.so', '.o', '.obj', '.a', '.lib', '.pdb', '.pyc', '.tmp'}
for package in packages:
    folder = root/'release/win_x64/extlibs'/package
    for path in folder.rglob('*'):
        if (path.is_file() and not excluded_dirs.intersection(path.relative_to(folder).parts)
                and path.suffix.lower() not in excluded_suffixes):
            add(path, category='validated-portable-package-source')
for case in module.CASES:
    add(root/'release/win_x64/examples'/(case+'.xl'), category='reported-example')
for path in (root/'release/win_x64/examples/games').rglob('*'):
    if path.is_file() and (path.name in ['_game.xl','README.md','run_games.bat'] or path.parent.name == 'assets'):
        add(path, category='game-support')
for platform in ['win_x64', 'linux_x64']:
    folder = root/'release'/platform/'extlibs/xge'
    if folder.is_dir():
        for path in folder.rglob('*'):
            if path.is_file() and path.suffix.lower() not in excluded_suffixes:
                add(path, category='delivered-xge-binding')
for name in ['freeze_and_precompile.py','final_windows_build.py','final_windows_delta.py',
             'linux-build.sh','linux-resume.sh','stage_linux_cases.py','capture_linux_records.py',
             'installed-linux-smoke.sh','socks-boundary.xl']:
    add(scratch/name, 'build-records/'+name)
add(scratch/'final-xge-preserve-init/init.xl', 'build-records/xge-init-forms.xl')
add(Path(__file__), 'build-records/finish_materials.py')

entries = []
with zipfile.ZipFile(sources/'overlay.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(overlay.items()):
        archive.write(path, name)
        entries.append(dict(path=name, sha256=sha(path), bytes=path.stat().st_size, category=categories[name]))
write(sources/'entries.json', entries)
parent = root/'dev/release-materials/sources/compiler-rebuild-20261106/manifest.json'
write(sources/'manifest.json', dict(
    schema=1, date='2026-11-07', sourceRevision=revision,
    parentSourceMaterials=describe(parent), overlay=describe(sources/'overlay.zip'),
    entries=describe(sources/'entries.json'), ownedCompiledSources=owned,
    portableSourcePackages=packages,
    reconstruction='Reconstruct the parent source manifest, then extract overlay.zip over it. '
                   'The 33 portable package source trees supply the isolated Linux example cohort; '
                   'normal Linux delivery still contains only its original selected packages. '
                   'Build records preserve historical absolute cache paths; regenerate objects/VFS when rebuilding elsewhere.',
    sourceBoundary='Compiled src files are the frozen qualified cohort plus the listed owned sources. '
                   'Concurrent uncommitted semantic and IDE changes were excluded. Package snapshots include unchanged dependencies, '
                   'not just authored edits. No binaries are included in this source overlay.',
    optimization='-O2', windowsIncremental=True, linuxFullProductionBuild=True))

# Copy raw evidence without changing embedded historical paths or failed results.
for folder in ['final-win-r2-acceptance','final-linux-r2-acceptance','modbus-portable-win',
               'modbus-portable-linux','final-xge-preserve-init','installed-smoke',
               'installed-smoke-r2','installed-smoke-r3','linux-build-records']:
    for path in (scratch/folder).rglob('*'):
        if path.is_file() and path.suffix.lower() in ['.log','.json']:
            destination = provenance/'evidence'/path.relative_to(scratch)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
for name in ['installed-products.json','owned-core.json','wire-migration.json',
             'shipping-sources-final.json','reconstruction-core-check.json',
             'linux-build.log','linux-build-r2.log',
             *['csv-'+case+'-'+mode+'.log' for case in ['global_lifecycle','boundaries','files','bom_values'] for mode in ['jit','aot']]]:
    shutil.copy2(scratch/name, provenance/name)
for name in ['games/jit-results.json','games/static-imports.json',
             'final-win/build.json','final-win/objects.json','final-win/runtime.rsp','final-win/compiler.rsp',
             'final-win-r2/build.json','final-win-r2/runtime.rsp','final-win-r2/compiler.rsp',
             'final2-precompiled/manifest.json']:
    destination = provenance/'build-records'/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(scratch/name, destination)

win = json.loads((scratch/'final-win-r2-acceptance/report.json').read_text())
linux = json.loads((scratch/'final-linux-r2-acceptance/report.json').read_text())
linux_delta = json.loads((scratch/'modbus-portable-linux/report.json').read_text())
win_delta = json.loads((scratch/'modbus-portable-win/report.json').read_text())
games = json.loads((scratch/'final-xge-preserve-init/report.json').read_text())
linux_cases = {row['name']: row['passed'] for row in linux['rows']}
linux_cases.update({row['name']: row['passed'] for row in linux_delta['rows']})
assert win['passed'] and win_delta['passed'] and games['passed']
assert len(linux_cases) == 35 and all(linux_cases.values())
assert all(row['passed'] for row in linux['core'])
assert json.loads((scratch/'installed-smoke-r3/report.json').read_text())['passed']
assert all(row['exitCode']==0 for row in json.loads((scratch/'installed-smoke/report.json').read_text())['rows'][:3])
installed = json.loads((scratch/'installed-products.json').read_text())
for product in installed['products']:
    assert sha(root/product['path']) == product['sha256'], product['path']
write(provenance/'summary.json', dict(
    schema=1, passed=True, reportedExamples=44, windowsExamples=44, linuxNonGuiExamples=35,
    windowsCheckAotAndRun=True, windowsNonGuiJit=35, windowsGamesJitAndStaticAot=9,
    gameFrameBudget=3, coreCasesPerPlatform=3, csvWindowsJitAotGroups=4,
    xgeInitFormsWindowsJitAot=True, socksMaximumLegalInputsWindowsAndLinuxJitAot=True,
    linuxAggregateCases=linux_cases,
    linuxEvidence='Initial batch passed 34 of 35; Modbus LP64 mismatch corrected and targeted JIT/AOT passed. Original failed report is preserved.',
    installedSmoke='Windows CSV/log/lifecycle; Linux version and two core cases; installed hashes equal qualified products.',
    harnessCorrections='Two initial installed Linux smoke attempts stopped at copy paths/missing test directory, before execution; corrected third attempt passed.',
    limits=['Redis excluded by user.', 'No external service/security/attack tests.',
            'Cloud live example verified only credential-free exit 2; no service request.',
            'Game checks create actual windows and run three frames, not full manual gameplay acceptance.',
            'No whole-project regression/certification.', 'This update is local only.']))

index = root/'dev/release-materials/provenance/current-delivery.json'
shutil.copy2(index, provenance/'previous-delivery.json')
evidence = [describe(path) for path in sorted(provenance.rglob('*')) if path.is_file()]
write(provenance/'evidence-index.json', evidence)
receipt = dict(schema=1, date='2026-11-07', passed=True, sourceRevision=revision,
               implementationRevisions=['7c659c492','9213f2a90'],
               sourceMaterials=describe(sources/'manifest.json'),
               acceptance=describe(provenance/'summary.json'), evidence=describe(provenance/'evidence-index.json'),
               products=installed['products'], optimization='-O2', publication='local-only',
               buildScope='Specified 44 example failures plus focused lifecycle, container, CSV, native TCP, XGE and legal-size formatting checks; concurrent semantic/IDE work excluded.',
               windowsBuild='Reused hash-verified qualified runtime/vendor objects; rebuilt project compiler/IR/Cgen TUs, affected native runtime TUs, serialized objects and VFS resources.',
               linuxBuild='Full O2 production source builds with matched TinyCC serialized objects and VFS; targeted Modbus LP64 correction is package-source-only.',
               remainingWithinRequestedScope=[])
write(provenance/'receipt.json', receipt)

# Read mutable index only after all artifact checks pass; preserve other owners' fields.
delivery = json.loads(index.read_text(encoding='utf-8-sig'))
previous_compiler = dict(delivery.get('compiler',{}))
compiler = delivery.setdefault('compiler',{})
compiler.update(sourceRevision=revision, currentBuildProvenance=describe(provenance/'receipt.json')['path'],
                sourceMaterials=describe(sources/'manifest.json'), rebuiltThisDelivery=True,
                entireAcceptanceRerunThisDelivery=False, reusedQualifiedProducts=True,
                optimization='-O2', buildScope=receipt['buildScope'],
                previousDelivery=describe(provenance/'previous-delivery.json'))
delivery['exampleFailureRepairs'] = dict(receipt=describe(provenance/'receipt.json'),
                                       acceptance=describe(provenance/'summary.json'),
                                       sourceMaterials=describe(sources/'manifest.json'),
                                       previousCompilerBuild=previous_compiler, publication='local-only')
for product in installed['products']:
    target = next((row for row in delivery['products'] if row['path']==product['path']), None)
    if target is None:
        target = dict(path=product['path']); delivery['products'].append(target)
    target.update(sha256=product['sha256'], bytes=product['bytes'], origin=tag, previousSha256=product['oldSha256'])
write(index, delivery)
(provenance/'README.md').write_text(
    '# 范例失败修复验收\n\n本轮单人完成指定的 44 个范例修复；Redis 排除。\n\n'
    '- Windows：44 个 check/AOT 构建及运行通过，非图形 35 个 JIT 通过；9 个游戏另经 JIT/静态 AOT 三帧运行。\n'
    '- Linux：35 个非图形范例通过；批量结果中的 Modbus LP64 问题修正后定点复测，保留原失败报告。\n'
    '- 核心：两端各 3 项；CSV 四组 Windows JIT/AOT；Socks 合法最大长度两端 JIT/AOT；XGE 两种初始化入口 Windows JIT/AOT。\n'
    '- 发布：本地 Windows/Linux 编译器、配套头文件和扩展源码已更新；IDE/XGE DLL 未在本轮重建；未执行外部发布。\n'
    '- 边界：云端 live 范例仅验无凭据退出；游戏仅验三帧运行；未执行全项目回归或安全专项。\n\n'
    'receipt.json 记录产品哈希和源码材料；summary.json 为聚合结论；evidence-index.json 索引原始证据。'
    '证据保留原报告字节及历史 scratch 路径；源码增量和验证依赖位于对应 sources 目录。\n', encoding='utf-8')
print(json.dumps(dict(sourceFiles=len(entries), sourceBytes=(sources/'overlay.zip').stat().st_size,
                      receipt=str(provenance/'receipt.json'), passed=True), ensure_ascii=False))

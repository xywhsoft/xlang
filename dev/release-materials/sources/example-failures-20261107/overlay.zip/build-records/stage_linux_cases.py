from pathlib import Path
import json,re,shutil,sys
repo=Path("/mnt/d/GIT/x-lang");win=repo/"release/win_x64";dst=Path("/root/.codex-builds/xlang-example-audit-20261107/release/linux_x64")
sys.path.insert(0,str(repo/"tools"));from check_example_failure_regressions import CASES
sources=[name for name in CASES if not name.startswith("games/")]
for name in sources:
 target=dst/"examples"/(name+".xl");target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(win/"examples"/(name+".xl"),target)
packages={}
for folder in (win/"extlibs").iterdir():
 p=folder/"xlang.package.json"
 if p.is_file():
  d=json.loads(p.read_text(encoding="utf-8-sig"));packages[d["name"]]=(folder,d)
needed=set();todo=[]
for name in sources:
 text=(dst/"examples"/(name+".xl")).read_text(encoding="utf-8-sig")
 todo += re.findall(r"^\s*(?:import|from)\s+([A-Za-z_][A-Za-z_0-9.]*)",text,re.M)
while todo:
 name=todo.pop()
 if name in needed or name not in packages:continue
 needed.add(name);folder,data=packages[name]
 todo += [v["name"]for v in data.get("dependencies",[])]
 shutil.copytree(folder,dst/"extlibs"/folder.name,dirs_exist_ok=True)
(repo/"build/example-failure-audit/linux-source-packages.json").write_text(json.dumps(dict(runtime=str(dst),source="Windows portable source packages; no Windows native binaries used",packages=sorted(needed)),indent=2))
print("Staged",len(needed),"source packages",flush=True)

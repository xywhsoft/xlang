from pathlib import Path
import json,subprocess,shutil,hashlib,concurrent.futures
r=Path('D:/GIT/x-lang');o=r/'build/example-failure-audit';s=o/'final2-source';parent=json.loads((o/'final-win/build.json').read_text());cc='E:/software/w64devkit/bin/gcc.exe';out=o/'final-win-r2';out.mkdir(exist_ok=True);rt=out/'runtime';rt.mkdir(exist_ok=True);mapping={};rows=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
shutil.copy2(o/'final2-precompiled/manifest.json',out/'previous-serialized-manifest.json')
v=subprocess.run(['python',str(s/'tools/precompile_builtin.py'),'--root',str(s),'--tcc',str(s/'build/tmp/tcc_bootstrap.exe'),'--tcc-dist',str(s/'res/tcc/win64/x86_64'),'--output',str(o/'final2-precompiled')],cwd=s,capture_output=True);(out/'precompile.log').write_bytes(v.stdout+v.stderr);assert not v.returncode,v.stderr[-1800:];print('Refreshed serialized objects',flush=True)
for profile,file in [('runtime','tcc_builtin_resources_runtime.c'),('xlc','tcc_builtin_resources.c')]:
 v=subprocess.run(['python',str(s/'tools/gen_tcc_vfs_resources.py'),'--root',str(s),'--manifest',str(s/f'tools/tcc_vfs_manifest_win64_{profile}.txt'),'--output',str(out/file),'--tcc-dist',str(s/'res/tcc/win64/x86_64'),'--xrt-obj',str(s/'build/tmp/xrt.o'),'--pack-tool',str(s/'build/tmp/tcc_vfs_lzma_pack.exe'),'--precompiled',str(o/'final2-precompiled/manifest.json')],cwd=s,capture_output=True);(out/f'resource-{profile}.log').write_bytes(v.stdout+v.stderr);assert not v.returncode,v.stderr[-1800:]
jobs=[]
for row in parent['rows']:
 rel=row['source'];name=Path(rel).name
 if name not in ['xl6_compile_unit.c','tcc_builtin_resources_runtime.c','tcc_builtin_resources.c']:continue
 target=out/(row['profile']+'-'+name+'.o');cmd=list(row['command']);cmd[cmd.index('-o')+1]=str(target);cmd[cmd.index('-c')+1]=str(s/rel)if(s/rel).is_file()else str(out/name);jobs.append((row,cmd,target));mapping[str(Path(row['object'])).replace('\\','/')]=str(target).replace('\\','/')
def compile(job):
 old,cmd,target=job;v=subprocess.run(cmd,cwd=s,capture_output=True);(out/(target.name+'.log')).write_bytes(v.stdout+v.stderr);assert not v.returncode,v.stderr[-1800:];return dict(profile=old['profile'],source=old['source'],command=cmd,object=str(target),sha256=sha(target))
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as x:rows=list(x.map(compile,jobs))
links=[]
for link in parent['links']:
 text=Path(link['response']).read_text()
 for before,after in mapping.items():text=text.replace('"'+before+'"','"'+after+'"')
 target=rt/Path(link['output']).name;text=text.replace('"'+link['output'].replace('\\','/')+'"','"'+str(target).replace('\\','/')+'"');rsp=out/(link['profile']+'.rsp');rsp.write_text(text);v=subprocess.run([cc,'@'+str(rsp)],cwd=s,capture_output=True);(out/(link['profile']+'-link.log')).write_bytes(v.stdout+v.stderr);assert not v.returncode,v.stderr[-1800:];links.append(dict(profile=link['profile'],output=str(target),sha256=sha(target),bytes=target.stat().st_size,response=str(rsp)));print('Linked',target.name,flush=True)
shutil.copy2(o/'final-win/runtime/xl.exe',rt/'xl.exe');(out/'build.json').write_text(json.dumps(dict(passed=True,parent=str(o/'final-win/build.json'),sourceRoot=str(s),rows=rows,links=links),indent=2))

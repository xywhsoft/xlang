#!/bin/bash
set -euo pipefail
repo=/mnt/d/GIT/x-lang
cohort=/root/.codex-builds/xlang-example-audit-20261107
mkdir -p "$cohort/release/linux_x64/extlibs/socks/test"
for rel in socks_native.c test/bytes_boundaries.xl xlang.package.json; do
  cp "$repo/release/win_x64/extlibs/socks/$rel" "$cohort/release/linux_x64/extlibs/socks/$rel"
done
cd "$cohort"
rt="$cohort/release/linux_x64"
"$rt/xl" run "$rt/extlibs/socks/test/bytes_boundaries.xl"
"$rt/xl" build "$rt/extlibs/socks/test/bytes_boundaries.xl" -o "$repo/build/example-failure-audit/installed-smoke/socks-linux"
"$repo/build/example-failure-audit/installed-smoke/socks-linux"
cd "$repo"
rt="$repo/release/linux_x64"
export LD_LIBRARY_PATH="$rt${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
"$rt/xl" --version
"$rt/xl" run "$repo/test/cases/xlir_destroy_receiver_borrow.xl"
"$rt/xl" run "$repo/test/cases/xlir_nested_array_append_context.xl"

from pathlib import Path
import json,hashlib,shutil
r=Path('/mnt/d/GIT/x-lang');b=r/'build/example-failure-audit';p=Path('/root/.codex-builds/xlang-example-audit-20261107');out=b/'linux-build-records'
for rel in ['build/linux/precompiled/manifest.json','build/linux/tcc_builtin_resources.c.stamp.json','build/linux/tcc_builtin_resources_runtime.c.stamp.json','build/linux/ir-contract-catalog/summary.json']:
 source=p/rel;dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
rows=[]
for rel,want in json.loads((b/'owned-core.json').read_text()).items():
 source=p/rel;digest=hashlib.sha256(source.read_bytes()).hexdigest();assert digest==want,(rel,digest,want);rows.append(dict(path=rel,sha256=digest,bytes=source.stat().st_size))
(out/'source-cohort.json').write_text(json.dumps(dict(sourceRoot=str(p),ownedSources=rows,allOwnedSourcesMatch=True),indent=2))

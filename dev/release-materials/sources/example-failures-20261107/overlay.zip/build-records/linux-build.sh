#!/bin/bash
set -euo pipefail
base=/root/.codex-builds/xlang-example-runtime-20261106-1958
root=/root/.codex-builds/xlang-example-audit-20261107
repo=/mnt/d/GIT/x-lang
test ! -e "$root"
mkdir -p "$root"
for name in src lib tools res release; do cp -a "$base/$name" "$root/$name"; done
cp "$repo/build_linux.sh" "$root/build_linux.sh"
python3 - <<'PY'
from pathlib import Path
import json,shutil
r=Path('/mnt/d/GIT/x-lang');out=r/'build/example-failure-audit';f=out/'final2-source';d=Path('/root/.codex-builds/xlang-example-audit-20261107')
for rel in json.loads((out/'owned-core.json').read_text()):shutil.copy2(f/rel,d/rel)
sdk=d/'release/linux_x64/include';shutil.copy2(f/'release/win_x64/include/xl_foreign_net.h',sdk/'xl_foreign_net.h')
for rel in ['src/runtime/xl6_foreign_resource.h','src/compile/xl6_artifact_runtime.h']:
 source=d/rel
 for p in [sdk/'__xl_runtime'/source.name,sdk/'__xl_compiler'/rel]:
  if p.parent.exists():shutil.copy2(source,p)
for p in [sdk/'__xl_compiler/include/xl_foreign_net.h',sdk/'__xl_runtime/xl_foreign_net.h']:shutil.copy2(sdk/'xl_foreign_net.h',p)
PY
cd "$root"
JOBS=2 bash build_linux.sh > "$repo/build/example-failure-audit/linux-build.log" 2>&1
printf 'Linux source build complete\n'

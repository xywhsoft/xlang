from pathlib import Path
import json,subprocess,hashlib,shutil,concurrent.futures,time
r=Path('D:/GIT/x-lang');o=r/'build/example-failure-audit';s=o/'final2-source';old=json.loads((r/'build/native-default-20261106/final-build.json').read_text());live=json.loads((r/'build/compiler-rebuild-20261106/latest-build.json').read_text());orig=json.loads((r/'build/example-runtime-fixes-20261106/native-final/build.json').read_text());cc=old['compiler'];out=o/'final-win';out.mkdir(exist_ok=True);rt=out/'runtime';rt.mkdir(exist_ok=True);rows=[];mapping={};named={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for row in old['units']+old['commonUnits']:assert sha(row['object'])==row['sha256'],row['object']
print('Verified inherited object hashes',flush=True)
for profile,file in [('runtime','tcc_builtin_resources_runtime.c'),('xlc','tcc_builtin_resources.c')]:
 cmd=['python',str(s/'tools/gen_tcc_vfs_resources.py'),'--root',str(s),'--manifest',str(s/f'tools/tcc_vfs_manifest_win64_{profile}.txt'),'--output',str(out/file),'--tcc-dist',str(s/'res/tcc/win64/x86_64'),'--xrt-obj',str(s/'build/tmp/xrt.o'),'--pack-tool',str(s/'build/tmp/tcc_vfs_lzma_pack.exe'),'--precompiled',str(o/'final2-precompiled/manifest.json')]
 v=subprocess.run(cmd,cwd=s,capture_output=True);(out/f'resource-{profile}.log').write_bytes(v.stdout+v.stderr);assert not v.returncode,v.stderr[-2500:];print('Packed',profile,flush=True)
def relative(row):
 text=str(row['source']).replace('\\','/');return text[text.index('src/'):]if'src/'in text else None
def flags(row):
 command=row.get('command')
 if not command:
  idx=int(Path(row['object']).stem);source=list(orig['profiles'][row['profile']]['objects'])[idx];command=next(v['command']for v in orig['units']if v['source']==source and v['profile']==row['profile'])
 return command[1:command.index('-c')]
jobs=[]
for row in old['units']:
 rel=relative(row)
 if rel is None or (rel.startswith('src/runtime/') and Path(rel).name not in ['xl6_foreign_net.c']):continue
 target=out/(row['profile']+'-'+Path(rel).name+'.o');cmd=[cc,'-I'+str(s),'-I'+str(s/'release/win_x64/include'),*flags(row),'-c',str(s/rel),'-o',str(target)];jobs.append((row['profile'],rel,target,cmd));mapping[str(Path(row['object'])).replace('\\','/')]=str(target).replace('\\','/');named[(row['profile'],Path(rel).name)]=target
for profile in ['runtime','compiler']:
 template=next(row for row in old['units']if row['profile']==profile and relative(row)=='src/runtime/xl6_foreign_net.c');target=out/(profile+'-xl6_foreign_tcp.c.o');cmd=[cc,'-I'+str(s),'-I'+str(s/'release/win_x64/include'),*flags(template),'-c',str(s/'src/runtime/xl6_foreign_tcp.c'),'-o',str(target)];jobs.append((profile,'src/runtime/xl6_foreign_tcp.c',target,cmd));named[(profile,'xl6_foreign_tcp.c')]=target
for row in live['rebuilt']:
 name=Path(row['source']).name;key=(row['profile'],name)
 if name.startswith('tcc_builtin_resources'):
  target=out/(row['profile']+'-'+name+'.o');command=row['command'];cmd=[cc,'-I'+str(s),'-I'+str(s/'release/win_x64/include'),*command[1:command.index('-c')],'-c',str(out/name),'-o',str(target)];jobs.append((row['profile'],name,target,cmd));named[key]=target
 if key in named:mapping[str(Path(row['object'])).replace('\\','/')]=str(named[key]).replace('\\','/')
def compile(job):
 profile,rel,target,cmd=job;t=time.monotonic();v=subprocess.run(cmd,cwd=s,capture_output=True);(out/(target.name+'.log')).write_bytes(v.stdout+v.stderr);row=dict(profile=profile,source=rel,sourceSha256=sha(s/rel)if(s/rel).exists()else sha(out/rel),object=str(target),command=cmd,exitCode=v.returncode,seconds=round(time.monotonic()-t,3));
 if not v.returncode:row['sha256']=sha(target)
 print(profile,Path(rel).name,v.returncode,flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(compile,jobs))
(out/'objects.json').write_text(json.dumps(rows,indent=2));assert all(not v['exitCode']for v in rows),[v['object']for v in rows if v['exitCode']]
links=[]
for link in live['links']:
 text=Path(link['response']).read_text()
 for before,after in mapping.items():text=text.replace('"'+before+'"','"'+after+'"')
 oldout=link['output'].replace('\\','/');target=rt/Path(oldout).name;text=text.replace('"'+oldout+'"','"'+str(target).replace('\\','/')+'"');new=str(named[(link['profile'],'xl6_foreign_tcp.c')]).replace('\\','/');text+='\n"'+new+'"\n';rsp=out/(link['profile']+'.rsp');rsp.write_text(text)
 v=subprocess.run([cc,'@'+str(rsp)],cwd=s,capture_output=True);(out/(link['profile']+'-link.log')).write_bytes(v.stdout+v.stderr);assert not v.returncode,v.stderr[-3000:];links.append(dict(profile=link['profile'],output=str(target),bytes=target.stat().st_size,sha256=sha(target),response=str(rsp)));print('Linked',target.name,flush=True)
shutil.copy2(r/'release/win_x64/xl.exe',rt/'xl.exe');(out/'build.json').write_text(json.dumps(dict(passed=True,sourceRoot=str(s),baseBuild=str(r/'build/native-default-20261106/final-build.json'),rows=rows,links=links),indent=2));print('Fresh matched Windows candidate complete',flush=True)

# srt

## 当前验证（2026-10-30）

三个文本入口 build/buildVtt/formatTime 统一为 `@owned string` 直接返回，
删除 `point` 局部变量、重复空值分支与 takeCstr 中转。对应 C 声明由
通用 void* 明确为 `char*`；名字、参数宽度与指针返回的机器 ABI 不变，
源码前置声明应使用当前公开头，不保留旧声明别名。字幕解析/生成算法、
格式范围、所有权与原生错误分类不改。

旧 takeCstr 本身已直接接管，不能宣称本轮少复制一份正文或少一次分配。
固定六种短输入的 C 原生成本为 1/1/1/3/2/8，分别为零/最大时间戳、
空/非空 SRT、空/带 ID WebVTT；扩容和 ID 去重仍会分配。每条从预算 0
扫到首个成功，合计 22 组；C 与旧、新 XLang 写法均达到相同预算，
故障立即恢复并检查独立输出、输入释放后结果仍有效和活动内存平衡。
这些成本只对应给定夹具与冻结 XRT，不外推长字幕或冷启动所有路径。

`test/owned_probe.xl` 检查三条完整返回链直接接管且不再转交或复制；
parseTime 的错误消息仍有输入复制，不误称整个生成文件零复制。
默认门禁另提取六条实际外部声明，与正式 C 头严格编译，保留原静态
毫秒 ABI、C 畸变/长正文/格式/分配回归及全部原语言字面量正例。
新增 owned_results.xl 已登记 coverage，不将 M1 原数组输入改为预期失败。

`examples/normalize.xl` 与 `normalize_c.c` 规范化同一外部 CRLF/非连续
序号字幕，转换为 WebVTT 再读回；共同六行黄金输出覆盖六项公开入口。
现有中文双语范例仍保留。新 C 范例仅按生产三个模块生成唯一 XRT 后
真实链接/运行，测试运行库沿用这三项加 MEMORY_DEBUG，不增加生产依赖。

从仓库根运行：

```powershell
./release/xl.exe run release/extlibs/srt/examples/normalize.xl
./release/xl.exe run release/extlibs/srt/examples/normalize_c.c
powershell -NoProfile -ExecutionPolicy Bypass -File release/extlibs/srt/test/check.ps1
bash release/extlibs/srt/test/check.sh
```

Linux 使用 `release/xl`，门禁需要 GCC/Python3，原生 C 检查启用
ASan/UBSan/泄漏检测。所有编译/运行有超时，输入前后指纹与原始命令/
输出/状态可查，成功只清理独占目录，失败留场。默认先验可运行路径与
七条可运行独立程序，原 core 字面量独立程序仍待 M1 修复；最后仍在
原语言数组进入 build 的 M1 处报红，不能把
原生解析结果可写出解释成字面量投影已修复。最终双平台范围与报告见
根目录验收矩阵和任务台账，`-SkipAot` 不作发布验收。

本轮未改变头部、控制块等解析规则；下文旧日期记录按历史保留，旧
目录、takeCstr 写法及缺符号描述不是当前入口或实现。

> 2026-10-24 发布版复验：严格 C、C 边界及 C 范例通过；首个
> XLang 用例在 `srt.build(var cues)` 报 `cues must be an array`。
> `test/foreign_array_repro.xl` 在 JIT 和 AOT 均复现；语言侧
> `type(cues) == array` 成立，但 C 入口的 `xrtValueType(cues)`
> 未识别为 `XVALUE_ARRAY`。直接传数组字面量也复现。
> 这与其他包的外部 `var` 容器投影阻断同类，应在主线统一修复；
> 包内不引入数据重建或转换绕行，修复后重跑完整 AOT 门禁。

`srt` 解析、生成 SRT 和常用 WebVTT 字幕。解析后返回 cue 数组，每项包含 `index`、`startMs`、`endMs` 和字符串数组 `lines`。WebVTT 中还可带 `id`、`settings`。时间单位都是毫秒；`build` 会把 SRT 序号按数组顺序重新编号。

2026-10-22：C 边界测试用固定 SRT/WebVTT 样本逐长度截断，并逐字节替换
时间分隔符、箭头、换行、NUL 和非法 UTF-8 等字节。失败结果必须有 XRT
诊断；仍可解析的结果必须能重新生成并再次解析，cue 数量保持不变。
Windows `-SkipAot` 与 Linux ASan/UBSan 包级门禁通过；默认 Windows
门禁的核心 AOT 通过，公开范例仍缺共享 `xl6ValueDataSnapshotV1`，
未签收发布级。这是短样本的确定性畸变回归，不是持续 fuzz。

2026-10-23：畸变夹具扩至双 cue 的 SRT/WebVTT，覆盖分隔空行、第二段时间轴和
不同 cue ID；每份夹具仍逐长度截断、逐字节替换，另以固定种子做 256 组双点
修改。成功解析的结果须能重建并再次读回，错误结果须有诊断。Windows
`test/check.ps1 -SkipAot` 与 Linux `test/check.sh` 的 C ASan/UBSan、XLang
和双语对照门禁通过；这不是持续 fuzz 或完整格式认证，带输出 AOT 阻断未变。

## XLang API

- `srt.parse(text)` / `srt.build(cues)`：SRT。需要正整数序号和 `HH:MM:SS,mmm` 时间戳。
- `srt.parseVtt(text)` / `srt.buildVtt(cues)`：WebVTT。需要 `WEBVTT` 头及空行，支持 cue ID、普通设置串、`MM:SS.mmm` 与 `HH:MM:SS.mmm`。生成时统一输出小时格式。
- WebVTT 时间轴的 `-->` 两侧各须至少一个空格或 tab；普通 SRT 仍接受无空白的箭头。
- WebVTT cue 的结束时间必须严格晚于开始时间；普通 SRT 保留原有的零时长宽容解析。
- `srt.parseTime(stamp)` / `srt.formatTime(milliseconds)`：解析 SRT/VTT 时间戳；格式化为 SRT 格式。非法值抛 `ValueError`。

解析接受 LF/CRLF 和 UTF-8 BOM，拒绝孤立 `\r`；正文按原样保留 UTF-8 字节和行内空白，拒绝内嵌 NUL 以免静默截断。WebVTT `NOTE`（含空格或 tab 注释标题）、`STYLE`、`REGION` 块跳过，**不保留**样式内容，也不解释 cue 文本标记/定位设置的语义。这是字幕文本与时间轴库，不是完整 WebVTT 浏览器排版引擎。生成时 cue 必须具有非负、顺序正确的整数时间和字符串行；行内换行、NUL、空行不被接受，以免输出不可往返的文档。WebVTT 的 `id` 不得与控制块标题冲突，解析与生成均拒绝 `settings` 中的第二个 `-->`；生成时 `id` 也不得包含 `-->`。时间戳和 SRT 序号按 `int64` 范围检查，不提前收窄有效上界。无固定行长或 64 KiB 输出上限。

WebVTT 正文中的 `-->` 在解析和生成时均拒绝；被跳过的 `NOTE`、`STYLE`、`REGION` 块也不能含有 `-->`，否则解析报错，而不是静默丢弃非法块。`STYLE` 和 `REGION` 只能位于首个 cue 之前，`NOTE` 仍可位于 cue 后。这些边界遵循 [W3C WebVTT 格式](https://www.w3.org/TR/webvtt1/)；普通 SRT 正文不受这些 WebVTT 限制。
`STYLE`、`REGION` 标题后可跟空格或 tab，但不能跟其他文字；这种写法仍按控制块处理，不会误作 cue ID。
WebVTT cue 的开始时间按文件顺序不得倒退（允许相等），非空 cue ID 在同一文档中必须唯一。解析和生成都验证这两点；普通 SRT 不套用 WebVTT 的时间顺序与 ID 规则。

SRT/WebVTT 输入整体必须是有效 UTF-8；C 值模型构建时，cue 正文、WebVTT `id` 和 `settings` 也必须是有效 UTF-8。XRT 字符串本身可保存任意字节，因此这些检查在字幕包边界执行。

## C API 与所有权

公开声明位于 `include/srt_native.h`，依赖 XRT 的 `xvalue`。C 字符串可调用 `xsrt_parse` / `xsrt_parse_vtt`，显式字节长度输入使用 `_n` 后缀入口；XLang 桥只用 `_n` 入口，避免内嵌 NUL 被截断。解析结果由调用方 `xrtValueRelease`；格式错误返回 `XVALUE_NULL`，同时设置 XRT 错误。`xsrt_build` / `xsrt_build_vtt` / `xsrt_format_time` 返回独立 NUL 结尾 `char*`，C 调用方须用 `xrtFree` 释放；失败返回 `NULL`。无静态返回缓冲，可并行处理不同文档。XLang 的 `@owned string` 声明直接接管同一分配，字符串生命周期结束时由运行时释放，接管仍需扫描长度，不额外复制正文。

`_n` 解析只读取指定的字节范围，不要求输入以 NUL 结尾，也不复制整份字幕；返回的 cue 字符串仍由 XRT 独立持有，调用方在解析结束后可以释放原输入。
cue 行、ID 和设置均从借用的输入切片直接构造独立的 XRT 字符串值，
不再经临时 C 字符串分配；各字段仍按精确字节长度保存。

三个显式长度 C 入口 `xsrt_parse_n`、`xsrt_parse_vtt_n`、`xsrt_parse_time_n` 会在读取输入前拒绝 `SIZE_MAX`；解析入口返回错误值并设置 XRT 诊断，时间入口返回 -1。其他长度必须真实对应可读缓冲区。

公开 C 操作在调用开始时清除本线程遗留的 XRT 错误；成功返回时不会同时留下上一调用的错误。本次输入、内存或格式错误仍按原返回值和 `xrtGetError()` 报告。

时间解析结果与格式化输入均使用 `int64_t`，与 XLang `int` 的 C ABI 一致。实现源直接包含公开头，避免两套声明再次漂移。

## 范例与包级验证

2026-10-24：WebVTT 的 `STYLE`、`REGION` 标题原只接受完全相等的
行，合法的尾随空格或 tab 被误识别为 cue ID。C 正例先红后绿，
解析器共用标题判断，同时维持 cue 后禁止这两类块的规则；XLang
正例、Windows `-SkipAot`、Linux C ASan/UBSan 与双语门禁通过。
Windows 核心 AOT 通过，完整范例 AOT 仍缺共享
`xl6ValueDataSnapshotV1`，整包未签收发布级。

2026-10-24：WebVTT cue 原允许开始与结束时间相等，解析和生成均与
WebVTT 时间轴规则不符。C/XLang 红例确认后，两条路径改为结束时间
严格晚于开始时间；普通 SRT 的零时长解析保持不变。Windows 包级
`-SkipAot`、Linux C ASan/UBSan、XLang 与双语对照通过；Windows
核心 AOT 构建运行通过，完整范例 AOT 仍缺共享
`xl6ValueDataSnapshotV1`，不签收整包发布级。

2026-10-24：WebVTT 解析原接受时间戳紧贴 `-->` 的非标准时间轴；
C/XLang 负例先复现，再限定 WebVTT 两侧空白规则，保留 tab 正例与 SRT
原有宽容解析。Windows `test/check.ps1 -SkipAot` 的严格 C、XLang
分配故障及双语范例通过；Linux `test/check.sh` 的 C ASan/UBSan、
XLang 与双语对照通过。完整 AOT 仍受共享缺符号阻断，不据此签收整包发布级。

2026-10-14：修复无效 UTF-8 的 C 输入被解析为正常字幕、无效 UTF-8 cue 被生成的问题，SRT/WebVTT 解析和生成三条红绿负例通过。`test/check.ps1` 覆盖严格 GCC、C/XL 边界及双语同输出；`test/check.sh` 对 C 边界启用 Linux ASan/UBSan 与泄漏检查，两套门禁均通过。完整 AOT 阻断不变。

- XLang：`release/examples/extlibs/srt.xl`；与 C 同输出：`release/examples/extlibs/srt_pair.xl` 和 `release/examples/extlibs/srt_c.c`
- 双语对照范例同时展示 SRT 解析/生成、带 ID 与设置的 WebVTT 解析/生成，
  以及时间戳解析/格式化；WebVTT 写出会规范化为含小时的时间格式。
  两份范例各自断言固定的 SRT/WebVTT 文本与毫秒时间，不只互比输出。
- C 边界：`release/extlibs/srt/test/test_srt.c`
- XLang 边界：`release/extlibs/srt/test/boundaries.xl`、`test/cases/extlib_srt.xl`
- 分配失败：`release/extlibs/srt/test/allocations.xl`；逐个注入前 32 个分配点，核对四条公开解析/生成路径的 `MemoryError` 分类、成功恢复和语义往返。

在 `release` 执行 `xl run extlibs/srt/test/boundaries.xl`；在仓库根目录执行 `powershell -NoProfile -ExecutionPolicy Bypass -File tools/run_extlib_c.ps1 -Package srt -Source release/extlibs/srt/test/test_srt.c`。验证覆盖严格时间戳、CRLF、WebVTT ID/设置往返、异常、超过旧固定缓冲长度的文本及独立结果。
Windows `test/check.ps1` 同时运行中央 XLang 用例、包内边界和分配失败用例，并将 C/XLang 范例输出逐字比较；Linux `test/check.sh` 还以 ASan/UBSan 运行 C 边界。
Windows 默认门禁还构建、运行核心 AOT，再构建、运行带输出的双语范例并核对
输出；`-SkipAot` 只跳过这两项 AOT。构建产物位于每次独占的 `build/test`
子目录，退出时校验路径并清理。2026-10-20 当前发布物的核心 AOT 通过，
带输出范例构建缺 `xl6ValueDataSnapshotV1`，默认门禁正确返回失败；
聚焦 C/XLang 门禁及 Linux ASan/UBSan、双语对照均通过。

2026-10-13：追加 `int64` 上界/越界、WebVTT `NOTE\t` 与保留 ID 的 C/XL 回归；Windows C/XL、Linux 严格 GCC 与 ASan/UBSan 已通过。完整 AOT 构建仍受共享 `xl6ValueIndexReadCopyV1` / `xl6ValueDataSnapshotV1` 链接缺符号影响；包级通过不等于发布验收完成。

2026-10-14：WebVTT 设置里出现第二个 `-->` 原先解析成功，但同一 cue 无法由生成器输出。新增 C/XLang 红色复现后在解析阶段拒绝，Windows 包级严格 GCC、C/XL 边界及双语同输出门禁、Linux ASan/UBSan 均通过；官网详情源和生成页哈希一致。完整 AOT 主线阻断不变。

2026-10-17：孤立回车会使解析结果无法再次生成；新增 C/XLang 负例后，SRT/WebVTT 解析统一只接受 LF/CRLF。Windows 严格 GCC、C/XL 边界、双语同输出和 Linux ASan/UBSan 包级门禁通过；完整 AOT 主线阻断不变。

2026-10-14：公开 C 入口补失败后成功的错误槽清理；`parseTime`、`formatTime`、`build` 和 `parse` 连续调用先复现旧错误残留，修复后 C 回归、Windows 严格 GCC/C/XL 包级门禁和 Linux ASan/UBSan 均通过。完整 AOT 的共享缺符号阻断不变。

2026-10-15：WebVTT 的长 `id/settings` 写入缓冲失败原被误报为无效 cue；分配故障红绿回归后，`buildVtt` 保留 `XERR_MEMORY`，无效 cue 仍报 `XERR_VALUE`。测试覆盖生成前 5 个和解析前 24 个分配点。包清单声明 Buffer、Value Container、Unicode 模块；同一核心 AOT 从 3,611,648 降至 656,384 字节并运行通过。Windows 严格 GCC/C/XLang 双语门禁、Linux ASan/UBSan 复跑通过；完整边界 AOT 仍缺 `xl6ValueIndexReadCopyV1`，不计为发布完成。

2026-10-15：箭头偏移改用 `size_t`，不再把长行位置收窄为 `int`；Windows 严格 GCC/C/XLang、双语输出对照和 Linux ASan/UBSan 门禁通过。现有回归覆盖 70 KiB 正文，不把它冒充数 GB 输入实测；完整 AOT 主线阻断不变。

2026-10-17：Linux `test/check.sh` 加入中央与包内 XLang 用例、C/XLang
范例逐字输出对照。严格 GCC 首次发现单文件 C 范例在首次包含 XRT 时
仅开启 Value Container，随后包含实现源所需的 Buffer/Unicode 声明
不可见；范例现于公开头之前声明这两个模块，不重复链接实现源。
修复后 Linux C ASan/UBSan 与语言联合门禁、Windows C 范例均通过。
完整 AOT 共享主线阻断不变。

2026-10-18：C 边界新增 UTF-8 BOM、CRLF 与中文正文的解析、规范化写出、
再次解析正例，与既有 XLang 中文边界对齐。Windows 严格 GCC/C/XLang
及双语范例门禁、Linux C ASan/UBSan 与 XLang 联合门禁通过；
实现未改，完整 AOT 共享阻断不变。

2026-10-21：C/XLang 负例先确认 WebVTT 正文含 `-->` 被解析、生成接受，
且首个 cue 之后的 `STYLE` 被静默跳过。现两处均拒绝，首 cue 前的样式
与后置 `NOTE` 仍可用；Windows `-SkipAot` 包级门禁和 Linux C ASan/UBSan、
XLang/双语联合门禁通过。独立 C 测试宿主现只编入包所需的 XRT 模块；
当前共享 XRT 全模块编译的未定义常量问题另见
`dev/extlib_blockers/xrt_proxy_dial_wait_forever_linux.md`，本包不修改 XRT。
完整带输出 AOT 仍待共享主线符号修复。

同日继续补 WebVTT 时间轴合同：C/XLang 负例先复现倒退的 cue 起点与重复 ID
在解析、生成时均被接受；现两条路径共同拒绝，等起点正例仍通过。
Windows `-SkipAot` 严格 C、XLang 边界/分配故障与双语同输出，
Linux C ASan/UBSan、XLang 与双语门禁通过；完整 AOT 仍待主线修复。

2026-10-22：控制块原直接跳过，导致 `NOTE` 标题/正文、`STYLE` 内容或
`REGION` 设置内的 `-->` 被静默接受；首个 cue 后的 `REGION` 也被忽略。
C/XLang 负例先红后绿，现这些输入均拒绝，合法的前置布局块和后置
`NOTE` 保持可用。Windows `-SkipAot` 严格 C、语言/双语门禁，Linux C
ASan/UBSan 与 XLang 对照通过；Windows 默认门禁的核心 AOT 通过，
带输出范例 AOT 仍缺共享 `xl6ValueDataSnapshotV1`，不签收整包发布级。

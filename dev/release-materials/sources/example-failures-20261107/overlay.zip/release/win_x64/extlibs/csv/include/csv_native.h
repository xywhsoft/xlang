#ifndef XL_CSV_NATIVE_H
#define XL_CSV_NATIVE_H
#include "xrt_csv.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct xcsv_reader_handle xcsv_reader_handle;
typedef struct xcsv_writer_handle xcsv_writer_handle;

/* 语言绑定的物理 ABI；拥有的字符串和 Buffer 通过 point 移交给宿主。 */
xcsv_reader_handle* xcsv_reader_open_memory(void* data, uint64 size, cstr delimiter, cstr quote,
    bool strict, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
xcsv_reader_handle* xcsv_reader_open_text(cstr text, uint64 size, cstr delimiter, cstr quote,
    bool strict, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
xcsv_reader_handle* xcsv_reader_open_file(cstr path, cstr delimiter, cstr quote, bool strict,
    uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
void xcsv_reader_destroy(xcsv_reader_handle* reader);
bool xcsv_reader_next(xcsv_reader_handle* reader);
bool xcsv_reader_eof(xcsv_reader_handle* reader);
int64 xcsv_reader_row(xcsv_reader_handle* reader);
int64 xcsv_reader_count(xcsv_reader_handle* reader);
bool xcsv_reader_close(xcsv_reader_handle* reader);
void* xcsv_reader_field(xcsv_reader_handle* reader, int64 index);

xcsv_writer_handle* xcsv_writer_create_memory(cstr delimiter, cstr quote, int newline, bool quoteAll,
    bool writeBOM, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
xcsv_writer_handle* xcsv_writer_open_file(cstr path, cstr delimiter, cstr quote, int newline, bool quoteAll,
    bool writeBOM, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
void xcsv_writer_destroy(xcsv_writer_handle* writer);
bool xcsv_writer_begin(xcsv_writer_handle* writer);
bool xcsv_writer_field(xcsv_writer_handle* writer, cstr value);
bool xcsv_writer_end(xcsv_writer_handle* writer);
bool xcsv_writer_close(xcsv_writer_handle* writer);
void* xcsv_writer_take_buffer(xcsv_writer_handle* writer);
/* 取走内存写入器的 UTF-8 结果；调用方使用 xrtFree 释放。 */
void* xcsv_writer_take_text(xcsv_writer_handle* writer);


// Cold owner-admission factories; data operations remain direct C calls.
int xcsv_reader_open_memory_owned(xcsv_reader_handle** output, void* data, uint64 size, cstr delimiter, cstr quote, bool strict, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
int xcsv_reader_open_text_owned(xcsv_reader_handle** output, cstr text, uint64 size, cstr delimiter, cstr quote, bool strict, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
int xcsv_reader_open_file_owned(xcsv_reader_handle** output, cstr path, cstr delimiter, cstr quote, bool strict, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
int xcsv_writer_create_memory_owned(xcsv_writer_handle** output, cstr delimiter, cstr quote, int newline, bool quoteAll, bool writeBOM, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);
int xcsv_writer_open_file_owned(xcsv_writer_handle** output, cstr path, cstr delimiter, cstr quote, int newline, bool quoteAll, bool writeBOM, uint64 maxInput, uint64 maxOutput, uint64 maxField, uint64 maxRows, uint64 maxFields);

#ifdef __cplusplus
}
#endif
#endif

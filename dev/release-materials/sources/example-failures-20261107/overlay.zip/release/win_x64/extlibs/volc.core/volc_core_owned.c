// Transfer the native thread-local result allocation into a language string.
#include "include/volc_core_owned.h"
char* xl_x_volc_core_sha256_hex(const char* text)
{ return (char*)x_volc_core_take_result(x_volc_core_sha256_hex(text)); }
char* xl_x_volc_core_hmac_sha256_hex(const char* key, const char* text)
{ return (char*)x_volc_core_take_result(x_volc_core_hmac_sha256_hex(key, text)); }
char* xl_x_volc_core_hmac_sha256_hex_key(const char* hex_key, const char* text)
{ return (char*)x_volc_core_take_result(x_volc_core_hmac_sha256_hex_key(hex_key, text)); }
char* xl_x_volc_core_canonical_query(const char* action, const char* version, const char* extra_pairs)
{ return (char*)x_volc_core_take_result(x_volc_core_canonical_query(action, version, extra_pairs)); }
char* xl_x_volc_core_json_string(const char* text)
{ return (char*)x_volc_core_take_result(x_volc_core_json_string(text)); }
char* xl_x_volc_core_sign_preview(const char* method, const char* host, const char* path, const char* service, const char* region, const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* content_type, const char* extra_pairs, const char* body, const char* x_date)
{ return (char*)x_volc_core_take_result(x_volc_core_sign_preview(method, host, path, service, region, action, version, access_key, secret_key, session_token, content_type, extra_pairs, body, x_date)); }
char* xl_x_volc_core_sign_preview_acep(const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* body, const char* x_date)
{ return (char*)x_volc_core_take_result(x_volc_core_sign_preview_acep(action, version, access_key, secret_key, session_token, body, x_date)); }
char* xl_x_volc_core_sign_preview_sts(const char* access_key, const char* secret_key, const char* role_trn, const char* role_session_name, int duration_seconds, const char* x_date)
{ return (char*)x_volc_core_take_result(x_volc_core_sign_preview_sts(access_key, secret_key, role_trn, role_session_name, duration_seconds, x_date)); }
char* xl_x_volc_core_sign_preview_acep_spec(const char* spec)
{ return (char*)x_volc_core_take_result(x_volc_core_sign_preview_acep_spec(spec)); }
char* xl_x_volc_core_sign_preview_sts_spec(const char* spec)
{ return (char*)x_volc_core_take_result(x_volc_core_sign_preview_sts_spec(spec)); }
char* xl_x_volc_core_request(const char* method, const char* host, const char* path, const char* service, const char* region, const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* content_type, const char* extra_pairs, const char* body, int timeout_ms)
{ return (char*)x_volc_core_take_result(x_volc_core_request(method, host, path, service, region, action, version, access_key, secret_key, session_token, content_type, extra_pairs, body, timeout_ms)); }
char* xl_x_volc_core_request_acep(const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* body, int timeout_ms)
{ return (char*)x_volc_core_take_result(x_volc_core_request_acep(action, version, access_key, secret_key, session_token, body, timeout_ms)); }
char* xl_x_volc_core_request_sts(const char* access_key, const char* secret_key, const char* role_trn, const char* role_session_name, int duration_seconds, int timeout_ms)
{ return (char*)x_volc_core_take_result(x_volc_core_request_sts(access_key, secret_key, role_trn, role_session_name, duration_seconds, timeout_ms)); }
char* xl_x_volc_core_request_acep_spec(const char* spec)
{ return (char*)x_volc_core_take_result(x_volc_core_request_acep_spec(spec)); }
char* xl_x_volc_core_request_sts_spec(const char* spec)
{ return (char*)x_volc_core_take_result(x_volc_core_request_sts_spec(spec)); }

#ifndef XL_VOLC_CORE_OWNED_H
#define XL_VOLC_CORE_OWNED_H
#include "volc_core_native.h"
char* xl_x_volc_core_sha256_hex(const char* text);
char* xl_x_volc_core_hmac_sha256_hex(const char* key, const char* text);
char* xl_x_volc_core_hmac_sha256_hex_key(const char* hex_key, const char* text);
char* xl_x_volc_core_canonical_query(const char* action, const char* version, const char* extra_pairs);
char* xl_x_volc_core_json_string(const char* text);
char* xl_x_volc_core_sign_preview(const char* method, const char* host, const char* path, const char* service, const char* region, const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* content_type, const char* extra_pairs, const char* body, const char* x_date);
char* xl_x_volc_core_sign_preview_acep(const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* body, const char* x_date);
char* xl_x_volc_core_sign_preview_sts(const char* access_key, const char* secret_key, const char* role_trn, const char* role_session_name, int duration_seconds, const char* x_date);
char* xl_x_volc_core_sign_preview_acep_spec(const char* spec);
char* xl_x_volc_core_sign_preview_sts_spec(const char* spec);
char* xl_x_volc_core_request(const char* method, const char* host, const char* path, const char* service, const char* region, const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* content_type, const char* extra_pairs, const char* body, int timeout_ms);
char* xl_x_volc_core_request_acep(const char* action, const char* version, const char* access_key, const char* secret_key, const char* session_token, const char* body, int timeout_ms);
char* xl_x_volc_core_request_sts(const char* access_key, const char* secret_key, const char* role_trn, const char* role_session_name, int duration_seconds, int timeout_ms);
char* xl_x_volc_core_request_acep_spec(const char* spec);
char* xl_x_volc_core_request_sts_spec(const char* spec);
#endif

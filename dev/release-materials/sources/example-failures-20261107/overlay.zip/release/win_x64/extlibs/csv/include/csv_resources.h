#ifndef XL_CSV_RESOURCES_H
#define XL_CSV_RESOURCES_H
#include "csv_native.h"
#include <__xl_runtime/xl6_foreign_view.h>
/* These language factories own only CSV parser/writer state, copied memory
 * or native file IO. They cannot accept language callbacks or user IO graphs.
 * The view's code lease keeps all package callbacks resident until retirement. */
static bool csvReaderDestroy(void* raw){xcsv_reader_destroy(raw);return true;}
static bool csvWriterDestroy(void* raw){xcsv_writer_destroy(raw);return true;}
static const XL6_ForeignViewDescriptorV1 csvReaderPolicy={sizeof(csvReaderPolicy),XL6_FOREIGN_VIEW_V1_TAG,"csv.Reader",0,1,NULL,NULL,csvReaderDestroy,0,1,NULL,NULL,NULL,NULL,0,NULL,NULL};
static const XL6_ForeignViewDescriptorV1 csvWriterPolicy={sizeof(csvWriterPolicy),XL6_FOREIGN_VIEW_V1_TAG,"csv.Writer",0,1,NULL,NULL,csvWriterDestroy,0,1,NULL,NULL,NULL,NULL,0,NULL,NULL};
#endif

from pathlib import Path
import concurrent.futures, hashlib, json, shlex, subprocess, sys, time

out = Path(__file__).resolve().parent
root = out / 'latest-source'
parent = out.parent / 'native-default-20261106'
old = json.loads((parent / 'final-build.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(old['compiler']) == old['compilerSha256']
for row in old['units'] + old['commonUnits']:
    assert sha(row['object']) == row['sha256'], row['object']
print('Verified 2734 inherited GCC/common objects', flush=True)
oldroot = Path(old['sourceRoot'])
changed = []
for folder in ('src', 'lib', 'release/win_x64/include'):
    for source in (oldroot / folder).rglob('*'):
        if source.is_file():
            relative = source.relative_to(oldroot)
            if sha(source) != sha(root / relative):
                changed.append(relative.as_posix())
assert changed == ['src/api/xl_api.c'], changed
resources = out / 'latest-resources'
resources.mkdir(exist_ok=True)
for profile, filename in [('runtime','tcc_builtin_resources_runtime.c'),('xlc','tcc_builtin_resources.c')]:
    command = [sys.executable, str(root/'tools/gen_tcc_vfs_resources.py'), '--root', str(root),
               '--manifest', str(root/f'tools/tcc_vfs_manifest_win64_{profile}.txt'),
               '--output', str(resources/filename), '--tcc-dist', str(root/'res/tcc/win64/x86_64'),
               '--xrt-obj', str(root/'build/tmp/xrt.o'), '--pack-tool', str(root/'build/tmp/tcc_vfs_lzma_pack.exe'),
               '--precompiled', str(out/'latest-precompiled-final/manifest.json')]
    r = subprocess.run(command, cwd=root, capture_output=True)
    (out/f'latest-resource-{profile}.log').write_bytes(r.stdout+r.stderr)
    assert r.returncode == 0, (profile, r.stderr[-4000:])
objects = out/'latest-objects'
objects.mkdir(exist_ok=True)
replacements = {}
jobs = []
for row in old['units']:
    name = Path(row['source']).name
    if name not in ('xl_api.c','tcc_builtin_resources.c','tcc_builtin_resources_runtime.c'):
        continue
    target = objects/(row['profile']+'-'+name+'.o')
    source = root/'src/api/xl_api.c' if name == 'xl_api.c' else resources/name
    command = list(row['command'])
    command[command.index(row['source'])] = str(source)
    command[command.index('-o')+1] = str(target)
    replacements[str(Path(row['object'])).replace('\\','/')] = str(target)
    jobs.append((row['profile'], source, target, command))
assert len(jobs) == 4
def compile(job):
    profile, source, target, command = job
    start = time.monotonic()
    r = subprocess.run(command, cwd=root, capture_output=True)
    (out/f'latest-{profile}-{target.name}.log').write_bytes(r.stdout+r.stderr)
    return dict(profile=profile, source=str(source), object=str(target), command=command,
                exitCode=r.returncode, seconds=round(time.monotonic()-start,3),
                sha256=sha(target) if r.returncode==0 else None)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    rows = list(pool.map(compile,jobs))
assert all(row['exitCode']==0 for row in rows), rows
links=[]
for link in old['links']:
    args=shlex.split(Path(link['response']).read_text(),posix=True)
    args=[replacements.get(a.replace('\\','/'),a) for a in args]
    target=root/'release/win_x64'/Path(link['output']).name
    args[args.index('-o')+1]=str(target)
    rsp=out/f"latest-{link['profile']}-link.rsp"
    rsp.write_text('\n'.join('"'+a.replace('\\','/').replace('"','\\"')+'"' for a in args)+'\n')
    r=subprocess.run([old['compiler'],'@'+str(rsp)],cwd=root,capture_output=True)
    (out/f"latest-{link['profile']}-link.log").write_bytes(r.stdout+r.stderr)
    assert r.returncode==0,(link['profile'],r.stderr[-4000:])
    links.append(dict(profile=link['profile'],output=str(target),sha256=sha(target),bytes=target.stat().st_size,response=str(rsp)))
    r=subprocess.run([str(root/'build/tmp/tcc_bootstrap.exe'),'-impdef',str(target),'-o',str(target.with_suffix('.def'))],cwd=root,capture_output=True)
    assert r.returncode==0,r.stderr
cli=root/'release/win_x64/xl.exe'
command=[old['compiler'],'-std=c11','-Wall','-O2','-s','-ffunction-sections','-fdata-sections','-Wl,--gc-sections',
         '-D_CRT_SECURE_NO_WARNINGS','-I.','-Irelease/win_x64','-Irelease/win_x64/include','-o',str(cli),
         'build/tmp/xlang_cli.res','src/driver/xl6_xlc_shell.c','src/common/xl6_console.c','release/win_x64/xlc.dll','-lShell32']
r=subprocess.run(command,cwd=root,capture_output=True)
(out/'latest-cli-build.log').write_bytes(r.stdout+r.stderr)
assert r.returncode==0,r.stderr
result=dict(passed=True,parentBuild=str(parent/'final-build.json'),parentBuildSha256=sha(parent/'final-build.json'),
            sourceRoot=str(root),changedSources=changed,reusedGccUnits=len(old['units'])-len(rows),verifiedCommonUnits=len(old['commonUnits']),
            compiler=old['compiler'],compilerSha256=old['compilerSha256'],rebuilt=rows,links=links,
            cli=dict(path=str(cli),sha256=sha(cli),command=command),precompiledManifestSha256=sha(out/'latest-precompiled-final/manifest.json'))
(out/'latest-build.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('Rebuilt 4 GCC units, both DLLs, serialized API/catalogs and native-linkage CLI; reused 2625+105 verified objects.',flush=True)

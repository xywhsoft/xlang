from pathlib import Path
import base64,hashlib,json,subprocess

root=Path('/root/.codex-builds/xlang-example-runtime-20261106-1958')
out=Path('/mnt/d/GIT/x-lang/build/compiler-rebuild-20261106/latest-linux-environment')
out.mkdir(exist_ok=False)
work=root/'build/test/rebuilt-c-environment'
work.mkdir(parents=True,exist_ok=False)
entry=work/'main.xl'
entry.write_text('export "native_public" func answer(c_int a) as c_int\n return a\nend\n')
(work/'native.c').write_text('int native_answer(void) { return 42; }\n')
project=work/'app.xlp'
project.write_text(json.dumps(dict(schema=1,name='bridge',kind='exe',entry='main.xl',cSources=['native.c'])))
stamp=root/'build/linux/tcc_builtin_resources.c.stamp.json'
resources=json.loads(stamp.read_text())['resources']
expected={r['virtual'].replace('\\','/').lower():r for r in resources if r['virtual'].startswith(('include/','lib/xrt/','lib/xruntime/')) and r['virtual'].endswith('.h')}
rows=[]
for name,source,options in [('exe',entry,[]),('shared',entry,['-shared']),('native-project',project,[])]:
    command=[str(root/'release/linux_x64/xl'),'c-bridge',str(source),'--json','--c-environment',*options]
    r=subprocess.run(command,capture_output=True,cwd=work,timeout=120)
    (out/(name+'.json')).write_bytes(r.stdout)
    (out/(name+'.stderr')).write_bytes(r.stderr)
    assert r.returncode==0,(name,r.stderr)
    v=json.loads(r.stdout)
    assert v['ok'] and v['cBridge']['complete']
    env=v['cBridge']['nativeEnvironment']
    assert env['complete'] and env['embeddedHeadersAvailable']
    assert env['outputKind']==('shared' if name=='shared' else 'exe')
    headers=env['builtinHeaders']
    assert len(headers)==len(expected)<=1024
    assert {h['name'] for h in headers}==set(expected)
    total=0
    for h in headers:
        data=base64.b64decode(h['base64'],validate=True)
        row=expected[h['name']]
        assert data==Path(row['source']).read_bytes()
        assert len(data)==h['size']<=16*1024*1024
        assert hashlib.sha256(data).hexdigest()==h['sha256']==row['sha256']
        total+=len(data)
    assert total==env['builtinBytes']<=32*1024*1024
    assert len(env['operations'])<=2048
    rows.append(dict(name=name,headers=len(headers),headerBytes=total,command=command))
record=dict(passed=True,rows=rows,headerComparisons=len(expected)*len(rows),stampSha256=hashlib.sha256(stamp.read_bytes()).hexdigest())
(out/'results.json').write_text(json.dumps(record,indent=2)+'\n')
print('Passed Linux C environment: '+str(record['headerComparisons'])+' header byte comparisons')

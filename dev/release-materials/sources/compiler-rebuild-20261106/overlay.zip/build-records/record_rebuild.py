from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile,datetime

main=Path('D:/GIT/x-lang')
root=Path('C:/Users/Administrator/.codex/worktrees/example-runtime-integration/x-lang')
art=main/'build/compiler-rebuild-20261106'
name='compiler-rebuild-20261106'
prov=root/'dev/release-materials/provenance'/name
sources=root/'dev/release-materials/sources'/name
prov.mkdir(parents=True,exist_ok=True)
sources.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ref(p):return dict(path=Path(p).relative_to(root).as_posix(),sha256=sha(p),bytes=Path(p).stat().st_size)
def copy(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)

win=load(art/'installed-windows/results.json')
linux=load(art/'installed-linux/results.json')
assert win['passed'] and linux['passed'] and len(win['rows'])==55 and len(linux['rows'])==48
for n in ('latest-windows-redis','latest-linux-redis'):
    assert load(art/n/'report.json')['passed']
for n in ('latest-win-linkage','latest-linux-linkage'):
    j=load(art/n/'results.json');assert j['passed'] and len(j['rows'])==33
environment=next(p for p in art.glob('c-bridge-environment-*/evidence.json') if load(p)['compiler'].endswith('latest-source\\release\\win_x64\\xl.exe'))
mapping=next(p for p in art.glob('c-bridge-map-*/evidence.json') if load(p)['compiler'].endswith('latest-source\\release\\win_x64\\xl.exe'))
assert load(environment)['status']==load(mapping)['status']=='passed'
assert load(art/'latest-linux-environment/results.json')['passed']
assert load(art/'latest-header-budget.json')['passed']
build=load(art/'latest-build.json')
assert build['passed'] and build['changedSources']==['src/api/xl_api.c']
source_revision=subprocess.check_output(['git','-C',str(root),'rev-parse','5db37c838']).decode().strip()
product_revision=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
for folder in ('installed-windows','installed-linux','latest-windows-redis','latest-linux-redis','latest-win-linkage','latest-linux-linkage'):
    for p in (art/folder).iterdir():
        if p.suffix in ('.json','.log') and p.name not in ('inputs.json',):copy(p,prov/folder/p.name)
copy(environment,prov/'c-bridge-environment.json')
copy(mapping,prov/'c-bridge-map.json')
copy(art/'latest-linux-environment/results.json',prov/'linux-c-environment.json')
for n in ('latest-build.log','latest-linux-build.log','latest-linux-toolchain.txt','latest-header-budget.json',
          'latest-header-budget-build.log','latest-header-budget-run.log','installed-products.json',
          'latest-resource-runtime.log','latest-resource-xlc.log','latest-cli-build.log'):
    copy(art/n,prov/n)
copy(art/'install/plan.json',prov/'installation.json')
previous=root/'dev/release-materials/provenance/current-delivery.json'
copy(previous,prov/'previous-delivery.json')

parent=root/'dev/release-materials/sources/native-linkage-default-20261106/sources.zip'
archive=sources/'overlay.zip'
owned=['src/api/xl_api.c','ide/src/services/c_bridge.c','ide/tests/c_bridge_header_budget_test.c','tools/check_c_bridge_environment.py']
overlay=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in owned:
        data=subprocess.check_output(['git','-C',str(root),'show',source_revision+':'+path])
        z.writestr(path,data)
        overlay.append(dict(path=path,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
    records=[('rebuild_latest.py','rebuild_windows.py'),('check_linux_environment.py','check_linux_environment.py'),
             ('record_rebuild.py','record_rebuild.py'),('latest-build.json','windows-build.json'),
             ('latest-precompiled-final/manifest.json','windows-precompiled.json'),
             ('latest-linux-precompiled.json','linux-precompiled.json'),
             ('latest-resources/tcc_builtin_resources.c.stamp.json','windows-resource-stamp.json'),
             ('latest-resources/tcc_builtin_resources_runtime.c.stamp.json','windows-runtime-stamp.json'),
             ('latest-linux-resource-stamp.json','linux-resource-stamp.json'),
             ('latest-linux-runtime-stamp.json','linux-runtime-stamp.json')]
    for original,target in records:z.write(art/original,'build-records/'+target)
    manifest=load(art/'latest-precompiled-final/manifest.json')
    for row in manifest['objects']:
        if row.get('provenance',{}).get('kind')=='recompiled':z.write(row['source'],row['virtual'])
material=dict(schema=1,date='2026-11-06',sourceRevision=source_revision,
              parentSourceArchive=ref(parent),overlay=ref(archive),ownedSources=overlay,
              reconstruction='Extract the parent source archive, then overlay.zip over it. Build with build_dll.bat/build_linux.sh and the matched SDKs. build-records preserve the exact incremental Windows commands and the full Linux object catalogs; absolute cache paths are historical build inputs.',
              windowsIncremental=True,linuxFullProductionBuild=True,
              semanticParity='All src files match the clean committed integration cohort after CRLF normalization; no concurrent uncommitted semantic/IDE edits were compiled.')
write(sources/'manifest.json',material)

products=[]
for row in load(art/'installed-products.json'):
    p=root/row['path'];assert sha(p)==row['sha256'] and sha(main/row['path'])==row['sha256']
    products.append(ref(p))
receipt=dict(schema=1,date='2026-11-06',passed=True,
    scope='Specified example failures, bounded native C header descriptors, compiler rebuild and installed regression checks; no whole-project certification.',
    sourceRevision=source_revision,productRevision=product_revision,sourceMaterials=ref(sources/'manifest.json'),
    parentBuildProvenance=ref(root/'dev/release-materials/provenance/native-linkage-default-20261106/receipt.json'),
    changes=['Native C header admission grows from 512 to 1024 while existing per-header, aggregate, operation and output byte limits remain enforced.',
             'IDE optional C-LSP accepts 1024 headers and reserves 1280 file leases for headers plus two metadata files per each of 128 projects.',
             'Generated Windows compiler exports now include xlcSetNativeLinkage in xlc.def.'],
    compiler=dict(version='0.6.0',optimization='-O2',
        windows=dict(recompiledGccUnits=4,reusedVerifiedGccUnits=2625,verifiedCommonUnits=105,
                     rebuiltSerializedApiObjects=4,inheritedSerializedObjects=1563,regeneratedNestedCatalog=True,
                     bothDllsRelinked=True,cliRecompiled=True,cliBytesIdenticalToPreviousQualifiedCli=True),
        linux=dict(fullProductionBuild=True,embeddedObjects=1565,regeneratedNestedCatalog=True)),
    validation=dict(installedWindowsSteps=55,installedLinuxSteps=48,
        windowsCEnvironmentResponses=12,windowsExactHeaderComparisons=5697,
        linuxCEnvironmentResponses=3,linuxExactHeaderComparisons=1605,
        declarationMapCommands=17,declarationMapResponses=12,nativeLinkageStepsPerPlatform=33,
        syntheticBudget=dict(headers=1024,projects=128,fileLeases=1280,overflowRejected=True),
        redis='Private authenticated disposable server, JIT and AOT on both platforms; no external user DB contacted.',
        serial='LOOPBACK',clipboard='Private Windows window station',
        installedProductsMatchQualifiedCandidates=True),
    products=products,previousDelivery=ref(prov/'previous-delivery.json'),
    preservation=dict(unrelatedWorkAndStaging=True,oldFlatReleaseDeletions=True,historicalReportsUnmodified=True,
                      nativeLinkageFeatureRetained=True,guiRebuilt=False,cLspEnabled=False,externalPublication=False),
    limits=['These results cover the specified examples and related interop boundaries, not the complete project test matrix.',
            'The C-LSP consumer source and enabled-path helper fixture were updated. The shipped GUI keeps its qualified C-LSP-disabled configuration.'])
evidence=[ref(p)for p in sorted(prov.rglob('*'))if p.is_file() and p.name not in ('receipt.json','report.md')]
receipt['evidence']=evidence
write(prov/'receipt.json',receipt)
(prov/'report.md').write_text('''# 编译器重新编译与指定范例最终验收

此前列出的范例及对应缺陷已修复，Windows、Linux 编译器已重新编译并更新到主线 `release/win_x64`、`release/linux_x64`。安装后的 Windows 55 项、Linux 48 项 JIT/独立程序检查全部通过；串口使用 LOOPBACK，剪贴板使用独立 window station。Redis 另在两个平台通过临时认证服务的 JIT、构建、独立程序执行，不接触用户数据库。

本轮关闭上一份范例验收报告留下的 `xl c-bridge --json --c-environment` 缺口：完整 SDK 含 633 个 Windows 头文件，超过旧的 512 上限。编译器与 IDE 可选 C-LSP 消费方统一支持 1024 个；每个头文件 16 MiB、总量 32 MiB、操作数及输出字节上限保留。消费方为最多 128 个项目的两个元数据文件额外预留 lease，总计 1280。真实 helper 的 1024/1025 头文件及 1280/1281 文件边界检查通过。

Windows C 环境门禁通过 16 次命令、12 份响应和 5697 次逐字节头文件比对；Linux 的 3 份响应通过 1605 次比对。声明映射门禁通过 17 次命令，包含 32769 个导出的容量退化检查。另一线程合入的静态扩展链接能力保留，两平台各 33 项验证通过；Windows `xlc.def` 同步导出 `xlcSetNativeLinkage`。

Windows 使用经哈希验证的增量构建：重编 4 个 GCC 单元、重链两份 DLL、重编 CLI，另重编内嵌目录中的 4 个 API 对象并重新生成资源；复用 2625 个原 GCC 对象、105 个公共对象和 1563 个内嵌对象。Linux 完成完整生产构建（1565 个内嵌对象）。两平台均使用 `-O2`。CLI 源码未变化，重新编译后的 CLI 字节与上一合格版本相同；DLL 已更新。没有把增量构建描述为全量重编。

源码修复、边界测试和产物分别提交。使用独立干净工作树与冻结源码，未纳入其他线程未提交的语义补全及 IDE 变更；合入保留这些变更和旧平铺 release 删除。未重建 GUI，其当前配置仍关闭 C-LSP；可选路径源代码及 helper 已测试。历史报告保持原字节，本报告取代其“C 环境描述器未修复”的状态。未执行全项目完整验收或外部发布。

精确来源、构建命令、产物哈希和验收范围见 `receipt.json`。源码 overlay 与上一次完整源快照的引用在 sibling `dev/release-materials/sources/compiler-rebuild-20261106/manifest.json`。
''',encoding='utf-8')

index=load(previous)
old_products={r['path']:r for r in index['products']}
for row in products:
    old=old_products[row['path']];old['previousSha256']=old['sha256'];old.update(row,origin=name)
index['primaryIntegrationRevision']=product_revision
index['compiler'].update(sourceRevision=source_revision,rebuiltThisDelivery=True,entireAcceptanceRerunThisDelivery=False,
                        reusedQualifiedProducts=False,currentBuildProvenance=ref(prov/'receipt.json')['path'],
                        sourceMaterials=ref(sources/'manifest.json'),previousDelivery=ref(prov/'previous-delivery.json'),
                        buildScope=receipt['scope'])
index['compilerRebuild']=ref(prov/'receipt.json')
index['acceptance']['compilerRebuild']=ref(prov/'receipt.json')
index['currentScope']=receipt['scope']
write(previous,index)
print('Recorded compiler source overlay, exact build/test evidence and mutable delivery index.')

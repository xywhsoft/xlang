#include "xui_config.h"
#if XUI_ENABLE_TABLE_GRID
#include "xui_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define XUI_TABLE_GRID_EDITOR_NONE	0
#define XUI_TABLE_GRID_EDITOR_INPUT	1
#define XUI_TABLE_GRID_EDITOR_NUMERIC	2
#define XUI_TABLE_GRID_EDITOR_COMBO	3
#define XUI_TABLE_GRID_EDITOR_COLOR	4
#define XUI_TABLE_GRID_EDITOR_DATE	5
#define XUI_TABLE_GRID_EDITOR_TEXTAREA	6

typedef struct xui_table_grid_key_route_t {
	xui_widget pGrid;
	xui_widget_event_proc onKey;
	void* pUser;
} xui_table_grid_key_route_t;

typedef struct xui_table_grid_data_t {
	xui_widget pTable;
	xui_widget pInput;
	xui_widget pNumeric;
	xui_widget pCombo;
	xui_widget pColor;
	xui_widget pDate;
	xui_widget pTextPopup;
	xui_widget pTextContent;
	xui_widget pTextEdit;
	xui_widget pTextOk;
	xui_widget pTextCancel;
	xui_font pFont;
	xui_table_view_count_proc onCount;
	xui_table_view_cell_proc onCell;
	xui_table_grid_set_proc onSet;
	void* pAdapterUser;
	void* pSetUser;
    xui_table_view_count_proc onCountOwned;
    xui_table_view_cell_owned_proc onCellOwned;
    xui_table_grid_set_proc onSetOwned;
    void* pCountOwnedUser;
    void* pCellOwnedUser;
    void* pSetOwnedUser;
    bool bAdapterOwned;
    xui_table_grid_editor_owned_proc onEditorOwned;
    void* pEditorOwnedUser;
	xui_table_grid_validate_proc onValidate;
	void* pValidateUser;
	xui_table_grid_change_proc onChange;
	void* pChangeUser;
	xui_table_grid_editor_proc onEditor;
	void* pEditorUser;
	xui_table_grid_editor_config_proc onEditorConfig;
	void* pEditorConfigUser;
    xui_table_grid_editor_config_owned_proc onEditorConfigOwned;
    void* pEditorConfigOwnedUser;
    xui_table_grid_editor_config_output_t tOwnedEditorConfig;
	xui_table_grid_context_proc onContext;
	void* pContextUser;
	xui_table_grid_editor_config_t tEditorConfig;
	xui_table_grid_key_route_t arrKeyRoutes[12];
	int iEditMode;
	int iEditingRow;
	int iEditingColumn;
	int iEditingType;
	int iActiveEditor;
	int iCommitCount;
	int iRejectCount;
	int iCancelCount;
	int iPickerCount;
	int iChangeCount;
	uint64_t iAdapterGeneration;
	int bCommitting;
	int bStartingEdit;
	uint32_t arrDefaultPalette[XUI_COLOR_PICKER_PALETTE_CAPACITY];
	int iDefaultPaletteCount;
	char sOriginalValue[XUI_TABLE_GRID_VALUE_CAPACITY];
} xui_table_grid_data_t;

/* Typed native snapshot, retained through the callback's physical return.
 * Scalar arguments and caller-owned hit snapshots precede reentrant Hold. */
static int __xuiOwnedInvoke_xuiTableGridSetContextMenu(xui_widget widget,xui_table_grid_data_t* data,xui_table_grid_context_proc selected,void* user,int iPart,int iRow,int iColumn,float fX,float fY)
{
    if(!widget->pEventOwners || !widget->pEventOwners->pBindings)return selected(widget,iPart,iRow,iColumn,fX,fY,user);
    xui_callback_snapshot_t snapshot={0};
    int status=xuiInternalCallbackSnapshotBeginReported(widget,&data->onContext,&user,&snapshot);
    if(status!=XUI_OK)return status;
    int value=selected(widget,iPart,iRow,iColumn,fX,fY,user);
    status=value<0 ? value:XUI_OK;
    xerror* first=status!=XUI_OK ? xrtTakeError():NULL;
    int ended=xuiInternalCallbackSnapshotEndOutcome(&snapshot,status,first);
    return ended!=XUI_OK ? ended:value;
}


static void __xuiTableGridRecordFailure(xui_context context,int status);
static xui_table_grid_data_t* __xuiTableGridGetData(xui_widget pWidget);
static int __xuiTableGridEditModeValid(int iMode);
static int __xuiTableGridEndEditOperation(xui_widget pWidget, int bCommit);

static int __xuiTableGridWidgetAlive(xui_widget pWidget, xui_table_grid_data_t* pData)
{
	xui_context pContext;

	if ( !xuiInternalWidgetIsValid(pWidget) ) return 0;
	pContext = xuiWidgetGetContext(pWidget);
	return xuiInternalContextIsValid(pContext) && !xuiInternalContextDestroyPending(pContext) &&
		__xuiTableGridGetData(pWidget) == pData;
}

static int __xuiTableGridFloatValid(float fValue)
{
	return (fValue == fValue) && (fValue >= 0.0f) && (fValue <= XUI_LAYOUT_UNBOUNDED);
}

static int __xuiTableGridFloatFinite(float fValue)
{
	return (fValue == fValue) &&
		(fValue >= -XUI_LAYOUT_UNBOUNDED) && (fValue <= XUI_LAYOUT_UNBOUNDED);
}

static int __xuiTableGridSelectionModeValid(int iMode)
{
	return (iMode == XUI_TABLE_VIEW_SELECTION_CELL) || (iMode == XUI_TABLE_VIEW_SELECTION_ROW);
}

static int __xuiTableGridScrollbarModeValid(int iMode)
{
	return (iMode == XUI_SCROLLBAR_MODE_FULL) || (iMode == XUI_SCROLLBAR_MODE_COMPACT);
}

static int __xuiTableGridColumnValid(const xui_table_view_column_t* pColumn)
{
	if ( pColumn == NULL || !__xuiTableGridFloatValid(pColumn->fWidth) ||
	     !__xuiTableGridFloatValid(pColumn->fMinWidth) ||
	     !__xuiTableGridFloatValid(pColumn->fMaxWidth) ) return 0;
	return (pColumn->fMaxWidth <= 0.0f) || (pColumn->fMinWidth <= pColumn->fMaxWidth);
}

static int __xuiTableGridColumnsValid(const xui_table_view_column_t* arrColumns, int iCount)
{
	int i;

	if ( iCount < 0 || iCount > XUI_TABLE_VIEW_COLUMN_CAPACITY ||
	     (iCount > 0 && arrColumns == NULL) ) return 0;
	for ( i = 0; i < iCount; i++ ) {
		if ( !__xuiTableGridColumnValid(&arrColumns[i]) ) return 0;
	}
	return 1;
}

static int __xuiTableGridRowsValid(const xui_table_view_row_t* arrRows, int iCount)
{
	int i;

	if ( iCount < 0 ) return 0;
	if ( arrRows == NULL ) return 1;
	for ( i = 0; i < iCount; i++ ) {
		if ( !__xuiTableGridFloatValid(arrRows[i].fHeight) ) return 0;
	}
	return 1;
}

static int __xuiTableGridDateModeValid(int iMode)
{
	return iMode >= XUI_DATE_PICKER_MODE_DATE && iMode <= XUI_DATE_PICKER_MODE_DATETIME_RANGE;
}

static int __xuiTableGridEditorConfigValid(const xui_table_grid_editor_config_t* pConfig)
{
	if ( pConfig == NULL || pConfig->iEnumItemCount < 0 ||
	     pConfig->iEnumItemCount > XUI_COMBOBOX_ITEM_CAPACITY ||
	     (pConfig->iEnumItemCount > 0 && pConfig->arrEnumItems == NULL &&
	      pConfig->arrEnumItemData == NULL) ||
	     !__xuiTableGridFloatFinite(pConfig->fMin) ||
	     !__xuiTableGridFloatFinite(pConfig->fMax) ||
	     !__xuiTableGridFloatFinite(pConfig->fStep) || pConfig->fStep < 0.0f ||
	     (pConfig->fMin != pConfig->fMax && pConfig->fMin > pConfig->fMax) ||
	     pConfig->iPrecision < -1 || pConfig->iPrecision > 9 ||
	     (pConfig->bDateModeSet && !__xuiTableGridDateModeValid(pConfig->iDateMode)) ||
	     pConfig->tDefaultRangeSpan < 0 ||
	     (pConfig->bDateHasMin && pConfig->bDateHasMax && pConfig->tDateMin > pConfig->tDateMax) ||
	     pConfig->iPaletteCount < 0 ||
	     pConfig->iPaletteCount > XUI_COLOR_PICKER_PALETTE_CAPACITY ||
	     (pConfig->iPaletteCount > 0 && pConfig->arrPalette == NULL) ) return 0;
	return 1;
}

static int __xuiTableGridTableContext(xui_widget pTable, int iPart, int iRow, int iColumn,
	float fX, float fY, void* pUser)
{
	xui_table_grid_data_t* pData = (xui_table_grid_data_t*)pUser;
	xui_widget pWidget = (pTable != NULL) ? xuiWidgetGetParent(pTable) : NULL;
	if ( pData == NULL || pWidget == NULL || pData->onContext == NULL ) return XUI_OK;
	return __xuiOwnedInvoke_xuiTableGridSetContextMenu(pWidget,pData,pData->onContext,pData->pContextUser ,iPart,iRow,iColumn,fX,fY);
}

static int __xuiTableGridTextEqualNoCase(const char* sA, const char* sB)
{
	unsigned char a;
	unsigned char b;

	if ( sA == NULL || sB == NULL ) {
		return sA == sB;
	}
	while ( (*sA != '\0') && (*sB != '\0') ) {
		a = (unsigned char)*sA++;
		b = (unsigned char)*sB++;
		if ( a >= 'A' && a <= 'Z' ) a = (unsigned char)(a - 'A' + 'a');
		if ( b >= 'A' && b <= 'Z' ) b = (unsigned char)(b - 'A' + 'a');
		if ( a != b ) return 0;
	}
	return *sA == *sB;
}

static int __xuiTableGridDescValid(const xui_table_grid_desc_t* pDesc)
{
	int i;

	if ( pDesc == NULL ) {
		return 1;
	}
	if ( (pDesc->iSize != 0) && (pDesc->iSize < sizeof(*pDesc)) ) {
		return 0;
	}
	if ( (pDesc->iColumnCount < 0) || (pDesc->iRowCount < 0) ||
	     (pDesc->iColumnCount > XUI_TABLE_VIEW_COLUMN_CAPACITY) ||
	     ((pDesc->iColumnCount > 0) && (pDesc->arrColumns == NULL)) ||
	     !__xuiTableGridSelectionModeValid(pDesc->iSelectionMode) ||
	     !__xuiTableGridEditModeValid(pDesc->iEditMode) ||
	     !__xuiTableGridScrollbarModeValid(pDesc->iScrollbarMode) ) {
		return 0;
	}
	if ( ((pDesc->fDefaultColumnWidth != 0.0f) && !__xuiTableGridFloatValid(pDesc->fDefaultColumnWidth)) ||
	     ((pDesc->fDefaultRowHeight != 0.0f) && !__xuiTableGridFloatValid(pDesc->fDefaultRowHeight)) ||
	     ((pDesc->fHeaderHeight != 0.0f) && !__xuiTableGridFloatValid(pDesc->fHeaderHeight)) ) return 0;
	for ( i = 0; i < pDesc->iColumnCount; i++ ) {
		if ( !__xuiTableGridColumnValid(&pDesc->arrColumns[i]) ) return 0;
	}
	if ( pDesc->arrRows != NULL ) {
		for ( i = 0; i < pDesc->iRowCount; i++ ) {
			if ( !__xuiTableGridFloatValid(pDesc->arrRows[i].fHeight) ) return 0;
		}
	}
	return 1;
}

static int __xuiTableGridEditModeValid(int iMode)
{
	return (iMode == XUI_TABLE_GRID_EDIT_DISPLAY) ||
	       (iMode == XUI_TABLE_GRID_EDIT_QUICK) ||
	       (iMode == XUI_TABLE_GRID_EDIT_IMMEDIATE);
}

static int __xuiTableGridIsNumericType(int iType)
{
	return (iType == XUI_TABLE_CELL_TYPE_INT) || (iType == XUI_TABLE_CELL_TYPE_FLOAT);
}

static int __xuiTableGridIsPickerType(int iType)
{
	return (iType == XUI_TABLE_CELL_TYPE_PICKER) ||
	       (iType == XUI_TABLE_CELL_TYPE_FILE) ||
	       (iType == XUI_TABLE_CELL_TYPE_IMAGE);
}

static int __xuiTableGridIsDateType(int iType)
{
	return (iType == XUI_TABLE_CELL_TYPE_DATE) ||
	       (iType == XUI_TABLE_CELL_TYPE_TIME) ||
	       (iType == XUI_TABLE_CELL_TYPE_DATETIME);
}

static int __xuiTableGridBoolValue(const char* sText, const void* pValue)
{
	if ( pValue != NULL ) {
		return ((intptr_t)pValue) != 0;
	}
	if ( sText == NULL ) {
		return 0;
	}
	return (strcmp(sText, "1") == 0) ||
	       __xuiTableGridTextEqualNoCase(sText, "true") ||
	       __xuiTableGridTextEqualNoCase(sText, "yes") ||
	       __xuiTableGridTextEqualNoCase(sText, "on");
}

static int __xuiTableGridValidateNumberText(const char* sText, int iType)
{
	int i;
	int iDot;

	if ( sText == NULL || sText[0] == '\0' ) {
		return 1;
	}
	i = 0;
	if ( sText[i] == '-' || sText[i] == '+' ) {
		i++;
	}
	iDot = 0;
	for ( ; sText[i] != '\0'; i++ ) {
		if ( sText[i] >= '0' && sText[i] <= '9' ) {
			continue;
		}
		if ( (iType == XUI_TABLE_CELL_TYPE_FLOAT) && (sText[i] == '.') && (iDot == 0) ) {
			iDot = 1;
			continue;
		}
		return 0;
	}
	return 1;
}

static int __xuiTableGridInferPrecision(const char* sText, int iType)
{
	const char* pDot;
	int iPrecision;

	if ( iType == XUI_TABLE_CELL_TYPE_INT ) {
		return 0;
	}
	if ( sText == NULL ) {
		return 3;
	}
	pDot = strchr(sText, '.');
	if ( pDot == NULL ) {
		return 3;
	}
	iPrecision = 0;
	pDot++;
	while ( (*pDot >= '0') && (*pDot <= '9') && (iPrecision < 6) ) {
		iPrecision++;
		pDot++;
	}
	return iPrecision;
}

static float __xuiTableGridStepForPrecision(int iPrecision)
{
	float fStep;
	int i;

	if ( iPrecision <= 0 ) {
		return 1.0f;
	}
	fStep = 1.0f;
	for ( i = 0; i < iPrecision; i++ ) {
		fStep *= 0.1f;
	}
	return fStep;
}

static int __xuiTableGridDateModeForType(int iType)
{
	if ( iType == XUI_TABLE_CELL_TYPE_TIME ) {
		return XUI_DATE_PICKER_MODE_TIME;
	}
	if ( iType == XUI_TABLE_CELL_TYPE_DATETIME ) {
		return XUI_DATE_PICKER_MODE_DATETIME;
	}
	return XUI_DATE_PICKER_MODE_DATE;
}

static const char* __xuiTableGridDefaultDateFormat(int iMode, int bShowSecond)
{
	switch ( iMode ) {
	case XUI_DATE_PICKER_MODE_TIME:
	case XUI_DATE_PICKER_MODE_TIME_RANGE:
		return bShowSecond ? "hh:nn:ss" : "hh:nn";
	case XUI_DATE_PICKER_MODE_DATETIME:
	case XUI_DATE_PICKER_MODE_DATETIME_RANGE:
		return bShowSecond ? "yyyy-mm-dd hh:nn:ss" : "yyyy-mm-dd hh:nn";
	case XUI_DATE_PICKER_MODE_DATE:
	case XUI_DATE_PICKER_MODE_DATE_RANGE:
	default:
		return "yyyy-mm-dd";
	}
}

static xui_widget __xuiTableGridActiveEditor(const xui_table_grid_data_t* pData)
{
	if ( pData == NULL ) {
		return NULL;
	}
	switch ( pData->iActiveEditor ) {
	case XUI_TABLE_GRID_EDITOR_INPUT: return pData->pInput;
	case XUI_TABLE_GRID_EDITOR_NUMERIC: return pData->pNumeric;
	case XUI_TABLE_GRID_EDITOR_COMBO: return pData->pCombo;
	case XUI_TABLE_GRID_EDITOR_COLOR: return pData->pColor;
	case XUI_TABLE_GRID_EDITOR_DATE: return pData->pDate;
	default: return NULL;
	}
}

static int __xuiTableGridCellRectWorld(xui_widget pWidget, xui_table_grid_data_t* pData, int iRow, int iColumn, xui_rect_t* pRect)
{
	xui_rect_t tTable;
	xui_rect_t tCell;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pTable == NULL) || (pRect == NULL) ) {
		return 0;
	}
	if ( xuiTableViewGetCellRect(pData->pTable, iRow, iColumn, &tCell) != XUI_OK ) {
		return 0;
	}
	tTable = xuiWidgetGetWorldRect(pData->pTable);
	tCell.fX += tTable.fX;
	tCell.fY += tTable.fY;
	*pRect = tCell;
	(void)pWidget;
	return 1;
}

static int __xuiTableGridClipEditorRect(xui_table_grid_data_t* pData, xui_rect_t* pRect)
{
	xui_rect_t tView;
	float fRight;
	float fBottom;
	float fViewRight;
	float fViewBottom;

	if ( (pData == NULL) || (pData->pTable == NULL) || (pRect == NULL) ) {
		return 0;
	}
	tView = xuiTableViewGetViewportRect(pData->pTable);
	fRight = pRect->fX + pRect->fW;
	fBottom = pRect->fY + pRect->fH;
	fViewRight = tView.fX + tView.fW;
	fViewBottom = tView.fY + tView.fH;
	if ( pRect->fX < tView.fX ) {
		pRect->fW -= tView.fX - pRect->fX;
		pRect->fX = tView.fX;
	}
	if ( pRect->fY < tView.fY ) {
		pRect->fH -= tView.fY - pRect->fY;
		pRect->fY = tView.fY;
	}
	if ( fRight > fViewRight ) {
		pRect->fW -= fRight - fViewRight;
	}
	if ( fBottom > fViewBottom ) {
		pRect->fH -= fBottom - fViewBottom;
	}
	if ( pRect->fW < 0.0f ) pRect->fW = 0.0f;
	if ( pRect->fH < 0.0f ) pRect->fH = 0.0f;
	return (pRect->fW > 4.0f) && (pRect->fH > 4.0f);
}

static int __xuiTableGridEditingRect(xui_widget pWidget, xui_table_grid_data_t* pData, xui_rect_t* pRect)
{
	xui_rect_t tTable;
	xui_rect_t tCell;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pTable == NULL) || (pRect == NULL) ||
	     (pData->iEditingRow < 0) || (pData->iEditingColumn < 0) ) {
		return 0;
	}
	if ( xuiTableViewGetCellRect(pData->pTable, pData->iEditingRow, pData->iEditingColumn, &tCell) != XUI_OK ) {
		return 0;
	}
	if ( !__xuiTableGridClipEditorRect(pData, &tCell) ) {
		return 0;
	}
	tTable = xuiWidgetGetRect(pData->pTable);
	tCell.fX += tTable.fX;
	tCell.fY += tTable.fY;
	*pRect = tCell;
	return 1;
}

static int __xuiTableGridPlaceEditor(xui_widget pWidget, xui_table_grid_data_t* pData, xui_widget pEditor, xui_rect_t tRect)
{
	int iRet;

	(void)pWidget;
	(void)pData;
	if ( pEditor == NULL ) {
		return XUI_ERROR_INVALID_ARGUMENT;
	}
	tRect = xuiInternalSnapRect(tRect);
	iRet = xuiWidgetSetRect(pEditor, tRect);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiWidgetSetVisible(pEditor, 1);
	if ( iRet != XUI_OK ) return iRet;
	/* The editor remains an absolute child of the grid. Arranging it as a
	 * standalone root would discard its parent-relative item coordinates. */
	return XUI_OK;
}

static int __xuiTableGridSetEditorLayerTree(xui_widget pWidget, int iLayer, int iZIndex)
{
	xui_widget pChild;
	int iRet;

	if ( pWidget == NULL ) {
		return XUI_OK;
	}
	iRet = xuiWidgetSetLayer(pWidget, iLayer, iZIndex);
	if ( iRet != XUI_OK ) {
		return iRet;
	}
	for ( pChild = xuiWidgetGetFirstChild(pWidget); pChild != NULL; pChild = xuiWidgetGetNextSibling(pChild) ) {
		iRet = __xuiTableGridSetEditorLayerTree(pChild, iLayer, iZIndex);
		if ( iRet != XUI_OK ) {
			return iRet;
		}
	}
	return XUI_OK;
}

static void __xuiTableGridHideEditors(xui_table_grid_data_t* pData)
{
	if ( pData == NULL ) {
		return;
	}
	if ( pData->pInput != NULL ) (void)xuiWidgetSetVisible(pData->pInput, 0);
	if ( pData->pNumeric != NULL ) (void)xuiWidgetSetVisible(pData->pNumeric, 0);
	if ( pData->pCombo != NULL ) {
		(void)xuiComboBoxClose(pData->pCombo);
		(void)xuiWidgetSetVisible(pData->pCombo, 0);
	}
	if ( pData->pColor != NULL ) {
		(void)xuiColorPickerClose(pData->pColor);
		(void)xuiWidgetSetVisible(pData->pColor, 0);
	}
	if ( pData->pDate != NULL ) {
		(void)xuiDatePickerClose(pData->pDate);
		(void)xuiWidgetSetVisible(pData->pDate, 0);
	}
	if ( pData->pTextPopup != NULL ) {
		(void)xuiPopupSetOpen(pData->pTextPopup, 0);
	}
}

static int __xuiTableGridEditorPopupOpen(xui_table_grid_data_t* pData)
{
	if ( pData == NULL ) return 0;
	if ( (pData->iActiveEditor == XUI_TABLE_GRID_EDITOR_COMBO) && xuiComboBoxIsOpen(pData->pCombo) ) return 1;
	if ( (pData->iActiveEditor == XUI_TABLE_GRID_EDITOR_COLOR) && xuiColorPickerIsOpen(pData->pColor) ) return 1;
	if ( (pData->iActiveEditor == XUI_TABLE_GRID_EDITOR_DATE) && xuiDatePickerIsOpen(pData->pDate) ) return 1;
	if ( (pData->iActiveEditor == XUI_TABLE_GRID_EDITOR_TEXTAREA) && xuiPopupIsOpen(pData->pTextPopup) ) return 1;
	return 0;
}

static int __xuiTableGridPointInWidget(xui_widget pWidget, float fX, float fY)
{
	xui_rect_t tRect;

	if ( pWidget == NULL || !xuiWidgetGetVisible(pWidget) ) {
		return 0;
	}
	tRect = xuiWidgetGetWorldRect(pWidget);
	return (fX >= tRect.fX) && (fY >= tRect.fY) && (fX < tRect.fX + tRect.fW) && (fY < tRect.fY + tRect.fH);
}

static int __xuiTableGridWidgetContains(xui_widget pAncestor, xui_widget pWidget)
{
	xui_widget pScan;

	if ( pAncestor == NULL || pWidget == NULL ) {
		return 0;
	}
	for ( pScan = pWidget; pScan != NULL; pScan = xuiWidgetGetParent(pScan) ) {
		if ( pScan == pAncestor ) {
			return 1;
		}
	}
	return 0;
}

static int __xuiTableGridEventInActiveEditor(xui_widget pWidget, xui_table_grid_data_t* pData, const xui_event_t* pEvent)
{
	xui_widget pEditor;
	xui_widget pCapture;

	if ( (pWidget == NULL) || (pData == NULL) || (pEvent == NULL) || (pData->iEditingRow < 0) ) {
		return 0;
	}
	pEditor = __xuiTableGridActiveEditor(pData);
	if ( pEditor == NULL ) {
		return 0;
	}
	if ( __xuiTableGridPointInWidget(pEditor, pEvent->fX, pEvent->fY) ) {
		return 1;
	}
	/* Text selection may release outside the editor while the input still owns pointer capture. */
	pCapture = xuiGetPointerCaptureEx(xuiWidgetGetContext(pWidget),
		pEvent->iPointerId, pEvent->iPointerType);
	return __xuiTableGridWidgetContains(pEditor, pCapture);
}

static void __xuiTableGridDefaultCell(xui_table_grid_data_t* pData, int iColumn, xui_table_view_cell_t* pCell)
{
	const xui_table_view_column_t* pColumn;

	if ( pCell == NULL ) return;
	memset(pCell, 0, sizeof(*pCell));
	pCell->iRowSpan = 1;
	pCell->iColSpan = 1;
	pCell->iType = XUI_TABLE_CELL_TYPE_TEXT;
	if ( (pData != NULL) && (pData->pTable != NULL) && (iColumn >= 0) ) {
		pColumn = xuiTableViewGetColumn(pData->pTable, iColumn);
		if ( pColumn != NULL ) {
			pCell->iType = pColumn->iType;
		}
	}
}

typedef struct xui_table_grid_cell_lease_t {
    xui_table_view_cell_output_t output;
    xui_table_cell_format_t format;
    xui_context context;
    uint64_t generation;
    bool owned,reading;
} xui_table_grid_cell_lease_t;
static void __xuiTableGridRecordFailure(xui_context context,int status);
static void __xuiTableGridOutcome(int next,int* status,xerror** first)
{
    xerror* error=xrtTakeError();
    if(next==XUI_OK && !error)return;
    if(*status==XUI_OK){*status=next!=XUI_OK ? next:XUI_ERROR_CALLBACK_FAILED;*first=error;}
    else xrtErrorFree(error);
}
static int __xuiTableGridCellEnd(xui_table_grid_cell_lease_t* lease,int status)
{
    xerror* first=xrtTakeError();
    if(status==XUI_OK && first)status=XUI_ERROR_CALLBACK_FAILED;
    if(lease->format.context){status=xuiInternalTableCellFormatEndOutcome(&lease->format,status,first);first=xrtTakeError();}
    if(lease->reading){lease->reading=false;xuiInternalContextCleanupOutcome(lease->context,xuiInternalTableCellReadEnd(&lease->output),&status,&first);}
    if(lease->owned){lease->owned=false;xuiInternalContextCleanupOutcome(lease->context,xuiTableViewCellOutputDisposeChecked(&lease->output),&status,&first);}
    memset(lease,0,sizeof(*lease));xrtSetErrorTake(first);return status;
}
static int __xuiTableGridGetCell(xui_widget pWidget, xui_table_grid_data_t* pData, int iRow, int iColumn, xui_table_view_cell_t* pCell, xui_table_grid_cell_lease_t* lease)
{
	xui_table_view_cell_proc onCell;
	void* pUser;

	__xuiTableGridDefaultCell(pData, iColumn, pCell);
	if ( (pData == NULL) || (pCell == NULL) || (iRow < 0) || (iColumn < 0) ) {
		return 0;
	}
    if(pData->bAdapterOwned || pData->onEditorOwned){
        lease->owned=true;lease->context=xuiWidgetGetContext(pWidget);lease->generation=pData->iAdapterGeneration;
        xuiTableViewCellOutputInit(&lease->output);
        int status=xuiTableViewGetCellOwned(pData->pTable,iRow,iColumn,&lease->output);
        if(status==XUI_OK && (!__xuiTableGridWidgetAlive(pWidget,pData) || pData->iAdapterGeneration!=lease->generation))status=XUI_ERROR_INVALID_STATE;
        if(status==XUI_OK)status=xuiInternalTableCellReadBegin(&lease->output);
        if(status!=XUI_OK){(void)__xuiTableGridCellEnd(lease,status);return 0;}
        lease->reading=true;xuiInternalTableCellProject(pCell,&lease->output);return 1;
    }
	onCell = pData->onCell;
	pUser = pData->pAdapterUser;
	if ( onCell != NULL ) {
		(void)onCell(pWidget, iRow, iColumn, pCell, pUser);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return 0;
	}
	if ( pCell->iRowSpan <= 0 ) pCell->iRowSpan = 1;
	if ( pCell->iColSpan <= 0 ) pCell->iColSpan = 1;
	return 1;
}

static const char* __xuiTableGridCellText(xui_widget pWidget, xui_table_grid_data_t* pData, int iRow, int iColumn, const xui_table_view_cell_t* pCell, xui_table_grid_cell_lease_t* lease, char* sBuffer, int iCapacity)
{
	xui_table_view_format_proc onFormat;
	void* pUser;
	const xui_table_view_column_t* pColumn;
	int iValue;

	if ( (sBuffer == NULL) || (iCapacity <= 0) ) return "";
	sBuffer[0] = '\0';
	if ( pCell == NULL ) return sBuffer;
	if ( !lease->owned && pCell->sText != NULL ) {
		snprintf(sBuffer, (size_t)iCapacity, "%s", pCell->sText);
		sBuffer[iCapacity - 1] = '\0';
		return sBuffer;
	}
    if(lease->owned){
        int status=xuiInternalTableCellFormatBegin(pWidget,iRow,iColumn,&lease->output,&lease->format);
        if(status==XUI_OK && (!__xuiTableGridWidgetAlive(pWidget,pData) || pData->iAdapterGeneration!=lease->generation))status=XUI_ERROR_INVALID_STATE;
        xstrview text=lease->format.text;
        if(status==XUI_OK && !text.Size){
            const xvalue* value=xuiTableViewCellOutputGetValue(&lease->output);
            if(value){
                switch(xrtValueType(value)){
                case XVALUE_BOOL:{bool valueBool=false;if(!xrtValueGetBool(value,&valueBool))status=XUI_ERROR_INVALID_STATE;else snprintf(sBuffer,(size_t)iCapacity,"%s",valueBool ? "true":"false");break;}
                case XVALUE_INT:{int64 valueInt=0;if(!xrtValueGetInt(value,&valueInt))status=XUI_ERROR_INVALID_STATE;else snprintf(sBuffer,(size_t)iCapacity,"%lld",(long long)valueInt);break;}
                case XVALUE_UINT:{uint64 valueUInt=0;if(!xrtValueGetUInt(value,&valueUInt))status=XUI_ERROR_INVALID_STATE;else snprintf(sBuffer,(size_t)iCapacity,"%llu",(unsigned long long)valueUInt);break;}
                case XVALUE_FLOAT:{double valueFloat=0;if(!xrtValueGetFloat(value,&valueFloat))status=XUI_ERROR_INVALID_STATE;else snprintf(sBuffer,(size_t)iCapacity,"%.17g",valueFloat);break;}
                case XVALUE_STRING:if(!xrtValueGetString(value,&text))status=XUI_ERROR_INVALID_STATE;break;
                case XVALUE_NULL:break;
                default:status=XUI_ERROR_UNSUPPORTED;break;
                }
            }
        }
        if(status==XUI_OK && text.Size){
            if(!text.Data || text.Size>=(size_t)iCapacity || memchr(text.Data,0,text.Size))status=XUI_ERROR_LIMIT_EXCEEDED;
            else{memcpy(sBuffer,text.Data,text.Size);sBuffer[text.Size]=0;}
        }
        if(status!=XUI_OK){__xuiTableGridRecordFailure(lease->context,status);return NULL;}
        return sBuffer;
    }
	onFormat = pCell->onFormat;
	pUser = pCell->pFormatUser;
	if ( onFormat == NULL && pData != NULL && pData->pTable != NULL ) {
		pColumn = xuiTableViewGetColumn(pData->pTable, iColumn);
		if ( pColumn != NULL ) {
			onFormat = pColumn->onFormat;
			pUser = pColumn->pFormatUser;
		}
	}
	if ( onFormat != NULL && onFormat(pWidget, iRow, iColumn, pCell, sBuffer, iCapacity, pUser) != 0 ) {
		sBuffer[iCapacity - 1] = '\0';
		return sBuffer;
	}
	if ( pCell->pValue != NULL ) {
		iValue = (int)(intptr_t)pCell->pValue;
		if ( pCell->iType == XUI_TABLE_CELL_TYPE_BOOL ) {
			snprintf(sBuffer, (size_t)iCapacity, "%s", iValue ? "true" : "false");
		} else {
			snprintf(sBuffer, (size_t)iCapacity, "%d", iValue);
		}
		sBuffer[iCapacity - 1] = '\0';
	}
	return sBuffer;
}

static void __xuiTableGridDefaultEditorConfig(xui_table_grid_editor_config_t* pConfig, int iType)
{
	if ( pConfig == NULL ) return;
	memset(pConfig, 0, sizeof(*pConfig));
	pConfig->iEnumSelected = -1;
	pConfig->iPrecision = -1;
	pConfig->iDateMode = __xuiTableGridDateModeForType(iType);
	pConfig->bShowSecond = 1;
	pConfig->sRangeSeparator = " - ";
}

static int __xuiTableGridLoadEditorConfig(xui_widget widget,xui_table_grid_data_t* data,int row,int column,int type)
{
    if(!data)return 0;
    xui_context context=xuiWidgetGetContext(widget);
    __xuiTableGridDefaultEditorConfig(&data->tEditorConfig,type);
    if(data->onEditorConfigOwned || data->onEditorOwned){
        xuiTableGridEditorConfigOutputDispose(&data->tOwnedEditorConfig);
        data->tOwnedEditorConfig.iDateMode=__xuiTableGridDateModeForType(type);
        xui_table_grid_editor_config_owned_proc selected=data->onEditorConfigOwned;
        if(selected){
            void* user=data->pEditorConfigOwnedUser;xui_callback_snapshot_t snapshot={0};
            int status=xuiInternalCallbackSnapshotBeginReported(widget,&data->onEditorConfigOwned,&user,&snapshot);
            if(status==XUI_OK){int result=selected(widget,row,column,type,&data->tOwnedEditorConfig,user);if(result!=XUI_OK)status=result<0 ? result:XUI_ERROR_INVALID_ARGUMENT;}
            status=xuiInternalCallbackSnapshotEnd(&snapshot,status);
            if(status!=XUI_OK){__xuiTableGridRecordFailure(context,status);return 0;}
            if(!__xuiTableGridWidgetAlive(widget,data))return 0;
        }
        xuiInternalTableGridConfigProject(&data->tOwnedEditorConfig,&data->tEditorConfig);
        if(!__xuiTableGridEditorConfigValid(&data->tEditorConfig)){
            __xuiTableGridRecordFailure(context,XUI_ERROR_INVALID_ARGUMENT);return 0;
        }
        return 1;
    }
    if(data->onEditorConfig){
        int result=data->onEditorConfig(widget,row,column,type,&data->tEditorConfig,data->pEditorConfigUser);
        if(result<0 || !__xuiTableGridWidgetAlive(widget,data))return 0;
    }
    return __xuiTableGridEditorConfigValid(&data->tEditorConfig);
}

static xtime __xuiTableGridParseDateValue(const char* sText, int iType, const char* sFormat)
{
	xtime tValue;
	int iYear;
	int iMonth;
	int iDay;
	int iHour;
	int iMinute;
	int iSecond;

	if ( sText == NULL || sText[0] == '\0' ) {
		return xrtNow();
	}
	if ( sFormat != NULL && sFormat[0] != '\0' ) {
		if ( xuiXrtTryTimeParse(sText,sFormat,&tValue) ) return tValue;
	}
	iYear = 0;
	iMonth = 0;
	iDay = 0;
	iHour = 0;
	iMinute = 0;
	iSecond = 0;
	if ( iType == XUI_TABLE_CELL_TYPE_TIME ) {
		if ( sscanf(sText, "%d:%d:%d", &iHour, &iMinute, &iSecond) >= 2 ) {
			return (xtime)iHour * XRT_TIME_HOUR + (xtime)iMinute * XRT_TIME_MINUTE + (xtime)iSecond * XRT_TIME_SECOND;
		}
		return xrtNow();
	}
	if ( iType == XUI_TABLE_CELL_TYPE_DATETIME ) {
		if ( sscanf(sText, "%d-%d-%d %d:%d:%d", &iYear, &iMonth, &iDay, &iHour, &iMinute, &iSecond) >= 5 ) {
			return xuiXrtDateSerial(iYear, iMonth, iDay) + (xtime)iHour * XRT_TIME_HOUR + (xtime)iMinute * XRT_TIME_MINUTE + (xtime)iSecond * XRT_TIME_SECOND;
		}
	}
	if ( sscanf(sText, "%d-%d-%d", &iYear, &iMonth, &iDay) == 3 ) {
		return xuiXrtDateSerial(iYear, iMonth, iDay);
	}
	return xrtNow();
}

static const char* __xuiTableGridCurrentEditorValue(xui_table_grid_data_t* pData, char* sBuffer, int iCapacity)
{
	const char* sText;
	const xui_combobox_item_t* pItem;
	int iIndex;

	if ( (sBuffer == NULL) || (iCapacity <= 0) ) return "";
	sBuffer[0] = '\0';
	if ( pData == NULL ) return sBuffer;
	if ( pData->iActiveEditor == XUI_TABLE_GRID_EDITOR_TEXTAREA ) {
		sText = xuiTextEditGetText(pData->pTextEdit);
		return (sText != NULL) ? sText : "";
	}
	switch ( pData->iActiveEditor ) {
	case XUI_TABLE_GRID_EDITOR_COMBO:
		iIndex = xuiComboBoxGetSelected(pData->pCombo);
		if ( pData->tEditorConfig.bEnumUseValue ) {
			snprintf(sBuffer, (size_t)iCapacity, "%d", xuiComboBoxGetSelectedValue(pData->pCombo));
		} else {
			pItem = xuiComboBoxGetItem(pData->pCombo, iIndex);
			snprintf(sBuffer, (size_t)iCapacity, "%s", (pItem != NULL && pItem->sText != NULL) ? pItem->sText : "");
		}
		sBuffer[iCapacity - 1] = '\0';
		return sBuffer;
	case XUI_TABLE_GRID_EDITOR_COLOR:
		sText = xuiColorPickerGetHex(pData->pColor);
		return (sText != NULL) ? sText : "";
	case XUI_TABLE_GRID_EDITOR_DATE:
		sText = xuiDatePickerGetText(pData->pDate);
		return (sText != NULL) ? sText : "";
	case XUI_TABLE_GRID_EDITOR_NUMERIC:
		(void)xuiNumericInputCommit(pData->pNumeric);
		sText = xuiNumericInputGetText(pData->pNumeric);
		return (sText != NULL) ? sText : "";
	case XUI_TABLE_GRID_EDITOR_INPUT:
	default:
		sText = xuiInputGetText(pData->pInput);
		return (sText != NULL) ? sText : "";
	}
}

static void __xuiTableGridClearEditState(xui_table_grid_data_t* pData)
{
	if ( pData == NULL ) return;
	pData->iEditingRow = -1;
	pData->iEditingColumn = -1;
	pData->iEditingType = XUI_TABLE_CELL_TYPE_TEXT;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
	pData->sOriginalValue[0] = '\0';
}

static int __xuiTableGridCommitValue(xui_widget pWidget, xui_table_grid_data_t* pData, const char* sValue)
{
	xui_table_grid_validate_proc onValidate;
	xui_table_grid_set_proc onSet;
	xui_table_grid_change_proc onChange;
	void* pValidateUser;
	void* pSetUser;
	xui_widget pInput;
	char sStable[XUI_TABLE_GRID_VALUE_CAPACITY];
	int iRow;
	int iColumn;
	int iType;
	int iActiveEditor;
	int bAccepted;
	int bChanged;
    uint64_t adapterGeneration;bool ownedAdapter;

	if ( pData == NULL || pData->bCommitting ) return 0;
	snprintf(sStable, sizeof(sStable), "%s", (sValue != NULL) ? sValue : "");
	sStable[sizeof(sStable) - 1] = '\0';
	iRow = pData->iEditingRow;
	iColumn = pData->iEditingColumn;
	iType = pData->iEditingType;
	iActiveEditor = pData->iActiveEditor;
    ownedAdapter=pData->bAdapterOwned;adapterGeneration=pData->iAdapterGeneration;
	onValidate = pData->onValidate;
	pValidateUser = pData->pValidateUser;
	onSet = pData->onSet;
	pSetUser = pData->pSetUser;
	onChange = pData->onChange;
	bChanged = strcmp(pData->sOriginalValue, sStable) != 0;
	pData->bCommitting = 1;
	if ( onValidate != NULL ) {
        xui_callback_snapshot_t validateSnapshot={0};
        int status=xuiInternalCallbackSnapshotBeginReported(pWidget,&pData->onValidate,&pValidateUser,&validateSnapshot);
        bool ownedValidate=validateSnapshot.pContext!=NULL;
        bAccepted=status==XUI_OK ? onValidate(pWidget,iRow,iColumn,sStable,iType,pValidateUser):0;
        if(ownedValidate && bAccepted<0){status=bAccepted;bAccepted=0;}
        status=xuiInternalCallbackSnapshotEnd(&validateSnapshot,status);
        if(status!=XUI_OK){__xuiTableGridRecordFailure(xuiWidgetGetContext(pWidget),status);bAccepted=0;}
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return 1;
		if ( bAccepted == 0 ) {
			pData->bCommitting = 0;
			pData->iRejectCount++;
			if ( iActiveEditor == XUI_TABLE_GRID_EDITOR_INPUT && pData->pInput != NULL ) {
				(void)xuiInputSetError(pData->pInput, 1);
			} else if ( iActiveEditor == XUI_TABLE_GRID_EDITOR_NUMERIC && pData->pNumeric != NULL ) {
				pInput = xuiNumericInputGetInputWidget(pData->pNumeric);
				if ( pInput != NULL ) (void)xuiInputSetError(pInput, 1);
			}
			return 0;
		}
	}
    if(ownedAdapter && (!pData->bAdapterOwned || pData->iAdapterGeneration!=adapterGeneration)){
        pData->bCommitting=0;return 0;
    }
	if ( bChanged ) {
        if(ownedAdapter && pData->onSetOwned){
            XUI_INTERNAL_CALLBACK_VOID(pWidget,pData->onSetOwned,xui_table_grid_set_proc,pData->pSetOwnedUser,pWidget,iRow,iColumn,sStable,iType);
            if(!__xuiTableGridWidgetAlive(pWidget,pData))return 1;
        }
		if ( !ownedAdapter && onSet != NULL ) {
			onSet(pWidget, iRow, iColumn, sStable, iType, pSetUser);
			if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return 1;
		}
		pData->iCommitCount++;
		pData->iChangeCount++;
		if ( onChange != NULL ) {
			XUI_INTERNAL_CALLBACK_VOID(pWidget, pData->onChange, xui_table_grid_change_proc, pData->pChangeUser, pWidget, iRow, iColumn, sStable, iType);
			if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return 1;
		}
	}
	pData->bCommitting = 0;
	return 1;
}

static int __xuiTableGridSyncActiveEditorRect(xui_widget pWidget, xui_table_grid_data_t* pData)
{
	xui_widget pEditor;
	xui_rect_t tRect;

	if ( (pData == NULL) || (pData->iEditingRow < 0) || (pData->iEditingColumn < 0) ) {
		return 0;
	}
	pEditor = __xuiTableGridActiveEditor(pData);
	if ( pEditor == NULL ) {
		if ( (pData->iActiveEditor == XUI_TABLE_GRID_EDITOR_TEXTAREA) &&
		     (pData->pTextPopup != NULL) &&
		     xuiPopupIsOpen(pData->pTextPopup) &&
		     __xuiTableGridCellRectWorld(pWidget, pData, pData->iEditingRow, pData->iEditingColumn, &tRect) ) {
			(void)xuiPopupSetAnchorRect(pData->pTextPopup, tRect);
		}
		return 0;
	}
	if ( !__xuiTableGridEditingRect(pWidget, pData, &tRect) ) {
		(void)xuiWidgetSetVisible(pEditor, 0);
		return 0;
	}
	(void)__xuiTableGridPlaceEditor(pWidget, pData, pEditor, tRect);
	return 1;
}

static void __xuiTableGridRecordFailure(xui_context context,int status)
{xuiInternalContextRecordFailure(context,status);}
static int __xuiTableGridOwnedCount(xui_widget table,void* user)
{
    xui_table_grid_data_t* data=user;xui_widget widget=xuiWidgetGetParent(table);
    if(!__xuiTableGridWidgetAlive(widget,data))return XUI_ERROR_INVALID_STATE;
    xui_table_view_count_proc selected=data->onCountOwned;void* selectedUser=data->pCountOwnedUser;
    if(!selected)return 0;
    uint64_t generation=data->iAdapterGeneration;xui_callback_snapshot_t snapshot={0};
    int status=xuiInternalCallbackSnapshotBeginReturned(widget,&data->onCountOwned,&selectedUser,&snapshot);
    int count=0;
    if(status==XUI_OK && (!__xuiTableGridWidgetAlive(widget,data) || data->iAdapterGeneration!=generation))status=XUI_ERROR_INVALID_STATE;
    if(status==XUI_OK){count=selected(widget,selectedUser);if(count<0)status=count;}
    if(status==XUI_OK && (!__xuiTableGridWidgetAlive(widget,data) || data->iAdapterGeneration!=generation))status=XUI_ERROR_INVALID_STATE;
    status=xuiInternalCallbackSnapshotEnd(&snapshot,status);
    return status!=XUI_OK ? status:count;
}
static int __xuiTableGridOwnedCell(xui_widget table,int row,int column,xui_table_view_cell_output_t* output,void* user)
{
    xui_table_grid_data_t* data=user;xui_widget widget=xuiWidgetGetParent(table);
    if(!__xuiTableGridWidgetAlive(widget,data))return XUI_ERROR_INVALID_STATE;
    xui_table_view_cell_owned_proc selected=data->onCellOwned;void* selectedUser=data->pCellOwnedUser;
    uint64_t generation=data->iAdapterGeneration;xui_callback_snapshot_t snapshot={0};int status=XUI_OK;
    if(selected){
        status=xuiInternalCallbackSnapshotBeginReturned(widget,&data->onCellOwned,&selectedUser,&snapshot);
        if(status==XUI_OK && (!__xuiTableGridWidgetAlive(widget,data) || data->iAdapterGeneration!=generation))status=XUI_ERROR_INVALID_STATE;
        if(status==XUI_OK){int result=selected(widget,row,column,output,selectedUser);if(result<0)status=result;}
    }
    if(status==XUI_OK && (!__xuiTableGridWidgetAlive(widget,data) || data->iAdapterGeneration!=generation))status=XUI_ERROR_INVALID_STATE;
    if(status==XUI_OK && data->iEditingRow==row && data->iEditingColumn==column)output->bEditing=1;
    /* Output now owns every nontrivial field. The language thunk has physically
     * returned; no pointer into its temporary strings is forwarded to Table. */
    return xuiInternalCallbackSnapshotEnd(&snapshot,status);
}
static int __xuiTableGridCountProc(xui_widget pTable, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pWidget;

	pData = (xui_table_grid_data_t*)pUser;
	pWidget = (pTable != NULL) ? xuiWidgetGetParent(pTable) : NULL;
	if ( (pData == NULL) || (pData->onCount == NULL) ) {
		return 0;
	}
	return pData->onCount(pWidget, pData->pAdapterUser);
}

static int __xuiTableGridCellProc(xui_widget pTable, int iRow, int iColumn, xui_table_view_cell_t* pCell, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pWidget;
	int iRet;

	pData = (xui_table_grid_data_t*)pUser;
	pWidget = (pTable != NULL) ? xuiWidgetGetParent(pTable) : NULL;
	if ( (pData == NULL) || (pCell == NULL) ) {
		return XUI_ERROR_INVALID_ARGUMENT;
	}
	__xuiTableGridDefaultCell(pData, iColumn, pCell);
	iRet = 1;
	if ( pData->onCell != NULL ) {
		iRet = pData->onCell(pWidget, iRow, iColumn, pCell, pData->pAdapterUser);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return iRet;
	}
	if ( (pData->iEditingRow == iRow) && (pData->iEditingColumn == iColumn) ) {
		pCell->bEditing = 1;
	}
	return iRet;
}

static void __xuiTableGridComboSelect(xui_widget pWidget, int iIndex, int iValue, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pGrid;

	(void)pWidget;
	(void)iIndex;
	(void)iValue;
	pData = (xui_table_grid_data_t*)pUser;
	if ( pData == NULL || pData->iActiveEditor != XUI_TABLE_GRID_EDITOR_COMBO ) return;
	pGrid = xuiWidgetGetParent(pData->pCombo);
	(void)xuiTableGridEndEdit(pGrid, 1);
}

static void __xuiTableGridColorChange(xui_widget pWidget, uint32_t iColor, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pGrid;
	char sValue[XUI_TABLE_GRID_VALUE_CAPACITY];
	const char* sHex;

	(void)pWidget;
	(void)iColor;
	pData = (xui_table_grid_data_t*)pUser;
	if ( pData == NULL || pData->iActiveEditor != XUI_TABLE_GRID_EDITOR_COLOR ) return;
	pGrid = xuiWidgetGetParent(pData->pColor);
	sHex = xuiColorPickerGetHex(pData->pColor);
	snprintf(sValue, sizeof(sValue), "%s", (sHex != NULL) ? sHex : "");
	sValue[sizeof(sValue) - 1] = '\0';
	if ( __xuiTableGridCommitValue(pGrid, pData, sValue) != 0 ) {
		if ( !__xuiTableGridWidgetAlive(pGrid, pData) ) return;
		snprintf(pData->sOriginalValue, sizeof(pData->sOriginalValue), "%s", sValue);
		(void)xuiTableViewRefresh(pData->pTable);
	}
}

static void __xuiTableGridDateCommit(xui_widget pWidget, xtime tStart, xtime tEnd, int iMode, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pGrid;

	(void)pWidget;
	(void)tStart;
	(void)tEnd;
	(void)iMode;
	pData = (xui_table_grid_data_t*)pUser;
	if ( pData == NULL || pData->iActiveEditor != XUI_TABLE_GRID_EDITOR_DATE ) return;
	pGrid = xuiWidgetGetParent(pData->pDate);
	(void)xuiTableGridEndEdit(pGrid, 1);
}

static void __xuiTableGridDateCancel(xui_widget pWidget, xtime tStart, xtime tEnd, int iMode, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pGrid;

	(void)pWidget;
	(void)tStart;
	(void)tEnd;
	(void)iMode;
	pData = (xui_table_grid_data_t*)pUser;
	if ( pData == NULL || pData->iActiveEditor != XUI_TABLE_GRID_EDITOR_DATE ) return;
	pGrid = xuiWidgetGetParent(pData->pDate);
	(void)xuiTableGridEndEdit(pGrid, 0);
}

static void __xuiTableGridTextOk(xui_widget pWidget, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pGrid;

	(void)pWidget;
	pData = (xui_table_grid_data_t*)pUser;
	if ( pData == NULL ) return;
	pGrid = xuiPopupGetOwner(pData->pTextPopup);
	(void)xuiTableGridEndEdit(pGrid, 1);
}

static void __xuiTableGridTextCancel(xui_widget pWidget, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_widget pGrid;

	(void)pWidget;
	pData = (xui_table_grid_data_t*)pUser;
	if ( pData == NULL ) return;
	pGrid = xuiPopupGetOwner(pData->pTextPopup);
	(void)xuiTableGridEndEdit(pGrid, 0);
}

static int __xuiTableGridFinishKey(xui_widget pWidget, const xui_event_t* pEvent)
{
	xui_context pContext = xuiWidgetGetContext(pWidget);
	xui_widget pTable = xuiTableGridGetTableView(pWidget);
	if ( xuiTableGridEndEdit(pWidget, pEvent->iKey != XUI_KEY_ESCAPE) &&
	     pEvent->iKey == XUI_KEY_TAB && !xuiInternalContextDestroyPending(pContext) &&
	     xuiInternalWidgetIsValid(pTable) && xuiGetFocusWidget(pContext) == pTable ) {
		/* EndEdit closes popups and restores the sole entry before traversing. */
		(void)xuiFocusNext(pContext, (pEvent->iModifiers & XUI_MOD_SHIFT) == 0);
	}
	return XUI_EVENT_DISPATCH_STOP;
}

static int __xuiTableGridOpenTextArea(xui_widget pWidget, xui_table_grid_data_t* pData)
{
	xui_rect_t tAnchor;
	float fW;
	float fH;
	int iRet;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pTextPopup == NULL) ) return 0;
	fW = 380.0f;
	fH = 238.0f;
	if ( !__xuiTableGridCellRectWorld(pWidget, pData, pData->iEditingRow, pData->iEditingColumn, &tAnchor) ) {
		tAnchor = xuiWidgetGetWorldRect(pWidget);
	}
	iRet = xuiTextEditSetText(pData->pTextEdit, pData->sOriginalValue);
	if ( iRet == XUI_OK ) iRet = xuiPopupSetOwner(pData->pTextPopup, pWidget);
	if ( iRet == XUI_OK ) iRet = xuiPopupSetFocusRestore(pData->pTextPopup, pData->pTable);
	if ( iRet == XUI_OK ) iRet = xuiPopupSetAnchorRect(pData->pTextPopup, tAnchor);
	if ( iRet == XUI_OK ) iRet = xuiPopupSetAnchor(pData->pTextPopup, XUI_POPUP_ANCHOR_BOTTOM_LEFT);
	if ( iRet == XUI_OK ) iRet = xuiPopupSetDirection(pData->pTextPopup, XUI_POPUP_DIRECTION_RIGHT_DOWN);
	if ( iRet == XUI_OK ) iRet = xuiPopupSetContentSize(pData->pTextPopup, fW, fH);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetRect(pData->pTextEdit, (xui_rect_t){10.0f, 10.0f, fW - 20.0f, fH - 58.0f});
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetRect(pData->pTextCancel, (xui_rect_t){fW - 172.0f, fH - 40.0f, 76.0f, 28.0f});
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetRect(pData->pTextOk, (xui_rect_t){fW - 88.0f, fH - 40.0f, 76.0f, 28.0f});
	if ( iRet == XUI_OK ) iRet = xuiPopupSetOpen(pData->pTextPopup, 1);
	if ( iRet != XUI_OK ) {
		(void)xuiPopupSetOpen(pData->pTextPopup, 0);
		return 0;
	}
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_TEXTAREA;
	if ( xuiSetFocusWidget(xuiWidgetGetContext(pWidget), pData->pTextEdit) != XUI_OK ) {
		(void)xuiPopupSetOpen(pData->pTextPopup, 0);
		pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
		return 0;
	}
	return 1;
}

static int __xuiTableGridOpenPicker(xui_widget pWidget, xui_table_grid_data_t* pData, xui_table_view_cell_t* pCell, xui_table_grid_cell_lease_t* lease)
{
	xui_table_grid_editor_proc onEditor;
	void* pUser;
	xui_rect_t tRect;
	int bHandled;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->onEditor == NULL && pData->onEditorOwned == NULL) || (pCell == NULL) ) {
		return 0;
	}
	if ( !__xuiTableGridCellRectWorld(pWidget, pData, pData->iEditingRow, pData->iEditingColumn, &tRect) ) {
		tRect = xuiWidgetGetWorldRect(pWidget);
	}
	onEditor = pData->onEditor;
	pUser = pData->pEditorUser;
    if(pData->onEditorOwned){
        if(!lease->owned)return 0;
        xui_table_grid_editor_owned_proc selected=pData->onEditorOwned;void* user=pData->pEditorOwnedUser;
        xui_callback_snapshot_t snapshot={0};int status=xuiInternalCallbackSnapshotBeginReported(pWidget,&pData->onEditorOwned,&user,&snapshot);
        int result=0;if(status==XUI_OK)result=selected(pWidget,pData->iEditingRow,pData->iEditingColumn,&lease->output,&pData->tOwnedEditorConfig,tRect,user);
        if(result<0)status=result;
        status=xuiInternalCallbackSnapshotEnd(&snapshot,status);
        if(status!=XUI_OK){__xuiTableGridRecordFailure(xuiWidgetGetContext(pWidget),status);return 0;}
        bHandled=result!=0;
    }else bHandled = onEditor(pWidget, pData->iEditingRow, pData->iEditingColumn, pCell, tRect, pUser) != 0;
	if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bHandled;
	if ( bHandled ) {
		pData->iPickerCount++;
		return 1;
	}
	return 0;
}

static int __xuiTableGridBeginComboEdit(xui_widget pWidget, xui_table_grid_data_t* pData, const char* sText, xui_rect_t tRect)
{
	const xui_combobox_item_t* pItem;
	int i;
	int iSelected;
	int iRet;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pCombo == NULL) ) return 0;
	if ( pData->tEditorConfig.arrEnumItemData != NULL && pData->tEditorConfig.iEnumItemCount > 0 ) {
		iRet = xuiComboBoxSetItemData(pData->pCombo, pData->tEditorConfig.arrEnumItemData, pData->tEditorConfig.iEnumItemCount);
		if ( iRet != XUI_OK ) return 0;
		if ( pData->tEditorConfig.bEnumUseValue ) {
			iRet = xuiComboBoxSetSelectedValue(pData->pCombo, pData->tEditorConfig.iEnumSelectedValue);
			if ( iRet != XUI_OK ) return 0;
		}
	} else if ( pData->tEditorConfig.arrEnumItems != NULL && pData->tEditorConfig.iEnumItemCount > 0 ) {
		iRet = xuiComboBoxSetItems(pData->pCombo, pData->tEditorConfig.arrEnumItems, pData->tEditorConfig.iEnumItemCount);
		if ( iRet != XUI_OK ) return 0;
	} else {
		return 0;
	}
	if(pData->tEditorConfig.arrEnumEnabled!=NULL){
        iRet = xuiComboBoxSetEnabledItems(pData->pCombo,pData->tEditorConfig.arrEnumEnabled,pData->tEditorConfig.iEnumItemCount);
        if(iRet!=XUI_OK)return 0;
    }
	if ( pData->tEditorConfig.bEnumUseValue && pData->tEditorConfig.arrEnumItemData != NULL ) {
		iSelected = xuiComboBoxGetSelected(pData->pCombo);
	} else {
		iSelected = pData->tEditorConfig.iEnumSelected;
		if ( iSelected < 0 && sText != NULL ) {
			for ( i = 0; i < xuiComboBoxGetItemCount(pData->pCombo); i++ ) {
				pItem = xuiComboBoxGetItem(pData->pCombo, i);
				if ( pItem != NULL && pItem->sText != NULL && strcmp(pItem->sText, sText) == 0 ) {
					iSelected = i;
					break;
				}
			}
		}
		iRet = xuiComboBoxSetSelected(pData->pCombo, iSelected);
		if ( iRet != XUI_OK ) return 0;
	}
	if ( __xuiTableGridPlaceEditor(pWidget, pData, pData->pCombo, tRect) != XUI_OK ) return 0;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_COMBO;
	if ( xuiSetFocusWidget(xuiWidgetGetContext(pWidget), pData->pCombo) != XUI_OK ) {
		(void)xuiWidgetSetVisible(pData->pCombo, 0);
		pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
		return 0;
	}
	return 1;
}

static int __xuiTableGridBeginColorEdit(xui_widget pWidget, xui_table_grid_data_t* pData, const char* sText, xui_rect_t tRect)
{
	const uint32_t* arrPalette;
	int iPaletteCount;
	int iRet;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pColor == NULL) ) return 0;
	iRet = xuiColorPickerSetAlphaEnabled(pData->pColor, pData->tEditorConfig.bAlphaEnabled);
	if ( iRet != XUI_OK ) return 0;
	if ( pData->tEditorConfig.arrPalette != NULL && pData->tEditorConfig.iPaletteCount > 0 ) {
		arrPalette = pData->tEditorConfig.arrPalette;
		iPaletteCount = pData->tEditorConfig.iPaletteCount;
	} else {
		arrPalette = pData->arrDefaultPalette;
		iPaletteCount = pData->iDefaultPaletteCount;
	}
	iRet = xuiColorPickerSetPalette(pData->pColor, arrPalette, iPaletteCount);
	if ( iRet != XUI_OK ) return 0;
	if ( xuiColorPickerSetHex(pData->pColor, sText != NULL ? sText : "") != XUI_OK ) {
		iRet = xuiColorPickerSetColor(pData->pColor, XUI_COLOR_RGBA(67, 167, 124, 255));
		if ( iRet != XUI_OK ) return 0;
	}
	if ( __xuiTableGridPlaceEditor(pWidget, pData, pData->pColor, tRect) != XUI_OK ) return 0;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_COLOR;
	if ( xuiSetFocusWidget(xuiWidgetGetContext(pWidget), pData->pColor) != XUI_OK ) {
		(void)xuiWidgetSetVisible(pData->pColor, 0);
		pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
		return 0;
	}
	return 1;
}

static int __xuiTableGridBeginDateEdit(xui_widget pWidget, xui_table_grid_data_t* pData, const char* sText, xui_rect_t tRect, int iType)
{
	const char* sFormat;
	int iMode;
	int iRet;
	xtime tValue;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pDate == NULL) ) return 0;
	iMode = pData->tEditorConfig.bDateModeSet ? pData->tEditorConfig.iDateMode : __xuiTableGridDateModeForType(iType);
	iRet = xuiDatePickerSetMode(pData->pDate, iMode);
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetNullable(pData->pDate, pData->tEditorConfig.bNullable);
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetShowSecond(pData->pDate, pData->tEditorConfig.bShowSecond);
	sFormat = (pData->tEditorConfig.sDateFormat != NULL) ? pData->tEditorConfig.sDateFormat : __xuiTableGridDefaultDateFormat(iMode, pData->tEditorConfig.bShowSecond);
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetFormat(pData->pDate, sFormat);
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetRangeSeparator(pData->pDate,
		pData->tEditorConfig.sRangeSeparator != NULL ? pData->tEditorConfig.sRangeSeparator : " - ");
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetDefaultRangeSpan(pData->pDate,
		pData->tEditorConfig.tDefaultRangeSpan);
	if ( iRet == XUI_OK && (pData->tEditorConfig.bDateHasMin || pData->tEditorConfig.bDateHasMax) ) {
		iRet = xuiDatePickerSetLimits(pData->pDate,
			pData->tEditorConfig.bDateHasMin ? pData->tEditorConfig.tDateMin : 0,
			pData->tEditorConfig.bDateHasMax ? pData->tEditorConfig.tDateMax : (xtime)XRT_TIME_DAY * (xtime)365242);
	} else if ( iRet == XUI_OK ) {
		iRet = xuiDatePickerClearLimits(pData->pDate);
	}
	if ( iRet != XUI_OK ) return 0;
	tValue = __xuiTableGridParseDateValue(sText, iType, sFormat);
	iRet = xuiDatePickerSetValue(pData->pDate, tValue);
	if ( iRet != XUI_OK || __xuiTableGridPlaceEditor(pWidget, pData, pData->pDate, tRect) != XUI_OK ) return 0;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_DATE;
	if ( xuiSetFocusWidget(xuiWidgetGetContext(pWidget), pData->pDate) != XUI_OK ) {
		(void)xuiWidgetSetVisible(pData->pDate, 0);
		pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
		return 0;
	}
	return 1;
}

static int __xuiTableGridBeginNumericEdit(xui_widget pWidget, xui_table_grid_data_t* pData, const char* sText, xui_rect_t tRect, int iType)
{
	xui_widget pInput;
	float fValue;
	float fMin;
	float fMax;
	int iPrecision;
	int iRet;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pNumeric == NULL) ) return 0;
	iPrecision = (pData->tEditorConfig.iPrecision >= 0) ? pData->tEditorConfig.iPrecision : __xuiTableGridInferPrecision(sText, iType);
	fMin = pData->tEditorConfig.fMin;
	fMax = pData->tEditorConfig.fMax;
	if ( fMin == fMax ) {
		fMin = -1000000000.0f;
		fMax = 1000000000.0f;
	}
	iRet = xuiNumericInputSetRange(pData->pNumeric, fMin, fMax);
	if ( iRet == XUI_OK ) iRet = xuiNumericInputSetInteger(pData->pNumeric, iType == XUI_TABLE_CELL_TYPE_INT);
	if ( iRet == XUI_OK ) iRet = xuiNumericInputSetPrecision(pData->pNumeric, iPrecision);
	if ( iRet == XUI_OK ) iRet = xuiNumericInputSetStep(pData->pNumeric,
		(pData->tEditorConfig.fStep > 0.0f) ? pData->tEditorConfig.fStep : __xuiTableGridStepForPrecision(iPrecision));
	if ( iRet == XUI_OK ) iRet = xuiNumericInputSetSpinnerVisible(pData->pNumeric, 1);
	if ( iRet != XUI_OK ) return 0;
	if ( sText != NULL && sText[0] != '\0' && __xuiTableGridValidateNumberText(sText, iType) ) {
		fValue = (float)strtod(sText, NULL);
		iRet = xuiNumericInputSetValue(pData->pNumeric, fValue);
		if ( iRet != XUI_OK ) return 0;
	}
	iRet = xuiNumericInputSetText(pData->pNumeric, sText != NULL ? sText : "");
	if ( iRet != XUI_OK || __xuiTableGridPlaceEditor(pWidget, pData, pData->pNumeric, tRect) != XUI_OK ) return 0;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NUMERIC;
	pInput = xuiNumericInputGetInputWidget(pData->pNumeric);
	if ( pInput != NULL ) {
		iRet = xuiInputSetError(pInput, 0);
		if ( iRet == XUI_OK ) iRet = xuiInputSelectAll(pInput);
		if ( iRet != XUI_OK ) return 0;
	}
	if ( xuiSetFocusWidget(xuiWidgetGetContext(pWidget), pInput != NULL ? pInput : pData->pNumeric) != XUI_OK ) {
		(void)xuiWidgetSetVisible(pData->pNumeric, 0);
		pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
		return 0;
	}
	return 1;
}

static int __xuiTableGridBeginInputEdit(xui_widget pWidget, xui_table_grid_data_t* pData, const char* sText, xui_rect_t tRect, int iColumn, int iType)
{
	const xui_table_view_column_t* pColumn;
	int iAlign;
	int iRet;

	if ( (pWidget == NULL) || (pData == NULL) || (pData->pInput == NULL) ) return 0;
	iRet = xuiInputSetReadonly(pData->pInput, 0);
	if ( iRet == XUI_OK ) iRet = xuiInputSetError(pData->pInput, 0);
	if ( iRet == XUI_OK ) iRet = xuiInputSetText(pData->pInput, sText != NULL ? sText : "");
	if ( iRet == XUI_OK ) iRet = xuiInputSelectAll(pData->pInput);
	if ( iRet != XUI_OK ) return 0;
	if ( __xuiTableGridIsNumericType(iType) ) {
		iAlign = XUI_INPUT_ALIGN_RIGHT;
	} else {
		pColumn = xuiTableViewGetColumn(pData->pTable, iColumn);
		if ( pColumn != NULL && ((pColumn->iAlign & XUI_TEXT_ALIGN_RIGHT) != 0) ) {
			iAlign = XUI_INPUT_ALIGN_RIGHT;
		} else if ( pColumn != NULL && ((pColumn->iAlign & XUI_TEXT_ALIGN_CENTER) != 0) ) {
			iAlign = XUI_INPUT_ALIGN_CENTER;
		} else {
			iAlign = XUI_INPUT_ALIGN_LEFT;
		}
	}
	iRet = xuiInputSetTextAlign(pData->pInput, iAlign);
	if ( iRet != XUI_OK || __xuiTableGridPlaceEditor(pWidget, pData, pData->pInput, tRect) != XUI_OK ) return 0;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_INPUT;
	if ( xuiSetFocusWidget(xuiWidgetGetContext(pWidget), pData->pInput) != XUI_OK ) {
		(void)xuiWidgetSetVisible(pData->pInput, 0);
		pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
		return 0;
	}
	return 1;
}

static int __xuiTableGridEvent(xui_widget pWidget, const xui_event_t* pEvent, void* pUser)
{
	xui_table_grid_data_t* pData;
	xui_rect_t tTableWorld;
	float fLocalX;
	float fLocalY;
	int iRow;
	int iColumn;
	int iRet;

	(void)pUser;
	pData = __xuiTableGridGetData(pWidget);
	if ( (pData == NULL) || (pEvent == NULL) ) return XUI_ERROR_INVALID_ARGUMENT;
	if ( pEvent->iType == XUI_EVENT_ENABLED_CHANGED || pEvent->iType == XUI_EVENT_VISIBLE_CHANGED ) {
		if ( (!xuiWidgetGetEffectiveEnabled(pWidget) || !xuiWidgetGetEffectiveVisible(pWidget)) &&
		     pData->iEditingRow >= 0 ) (void)xuiTableGridEndEdit(pWidget, 0);
		return XUI_OK;
	}
	if ( !xuiWidgetGetEffectiveEnabled(pWidget) || !xuiWidgetGetEffectiveVisible(pWidget) ) return XUI_OK;
	if ( pEvent->iType == XUI_EVENT_KEY_DOWN ) {
		if ( pEvent->iPhase == XUI_EVENT_PHASE_CAPTURE ) {
			return XUI_OK;
		}
		if ( pData->iEditingRow >= 0 ) {
			if ( pEvent->iKey == XUI_KEY_ENTER || pEvent->iKey == XUI_KEY_ESCAPE ||
			     (pEvent->iKey == XUI_KEY_TAB && (pEvent->iModifiers & (XUI_MOD_CTRL | XUI_MOD_ALT)) == 0) ) {
				return __xuiTableGridFinishKey(pWidget, pEvent);
			}
		}
		if ( pData->iEditingRow < 0 ) {
			if ( pEvent->iKey == XUI_KEY_ENTER || pEvent->iKey == XUI_KEY_SPACE ||
			     pEvent->iKey == XUI_KEY_F2 ) {
				iRow = -1;
				iColumn = -1;
				(void)xuiTableViewGetSelectedCell(pData->pTable, &iRow, &iColumn);
				if ( iColumn < 0 ) {
					(void)xuiTableViewGetActiveCell(pData->pTable, &iRow, &iColumn);
				}
				if ( xuiTableGridBeginEdit(pWidget, iRow, iColumn) != 0 ) {
					return XUI_EVENT_DISPATCH_STOP;
				}
			}
		}
		return XUI_OK;
	}
	if ( pEvent->iPhase != XUI_EVENT_PHASE_CAPTURE ) {
		return XUI_OK;
	}
	if ( pEvent->iType == XUI_EVENT_POINTER_DOWN && pData->iEditingRow >= 0 ) {
		if ( __xuiTableGridEditorPopupOpen(pData) ) {
			return XUI_OK;
		}
		if ( __xuiTableGridPointInWidget(__xuiTableGridActiveEditor(pData), pEvent->fX, pEvent->fY) ) {
			return XUI_OK;
		}
		if ( xuiTableGridEndEdit(pWidget, 1) == 0 ) {
			return XUI_EVENT_DISPATCH_STOP;
		}
		pData = __xuiTableGridGetData(pWidget);
		if ( pData == NULL ) return XUI_EVENT_DISPATCH_STOP;
	}
	if ( pEvent->iType == XUI_EVENT_POINTER_WHEEL && pData->iEditingRow >= 0 ) {
		if ( __xuiTableGridEditorPopupOpen(pData) ||
		     __xuiTableGridPointInWidget(__xuiTableGridActiveEditor(pData), pEvent->fX, pEvent->fY) ) {
			return XUI_OK;
		}
		if ( xuiTableGridEndEdit(pWidget, 1) == 0 ) {
			return XUI_EVENT_DISPATCH_STOP;
		}
		pData = __xuiTableGridGetData(pWidget);
		if ( pData == NULL ) return XUI_EVENT_DISPATCH_STOP;
	}
	if ( pData->iEditingRow >= 0 &&
	     (pEvent->iType == XUI_EVENT_POINTER_UP || pEvent->iType == XUI_EVENT_POINTER_DOUBLE_CLICK) &&
	     __xuiTableGridEventInActiveEditor(pWidget, pData, pEvent) ) {
		return XUI_OK;
	}
	if ( (pEvent->iButton == 0 || pEvent->iButton == XUI_POINTER_BUTTON_LEFT) &&
	     ((pEvent->iType == XUI_EVENT_POINTER_DOWN && pData->iEditMode == XUI_TABLE_GRID_EDIT_IMMEDIATE) ||
	      (pEvent->iType == XUI_EVENT_POINTER_UP && pData->iEditMode == XUI_TABLE_GRID_EDIT_QUICK) ||
	      (pEvent->iType == XUI_EVENT_POINTER_DOUBLE_CLICK && pData->iEditMode == XUI_TABLE_GRID_EDIT_DISPLAY)) ) {
		tTableWorld = xuiWidgetGetWorldRect(pData->pTable);
		fLocalX = pEvent->fX - tTableWorld.fX;
		fLocalY = pEvent->fY - tTableWorld.fY;
		iRow = -1;
		iColumn = -1;
		iRet = xuiTableViewGetItemAt(pData->pTable, fLocalX, fLocalY, &iRow, &iColumn);
		if ( iRet == XUI_OK && iRow >= 0 && iColumn >= 0 ) {
			if ( pEvent->iType == XUI_EVENT_POINTER_DOWN ) {
				iRet = xuiTableViewSetSelectedCell(pData->pTable, iRow, iColumn);
				pData = __xuiTableGridGetData(pWidget);
				if ( iRet != XUI_OK || pData == NULL ) return XUI_EVENT_DISPATCH_STOP;
			}
			if ( xuiTableGridBeginEdit(pWidget, iRow, iColumn) != 0 ) {
				return XUI_EVENT_DISPATCH_STOP;
			}
		}
	}
	return XUI_OK;
}

static int __xuiTableGridKeyEvent(xui_widget pWidget, const xui_event_t* pEvent, void* pUser)
{
	xui_table_grid_key_route_t tRoute = *(xui_table_grid_key_route_t*)pUser;
	xui_table_grid_data_t* pData = __xuiTableGridGetData(tRoute.pGrid);
	xui_context pContext = xuiWidgetGetContext(pWidget);
	xui_widget pTable;
	xui_widget pDate;
	xui_event_t tCommit;
	int bTab;
	int bMenu;
	int iRejectCount;
	int iRet;
	int i;

	if ( pData == NULL || pEvent == NULL ) return XUI_OK;
	if ( pEvent->iPhase == XUI_EVENT_PHASE_CAPTURE ) goto delegate;
	if ( !xuiWidgetGetEffectiveEnabled(tRoute.pGrid) ) return XUI_OK;
	pTable = pData->pTable;
	if ( pWidget == pTable ) {
		if ( pEvent->iKey == XUI_KEY_ENTER || pEvent->iKey == XUI_KEY_SPACE ||
		     pEvent->iKey == XUI_KEY_F2 ) {
			iRet = __xuiTableGridEvent(tRoute.pGrid, pEvent, NULL);
			if ( iRet < 0 ) return iRet;
			return XUI_EVENT_DISPATCH_STOP;
		}
		goto delegate;
	}
	if ( pData->iEditingRow < 0 ) goto delegate;
	bTab = pEvent->iKey == XUI_KEY_TAB && (pEvent->iModifiers & (XUI_MOD_CTRL | XUI_MOD_ALT)) == 0;
	bMenu = pWidget == xuiComboBoxGetMenuWidget(pData->pCombo);
	if ( pEvent->iKey == XUI_KEY_ESCAPE ) {
		if ( tRoute.onKey != NULL && (bMenu || pWidget == xuiDatePickerGetPanelWidget(pData->pDate) ||
		     pWidget == xuiColorPickerGetPanelWidget(pData->pColor)) ) {
			iRet = tRoute.onKey(pWidget, pEvent, tRoute.pUser);
			if ( iRet < 0 ) return iRet;
			if ( !xuiInternalWidgetIsValid(tRoute.pGrid) || xuiInternalContextDestroyPending(pContext) ) return XUI_EVENT_DISPATCH_STOP;
		}
		return __xuiTableGridFinishKey(tRoute.pGrid, pEvent);
	}
	if ( !bTab && pEvent->iKey != XUI_KEY_ENTER && !(bMenu && pEvent->iKey == XUI_KEY_SPACE) ) goto delegate;
	/* Multiline values keep Shift+Enter; plain Enter completes the cell. */
	if ( pWidget == pData->pTextEdit && !bTab && (pEvent->iModifiers & XUI_MOD_SHIFT) != 0 ) goto delegate;
	if ( bMenu ) {
		iRejectCount = pData->iRejectCount;
		tCommit = *pEvent;
		if ( bTab ) { tCommit.iKey = XUI_KEY_ENTER; tCommit.iModifiers = 0; }
		iRet = tRoute.onKey != NULL ? tRoute.onKey(pWidget, &tCommit, tRoute.pUser) : XUI_OK;
		if ( iRet < 0 ) return iRet;
		pData = __xuiTableGridGetData(tRoute.pGrid);
		if ( pData == NULL || xuiInternalContextDestroyPending(pContext) ) return XUI_EVENT_DISPATCH_STOP;
		/* Re-selecting the same item does not emit ComboBox's change callback. */
		if ( pData->iEditingRow >= 0 && pData->iRejectCount == iRejectCount ) {
			(void)xuiTableGridEndEdit(tRoute.pGrid, xuiComboBoxGetSelected(pData->pCombo) >= 0);
		}
		if ( bTab && !xuiInternalContextDestroyPending(pContext) && xuiInternalWidgetIsValid(pTable) &&
		     !xuiTableGridIsEditing(tRoute.pGrid) && xuiGetFocusWidget(pContext) == pTable ) {
			(void)xuiFocusNext(pContext, (pEvent->iModifiers & XUI_MOD_SHIFT) == 0);
		}
		return XUI_EVENT_DISPATCH_STOP;
	}
	if ( pWidget == xuiDatePickerGetPanelWidget(pData->pDate) ) {
		if ( !bTab ) goto delegate;
		/* Commit the date draft through its existing callback. Date fields may
		   need one Enter before the popup; invalid fields keep their focus. */
		pDate = pData->pDate;
		tCommit = *pEvent;
		tCommit.iKey = XUI_KEY_ENTER;
		tCommit.iModifiers = 0;
		for ( i = 0; i < 2; i++ ) {
			iRet = tRoute.onKey != NULL ? tRoute.onKey(pWidget, &tCommit, tRoute.pUser) : XUI_OK;
			if ( iRet < 0 ) return iRet;
			if ( !xuiInternalWidgetIsValid(tRoute.pGrid) || xuiInternalContextDestroyPending(pContext) ) return XUI_EVENT_DISPATCH_STOP;
			if ( !xuiTableGridIsEditing(tRoute.pGrid) || !xuiDatePickerIsOpen(pDate) ) break;
		}
		if ( !xuiTableGridIsEditing(tRoute.pGrid) && xuiGetFocusWidget(pContext) == pTable ) {
			(void)xuiFocusNext(pContext, (pEvent->iModifiers & XUI_MOD_SHIFT) == 0);
		}
		return XUI_EVENT_DISPATCH_STOP;
	}
	if ( pWidget == xuiColorPickerGetPanelWidget(pData->pColor) ) {
		iRet = xuiInternalColorPickerCommitPendingEdit(pData->pColor);
		if ( iRet == XUI_ERROR_INVALID_ARGUMENT ) return XUI_EVENT_DISPATCH_STOP;
		if ( iRet != XUI_OK ) return iRet;
		if ( !xuiInternalWidgetIsValid(tRoute.pGrid) || xuiInternalContextDestroyPending(pContext) ) {
			return XUI_EVENT_DISPATCH_STOP;
		}
		return __xuiTableGridFinishKey(tRoute.pGrid, pEvent);
	}
	return __xuiTableGridFinishKey(tRoute.pGrid, pEvent);
delegate:
	return tRoute.onKey != NULL ? tRoute.onKey(pWidget, pEvent, tRoute.pUser) : XUI_OK;
}

static int __xuiTableGridInitKeyboard(xui_widget pWidget, xui_table_grid_data_t* pData)
{
	xui_widget pFrame = xuiTableViewGetFrameWidget(pData->pTable);
	xui_widget arrTargets[] = {pData->pTable, pData->pInput, pData->pNumeric,
		xuiNumericInputGetInputWidget(pData->pNumeric), pData->pCombo, pData->pColor, pData->pDate,
		pData->pTextEdit, xuiComboBoxGetMenuWidget(pData->pCombo),
		xuiColorPickerGetPanelWidget(pData->pColor), xuiDatePickerGetPanelWidget(pData->pDate), pData->pTextPopup};
	int i;
	int iRet;
	/* TableView navigation already scrolls its active cell into view. */
	iRet = xuiWidgetSetTabStop(xuiScrollFrameGetHScrollBarWidget(pFrame), 0);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiWidgetSetTabStop(xuiScrollFrameGetVScrollBarWidget(pFrame), 0);
	if ( iRet != XUI_OK ) return iRet;
	/* Preserve each owned control's navigation handler; callbacks run too late
	   for keys already consumed by TableView, NumericInput, or popup fields. */
	for ( i = 0; i < (int)(sizeof(arrTargets) / sizeof(arrTargets[0])); i++ ) {
		pData->arrKeyRoutes[i].pGrid = pWidget;
		iRet = xuiWidgetGetEventHandler(arrTargets[i], XUI_EVENT_KEY_DOWN,
			&pData->arrKeyRoutes[i].onKey, &pData->arrKeyRoutes[i].pUser);
		if ( iRet != XUI_OK ) return iRet;
		iRet = xuiWidgetSetEventHandler(arrTargets[i], XUI_EVENT_KEY_DOWN, __xuiTableGridKeyEvent, &pData->arrKeyRoutes[i]);
		if ( iRet != XUI_OK ) return iRet;
	}
	return XUI_OK;
}

static int __xuiTableGridUpdate(xui_widget pWidget, float fDelta, void* pUser)
{
	xui_table_grid_data_t* pData;

	(void)fDelta;
	(void)pUser;
	pData = __xuiTableGridGetData(pWidget);
	if ( pData != NULL ) {
		(void)__xuiTableGridSyncActiveEditorRect(pWidget, pData);
	}
	return XUI_OK;
}

static void __xuiTableGridDefaultLayout(xui_layout_t* pLayout)
{
	memset(pLayout, 0, sizeof(*pLayout));
	pLayout->iLayoutType = XUI_LAYOUT_OVERLAY;
	pLayout->iWidthMode = XUI_SIZE_CONTENT;
	pLayout->iHeightMode = XUI_SIZE_CONTENT;
	pLayout->iFlowMode = XUI_FLOW_BLOCK;
	pLayout->iDock = 0;
	pLayout->iOverflow = XUI_OVERFLOW_VISIBLE;
	pLayout->iAlignX = XUI_ALIGN_START;
	pLayout->iAlignY = XUI_ALIGN_START;
	pLayout->iTableRowSpan = 1;
	pLayout->iTableColumnSpan = 1;
	pLayout->iGridColumnCount = 1;
	pLayout->fMaxWidth = XUI_LAYOUT_UNBOUNDED;
	pLayout->fMaxHeight = XUI_LAYOUT_UNBOUNDED;
	pLayout->fShrink = 1.0f;
}

static int __xuiTableGridContentMeasure(xui_widget pWidget, xui_vec2_t tConstraint, xui_vec2_t* pSize, void* pUser)
{
	(void)pWidget;
	(void)tConstraint;
	(void)pUser;
	if ( pSize == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	pSize->fX = 360.0f;
	pSize->fY = 220.0f;
	return XUI_OK;
}

static int __xuiTableGridAccessibleNode(xui_widget pWidget, xui_accessible_node_t* pNode)
{
	if ( __xuiTableGridGetData(pWidget) == NULL || pNode == NULL ) {
		return XUI_ERROR_INVALID_ARGUMENT;
	}
	/* TableView owns the table/cell semantics. The wrapper is only an editor host. */
	pNode->iRole = XUI_ACCESSIBLE_ROLE_GROUP;
	if ( xuiWidgetGetAccessibleName(pWidget) == NULL ) pNode->sName = "Data grid";
	return XUI_OK;
}

static const xui_internal_accessibility_adapter_t g_xuiTableGridAccessible = {
	.getNode = __xuiTableGridAccessibleNode,
	.performAction = NULL
};

static int __xuiTableGridInitEvents(xui_widget pWidget)
{
	int iRet;

	iRet = xuiWidgetSetEventHandler(pWidget, XUI_EVENT_POINTER_DOWN, __xuiTableGridEvent, NULL);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetEventHandler(pWidget, XUI_EVENT_POINTER_UP, __xuiTableGridEvent, NULL);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetEventHandler(pWidget, XUI_EVENT_POINTER_DOUBLE_CLICK, __xuiTableGridEvent, NULL);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetEventHandler(pWidget, XUI_EVENT_POINTER_WHEEL, __xuiTableGridEvent, NULL);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetEventHandler(pWidget, XUI_EVENT_KEY_DOWN, __xuiTableGridEvent, NULL);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetEventHandler(pWidget, XUI_EVENT_ENABLED_CHANGED, __xuiTableGridEvent, NULL);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetEventHandler(pWidget, XUI_EVENT_VISIBLE_CHANGED, __xuiTableGridEvent, NULL);
	return iRet;
}

static int __xuiTableGridApplyEditorColors(xui_table_grid_data_t* pData,
	const xui_table_view_colors_t* pColors)
{
	int iRet;

	if ( pData == NULL || pColors == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	if ( pData->pInput != NULL ) {
		iRet = xuiInputSetColors(pData->pInput, pColors->iRowColor, pColors->iTextColor,
			pColors->iGridColor, pColors->iFocusRingColor);
		if ( iRet != XUI_OK ) return iRet;
	}
	if ( pData->pNumeric != NULL ) {
		iRet = xuiNumericInputSetColors(pData->pNumeric, pColors->iRowColor, pColors->iTextColor,
			pColors->iGridColor, pColors->iFocusRingColor);
		if ( iRet != XUI_OK ) return iRet;
	}
	if ( pData->pCombo != NULL ) {
		iRet = xuiComboBoxSetColors(pData->pCombo, pColors->iTextColor, pColors->iDisabledTextColor,
			pColors->iRowColor, pColors->iAltRowColor, pColors->iHoverColor, pColors->iDisabledColor);
		if ( iRet == XUI_OK ) iRet = xuiComboBoxSetBorderColors(pData->pCombo,
			pColors->iGridColor, pColors->iGridColor, pColors->iFocusRingColor);
		if ( iRet != XUI_OK ) return iRet;
	}
	if ( pData->pColor != NULL ) {
		iRet = xuiColorPickerSetColors(pData->pColor, pColors->iTextColor, pColors->iDisabledTextColor,
			pColors->iRowColor, pColors->iAltRowColor, pColors->iHoverColor, pColors->iDisabledColor);
		if ( iRet == XUI_OK ) iRet = xuiColorPickerSetBorderColors(pData->pColor,
			pColors->iGridColor, pColors->iGridColor, pColors->iFocusRingColor);
		if ( iRet != XUI_OK ) return iRet;
	}
	if ( pData->pDate != NULL ) {
		iRet = xuiDatePickerSetColors(pData->pDate, pColors->iTextColor, pColors->iDisabledTextColor,
			pColors->iRowColor, pColors->iAltRowColor, pColors->iHoverColor, pColors->iDisabledColor);
		if ( iRet == XUI_OK ) iRet = xuiDatePickerSetBorderColors(pData->pDate,
			pColors->iGridColor, pColors->iGridColor, pColors->iFocusRingColor);
		if ( iRet != XUI_OK ) return iRet;
	}
	if ( pData->pTextEdit != NULL ) {
		iRet = xuiTextEditSetColors(pData->pTextEdit, pColors->iRowColor, pColors->iTextColor,
			pColors->iGridColor, pColors->iFocusRingColor);
		if ( iRet != XUI_OK ) return iRet;
	}
	return XUI_OK;
}

static int __xuiTableGridCreateEditors(xui_widget pWidget, xui_table_grid_data_t* pData, const xui_table_grid_desc_t* pDesc)
{
	xui_input_desc_t tInput;
	xui_numeric_input_desc_t tNumeric;
	xui_combobox_desc_t tCombo;
	xui_color_picker_desc_t tColor;
	xui_date_picker_desc_t tDate;
	xui_popup_desc_t tPopup;
	xui_text_edit_desc_t tTextEdit;
	xui_button_desc_t tButton;
	xui_widget pContent;
	xui_table_view_colors_t tColors;
	int i;
	int iRet;

	(void)pDesc;
	memset(&tInput, 0, sizeof(tInput));
	tInput.iSize = sizeof(tInput);
	tInput.pFont = pData->pFont;
	tInput.iMaxLength = XUI_TABLE_GRID_VALUE_CAPACITY - 1;
	tInput.iTextAlign = XUI_INPUT_ALIGN_LEFT;
	iRet = xuiInternalInputCreatePart(pWidget,&pData->pInput,&tInput);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pWidget,pData->pInput,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pInput);
		pData->pInput = NULL;
		return iRet;
	}
	memset(&tNumeric, 0, sizeof(tNumeric));
	tNumeric.iSize = sizeof(tNumeric);
	tNumeric.pFont = pData->pFont;
	tNumeric.fMin = -1000000000.0f;
	tNumeric.fMax = 1000000000.0f;
	tNumeric.fStep = 1.0f;
	tNumeric.iPrecision = 3;
	tNumeric.bSpinnerVisible = 1;
	iRet = xuiInternalNumericInputCreatePart(pWidget,&pData->pNumeric,&tNumeric);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pWidget,pData->pNumeric,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pNumeric);
		pData->pNumeric = NULL;
		return iRet;
	}

	memset(&tCombo, 0, sizeof(tCombo));
	tCombo.iSize = sizeof(tCombo);
	tCombo.pFont = pData->pFont;
	tCombo.fPopupMaxHeight = 180.0f;
	iRet = xuiInternalComboBoxCreatePart(pWidget,&pData->pCombo,&tCombo);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pWidget,pData->pCombo,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pCombo);
		pData->pCombo = NULL;
		return iRet;
	}
	iRet = xuiTableViewGetColors(pData->pTable, &tColors);
	if ( iRet != XUI_OK ) return iRet;
	iRet = __xuiTableGridApplyEditorColors(pData, &tColors);
	if ( iRet != XUI_OK ) return iRet;

	memset(&tColor, 0, sizeof(tColor));
	tColor.iSize = sizeof(tColor);
	tColor.pFont = pData->pFont;
	tColor.iColor = XUI_COLOR_RGBA(67, 167, 124, 255);
	iRet = xuiInternalColorPickerCreatePart(pWidget,&pData->pColor,&tColor);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pWidget,pData->pColor,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pColor);
		pData->pColor = NULL;
		return iRet;
	}
	pData->iDefaultPaletteCount = xuiColorPickerGetPaletteCount(pData->pColor);
	if ( pData->iDefaultPaletteCount < 0 ||
	     pData->iDefaultPaletteCount > XUI_COLOR_PICKER_PALETTE_CAPACITY ) return XUI_ERROR_INVALID_STATE;
	for ( i = 0; i < pData->iDefaultPaletteCount; i++ ) {
		pData->arrDefaultPalette[i] = xuiColorPickerGetPaletteColor(pData->pColor, i);
	}

	memset(&tDate, 0, sizeof(tDate));
	tDate.iSize = sizeof(tDate);
	tDate.pFont = pData->pFont;
	tDate.iMode = XUI_DATE_PICKER_MODE_DATE;
	tDate.tValue = xrtNow();
	iRet = xuiInternalDatePickerCreatePart(pWidget,&pData->pDate,&tDate);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pWidget,pData->pDate,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pDate);
		pData->pDate = NULL;
		return iRet;
	}

	memset(&tPopup, 0, sizeof(tPopup));
	tPopup.iSize = sizeof(tPopup);
	tPopup.pOwner = pWidget;
	tPopup.fContentWidth = 380.0f;
	tPopup.fContentHeight = 238.0f;
	tPopup.fPadding = 0.0f;
	tPopup.fBorderWidth = 1.0f;
	tPopup.iOutsidePolicy = XUI_POPUP_OUTSIDE_IGNORE;
	tPopup.iOwnerPolicy = XUI_POPUP_OWNER_PASSTHROUGH;
	tPopup.iEscapePolicy = XUI_POPUP_ESCAPE_IGNORE;
	tPopup.iFocusPolicy = XUI_POPUP_FOCUS_CUSTOM;
	iRet = xuiInternalPopupCreatePart(pWidget,&pData->pTextPopup,&tPopup);
	if ( iRet != XUI_OK ) return iRet;
	pContent = xuiPopupGetContentWidget(pData->pTextPopup);
	if ( pContent == NULL ) return XUI_ERROR_INVALID_STATE;
	pData->pTextContent = pContent;

	memset(&tTextEdit, 0, sizeof(tTextEdit));
	tTextEdit.iSize = sizeof(tTextEdit);
	tTextEdit.pFont = pData->pFont;
	tTextEdit.bWordWrap = 1;
	tTextEdit.iMaxLength = XUI_TABLE_GRID_VALUE_CAPACITY - 1;
	iRet = xuiInternalTextEditCreatePart(pWidget,&pData->pTextEdit,&tTextEdit);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pContent,pData->pTextEdit,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pTextEdit);
		pData->pTextEdit = NULL;
		return iRet;
	}

	memset(&tButton, 0, sizeof(tButton));
	tButton.iSize = sizeof(tButton);
	tButton.pFont = pData->pFont;
	tButton.sText = "OK";
	iRet = xuiInternalButtonCreatePart(pWidget,&pData->pTextOk,&tButton);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pContent,pData->pTextOk,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pTextOk);
		pData->pTextOk = NULL;
		return iRet;
	}
	tButton.sText = "Cancel";
	iRet = xuiInternalButtonCreatePart(pWidget,&pData->pTextCancel,&tButton);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiInternalWidgetInsertPart(pWidget,pContent,pData->pTextCancel,NULL);
	if ( iRet != XUI_OK ) {
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pTextCancel);
		pData->pTextCancel = NULL;
		return iRet;
	}

	iRet = xuiWidgetSetVisible(pData->pInput, 0);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetVisible(pData->pNumeric, 0);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetVisible(pData->pCombo, 0);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetVisible(pData->pColor, 0);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetVisible(pData->pDate, 0);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetFlowMode(pData->pInput, XUI_FLOW_ABSOLUTE);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetFlowMode(pData->pNumeric, XUI_FLOW_ABSOLUTE);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetFlowMode(pData->pCombo, XUI_FLOW_ABSOLUTE);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetFlowMode(pData->pColor, XUI_FLOW_ABSOLUTE);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetFlowMode(pData->pDate, XUI_FLOW_ABSOLUTE);
	if ( iRet != XUI_OK ) return iRet;
	iRet = __xuiTableGridSetEditorLayerTree(pData->pInput, XUI_LAYER_NORMAL, 100);
	if ( iRet != XUI_OK ) return iRet;
	iRet = __xuiTableGridSetEditorLayerTree(pData->pNumeric, XUI_LAYER_NORMAL, 100);
	if ( iRet != XUI_OK ) return iRet;
	iRet = __xuiTableGridSetEditorLayerTree(pData->pCombo, XUI_LAYER_NORMAL, 100);
	if ( iRet != XUI_OK ) return iRet;
	iRet = __xuiTableGridSetEditorLayerTree(pData->pColor, XUI_LAYER_NORMAL, 100);
	if ( iRet != XUI_OK ) return iRet;
	iRet = __xuiTableGridSetEditorLayerTree(pData->pDate, XUI_LAYER_NORMAL, 100);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiComboBoxSetSelect(pData->pCombo, __xuiTableGridComboSelect, pData);
	if ( iRet == XUI_OK ) iRet = xuiColorPickerSetChange(pData->pColor, __xuiTableGridColorChange, pData);
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetCommit(pData->pDate, __xuiTableGridDateCommit, pData);
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetCancel(pData->pDate, __xuiTableGridDateCancel, pData);
	if ( iRet == XUI_OK ) iRet = xuiButtonSetClick(pData->pTextOk, __xuiTableGridTextOk, pData);
	if ( iRet == XUI_OK ) iRet = xuiButtonSetClick(pData->pTextCancel, __xuiTableGridTextCancel, pData);
	if ( iRet == XUI_OK ) iRet = xuiPopupSetFocusPolicy(pData->pTextPopup, XUI_POPUP_FOCUS_CUSTOM, pData->pTextEdit);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetLayoutType(pContent, XUI_LAYOUT_MANUAL);
	if ( iRet == XUI_OK ) iRet = __xuiTableGridApplyEditorColors(pData, &tColors);
	return iRet;
}

static void __xuiTableGridCleanupInit(xui_widget pWidget,xui_table_grid_data_t* pData)
{
	xui_widget arrChildren[6];
	int i;

	if ( pData == NULL ) return;
	if ( pData->pTextPopup != NULL ) {
		(void)xuiPopupSetOwner(pData->pTextPopup, NULL);
		(void)xuiInternalWidgetDestroyPart(pWidget,pData->pTextPopup);
		pData->pTextPopup = NULL;
		pData->pTextContent = NULL;
		pData->pTextEdit = NULL;
		pData->pTextOk = NULL;
		pData->pTextCancel = NULL;
	}
	arrChildren[0] = pData->pDate;
	arrChildren[1] = pData->pColor;
	arrChildren[2] = pData->pCombo;
	arrChildren[3] = pData->pNumeric;
	arrChildren[4] = pData->pInput;
	arrChildren[5] = pData->pTable;
	for ( i = 0; i < (int)(sizeof(arrChildren) / sizeof(arrChildren[0])); i++ ) {
		if ( arrChildren[i] == NULL ) continue;
		if ( xuiWidgetGetParent(arrChildren[i]) != NULL ) (void)xuiInternalWidgetDetachPart(pWidget,arrChildren[i]);
		(void)xuiInternalWidgetDestroyPart(pWidget,arrChildren[i]);
	}
	pData->pDate = NULL;
	pData->pColor = NULL;
	pData->pCombo = NULL;
	pData->pNumeric = NULL;
	pData->pInput = NULL;
	pData->pTable = NULL;
}

static int __xuiTableGridInit(xui_widget pWidget, void* pTypeData, const void* pCreateData, void* pUser)
{
	xui_table_grid_data_t* pData;
	const xui_table_grid_desc_t* pDesc;
	xui_table_view_desc_t tTableDesc;
	int iRet;

	(void)pUser;
	pData = (xui_table_grid_data_t*)pTypeData;
	pDesc = (const xui_table_grid_desc_t*)pCreateData;
	if ( (pWidget == NULL) || (pData == NULL) || !__xuiTableGridDescValid(pDesc) ) {
		return XUI_ERROR_INVALID_ARGUMENT;
	}
	memset(pData, 0, sizeof(*pData));
	pData->pFont = (pDesc != NULL) ? pDesc->pFont : NULL;
	pData->iEditMode = (pDesc != NULL && __xuiTableGridEditModeValid(pDesc->iEditMode)) ? pDesc->iEditMode : XUI_TABLE_GRID_EDIT_DISPLAY;
	pData->iEditingRow = -1;
	pData->iEditingColumn = -1;
	pData->iEditingType = XUI_TABLE_CELL_TYPE_TEXT;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
	pData->onCount = (pDesc != NULL) ? pDesc->onCount : NULL;
	pData->onCell = (pDesc != NULL) ? pDesc->onCell : NULL;
	pData->onSet = (pDesc != NULL) ? pDesc->onSet : NULL;
	pData->pAdapterUser = (pDesc != NULL) ? pDesc->pAdapterUser : NULL;
	pData->pSetUser = pData->pAdapterUser;
	pData->onValidate = (pDesc != NULL) ? pDesc->onValidate : NULL;
	pData->pValidateUser = (pDesc != NULL) ? pDesc->pValidateUser : NULL;
	pData->onChange = (pDesc != NULL) ? pDesc->onChange : NULL;
	pData->pChangeUser = (pDesc != NULL) ? pDesc->pChangeUser : NULL;
	pData->onEditor = (pDesc != NULL) ? pDesc->onEditor : NULL;
	pData->pEditorUser = (pDesc != NULL) ? pDesc->pEditorUser : NULL;
	xuiTableGridEditorConfigOutputInit(&pData->tOwnedEditorConfig);
	pData->onEditorConfig = (pDesc != NULL) ? pDesc->onEditorConfig : NULL;
	pData->pEditorConfigUser = (pDesc != NULL) ? pDesc->pEditorConfigUser : NULL;

	memset(&tTableDesc, 0, sizeof(tTableDesc));
	tTableDesc.iSize = sizeof(tTableDesc);
	if ( pDesc != NULL ) {
		tTableDesc.arrColumns = pDesc->arrColumns;
		tTableDesc.arrRows = pDesc->arrRows;
		tTableDesc.iColumnCount = pDesc->iColumnCount;
		tTableDesc.iRowCount = pDesc->iRowCount;
		tTableDesc.pFont = pDesc->pFont;
		tTableDesc.fDefaultColumnWidth = pDesc->fDefaultColumnWidth;
		tTableDesc.fDefaultRowHeight = pDesc->fDefaultRowHeight;
		tTableDesc.fHeaderHeight = pDesc->fHeaderHeight;
		tTableDesc.iSelectionMode = pDesc->iSelectionMode;
		tTableDesc.iScrollbarMode = pDesc->iScrollbarMode;
		tTableDesc.tColors = pDesc->tColors;
		tTableDesc.iTrackColor = pDesc->iTrackColor;
		tTableDesc.iThumbColor = pDesc->iThumbColor;
		tTableDesc.iScrollbarHoverColor = pDesc->iScrollbarHoverColor;
		tTableDesc.iScrollbarActiveColor = pDesc->iScrollbarActiveColor;
		tTableDesc.iScrollbarFocusColor = pDesc->iScrollbarFocusColor;
		tTableDesc.iScrollbarDisabledColor = pDesc->iScrollbarDisabledColor;
	}
	tTableDesc.onCount = (pData->onCount != NULL) ? __xuiTableGridCountProc : NULL;
	tTableDesc.onCell = (pData->onCell != NULL) ? __xuiTableGridCellProc : NULL;
	tTableDesc.pAdapterUser = pData;
	iRet = xuiInternalTableViewCreatePart(pWidget,&pData->pTable,&tTableDesc);
	if ( iRet != XUI_OK ) goto cleanup;
	iRet = xuiTableViewSetContextMenu(pData->pTable, __xuiTableGridTableContext, pData);
	if ( iRet != XUI_OK ) goto cleanup;
	iRet = xuiWidgetSetFlowMode(pData->pTable, XUI_FLOW_BLOCK);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetSizeMode(pData->pTable, XUI_SIZE_FILL, XUI_SIZE_FILL);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetAlign(pData->pTable, XUI_ALIGN_STRETCH, XUI_ALIGN_STRETCH);
	if ( iRet != XUI_OK ) goto cleanup;
	iRet = xuiInternalWidgetInsertPart(pWidget,pWidget,pData->pTable,NULL);
	if ( iRet != XUI_OK ) goto cleanup;
	iRet = __xuiTableGridCreateEditors(pWidget, pData, pDesc);
	if ( iRet != XUI_OK ) goto cleanup;
	iRet = __xuiTableGridInitKeyboard(pWidget, pData);
	if ( iRet != XUI_OK ) goto cleanup;
	iRet = xuiWidgetSetLayoutType(pWidget, XUI_LAYOUT_OVERLAY);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetFlowMode(pWidget, XUI_FLOW_BLOCK);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetOverflow(pWidget, XUI_OVERFLOW_VISIBLE);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetFocusable(pWidget, 0);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetTabStop(pWidget, 0);
	if ( iRet == XUI_OK ) iRet = xuiWidgetSetPadding(pWidget, (xui_thickness_t){0.0f, 0.0f, 0.0f, 0.0f});
	if ( iRet == XUI_OK ) iRet = __xuiTableGridInitEvents(pWidget);
	if ( iRet != XUI_OK ) goto cleanup;
	return XUI_OK;

cleanup:
	__xuiTableGridCleanupInit(pWidget,pData);
	return iRet;
}

static void __xuiTableGridDestroy(xui_widget pWidget, void* pTypeData, void* pUser)
{
	xui_table_grid_data_t* pData;

	(void)pWidget;
	(void)pUser;
	pData = (xui_table_grid_data_t*)pTypeData;
	if ( pData != NULL ) {
		if ( pData->pTextPopup != NULL ) {
			(void)xuiInternalWidgetDestroyPart(pWidget,pData->pTextPopup);
		}
		xuiTableGridEditorConfigOutputDispose(&pData->tOwnedEditorConfig);
		memset(pData, 0, sizeof(*pData));
	}
}

static xui_table_grid_data_t* __xuiTableGridGetData(xui_widget pWidget)
{
	xui_context pContext;
	xui_widget_type pType;

	if ( !xuiInternalWidgetIsValid(pWidget) ) {
		return NULL;
	}
	pContext = xuiWidgetGetContext(pWidget);
	if ( !xuiInternalContextIsValid(pContext) || xuiInternalContextDestroyPending(pContext) ) {
		return NULL;
	}
	pType = xuiWidgetFindType(pContext, "tablegrid");
	if ( (pType == NULL) || !xuiWidgetIsType(pWidget, pType) ) {
		return NULL;
	}
	return (xui_table_grid_data_t*)xuiWidgetGetTypeData(pWidget);
}

XUI_API xui_widget_type xuiTableGridGetType(xui_context pContext)
{
	xui_widget_type pType;
	xui_widget_type_desc_t tDesc;

	if ( !xuiInternalContextIsValid(pContext) ) {
		return NULL;
	}
	pType = xuiWidgetFindType(pContext, "tablegrid");
	if ( pType != NULL ) {
		pType->pAccessibleAdapter = &g_xuiTableGridAccessible;
		return pType;
	}
	memset(&tDesc, 0, sizeof(tDesc));
	tDesc.iSize = sizeof(tDesc);
	tDesc.sName = "tablegrid";
	tDesc.pParent = xuiWidgetGetBaseType();
	tDesc.iTypeDataSize = sizeof(xui_table_grid_data_t);
	tDesc.onInit = __xuiTableGridInit;
	tDesc.onDestroy = __xuiTableGridDestroy;
	tDesc.onContentMeasure = __xuiTableGridContentMeasure;
	tDesc.onUpdate = __xuiTableGridUpdate;
	__xuiTableGridDefaultLayout(&tDesc.tLayout);
	if ( xuiWidgetRegisterType(pContext, &pType, &tDesc) != XUI_OK ) {
		return NULL;
	}
	pType->pAccessibleAdapter = &g_xuiTableGridAccessible;
	    static const size_t fontOffsets[]={offsetof(xui_table_grid_data_t,pFont)};
    pType->pFontOffsets=fontOffsets;pType->iFontSlotCount=sizeof(fontOffsets)/sizeof(fontOffsets[0]);
    return pType;
}

static int __xuiTableGridCreateWithOwner(xui_context pContext, xui_widget* ppWidget, const xui_table_grid_desc_t* pDesc,xui_widget pNativeOwner)
{
	xui_widget_type pType;

	if ( ppWidget == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	*ppWidget = NULL;
	if ( !xuiInternalContextIsValid(pContext) || !__xuiTableGridDescValid(pDesc) ) return XUI_ERROR_INVALID_ARGUMENT;
	pType = xuiTableGridGetType(pContext);
	if ( pType == NULL ) {
		return XUI_ERROR_NOT_INITIALIZED;
	}
	return (pNativeOwner ? xuiInternalWidgetCreatePart(pNativeOwner,pType,ppWidget,pDesc) : xuiWidgetCreateTyped(pContext,pType,ppWidget,pDesc));
}

XUI_API int xuiTableGridCreate(xui_context pContext, xui_widget* ppWidget, const xui_table_grid_desc_t* pDesc)
{return __xuiTableGridCreateWithOwner(pContext,ppWidget,pDesc,NULL);}
int xuiInternalTableGridCreatePart(xui_widget pOwner,xui_widget* ppWidget,const xui_table_grid_desc_t* pDesc)
{
    if(ppWidget)*ppWidget=NULL;
    if(!xuiInternalWidgetIsValid(pOwner) || !ppWidget)return XUI_ERROR_INVALID_ARGUMENT;
    xui_context context=xuiWidgetGetContext(pOwner);
    xuiInternalOperationEnter(context);
    int status=__xuiTableGridCreateWithOwner(context,ppWidget,pDesc,pOwner);
    xuiInternalOperationLeave(context);
    return status;
}


XUI_API xui_widget xuiTableGridGetTableView(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->pTable : NULL;
}

XUI_API int xuiTableGridSetColumns(xui_widget pWidget, const xui_table_view_column_t* arrColumns, int iCount)
{
	xui_context pContext;
	xui_table_grid_data_t* pData;
	int iRet;

	if ( !xuiInternalWidgetIsValid(pWidget) || !__xuiTableGridColumnsValid(arrColumns, iCount) ) {
		return XUI_ERROR_INVALID_ARGUMENT;
	}
	pContext = xuiWidgetGetContext(pWidget);
	xuiInternalOperationEnter(pContext);
	pData = __xuiTableGridGetData(pWidget);
	iRet = XUI_ERROR_INVALID_ARGUMENT;
	if ( pData != NULL && pData->pTable != NULL ) {
		if ( pData->iEditingRow >= 0 && xuiTableGridEndEdit(pWidget, 0) == 0 ) {
			xuiInternalOperationLeave(pContext);
			return XUI_ERROR_INVALID_STATE;
		}
		pData = __xuiTableGridGetData(pWidget);
		if ( pData != NULL && pData->pTable != NULL ) iRet = xuiTableViewSetColumns(pData->pTable, arrColumns, iCount);
	}
	xuiInternalOperationLeave(pContext);
	return iRet;
}

/* Same edit boundary as the borrowed setter, with owned column text. */
XUI_API int xuiTableGridSetColumnsCopy(xui_widget widget,
    const xui_table_view_column_t* columns, int count)
{
    if (!xuiInternalWidgetIsValid(widget) || !__xuiTableGridColumnsValid(columns,count))
        return XUI_ERROR_INVALID_ARGUMENT;
    xui_context context=xuiWidgetGetContext(widget);
    xuiInternalOperationEnter(context);
    xui_table_grid_data_t* data=__xuiTableGridGetData(widget);
    int result=XUI_ERROR_INVALID_ARGUMENT;
    if (data && data->pTable) {
        if (data->iEditingRow>=0 && xuiTableGridEndEdit(widget,0)==0) result=XUI_ERROR_INVALID_STATE;
        else {
            data=__xuiTableGridGetData(widget);
            if (data && data->pTable) result=xuiTableViewSetColumnsCopy(data->pTable,columns,count);
        }
    }
    xuiInternalOperationLeave(context);
    return result;
}

XUI_API int xuiTableGridSetRows(xui_widget pWidget, const xui_table_view_row_t* arrRows, int iCount)
{
	xui_context pContext;
	xui_table_grid_data_t* pData;
	int iRet;

	if ( !xuiInternalWidgetIsValid(pWidget) || !__xuiTableGridRowsValid(arrRows, iCount) ) {
		return XUI_ERROR_INVALID_ARGUMENT;
	}
	pContext = xuiWidgetGetContext(pWidget);
	xuiInternalOperationEnter(pContext);
	pData = __xuiTableGridGetData(pWidget);
	iRet = XUI_ERROR_INVALID_ARGUMENT;
	if ( pData != NULL && pData->pTable != NULL ) {
		if ( pData->iEditingRow >= 0 && xuiTableGridEndEdit(pWidget, 0) == 0 ) {
			xuiInternalOperationLeave(pContext);
			return XUI_ERROR_INVALID_STATE;
		}
		pData = __xuiTableGridGetData(pWidget);
		if ( pData != NULL && pData->pTable != NULL ) iRet = xuiTableViewSetRows(pData->pTable, arrRows, iCount);
	}
	xuiInternalOperationLeave(pContext);
	return iRet;
}

static int __xuiTableGridBindAdapter(xui_table_grid_data_t* data)
{
    if(data->bAdapterOwned)return xuiTableViewSetAdapterOwned(data->pTable,
        data->onCountOwned ? __xuiTableGridOwnedCount:NULL,data,NULL,
        data->onCellOwned ? __xuiTableGridOwnedCell:NULL,data,NULL);
    return xuiTableViewSetAdapter(data->pTable,
        data->onCount ? __xuiTableGridCountProc:NULL,data->onCell ? __xuiTableGridCellProc:NULL,data);
}
XUI_API int xuiTableGridSetAdapterOwned(xui_widget widget,
    xui_table_view_count_proc count,void* countUser,const xui_callback_owner_t* countOwner,
    xui_table_view_cell_owned_proc cell,void* cellUser,const xui_callback_owner_t* cellOwner,
    xui_table_grid_set_proc set,void* setUser,const xui_callback_owner_t* setOwner)
{
    xui_table_grid_data_t* data=__xuiTableGridGetData(widget);if(!data || !data->pTable)return XUI_ERROR_INVALID_ARGUMENT;
    if(data->bStartingEdit || data->bCommitting)return XUI_ERROR_BUSY;
    xui_callback_group_entry_t entries[3]={
        {.pSlot=&data->onCountOwned,.bHasCallback=count!=NULL,.pUser=countUser,.pOwner=countOwner},
        {.pSlot=&data->onCellOwned,.bHasCallback=cell!=NULL,.pUser=cellUser,.pOwner=cellOwner},
        {.pSlot=&data->onSetOwned,.bHasCallback=set!=NULL,.pUser=setUser,.pOwner=setOwner}
    };
    xui_callback_group_update_t update={0};int status=xuiInternalCallbackGroupUpdateBegin(widget,entries,3,&update);
    if(status!=XUI_OK)return status;
    data->onCountOwned=count;data->pCountOwnedUser=countUser;data->onCellOwned=cell;data->pCellOwnedUser=cellUser;
    data->onSetOwned=set;data->pSetOwnedUser=setUser;data->bAdapterOwned=count || cell || set;
    data->onCount=NULL;data->onCell=NULL;data->onSet=NULL;data->pAdapterUser=NULL;data->pSetUser=NULL;++data->iAdapterGeneration;
    xuiInternalCallbackGroupUpdatePublish(&update);
    if(data->iEditingRow>=0 && !xuiTableGridEndEdit(widget,0))status=XUI_ERROR_INVALID_STATE;
    if(status==XUI_OK && !__xuiTableGridWidgetAlive(widget,data))status=XUI_ERROR_INVALID_STATE;
    if(status==XUI_OK)status=__xuiTableGridBindAdapter(data);
    return xuiInternalCallbackGroupUpdateEnd(&update,status);
}
static int __xuiTableGridClearOwnedAdapter(xui_widget widget,xui_table_grid_data_t* data)
{
    xui_callback_group_entry_t entries[3]={{.pSlot=&data->onCountOwned},{.pSlot=&data->onCellOwned},{.pSlot=&data->onSetOwned}};
    xui_callback_group_update_t update={0};int status=xuiInternalCallbackGroupUpdateBegin(widget,entries,3,&update);
    if(status!=XUI_OK)return status;
    data->onCountOwned=NULL;data->pCountOwnedUser=NULL;data->onCellOwned=NULL;data->pCellOwnedUser=NULL;data->onSetOwned=NULL;data->pSetOwnedUser=NULL;data->bAdapterOwned=false;
    xuiInternalCallbackGroupUpdatePublish(&update);return xuiInternalCallbackGroupUpdateEnd(&update,XUI_OK);
}
XUI_API int xuiTableGridSetAdapter(xui_widget pWidget, xui_table_view_count_proc onCount, xui_table_view_cell_proc onCell, xui_table_grid_set_proc onSet, void* pUser)
{
	xui_context pContext;
	xui_table_grid_data_t* pData;
	xui_table_view_count_proc onOldCount;
	xui_table_view_cell_proc onOldCell;
	xui_table_grid_set_proc onOldSet;
	void* pOldAdapterUser;
	void* pOldSetUser;
	uint64_t iGeneration;
	int iRet;
    bool oldOwned;

	if ( !xuiInternalWidgetIsValid(pWidget) ) return XUI_ERROR_INVALID_ARGUMENT;
	pContext = xuiWidgetGetContext(pWidget);
	xuiInternalOperationEnter(pContext);
	pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL || pData->pTable == NULL ) {
		xuiInternalOperationLeave(pContext);
		return XUI_ERROR_INVALID_ARGUMENT;
	}
	if ( pData->iEditingRow >= 0 && xuiTableGridEndEdit(pWidget, 0) == 0 ) {
		xuiInternalOperationLeave(pContext);
		return XUI_ERROR_INVALID_STATE;
	}
	pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL || pData->pTable == NULL ) {
		xuiInternalOperationLeave(pContext);
		return XUI_ERROR_INVALID_STATE;
	}
    oldOwned=pData->bAdapterOwned;
	onOldCount = pData->onCount;
	onOldCell = pData->onCell;
	onOldSet = pData->onSet;
	pOldAdapterUser = pData->pAdapterUser;
	pOldSetUser = pData->pSetUser;
    pData->bAdapterOwned=false;
	pData->onCount = onCount;
	pData->onCell = onCell;
	pData->onSet = onSet;
	pData->pAdapterUser = pUser;
	pData->pSetUser = pUser;
	iGeneration = ++pData->iAdapterGeneration;
	iRet = __xuiTableGridBindAdapter(pData);
	if ( __xuiTableGridWidgetAlive(pWidget, pData) ) {
		if ( pData->iAdapterGeneration != iGeneration ) {
			iRet = __xuiTableGridBindAdapter(pData);
		} else if ( iRet != XUI_OK ) {
            pData->bAdapterOwned=oldOwned;
			pData->onCount = onOldCount;
			pData->onCell = onOldCell;
			pData->onSet = onOldSet;
			pData->pAdapterUser = pOldAdapterUser;
			pData->pSetUser = pOldSetUser;
			pData->iAdapterGeneration++;
		}
	}
    if(iRet==XUI_OK && __xuiTableGridWidgetAlive(pWidget,pData) && oldOwned && pData->iAdapterGeneration==iGeneration){
        iRet=__xuiTableGridClearOwnedAdapter(pWidget,pData);
    }
	xuiInternalOperationLeave(pContext);
	return iRet;
}

XUI_API int xuiTableGridSetValidateOwned(xui_widget widget,xui_table_grid_validate_proc validate,void* user,const xui_callback_owner_t* owner)
{
    xui_table_grid_data_t* data=__xuiTableGridGetData(widget);if(!data)return XUI_ERROR_INVALID_ARGUMENT;
    xui_callback_update_t update={0};int status=xuiInternalCallbackUpdateBegin(widget,&data->onValidate,validate!=NULL,user,owner,&update);
    if(status!=XUI_OK)return status;
    data->onValidate=validate;data->pValidateUser=user;xuiInternalCallbackUpdatePublish(&update);
    return xuiInternalCallbackUpdateEnd(&update,XUI_OK);
}
XUI_API int xuiTableGridSetValidate(xui_widget pWidget, xui_table_grid_validate_proc onValidate, void* pUser)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
    if(xuiInternalCallbackSlotOwned(pWidget,&pData->onValidate))return xuiTableGridSetValidateOwned(pWidget,onValidate,pUser,NULL);
	pData->onValidate = onValidate;
	pData->pValidateUser = pUser;
	return XUI_OK;
}

XUI_API int xuiTableGridSetChangeOwned(xui_widget pWidget, xui_table_grid_change_proc onChange, void* pUser, const xui_callback_owner_t* pOwner)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	xui_callback_update_t tUpdate = {0};
	int iResult = xuiInternalCallbackUpdateBegin(pWidget, &pData->onChange, onChange != NULL, pUser, pOwner, &tUpdate);
	if ( iResult != XUI_OK ) return iResult;
	pData->onChange = onChange;
	pData->pChangeUser = pUser;
	xuiInternalCallbackUpdatePublish(&tUpdate);
	return xuiInternalCallbackUpdateEnd(&tUpdate, XUI_OK);
}

XUI_API int xuiTableGridSetChange(xui_widget pWidget, xui_table_grid_change_proc onChange, void* pUser)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	if ( xuiInternalCallbackSlotOwned(pWidget, &pData->onChange) )
		return xuiTableGridSetChangeOwned(pWidget, onChange, pUser, NULL);
	pData->onChange = onChange;
	pData->pChangeUser = pUser;
	return XUI_OK;
}

static int __xuiTableGridNoRawConfig(xui_widget widget,void* raw)
{
    xui_table_grid_data_t* data=raw;
    if(__xuiTableGridGetData(widget)!=data)return XUI_ERROR_INVALID_STATE;
    return data->onEditorConfig ? XUI_ERROR_UNSUPPORTED:XUI_OK;
}
static int __xuiTableGridNoOwnedEditor(xui_widget widget,void* raw)
{
    xui_table_grid_data_t* data=raw;
    if(__xuiTableGridGetData(widget)!=data)return XUI_ERROR_INVALID_STATE;
    return data->onEditorOwned ? XUI_ERROR_UNSUPPORTED:XUI_OK;
}
static int __xuiTableGridSetEditorCallbacks(xui_widget widget,xui_table_grid_editor_proc raw,
    xui_table_grid_editor_owned_proc owned,void* user,const xui_callback_owner_t* owner)
{
    xui_table_grid_data_t* data=__xuiTableGridGetData(widget);if(!data)return XUI_ERROR_INVALID_ARGUMENT;
    if(owned && data->onEditorConfig)return XUI_ERROR_UNSUPPORTED;
    if(!owned && !owner && !xuiInternalCallbackSlotOwned(widget,&data->onEditorOwned)){
        data->onEditor=raw;data->pEditorUser=raw ? user:NULL;data->onEditorOwned=NULL;data->pEditorOwnedUser=NULL;return XUI_OK;
    }
    xui_callback_update_t update={0};int status=xuiInternalCallbackUpdateBeginValidated(widget,&data->onEditorOwned,owned!=NULL,user,owner,owned ? __xuiTableGridNoRawConfig:NULL,data,&update);
    if(status!=XUI_OK)return status;
    data->onEditor=raw;data->pEditorUser=raw ? user:NULL;data->onEditorOwned=owned;data->pEditorOwnedUser=owned ? user:NULL;
    xuiInternalCallbackUpdatePublish(&update);return xuiInternalCallbackUpdateEnd(&update,XUI_OK);
}
XUI_API int xuiTableGridSetEditorOwned(xui_widget widget,xui_table_grid_editor_owned_proc editor,void* user,const xui_callback_owner_t* owner)
{return __xuiTableGridSetEditorCallbacks(widget,NULL,editor,user,owner);}
XUI_API int xuiTableGridSetEditor(xui_widget pWidget, xui_table_grid_editor_proc onEditor, void* pUser)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
    if(pData->onEditorOwned || xuiInternalCallbackSlotOwned(pWidget,&pData->onEditorOwned))return __xuiTableGridSetEditorCallbacks(pWidget,onEditor,NULL,pUser,NULL);
	pData->onEditor = onEditor;
	pData->pEditorUser = pUser;
	return XUI_OK;
}

static int __xuiTableGridSetConfigCallbacks(xui_widget widget,xui_table_grid_editor_config_proc raw,
    xui_table_grid_editor_config_owned_proc owned,void* user,const xui_callback_owner_t* owner)
{
    xui_table_grid_data_t* data=__xuiTableGridGetData(widget);if(!data)return XUI_ERROR_INVALID_ARGUMENT;
    if(raw && data->onEditorOwned)return XUI_ERROR_UNSUPPORTED;
    if(!owned && !owner && !xuiInternalCallbackSlotOwned(widget,&data->onEditorConfigOwned)){
        data->onEditorConfig=raw;data->pEditorConfigUser=raw ? user:NULL;data->onEditorConfigOwned=NULL;data->pEditorConfigOwnedUser=NULL;return XUI_OK;
    }
    xui_callback_update_t update={0};int status=xuiInternalCallbackUpdateBeginValidated(widget,&data->onEditorConfigOwned,owned!=NULL,user,owner,raw ? __xuiTableGridNoOwnedEditor:NULL,data,&update);
    if(status!=XUI_OK)return status;
    data->onEditorConfig=raw;data->pEditorConfigUser=raw ? user:NULL;
    data->onEditorConfigOwned=owned;data->pEditorConfigOwnedUser=owned ? user:NULL;
    xuiInternalCallbackUpdatePublish(&update);return xuiInternalCallbackUpdateEnd(&update,XUI_OK);
}
XUI_API int xuiTableGridSetEditorConfig(xui_widget widget,xui_table_grid_editor_config_proc config,void* user)
{return __xuiTableGridSetConfigCallbacks(widget,config,NULL,user,NULL);}
XUI_API int xuiTableGridSetEditorConfigOwned(xui_widget widget,xui_table_grid_editor_config_owned_proc config,void* user,const xui_callback_owner_t* owner)
{return __xuiTableGridSetConfigCallbacks(widget,NULL,config,user,owner);}

XUI_API int xuiTableGridSetContextMenuOwned(xui_widget pWidget, xui_table_grid_context_proc onContext, void* pUser, const xui_callback_owner_t* pOwner)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	xui_callback_update_t ownedUpdate={0};
    int ownedStatus=xuiInternalCallbackUpdateBegin(pWidget,&pData->onContext,onContext!=NULL,pUser,pOwner,&ownedUpdate);
    if(ownedStatus!=XUI_OK)return ownedStatus;
    pData->onContext = onContext;
	pData->pContextUser = pUser;
    xuiInternalCallbackUpdatePublish(&ownedUpdate);
	return xuiInternalCallbackUpdateEnd(&ownedUpdate,XUI_OK);
}

XUI_API int xuiTableGridSetContextMenu(xui_widget pWidget, xui_table_grid_context_proc onContext, void* pUser)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	if(xuiInternalCallbackSlotOwned(pWidget,&pData->onContext))return xuiTableGridSetContextMenuOwned(pWidget,onContext,pUser,NULL);
    pData->onContext = onContext;
	pData->pContextUser = pUser;
	return XUI_OK;
}

XUI_API int xuiTableGridSetEditMode(xui_widget pWidget, int iMode)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL || !__xuiTableGridEditModeValid(iMode) ) return XUI_ERROR_INVALID_ARGUMENT;
	if ( pData->iEditMode == iMode ) return XUI_OK;
	pData->iEditMode = iMode;
	return XUI_OK;
}

XUI_API int xuiTableGridGetEditMode(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->iEditMode : XUI_TABLE_GRID_EDIT_DISPLAY;
}

static int __xuiTableGridSetFontChildren(xui_table_grid_data_t* pData, xui_font pFont)
{
	int iRet;

	iRet = xuiTableViewSetFont(pData->pTable, pFont);
	if ( iRet == XUI_OK ) iRet = xuiInputSetFont(pData->pInput, pFont);
	if ( iRet == XUI_OK ) iRet = xuiNumericInputSetFont(pData->pNumeric, pFont);
	if ( iRet == XUI_OK ) iRet = xuiComboBoxSetFont(pData->pCombo, pFont);
	if ( iRet == XUI_OK ) iRet = xuiColorPickerSetFont(pData->pColor, pFont);
	if ( iRet == XUI_OK ) iRet = xuiDatePickerSetFont(pData->pDate, pFont);
	if ( iRet == XUI_OK ) iRet = xuiTextEditSetFont(pData->pTextEdit, pFont);
	if ( iRet == XUI_OK ) iRet = xuiButtonSetFont(pData->pTextOk, pFont);
	if ( iRet == XUI_OK ) iRet = xuiButtonSetFont(pData->pTextCancel, pFont);
	return iRet;
}

XUI_API int xuiTableGridSetFont(xui_widget pWidget, xui_font pFont)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	xui_font pOldFont;
	int iRet;

	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	if ( pData->pFont == pFont ) return XUI_OK;
    xui_font_slot_update_t fontUpdate={0};
    int fontStatus=xuiInternalFontSlotPrepare(pWidget->pContext,&pData->pFont,pFont,pWidget->bTypeInitialized!=0,true,&fontUpdate);
    if(fontStatus!=XUI_OK)return fontStatus;
    fontUpdate.widget=pWidget;
	pOldFont = pData->pFont;
	iRet = __xuiTableGridSetFontChildren(pData, pFont);
	if ( iRet != XUI_OK ) {
		(void)__xuiTableGridSetFontChildren(pData, pOldFont);
		return xuiInternalFontSlotEnd(&fontUpdate,true,iRet);
	}
	fontStatus=xuiInternalFontSlotPublish(&fontUpdate);
    if(fontStatus!=XUI_OK)return xuiInternalFontSlotEnd(&fontUpdate,true,fontStatus);
	return xuiInternalFontSlotEnd(&fontUpdate,true,XUI_OK);
}

XUI_API xui_font xuiTableGridGetFont(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->pFont : NULL;
}

XUI_API int xuiTableGridSetDefaultMetrics(xui_widget pWidget, float fColumnWidth, float fRowHeight, float fHeaderHeight)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	return xuiTableViewSetDefaultMetrics(pData->pTable, fColumnWidth, fRowHeight, fHeaderHeight);
}

XUI_API int xuiTableGridSetSelectionMode(xui_widget pWidget, int iMode)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	return xuiTableViewSetSelectionMode(pData->pTable, iMode);
}

XUI_API int xuiTableGridSetScrollbarMode(xui_widget pWidget, int iMode)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	return xuiTableViewSetScrollbarMode(pData->pTable, iMode);
}

XUI_API int xuiTableGridSetColors(xui_widget pWidget, uint32_t iBackground, uint32_t iHeader, uint32_t iRow, uint32_t iSelected, uint32_t iGrid, uint32_t iText)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	xui_table_view_colors_t tColors;
	int iRet;
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	iRet = xuiTableViewSetColors(pData->pTable, iBackground, iHeader, iRow, iSelected, iGrid, iText);
	if ( iRet != XUI_OK ) return iRet;
	iRet = xuiTableViewGetColors(pData->pTable, &tColors);
	if ( iRet != XUI_OK ) return iRet;
	return __xuiTableGridApplyEditorColors(pData, &tColors);
}

XUI_API int xuiTableGridSetColorStyle(xui_widget pWidget, const xui_table_view_colors_t* pColors)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	int iRet;
	if ( (pData == NULL) || (pColors == NULL) ) return XUI_ERROR_INVALID_ARGUMENT;
	iRet = xuiTableViewSetColorStyle(pData->pTable, pColors);
	if ( iRet != XUI_OK ) return iRet;
	return __xuiTableGridApplyEditorColors(pData, pColors);
}

static int __xuiTableGridBeginEditBody(xui_widget pWidget, int iRow, int iColumn, xui_table_grid_cell_lease_t* lease)
{
	xui_table_grid_data_t* pData;
	xui_table_view_cell_t tCell;
	xui_rect_t tRect;
	char sValue[XUI_TABLE_GRID_VALUE_CAPACITY];
	const char* sText;
	int iType;
	int bOK;
	int iRet;

	pData = __xuiTableGridGetData(pWidget);
	if ( (pData == NULL) || (pData->pTable == NULL) || (iRow < 0) || (iColumn < 0) ) {
		return 0;
	}
	if ( !xuiWidgetGetEffectiveEnabled(pWidget) || !xuiWidgetGetEffectiveVisible(pWidget) || pData->bCommitting ) {
		return 0;
	}
	iRet = xuiTableViewGetRowCount(pData->pTable);
	if ( !__xuiTableGridWidgetAlive(pWidget, pData) || iRet <= iRow ) {
		return 0;
	}
	if ( xuiTableViewGetColumnCount(pData->pTable) <= iColumn ) return 0;
	if ( pData->iEditingRow >= 0 && __xuiTableGridEndEditOperation(pWidget, 1) == 0 ) {
		return 0;
	}
	pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL || !__xuiTableGridGetCell(pWidget, pData, iRow, iColumn, &tCell,lease) ) return 0;
	if ( tCell.bDisabled || tCell.bReadOnly ) {
		return 0;
	}
	iType = tCell.iType;
	sText = __xuiTableGridCellText(pWidget, pData, iRow, iColumn, &tCell, lease, sValue, (int)sizeof(sValue));
	if ( sText == NULL || !__xuiTableGridWidgetAlive(pWidget, pData) ) return 0;
	if ( xuiTableViewGetSelectionMode(pData->pTable) == XUI_TABLE_VIEW_SELECTION_ROW ) {
		iRet = xuiTableViewSetSelectedRow(pData->pTable, iRow);
	} else {
		iRet = xuiTableViewSetSelectedCell(pData->pTable, iRow, iColumn);
	}
	if ( iRet != XUI_OK || !__xuiTableGridWidgetAlive(pWidget, pData) ) return 0;
	if ( iType == XUI_TABLE_CELL_TYPE_BOOL ) {
        bool oldBool=__xuiTableGridBoolValue(sText,tCell.pValue);
        if(lease->owned && __xuiTableGridCellEnd(lease,XUI_OK)!=XUI_OK)return 0;
        if(!__xuiTableGridWidgetAlive(pWidget,pData))return 0;
		pData->iEditingRow = iRow;
		pData->iEditingColumn = iColumn;
		pData->iEditingType = iType;
		snprintf(pData->sOriginalValue, sizeof(pData->sOriginalValue), "%s", oldBool ? "true" : "false");
		bOK = __xuiTableGridCommitValue(pWidget, pData, oldBool ? "false" : "true");
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		__xuiTableGridClearEditState(pData);
		(void)xuiTableViewRefresh(pData->pTable);
		return bOK;
	}
	iRet = xuiTableViewEnsureCellVisible(pData->pTable, iRow, iColumn);
	if ( !__xuiTableGridWidgetAlive(pWidget, pData) || iRet != XUI_OK ) return 0;
	__xuiTableGridHideEditors(pData);
	if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return 0;
	pData->iEditingRow = iRow;
	pData->iEditingColumn = iColumn;
	if ( !__xuiTableGridEditingRect(pWidget, pData, &tRect) ) {
		__xuiTableGridClearEditState(pData);
		return 0;
	}
	pData->iEditingType = iType;
	pData->iActiveEditor = XUI_TABLE_GRID_EDITOR_NONE;
	snprintf(pData->sOriginalValue, sizeof(pData->sOriginalValue), "%s", sText != NULL ? sText : "");
	if ( !__xuiTableGridLoadEditorConfig(pWidget, pData, iRow, iColumn, iType) ||
	     !__xuiTableGridWidgetAlive(pWidget, pData) ) {
		if ( __xuiTableGridWidgetAlive(pWidget, pData) ) {
			__xuiTableGridClearEditState(pData);
			__xuiTableGridHideEditors(pData);
			(void)xuiTableViewRefresh(pData->pTable);
		}
		return 0;
	}
	if ( iType == XUI_TABLE_CELL_TYPE_TEXTAREA ) {
		(void)xuiTableViewRefresh(pData->pTable);
		return __xuiTableGridOpenTextArea(pWidget, pData);
	}
	if ( __xuiTableGridIsPickerType(iType) ) {
		(void)xuiTableViewRefresh(pData->pTable);
		bOK = __xuiTableGridOpenPicker(pWidget, pData, &tCell,lease);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		__xuiTableGridClearEditState(pData);
		(void)xuiTableViewRefresh(pData->pTable);
		return bOK;
	}
	if ( iType == XUI_TABLE_CELL_TYPE_ENUM ) {
		bOK = __xuiTableGridBeginComboEdit(pWidget, pData, pData->sOriginalValue, tRect);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		if ( bOK ) {
			(void)xuiTableViewRefresh(pData->pTable);
			if ( pData->iEditMode != XUI_TABLE_GRID_EDIT_DISPLAY ) {
				(void)xuiComboBoxOpen(pData->pCombo);
			}
			return 1;
		}
		bOK = __xuiTableGridOpenPicker(pWidget, pData, &tCell,lease);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		if ( bOK ) {
			__xuiTableGridClearEditState(pData);
			return 1;
		}
	}
	if ( iType == XUI_TABLE_CELL_TYPE_COLOR ) {
		bOK = __xuiTableGridBeginColorEdit(pWidget, pData, pData->sOriginalValue, tRect);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		if ( bOK ) {
			(void)xuiTableViewRefresh(pData->pTable);
			if ( pData->iEditMode != XUI_TABLE_GRID_EDIT_DISPLAY ) {
				(void)xuiColorPickerOpen(pData->pColor);
			}
			return 1;
		}
	}
	if ( __xuiTableGridIsDateType(iType) ) {
		bOK = __xuiTableGridBeginDateEdit(pWidget, pData, pData->sOriginalValue, tRect, iType);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		if ( bOK ) {
			(void)xuiTableViewRefresh(pData->pTable);
			return 1;
		}
	}
	if ( iType == XUI_TABLE_CELL_TYPE_CUSTOM ) {
		bOK = __xuiTableGridOpenPicker(pWidget, pData, &tCell,lease);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		if ( bOK ) {
			__xuiTableGridClearEditState(pData);
			return 1;
		}
	}
	if ( __xuiTableGridIsNumericType(iType) ) {
		bOK = __xuiTableGridBeginNumericEdit(pWidget, pData, pData->sOriginalValue, tRect, iType);
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
		if ( bOK ) {
			(void)xuiTableViewRefresh(pData->pTable);
			return 1;
		}
	}
	bOK = __xuiTableGridBeginInputEdit(pWidget, pData, pData->sOriginalValue, tRect, iColumn, iType);
	if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return bOK;
	if ( bOK ) {
		(void)xuiTableViewRefresh(pData->pTable);
		return 1;
	}
	__xuiTableGridClearEditState(pData);
	__xuiTableGridHideEditors(pData);
	(void)xuiTableViewRefresh(pData->pTable);
	return 0;
}

static int __xuiTableGridBeginEditOperation(xui_widget widget,int row,int column)
{
    xui_table_grid_cell_lease_t lease={0};lease.context=xuiWidgetGetContext(widget);
    int accepted=__xuiTableGridBeginEditBody(widget,row,column,&lease);
    return __xuiTableGridCellEnd(&lease,XUI_OK)==XUI_OK ? accepted:0;
}

XUI_API int xuiTableGridBeginEdit(xui_widget pWidget, int iRow, int iColumn)
{
	xui_context pContext;
	xui_table_grid_data_t* pData;
	int iRet;

	if ( !xuiInternalWidgetIsValid(pWidget) ) return 0;
	pContext = xuiWidgetGetContext(pWidget);
	xuiInternalOperationEnter(pContext);
	pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL || pData->bStartingEdit || pData->bCommitting ) {
		xuiInternalOperationLeave(pContext);
		return 0;
	}
	pData->bStartingEdit = 1;
	iRet = __xuiTableGridBeginEditOperation(pWidget, iRow, iColumn);
	if ( __xuiTableGridWidgetAlive(pWidget, pData) ) pData->bStartingEdit = 0;
	xuiInternalOperationLeave(pContext);
	return iRet;
}

static int __xuiTableGridEndEditOperation(xui_widget pWidget, int bCommit)
{
	xui_table_grid_data_t* pData;
	char sBuffer[XUI_TABLE_GRID_VALUE_CAPACITY];
	const char* sValue;

	pData = __xuiTableGridGetData(pWidget);
	if ( (pData == NULL) || (pData->iEditingRow < 0) || (pData->iEditingColumn < 0) ) {
		return 1;
	}
	if ( pData->bCommitting ) return 0;
	if ( bCommit ) {
		sValue = __xuiTableGridCurrentEditorValue(pData, sBuffer, (int)sizeof(sBuffer));
		if ( __xuiTableGridCommitValue(pWidget, pData, sValue) == 0 ) {
			return 0;
		}
		if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return 1;
	} else {
		pData->iCancelCount++;
	}
	__xuiTableGridClearEditState(pData);
	(void)xuiInputSetText(pData->pInput, "");
	(void)xuiInputSetError(pData->pInput, 0);
	(void)xuiNumericInputSetText(pData->pNumeric, "");
	__xuiTableGridHideEditors(pData);
	if ( !__xuiTableGridWidgetAlive(pWidget, pData) ) return 1;
	if ( pData->pTable != NULL ) {
		if ( xuiWidgetGetEffectiveEnabled(pWidget) && xuiWidgetGetEffectiveVisible(pWidget) )
			(void)xuiSetFocusWidget(xuiWidgetGetContext(pWidget), pData->pTable);
		(void)xuiTableViewRefresh(pData->pTable);
	}
	return 1;
}

XUI_API int xuiTableGridEndEdit(xui_widget pWidget, int bCommit)
{
	xui_context pContext;
	xui_table_grid_data_t* pData;
	int iRet;

	if ( !xuiInternalWidgetIsValid(pWidget) ) return 1;
	pContext = xuiWidgetGetContext(pWidget);
	xuiInternalOperationEnter(pContext);
	pData = __xuiTableGridGetData(pWidget);
	if ( pData != NULL && pData->bStartingEdit ) {
		xuiInternalOperationLeave(pContext);
		return 0;
	}
	iRet = __xuiTableGridEndEditOperation(pWidget, bCommit);
	xuiInternalOperationLeave(pContext);
	return iRet;
}

XUI_API int xuiTableGridIsEditing(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) && (pData->iEditingRow >= 0) && (pData->iEditingColumn >= 0);
}

XUI_API int xuiTableGridGetEditingCell(xui_widget pWidget, int* pRow, int* pColumn)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	if ( pData == NULL ) return XUI_ERROR_INVALID_ARGUMENT;
	if ( pRow != NULL ) *pRow = pData->iEditingRow;
	if ( pColumn != NULL ) *pColumn = pData->iEditingColumn;
	return XUI_OK;
}

XUI_API int xuiTableGridGetCommitCount(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->iCommitCount : 0;
}

XUI_API int xuiTableGridGetRejectCount(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->iRejectCount : 0;
}

XUI_API int xuiTableGridGetCancelCount(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->iCancelCount : 0;
}

XUI_API int xuiTableGridGetPickerCount(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->iPickerCount : 0;
}

XUI_API int xuiTableGridGetChangeCount(xui_widget pWidget)
{
	xui_table_grid_data_t* pData = __xuiTableGridGetData(pWidget);
	return (pData != NULL) ? pData->iChangeCount : 0;
}

#endif

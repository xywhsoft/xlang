
from pathlib import Path
import concurrent.futures,json,os,shutil,subprocess,time,hashlib
root=Path('D:/GIT/x-lang');b=Path('F:/xlang-validation/xui-gallery-20261106');runtime=root/'release/win_x64';source=root/'lib/bindings/xui/examples'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(json.loads((b/name).read_text())['passed']for name in('final-win-r4/results.json','final-win-r5/results.json','alias-final-candidate/results.json'))
# Canonical programs are copied byte-for-byte; preserve every unrelated file.
files=sorted(p for p in source.iterdir()if p.is_file()and p.suffix in('.xl','.md','.json','.bat'))
for directory in ('release/win_x64/examples/xui','release/linux_x64/examples/xui','release/win_x64/extlibs/xui/examples','release/linux_x64/extlibs/xui/examples','release/win_x64/static/xge3/packages/xui/examples'):
 target=root/directory;target.mkdir(parents=True,exist_ok=True)
 for p in files:
  destination=target/p.name
  if not destination.exists()or sha(p)!=sha(destination):
   pending=destination.with_name(destination.name+'.gallery-pending');shutil.copy2(p,pending);os.replace(pending,destination)
  assert sha(p)==sha(destination)
# Pin the packages and compiler actually used by the installed-path checks.
out=b/'installed-acceptance';out.mkdir();inputs={str(p):sha(p)for p in files};inputs.update((str(runtime/n),sha(runtime/n))for n in('xl.exe','xl.dll','xlc.dll'));env={k:v for k,v in os.environ.items()if not k.startswith('XUI_EXAMPLE_')};env.update(XLANG_PACKAGE_PATH=str(runtime/'extlibs'),XUI_EXAMPLE_FRAMES='3');cases=[]
for name in ('headless_path','headless_cell','context_graph','manager_lifetime','document_model','document_ui_headless','data_object','gui_surface_draw','all_controls'):
 cases.append((name,[str(runtime/'xl.exe'),'run',str(runtime/'examples/xui'/(name+'.xl'))]))
cases += [('bat-launcher',['cmd.exe','/d','/c',str(runtime/'examples/xui/run_xui_examples.bat')]),('powershell-launcher',['powershell.exe','-NoProfile','-File',str(root/'tools/run_xui_examples.ps1'),'-Example','button','-Run','-Frames','3'])]
def run(item):
 name,args=item;start=time.monotonic();r=subprocess.run(args,cwd=runtime,env=env,capture_output=True,timeout=180);log=out/(name+'.log');log.write_bytes(r.stdout+r.stderr);row=dict(name=name,command=args,exitCode=r.returncode,seconds=time.monotonic()-start,logSha256=sha(log));print(name,r.returncode,flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(run,cases))
report=dict(complete=True,passed=all(row['exitCode']==0 for row in rows)and all(sha(p)==h for p,h in inputs.items()),rows=rows,inputs=inputs);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');assert report['passed']
# Same full gallery with the installed optional static SDK, in a standalone directory.
out=b/'static-gallery';out.mkdir();env['XLANG_PACKAGE_PATH']=str(runtime/'static/xge3/packages');args=[str(runtime/'xl.exe'),'build',str(runtime/'examples/xui/all_controls.xl'),'-o',str(out/'program.exe')];start=time.monotonic();r=subprocess.run(args,cwd=runtime,env=env,capture_output=True,timeout=180);(out/'build.log').write_bytes(r.stdout+r.stderr);rows=[dict(mode='build',exitCode=r.returncode,seconds=time.monotonic()-start)];assert not r.returncode,(out/'build.log')
env.pop('XLANG_PACKAGE_PATH');env.update(XUI_EXAMPLE_CYCLE='1',XUI_EXAMPLE_FRAMES='143',XUI_EXAMPLE_FONT=str(runtime/'data/fonts/Consolas-with-Yahei_Nerd_Font.ttf'));start=time.monotonic();r=subprocess.run([str(out/'program.exe')],cwd=out,env=env,capture_output=True,timeout=60);(out/'execute.log').write_bytes(r.stdout+r.stderr);scenes=sum(line.startswith(b'SCENE ')for line in r.stdout.splitlines());rows.append(dict(mode='execute',exitCode=r.returncode,scenes=scenes,seconds=time.monotonic()-start));report=dict(complete=True,passed=all(row['exitCode']==0 for row in rows)and scenes==47,rows=rows,programSha256=sha(out/'program.exe'));(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');assert report['passed'];print('INSTALLED AND STATIC PASSED',flush=True)

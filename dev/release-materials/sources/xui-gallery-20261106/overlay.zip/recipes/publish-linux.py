from pathlib import Path
import json,hashlib,shutil,os
b=Path('/home/ubuntu/xlang-validation/xui-gallery-20261106');root=Path('/mnt/d/GIT/x-lang');out=b/'publication-r2';out.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();r=json.loads((b/'production-accept-r1/results.json').read_text());assert r['complete']and r['passed'];rows=[]
def put(src,dst):
 src,dst=Path(src),Path(dst);old=out/'rollback'/dst.relative_to(root);old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,old);tmp=dst.with_name(dst.name+'.gallery-pending');shutil.copy2(src,tmp);os.replace(tmp,dst);rows.append(dict(path=str(dst),previousSha256=sha(old),sha256=sha(dst),bytes=dst.stat().st_size))
for name in ('libxl.so','libxlc.so'):put(b/'compiler-inline-r3'/name,root/'release/linux_x64'/name)
p=root/'release/linux_x64/extlibs/_xge_native';s=b/'columns-r1/source';put(b/'columns-r1/host/libxge3_host.so',p/'native/libxge3_host.so')
for name in ('xge.h','xui.h'):put(s/'include'/name,p/'include'/name)
put(b/'columns-r1/host/xge_build_config.h',p/'include/xge_build_config.h')
f=p/'xlang.package.json';m=json.loads(f.read_text());m['native']['sha256']=sha(p/'native/libxge3_host.so');t=f.with_name(f.name+'.gallery-pending');t.write_text(json.dumps(m,indent=2)+'\n');os.replace(t,f)
(out/'receipt.json').write_text(json.dumps(dict(complete=True,passed=True,rows=rows,coreCpuRows=len(r['rows'])),indent=2)+'\n');print('published',len(rows),'CPU',len(r['rows']))

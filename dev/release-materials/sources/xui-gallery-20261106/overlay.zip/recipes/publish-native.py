from pathlib import Path
import json,shutil,hashlib,time,os
b=Path('F:/xlang-validation/xui-gallery-20261106');root=Path('D:/GIT/x-lang');source=b/'columns-r1/source';assert json.loads((b/'columns-r1/cpu-r3/results.json').read_text())['passed'];out=b/'publication-r5';out.mkdir();rows=[];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(src,dst):
 src,dst=Path(src),Path(dst);before=sha(dst)if dst.exists()else None
 if before!=sha(src):
  backup=out/'rollback'/dst.relative_to(root);backup.parent.mkdir(parents=True,exist_ok=True)
  if dst.exists():shutil.copy2(dst,backup)
  for attempt in range(3):
   try:
    pending=dst.with_name(dst.name+".gallery-pending")
    shutil.copy2(src,pending)
    os.replace(pending,dst)
    break
   except OSError:
    if attempt==2:raise
    time.sleep(.5)
 rows.append(dict(source=str(src),target=str(dst),beforeSha256=before,sha256=sha(dst),bytes=dst.stat().st_size))
private=root/'release/win_x64/extlibs/_xge_native'
put(b/'columns-r1/host-win/xge3_host.dll',private/'native/xge3_host.dll')
for name in ('xge.h','xui.h'):put(source/'include'/name,private/'include'/name)
put(b/'columns-r1/host-win/xge_build_config.h',private/'include/xge_build_config.h')
p=private/'xlang.package.json';m=json.loads(p.read_text());m['native']['sha256']=sha(private/'native/xge3_host.dll');pending=p.with_name(p.name+'.gallery-pending');pending.write_text(json.dumps(m,indent=2)+'\n');os.replace(pending,p)
static=root/'release/win_x64/static/xge3/packages/_xge_native';product=b/'columns-r1/static-win'
put(product/'libxge3_static.a',static/'native/libxge3_static.a')
for name in ('xge.h','xui.h'):put(source/'include'/name,static/'include'/name)
for name in ('xge_build_config.h','xge_static_xrt_contract.h'):put(product/name,static/'include'/name)
r=json.loads((product/'build-report.json').read_text());support=[]
for a in r['compiler_support']['artifacts']:
 src=Path(a['path']);dst=static/'native'/src.name;assert sha(dst)==a['sha256'],(src,'compiler support changed');support.append(dict(path=str(dst),sha256=sha(dst)))
p=static/'xlang.package.json';m=json.loads(p.read_text());m['native']['sha256']=sha(static/'native/libxge3_static.a');pending=p.with_name(p.name+'.gallery-pending');pending.write_text(json.dumps(m,indent=2)+'\n');os.replace(pending,p)
for p in (root/'release/win_x64/extlibs/xui/src/managed.xl',root/'release/linux_x64/extlibs/xui/src/managed.xl',root/'release/win_x64/static/xge3/packages/xui/src/managed.xl'):put(root/'lib/bindings/xui/src/managed.xl',p)
(out/'receipt.json').write_text(json.dumps(dict(complete=True,passed=True,scope='Matched copied-column Native SDK and static cohort; compiler-support artifact bytes unchanged.',rows=rows,compilerSupportUnchanged=support),indent=2)+'\n')

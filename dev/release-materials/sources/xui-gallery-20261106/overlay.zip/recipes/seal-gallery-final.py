"""Seal the final source overlay, raw reports and current local delivery."""
from pathlib import Path
import json,hashlib,zipfile,shutil,os
root=Path('D:/GIT/x-lang');b=Path('F:/xlang-validation/xui-gallery-20261106');materials=root/'dev/release-materials'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,data):
 p=Path(p);t=p.with_name(p.name+'.gallery-pending');t.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(t,p)
def ref(p):return dict(path=Path(p).relative_to(root).as_posix(),sha256=sha(p),bytes=Path(p).stat().st_size)
def passed(p):
 r=load(p);assert r['complete']and r['passed'],p;return r
win1=passed(b/'final-win-r4/results.json');win2=passed(b/'final-win-r5/results.json');assert len(win1['rows'])+len(win2['rows'])==96
alias=passed(b/'alias-final-candidate/results.json');adoption=passed(b/'alias-adoption.json');installed=passed(b/'installed-acceptance-final.json');static=passed(b/'static-gallery/results.json');linux=b/'linux-evidence';lin=passed(linux/'gallery-build-r2/results.json');assert len(lin['rows'])==48;passed(linux/'final-alias-and-cpu/results.json');lincpu=passed(linux/'production-accept-r1/results.json');wincpu=passed(b/'production-accept-r1/results.json');passed(b/'columns-r1/cpu-r3/results.json')
source=root/'lib/bindings/xui/examples';programs=[p for p in source.glob('*.xl')if not p.name.startswith('_')];assert len(programs)==56
# The sole final contract refinement changes two clients, without changing any native ABI.
for name in ('accordion','all_controls'):assert sha(source/(name+'.xl'))==sha(b/'alias-final-candidate/lib/bindings/xui/examples'/(name+'.xl'))
for name in {r['example']for r in win1['rows']+win2['rows']}-{'accordion','all_controls'}:
 p=source/(name+'.xl');assert win1['inputs'][str(p)]==sha(p)
for row in adoption['rows']:
 if row['path'].endswith('managed.xl'):assert sha(row['path'])==row['sha256']
files=sorted(p for p in source.iterdir()if p.is_file()and p.suffix in('.xl','.md','.json','.bat'));publication=[]
for directory in ('release/win_x64/examples/xui','release/linux_x64/examples/xui','release/win_x64/extlibs/xui/examples','release/linux_x64/extlibs/xui/examples','release/win_x64/static/xge3/packages/xui/examples'):
 for p in files:
  dest=root/directory/p.name;assert sha(dest)==sha(p);publication.append(ref(dest))
src=materials/'sources/xui-gallery-20261106';prov=materials/'provenance/xui-gallery-20261106';src.mkdir(exist_ok=False);prov.mkdir(exist_ok=False);index=materials/'provenance/current-delivery.json';shutil.copy2(index,prov/'previous-delivery.json')
# All build inputs not present here remain in the exact predecessor bundles.
source_files=[*files,root/'lib/bindings/xui/src/managed.xl']+[root/'tools'/n for n in('xui_gallery_contracts.py','update_xui_gallery.py','check_xui_gallery.py','run_xui_examples.ps1','check_xge3_bindings.py','gen_tcc_vfs_resources.py')]+[root/'docs/xge3-xui3-example-status.md'];entries=[]
with zipfile.ZipFile(src/'overlay.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
 def add(p,entry):
  archive.write(p,entry);entries.append(dict(source=str(p),entry=entry,sha256=sha(p),bytes=Path(p).stat().st_size))
 for p in source_files:add(p,'xlang/'+p.relative_to(root).as_posix())
 for name in ('src/xui/core/xui_core.c','src/xui/controls/xui_table_view.c','src/xui/controls/xui_table_grid.c','include/xui.h','tools/build/static.py','tools/build/static_support.py'):add(b/'columns-r1/source'/name,'native/'+name)
 for name in ('test_xui_owned_context_proxy.c','test_xui_column_copy.c'):add(Path('D:/GIT/xge/tests')/name,'native/tests/'+name)
 for name in ('rebuild-inline-catalog.py','rebuild-inline-linux.py','patch-column-copy.py','publish-native.py','publish-linux.py','check-final-linux.py','check-alias-candidate.py','publish-and-check.py','seal-gallery-final.py'):add(b/name,'recipes/'+name)
 patched=linux/'compiler-inline-r3/gen_tcc_vfs_resources.py';add(patched,'recipes/linux-legacy-gen_tcc_vfs_resources.py')
write(src/'manifest.json',dict(schema=1,scope='Exact gallery/binding/source overlays over preserved compiler and Native source cohorts. Compiler Linux baseline remains its earlier frozen production source; only its resource tool changes.',archive=ref(src/'overlay.zip'),entries=entries,nativeCommits=['a9eb0aa6','4d402c0'],nativeBase=ref(materials/'sources/xge-static-20261106-r1/manifest.json'),windowsCoreBase=ref(materials/'sources/native-static-core-20261106/manifest.json'),linuxCoreParent='linux-evidence/compiler-inline-r3/results.json in acceptance.zip'))
records=[]
with zipfile.ZipFile(prov/'acceptance.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
 for p in sorted(b.rglob('*')):
  relative=p.relative_to(b)
  if not p.is_file()or any(part in('source','producer','packages','packages-r2','release','rollback','obj','obj-debug','combined-members')for part in relative.parts):continue
  if p.suffix not in('.json','.log','.py','.sh','.png'):continue
  archive.write(p,relative.as_posix());records.append(dict(path=str(p),entry=relative.as_posix(),sha256=sha(p),bytes=p.stat().st_size))
products=[root/'release'/platform/name for platform,names in [('win_x64',('xl.dll','xlc.dll')),('linux_x64',('libxl.so','libxlc.so'))]for name in names]
for platform,library in [('win_x64','xge3_host.dll'),('linux_x64','libxge3_host.so')]:
 base=root/'release'/platform/'extlibs/_xge_native';products.extend([base/'native'/library,base/'xlang.package.json',*[base/'include'/name for name in('xge.h','xui.h','xge_build_config.h')]])
base=root/'release/win_x64/static/xge3/packages/_xge_native';products.extend([base/'native/libxge3_static.a',base/'xlang.package.json',*[base/'include'/name for name in('xge.h','xui.h','xge_build_config.h','xge_static_xrt_contract.h')]])
receipt=dict(schema=1,date='2026-11-06',complete=True,passed=True,externalPublishPerformed=False,scope='48 rewritten declarative XUI entrypoints and eight retained examples, matched Native/SDK ownership corrections and actual production compilers.',sources=ref(src/'manifest.json'),archive=ref(prov/'acceptance.zip'),records=records,products=[ref(p)for p in products],publishedExamples=publication,counts=dict(publicPrograms=56,galleryEntrypoints=48,aggregateScenes=47,windowsBuildAndExecuteRows=96,finalAliasCandidateRows=4,linuxBuilds=48,linuxFinalAliasAndCpuRows=9,windowsInstalledRows=len(installed['rows']),windowsStaticRows=len(static['rows']),windowsCoreCpuRows=len(wincpu['rows']),linuxCoreCpuRows=len(lincpu['rows'])),nativeCommits=['a9eb0aa6','4d402c0'],builds=dict(windowsCore='Two resource objects rebuilt over exact Root11 production objects; algorithms unchanged.',linuxCore='Both earlier frozen production profiles fully recompiled with original O2 flags, 2835 translation units; only resource catalogs changed.',native='Fresh matched hosts/static profiles with additive copied-column APIs; Windows host resumed its validated own cache after one OOM. Compiler-support artifacts unchanged.'),limits=['Real bounded Windows graphics, 47-scene switching and one synthetic button-click assertion; not exhaustive manual UI or performance testing.','Linux has no display: CPU execution and AOT builds only.','Array projections use O(n) temporary storage; table columns copy text into one owned native allocation. Checked lifetime/error costs remain.','No network/security, browser, shell or OS clipboard tests.','Unrelated live compiler/IDE/native edits and historical flat-release deletions are excluded.'],previousIndex=ref(prov/'previous-delivery.json'))
write(prov/'receipt.json',receipt)
r=load(index)
for row in r['products']:
 for product in receipt['products']:
  if row['path']==product['path']:row.update(product,origin='xui-gallery-20261106')
r['compiler']['previousGalleryBuildEvidence']=r['compiler']['currentBuildProvenance'];r['compiler']['currentBuildProvenance']=ref(prov/'receipt.json')['path'];r['compiler']['buildScope']=receipt['builds'];r['compiler']['sourceOverlays'].append(ref(src/'manifest.json'));r['sourceMaterials']['xuiGallery']=ref(src/'manifest.json');r['xuiGallery']=dict(status='installed-qualified',provenance=ref(prov/'receipt.json'),sourceMaterials=ref(src/'manifest.json'),publicPrograms=56,galleryEntrypoints=48,aggregateScenes=47,windowsBuildAndExecuteRows=96,linuxBuilds=48,linuxGuiRun=False,report='docs/reports/xui-gallery-20261106.md');r['nativeStaticIntegration']['gallerySuccessor']=ref(prov/'receipt.json');sdk=root/'release/win_x64/static/xge3/packages';r['nativeStaticIntegration']['staticSdk'].update(files=sum(p.is_file()for p in sdk.rglob('*')),bytes=sum(p.stat().st_size for p in sdk.rglob('*')if p.is_file()));write(index,r);write(b/'seal-result.json',dict(complete=True,passed=True,sourceMaterials=ref(src/'manifest.json'),provenance=ref(prov/'receipt.json')));print('SEALED',len(files),'source files',len(publication),'published files',len(records),'raw evidence files')

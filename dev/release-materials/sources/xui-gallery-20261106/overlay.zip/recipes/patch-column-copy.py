from pathlib import Path
import json,hashlib
base=Path('F:/xlang-validation/xui-gallery-20261106/owned-proxy-r1/source');live=Path('D:/GIT/xge')
helpers='''typedef struct xui_table_column_storage_t {
    size_t references;
    size_t bytes;
    xui_table_view_column_t columns[];
} xui_table_column_storage_t;

static int __xuiTableColumnStorageRetain(xui_table_column_storage_t* storage)
{
    if (!storage) return XUI_OK;
    if (storage->references == (size_t)-1) return XUI_ERROR_LIMIT_EXCEEDED;
    ++storage->references;
    return XUI_OK;
}
static void __xuiTableColumnStorageRelease(xui_table_column_storage_t* storage)
{
    if (storage && --storage->references == 0) xrtFree(storage);
}
static int __xuiTableColumnStorageAliases(const xui_table_column_storage_t* storage,
    const xui_table_view_column_t* columns, int count)
{
    if (!storage) return 0;
    uintptr_t start = (uintptr_t)storage;
    for (int i = 0; i < count; ++i) {
        uintptr_t id = (uintptr_t)columns[i].sId;
        uintptr_t title = (uintptr_t)columns[i].sTitle;
        if ((id >= start && id - start < storage->bytes) ||
            (title >= start && title - start < storage->bytes)) return 1;
    }
    return 0;
}

'''
copyapi='''/* The ordinary setter keeps its existing borrowed-string contract. This
 * variant owns one contiguous copy of both text fields. Other pointer fields
 * (callbacks/user data) keep their explicit C borrowing contract. */
XUI_API int xuiTableViewSetColumnsCopy(xui_widget widget,
    const xui_table_view_column_t* columns, int count)
{
    if (!__xuiTableViewGetData(widget) || count < 0 ||
        count > XUI_TABLE_VIEW_COLUMN_CAPACITY || (count && !columns))
        return XUI_ERROR_INVALID_ARGUMENT;
    size_t bytes = sizeof(xui_table_column_storage_t) + (size_t)count * sizeof(*columns);
    for (int i = 0; i < count; ++i) {
        if (!__xuiTableViewColumnDescValid(&columns[i])) return XUI_ERROR_INVALID_ARGUMENT;
        const char* texts[2] = { columns[i].sId, columns[i].sTitle };
        for (int field = 0; field < 2; ++field) if (texts[field]) {
            size_t length = strlen(texts[field]);
            if (length == (size_t)-1 || length + 1 > (size_t)-1 - bytes)
                return XUI_ERROR_LIMIT_EXCEEDED;
            bytes += length + 1;
        }
    }
    xui_table_column_storage_t* storage = count ? xrtMalloc(bytes) : NULL;
    if (count && !storage) return XUI_ERROR_OUT_OF_MEMORY;
    if (storage) {
        storage->references = 1;
        storage->bytes = bytes;
        memcpy(storage->columns, columns, (size_t)count * sizeof(*columns));
        char* text = (char*)(storage->columns + count);
        for (int i = 0; i < count; ++i) {
            const char* inputs[2] = { columns[i].sId, columns[i].sTitle };
            const char** outputs[2] = { &storage->columns[i].sId, &storage->columns[i].sTitle };
            for (int field = 0; field < 2; ++field) if (inputs[field]) {
                size_t length = strlen(inputs[field]) + 1;
                memcpy(text, inputs[field], length);
                *outputs[field] = text;
                text += length;
            }
        }
    }
    xui_context context = xuiWidgetGetContext(widget);
    xuiInternalOperationEnter(context);
    int result = __xuiTableViewSetColumnsOperation(widget,
        storage ? storage->columns : NULL, count, storage);
    xuiInternalOperationLeave(context);
    __xuiTableColumnStorageRelease(storage);
    return result;
}

'''
def patch_view(s):
 assert 'xuiTableViewSetColumnsCopy' not in s
 anchor='typedef struct xui_table_view_data_t {';assert s.count(anchor)==1;s=s.replace(anchor,helpers+anchor)
 anchor='\txui_table_view_column_t arrColumns[XUI_TABLE_VIEW_COLUMN_CAPACITY];';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n    xui_table_column_storage_t* pColumnStorage;')
 anchor='        xrtFree(pData->sResolvedTooltip);pData->sResolvedTooltip=NULL;';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n        __xuiTableColumnStorageRelease(pData->pColumnStorage);pData->pColumnStorage=NULL;')
 start=s.index('static int __xuiTableViewSetColumnsOperation(');end=s.index('\nstatic int __xuiTableViewSetRowsOperation',start);f=s[start:end]
 f=f.replace('const xui_table_view_column_t* arrColumns, int iCount)','const xui_table_view_column_t* arrColumns, int iCount, xui_table_column_storage_t* storage)',1)
 f=f.replace('\tmemset(arrNewColumns, 0, sizeof(arrNewColumns));','    if (!__xuiTableViewWidgetAlive(pWidget,pData)) return XUI_ERROR_INVALID_STATE;\n\tmemset(arrNewColumns, 0, sizeof(arrNewColumns));',1)
 anchor='\t__xuiTableViewCancelPointer(pWidget, pData, 1);';assert f.count(anchor)==1
 f=f.replace(anchor,'''    xui_table_column_storage_t* oldStorage = pData->pColumnStorage;
    if (!storage && __xuiTableColumnStorageAliases(oldStorage,arrColumns,iCount)) storage = oldStorage;
    if (__xuiTableColumnStorageRetain(oldStorage) != XUI_OK) return XUI_ERROR_LIMIT_EXCEEDED;
    if (__xuiTableColumnStorageRetain(storage) != XUI_OK) {
        __xuiTableColumnStorageRelease(oldStorage);
        return XUI_ERROR_LIMIT_EXCEEDED;
    }
'''+anchor+'''
    if (!__xuiTableViewWidgetAlive(pWidget,pData)) {
        __xuiTableColumnStorageRelease(oldStorage);
        __xuiTableColumnStorageRelease(storage);
        return XUI_ERROR_INVALID_STATE;
    }
    xui_table_column_storage_t* previousStorage = pData->pColumnStorage;
    pData->pColumnStorage = storage; /* transfer the reserved field reference */
    __xuiTableColumnStorageRelease(previousStorage);''')
 anchor='\tiRet = __xuiTableViewUpdateContentSizeCommitted(pWidget, pData);';assert f.count(anchor)==1;f=f.replace(anchor,anchor+'''
    if (!__xuiTableViewWidgetAlive(pWidget,pData)) {
        __xuiTableColumnStorageRelease(oldStorage);
        return iRet == XUI_OK ? XUI_ERROR_INVALID_STATE : iRet;
    }''')
 anchor='\tif ( iRet != XUI_OK ) {\n\t\tmemcpy(pData->arrColumns, arrOldColumns, sizeof(arrOldColumns));';assert f.count(anchor)==1
 f=f.replace(anchor,'''\tif ( iRet != XUI_OK ) {
        previousStorage = pData->pColumnStorage;
        pData->pColumnStorage = oldStorage; /* transfer the rollback snapshot */
        __xuiTableColumnStorageRelease(previousStorage);
\t\tmemcpy(pData->arrColumns, arrOldColumns, sizeof(arrOldColumns));''')
 anchor='\tpData->iChangeCount++;';assert f.count(anchor)==1;f=f.replace(anchor,'    __xuiTableColumnStorageRelease(oldStorage);\n'+anchor)
 s=s[:start]+f+s[end:]
 anchor='\tiRet = __xuiTableViewSetColumnsOperation(pWidget, arrColumns, iCount);';assert s.count(anchor)==1;s=s.replace(anchor,'\tiRet = __xuiTableViewSetColumnsOperation(pWidget, arrColumns, iCount, NULL);')
 anchor='XUI_API int xuiTableViewSetRows(';assert s.count(anchor)==1;s=s.replace(anchor,copyapi+anchor)
 return s
def patch_grid(s):
 anchor='XUI_API int xuiTableGridSetRows(';assert s.count(anchor)==1
 f='''/* Same edit boundary as the borrowed setter, with owned column text. */
XUI_API int xuiTableGridSetColumnsCopy(xui_widget widget,
    const xui_table_view_column_t* columns, int count)
{
    if (!xuiInternalWidgetIsValid(widget) || !__xuiTableGridColumnsValid(columns,count))
        return XUI_ERROR_INVALID_ARGUMENT;
    xui_context context=xuiWidgetGetContext(widget);
    xuiInternalOperationEnter(context);
    xui_table_grid_data_t* data=__xuiTableGridGetData(widget);
    int result=XUI_ERROR_INVALID_ARGUMENT;
    if (data && data->pTable) {
        if (data->iEditingRow>=0 && xuiTableGridEndEdit(widget,0)==0) result=XUI_ERROR_INVALID_STATE;
        else {
            data=__xuiTableGridGetData(widget);
            if (data && data->pTable) result=xuiTableViewSetColumnsCopy(data->pTable,columns,count);
        }
    }
    xuiInternalOperationLeave(context);
    return result;
}

'''
 return s.replace(anchor,f+anchor)
def patch_header(s):
 for cls in ('TableView','TableGrid'):
  anchor=f'XUI_API int xui{cls}SetColumns(xui_widget pWidget, const xui_table_view_column_t* arrColumns, int iCount);';assert s.count(anchor)==1
  s=s.replace(anchor,anchor+'\n/* Copies descriptor and sId/sTitle text. Callback/user pointer lifetimes remain caller-owned. */\n'+f'XUI_API int xui{cls}SetColumnsCopy(xui_widget pWidget, const xui_table_view_column_t* arrColumns, int iCount);')
 return s
patches={'src/xui/controls/xui_table_view.c':patch_view,'src/xui/controls/xui_table_grid.c':patch_grid,'include/xui.h':patch_header}
rows=[]
for path,patch in patches.items():
 for root in (base,live):
  p=root/path;s=p.read_text(encoding='utf-8');t=patch(s);p.write_text(t,encoding='utf-8');rows.append(dict(path=str(p),before=hashlib.sha256(s.encode()).hexdigest(),after=hashlib.sha256(t.encode()).hexdigest()))
Path('F:/xlang-validation/xui-gallery-20261106/column-copy-source.json').write_text(json.dumps(rows,indent=2)+'\n')

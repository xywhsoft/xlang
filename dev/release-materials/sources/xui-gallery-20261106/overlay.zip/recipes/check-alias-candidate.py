from pathlib import Path
import shutil,subprocess,json,os,time,hashlib,concurrent.futures
root=Path('D:/GIT/x-lang');b=Path('F:/xlang-validation/xui-gallery-20261106');out=b/'alias-final-candidate';source=out/'lib/bindings/xui/examples';source.parent.mkdir(parents=True);shutil.copytree(root/'lib/bindings/xui/examples',source);(out/'tools').mkdir();shutil.copy2(root/'tools/update_xui_gallery.py',out/'tools/update_xui_gallery.py');shutil.copy2(b/'accordion-null-output-probe/accordion.xl',source/'accordion.xl');subprocess.run(['python','-B',str(out/'tools/update_xui_gallery.py')],check=True)
packages=b/'accordion-null-output-probe/packages';runtime=root/'release/win_x64';env=dict(os.environ,XLANG_PACKAGE_PATH=str(packages),XUI_EXAMPLE_FRAMES='3');env.pop('XUI_EXAMPLE_DUMP',None);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();inputs={str(p):sha(p)for p in source.rglob('*')if p.is_file()};inputs[str(packages/'xui/src/managed.xl')]=sha(packages/'xui/src/managed.xl');rows=[]
def run(name):
 exe=out/(name+'.exe');args=[str(runtime/'xl.exe'),'build',str(source/(name+'.xl')),'-o',str(exe)];r=subprocess.run(args,cwd=runtime,env=env,capture_output=True,timeout=180);(out/(name+'-build.log')).write_bytes(r.stdout+r.stderr);local=[dict(name=name,mode='build',exitCode=r.returncode,command=args)]
 if not r.returncode:
  child=dict(env,PATH=str(runtime/'extlibs/_xge_native/native')+os.pathsep+env.get('PATH',''));child.pop('XLANG_PACKAGE_PATH',None)
  if name=='all_controls':child.update(XUI_EXAMPLE_CYCLE='1',XUI_EXAMPLE_FRAMES='143')
  r=subprocess.run([str(exe)],cwd=runtime,env=child,capture_output=True,timeout=60);(out/(name+'-execute.log')).write_bytes(r.stdout+r.stderr);scenes=sum(v.startswith(b'SCENE ')for v in r.stdout.splitlines());local.append(dict(name=name,mode='execute',exitCode=r.returncode,scenes=scenes,artifactSha256=sha(exe)));assert name!='all_controls'or scenes==47
 print(name,[(v['mode'],v['exitCode'])for v in local],flush=True);return local
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for records in pool.map(run,('accordion','all_controls')):rows+=records
report=dict(complete=True,passed=all(v['exitCode']==0 for v in rows)and all(sha(p)==h for p,h in inputs.items()),inputs=inputs,rows=rows,scope='Direct native add with NULL output and explicit internal-alias getter. Same Native ABI/cohort; only accordion and aggregate source bodies change.');(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');assert report['passed']

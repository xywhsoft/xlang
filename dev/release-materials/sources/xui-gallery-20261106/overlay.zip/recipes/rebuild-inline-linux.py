from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time,sys,shutil
b=Path('/home/ubuntu/xlang-validation/xui-gallery-20261106');out=b/'compiler-inline-r3';out.mkdir();parent=Path('/home/ubuntu/xlang-validation/production-final-linux-r1');meta=json.loads((parent/'production-build.json').read_text());old=Path('/home/ubuntu/xlang-validation/provider-final-core-linux-r1');tool=old/'producer/tools/gen_tcc_vfs_resources.py';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();report=dict(complete=False,passed=False,parent=str(parent/'production-build.json'),parentSha256=sha(parent/'production-build.json'),scope='Frozen production Linux source and O2 flags; only Host-XRT inline SDK aliases added. Parent did not retain .o files, so both production profiles are fully recompiled without algorithm or ABI changes.',rows=[],sourceRoot=meta['producer']);save=lambda:(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,cwd=None,timeout=1200):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,timeout=timeout);log=out/(name+'.log');log.write_bytes(r.stdout+r.stderr);row=dict(name=name,command=list(map(str,args)),exitCode=r.returncode,seconds=time.monotonic()-start,logSha256=sha(log));print(name,r.returncode,flush=True);return row
commands=[r['command']for r in json.loads((old/'provider.json').read_text())['rows']if r['name']in('runtime-resources','xlc-resources')];assert len(commands)==2
for command in commands:
 command=command[:];name=Path(command[-1]).name;command[-1]=str(out/('baseline-'+name));row=run('baseline-'+name,command);report['rows'].append(row);save();assert not row['exitCode'];assert sha(out/('baseline-'+name))==sha(parent/'build'/name),(name,'parent resource source does not match')
 if name=='tcc_builtin_resources_runtime.c':shutil.copy2(out/('baseline-'+name),out/name)
s=tool.read_text();needle='        for row in manifest_data["objects"]:';patch='''        # Keep the selected-XRT inline catalog in both SDK profiles.
        for name in ("xl6_host_xrt.c", "xl6_host_xrt.h", "xl6_host_xrt_symbols.h"):
            virtual = "__xl_compiler/src/runtime/" + name
            if not any(resource.virtual == virtual for resource in resources):
                resources.append(Resource(virtual, root / "src/runtime" / name))
''';assert s.count(needle)==1;s=s.replace(needle,patch+needle);marker='from __future__ import annotations';assert marker in s;s=s.replace(marker,marker+'\nimport sys\nsys.path.insert(0,'+repr(str(tool.parent))+')');patched=out/'gen_tcc_vfs_resources.py';patched.write_text(s)
for command in commands:
 command=command[:];name=Path(command[-1]).name;command[1]=str(patched);command[-1]=str(out/name);row=run('pack-'+name,command);report['rows'].append(row);save();assert not row['exitCode']
script=(Path(meta['producer'])/'build_linux.sh').read_text();prefix=script.split("printf 'Building libxl.so")[0];prefix=prefix.replace('BUILD_DIR="'+str(parent/'build')+'"','BUILD_DIR="'+str(out)+'"');parts=script.split("printf 'Building ");jobs=[]
for profile,name,part in [('runtime','libxl.so',parts[1]),('compiler','libxlc.so',parts[2])]:
 body=part.split('\n',1)[1];body=body.split("printf '")[0];body=body.replace('-o "$ROOT/release/linux_x64/'+name+'"','-o "'+str(out/name)+'"');p=out/(profile+'.sh');p.write_text(prefix+body);jobs.append((profile,['bash',str(p)]))
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for row in pool.map(lambda item:run('build-'+item[0],item[1]),jobs):report['rows'].append(row);save();assert not row['exitCode']
report.update(complete=True,passed=True,images=[dict(path=str(out/name),sha256=sha(out/name),bytes=(out/name).stat().st_size)for name in('libxl.so','libxlc.so')],flags=meta['commonFlags'],totalFreshTranslationUnits=meta['totalGccTranslationUnitCompilations']);save()

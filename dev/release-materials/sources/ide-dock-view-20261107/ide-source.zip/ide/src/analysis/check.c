#include "analysis/dependency_capture.h"
#include "analysis/function_unit_internal.h"
#include "analysis/check.h"
#include "analysis/frontend_overlay.h"
#include "analysis/check_ir.h"
#include "analysis/frontend_context.h"
#include "analysis/frontend_entry_cache.h"
#include "analysis/frontend_input_view.h"
#include "analysis/frontend_input_usage.h"
#include "analysis/input_topology.h"
#include "analysis/frontend_module_graph.h"
#include "analysis/frontend_index.h"
#include "analysis/frontend_internal.h"
#include "analysis/frontend_sem.h"
#include "analysis/frontend_raw_body.h"
#include "analysis/frontend_cancel.h"
#include "analysis/frontend_ir_memo.h"
#include "analysis/typed_module_internal.h"
#include "analysis/index_entities.h"
#include "src/parser/xl6_parser_api.h"
#include "src/compile/xl6_imports.h"
#include "src/stdlib/xl6_stdlib.h"
#include "src/sem/xl6_sem.h"
#include "src/sem/xl6_sem_index.h"
#include "src/ir/xl6_ir.h"
#include <stdio.h>

struct xls_semantic_check {
    xatomic32 references,invalid;
    xls_context* context;
    xmutex lock;
    int lockInitialized;
    XL6_ParseResult parse;
    XL6_ImportDeps deps;
    XL6_SourceReport report;
    XL6_SourceOverlay overlay;
    xls_input_batch* inputOwner;
    XL6_IrModule ir;
    xls_ir_result* cachedIr;
    xls_typed_module* typedModule;
    uint64_t irPrepared;
    char *path,*index;
    xls_semantic_index* typedIndex;
    xls_sem_memo* memo;
    xls_sem_work semanticWork;
    xls_entry_parse_work entryWork,moduleWork;
    xls_parse_work moduleSyntaxWork;
    xls_ast_materialize_work materializationWork;
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    xls_sem_native_work nativeWork;
#endif
    const char* phase;
    int accepted,captureIndex,dependenciesExpanded;
    uint64_t usedInputs;int usageKnown;
    xls_input_topology* topology;
    xls_module_graph* modules;
};
static int stopped(int (*cancelled)(void*),void* user)
{ return xlsFrontendCancelObserved() || (cancelled && cancelled(user)); }
static void fail(char* error,size_t capacity,const char* message)
{ if(error && capacity) snprintf(error,capacity,"%s",message); }
static int invalid(const xls_semantic_check* r)
{ return xrtAtomic32Load(&r->invalid,XMEMORY_ACQUIRE)!=0; }
xls_semantic_check* xlsSemanticCheckRetain(xls_semantic_check* r)
{ if(r) xrtAtomic32FetchAdd(&r->references,1,XMEMORY_RELAXED); return r; }
void xlsSemanticCheckDestroy(xls_semantic_check* r)
{
    if(!r || xrtAtomic32FetchSub(&r->references,1,XMEMORY_ACQ_REL)!=1) return;
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    if(!r->typedModule)xlsFrontendSemMemoDetachNative(r->memo,r->parse.root);
#endif
    xrtFree(r->index); xlsFrontendIndexDestroy(r->typedIndex); xlsFrontendSemMemoDestroy(r->memo);
    xlsInputTopologyDestroy(r->topology);
    xlsModuleGraphRelease(r->modules);
    xlsFrontendIrResultDestroy(r->cachedIr);xl6IrModuleFree(&r->ir);
    if(r->typedModule){r->parse.root=NULL;xlsTypedModuleRelease(r->typedModule);}
    xl6ParseResultFree(&r->parse);
    xl6ImportDepsFree(&r->deps); xlsFrontendOverlayClear(&r->overlay,r->inputOwner);xlsInputBatchDestroy(r->inputOwner); xl6SourceReportFree(&r->report);
    xlsContextRelease(r->context); xrtFree(r->path); if(r->lockInitialized) xrtMutexUnit(&r->lock); xrtFree(r);
}
static xls_semantic_check* createBody(xls_context* context,const char* entry,
    const xls_semantic_input* inputs,size_t count,int dependenciesOnly,int captureIndex,const xls_syntax* syntax,
    xls_semantic_check* previous,int memoEnabled,xls_module_graph_scope* moduleScope,int (*cancelled)(void*),void* user,char* error,size_t capacity,const xls_input_batch* batch,int allowBorrow,int* retry)
{
    xls_semantic_check* r=NULL;const xls_ir_result* irBaseline=NULL;const xls_semantic_check* indexBaseline=NULL;
    if(error && capacity) *error=0;
    if(xlsSyntaxIsCursor(syntax)) { fail(error,capacity,"ordinary check cannot consume cursor syntax"); return NULL; }
    if(!entry || !xrtPathIsAbs(entry) || count>XL6_SOURCE_OVERLAY_FILES ||
       (count && !inputs) || (captureIndex!=0 && captureIndex!=1)) {
        fail(error,capacity,"check requires an absolute entry and 0..64 overlays"); return NULL;
    }
    if(stopped(cancelled,user)) { fail(error,capacity,"semantic check cancelled"); return NULL; }
    r=xrtCalloc(1,sizeof(*r)); if(!r) { fail(error,capacity,"cannot allocate semantic check"); return NULL; }
    xrtAtomic32Init(&r->references,1); xrtAtomic32Init(&r->invalid,0); r->context=xlsContextRetain(context);
    if(!xrtMutexInit(&r->lock)) goto invalid;
    r->lockInitialized=1;
    xl6ParseResultInit(&r->parse); xl6ImportDepsInit(&r->deps); xl6SourceReportInit(&r->report); xl6IrModuleInit(&r->ir);
    r->path=xrtPathAbs(entry); r->captureIndex=captureIndex;
    r->inputOwner=xlsInputBatchRetain(batch);
    if(!r->path) goto invalid;
    if(batch) {
        int captured=xlsFrontendOverlayBorrow(&r->overlay,batch,cancelled,user);
        if(captured<0)goto cancel;
        if(!captured)goto invalid;
    } else for(size_t i=0;i<count;++i) {
        const xls_semantic_input* in=&inputs[i]; size_t bom=0;
        const XL6_SourceOverlayItem* duplicate=NULL;
        if(stopped(cancelled,user)) goto cancel;
        if(!in->path || !xrtPathIsAbs(in->path) || !in->text || in->size>XL6_SOURCE_OVERLAY_BYTES ||
           xlsFrontendOverlayLookup(&r->overlay,in->path,&duplicate)!=0) goto invalid;
        if(in->size>=3 && !memcmp(in->text,"\xef\xbb\xbf",3)) bom=3;
        if(!xl6SourceOverlaySet(&r->overlay,in->path,in->text+bom,in->size-bom)) goto invalid;
    }
    xlsFrontendInputUsageBind(&r->overlay,r->overlay.count);
    r->overlay.report=&r->report; r->overlay.semanticIndex=captureIndex; r->deps.sourceOverlay=&r->overlay;
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    xls_raw_scope* raw=xlsRawBodyScopeCurrent();
    if(raw && raw->ordinary && allowBorrow && previous && previous->accepted && previous->memo && xlsFrontendSemMemoNativeWork(previous->memo).retained &&
       previous->captureIndex==captureIndex && !strcmp(previous->path,r->path) && xlsFrontendContextsEqual(previous->context,context) &&
       xlsSemanticCheckValidate(previous) && xlsInputTopologyOverlayCompatible(xlsSemanticCheckTopology(previous),&previous->overlay,&r->overlay))raw->baseline=previous->memo;
#endif
    r->phase="parse"; int okay;
    if(syntax) {
        /* Keep exactly the overlay/report contract used by the shared parser.
         * Reject an unrelated parse rather than silently accepting stale facts. */
        const XL6_SourceOverlayItem* item=NULL;
        if(xlsFrontendOverlayLookup(&r->overlay,r->path,&item)!=1)goto invalid;
        const xls_text* text=xlsSyntaxText(syntax); size_t skip=0;
        if(text && xlsTextSize(text)>=3 && !memcmp(xlsTextData(text),"\xef\xbb\xbf",3)) skip=3;
        if(!item || !text || strcmp(item->path,xlsSyntaxPath(syntax)) ||
           item->size!=xlsTextSize(text)-skip || memcmp(item->text,xlsTextData(text)+skip,item->size)) goto invalid;
        if(!xl6SourceReportText(&r->report,item->path,item->text,item->size,"overlay") ||
           !xlsRawBodyCopyParse(syntax,&r->parse)) {
            fail(error,capacity,"cannot own parsed entry or source report"); xlsSemanticCheckDestroy(r); return NULL;
        }
        okay=xlsSyntaxAccepted(syntax);
    } else okay=xl6SourceOverlayParse(&r->overlay,r->path,&r->parse);
    if(stopped(cancelled,user)) goto cancel;
    if(okay) { r->phase="import"; okay=xl6ImportsExpandModule(r->parse.root,r->path,&r->parse.diags,&r->deps); }
    if(stopped(cancelled,user)) goto cancel;
    if(okay) { r->phase="stdlib"; okay=xl6StdlibExpandModule(r->parse.root,&r->parse.diags); }
    if(stopped(cancelled,user)) goto cancel;
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    if(!dependenciesOnly && !xlsRawBodySealPreprocess(&r->report) && raw && raw->deferred)goto nativeRetry;
    if(raw && raw->ordinary && raw->deferred && (!okay || r->parse.diags.count))goto nativeRetry;
#endif

    if(dependenciesOnly){
        /* Same original prefix;no semantic/index/IR entry point is called.
         * Finish the original import graph before discarding private AST.
         * Source report and overlay own all data needed by the input guard. */
        r->modules=xlsModuleGraphEnd(moduleScope,&r->report);
        r->dependenciesExpanded=okay && !r->parse.diags.count;
        if(stopped(cancelled,user))goto cancel;
        if(!xlsSemanticCheckValidate(r)){
            fail(error,capacity,"dependency capture inputs are incomplete or changed");
            xlsSemanticCheckDestroy(r);return NULL;
        }
        if(r->dependenciesExpanded)r->phase="dependencies";
        xl6AstFree(r->parse.root);r->parse.root=NULL;
        return r;
    }
    if(okay) {
        char module[256]; char* stem=xrtPathStem(r->path); if(!stem) goto invalid;
        snprintf(module,sizeof(module),"%s",*stem ? stem : "module"); xrtFree(stem);
        r->phase="sem";
        if(memoEnabled) {
            const xls_sem_memo* baseline=NULL;
            int compatible=previous && xlsFrontendContextsEqual(previous->context,context) && previous->memo && previous->captureIndex==captureIndex && !strcmp(previous->path,r->path) &&
                xlsSemanticCheckValidate(previous) && xlsInputTopologyOverlayCompatible(xlsSemanticCheckTopology(previous),&previous->overlay,&r->overlay);
            /* The frontend compares every function/environment and maps
             * coordinates against each report's original source bytes.
             * Membership is exact or differences have a complete original
             * lookup absence proof. Disk/probe/environment validity still
             * precedes every borrowed per-function semantic/IR fact. */
            if(compatible) {baseline=previous->memo;irBaseline=previous->cachedIr;indexBaseline=previous;}
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
            okay=xlsFrontendSemCheckMemoFinal(r->parse.root,&r->parse.diags,module,captureIndex,r->path,
                &r->report,baseline ? &previous->report : NULL,baseline,&r->memo,&r->semanticWork,32u*1024u*1024u);
#else
            okay=xlsFrontendSemCheckMemo(r->parse.root,&r->parse.diags,module,captureIndex,r->path,
                &r->report,baseline ? &previous->report : NULL,baseline,&r->memo,&r->semanticWork);
#endif
        } else okay=xl6SemCheckModuleWithIndex(r->parse.root,&r->parse.diags,module,captureIndex);
    }
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    if(okay<0 || (raw && raw->ordinary && raw->deferred && (!okay || r->parse.diags.count)))goto nativeRetry;
#endif
    if(stopped(cancelled,user)) goto cancel;
    /* Collect checked facts before raw IR so the optional cache can bind
     * external identities to THIS compilation. Delay index resource errors
     * until after original IR diagnostics;neither changes their precedence. */
    char indexError[256]={0};
    if(okay && captureIndex)r->typedIndex=xlsFrontendIndexCreateCached(r->parse.root,&r->report,r->memo,
        indexBaseline ? indexBaseline->typedIndex : NULL,indexBaseline ? indexBaseline->memo : NULL,indexError,sizeof(indexError));
    r->modules=xlsModuleGraphEnd(moduleScope,&r->report);
    xlsFrontendIndexAttachModules(r->typedIndex,r->modules);
    if(stopped(cancelled,user)) goto cancel;
    if(okay) {
        r->phase="ir";
        if(memoEnabled){
            /* Optional fragment failures never invent source diagnostics.
             * Keep attempts private;the original builder remains authoritative
             * for a failed attempt as well as the independent fresh API. */
            XL6_DiagList attempted;xl6DiagInit(&attempted);
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
            r->typedModule=xlsFrontendSemMemoTakeModule(r->memo,r->parse.root);
            if(!r->typedModule && xlsFrontendSemMemoNativeWork(r->memo).reused){xl6DiagFree(&attempted);goto nativeRetry;}
#else
            r->typedModule=xlsTypedModuleTake(r->parse.root);
#endif
            if(r->typedModule)xlsFrontendIndexBindFunctions(r->typedIndex,r->typedModule);
            int prepared=0;
            if(r->typedModule && irBaseline && r->semanticWork.contextHits && xlsFrontendSemMemoInputCandidate(r->memo))
                prepared=xlsFrontendIrResultPreparePersistent((xls_ir_result*)irBaseline,32u*1024u*1024u);
            r->irPrepared=prepared==2;
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
            r->cachedIr=r->typedModule ? xlsFrontendIrResultBuildTypedChecked(r->typedModule,&attempted,irBaseline,32u*1024u*1024u,
                xlsSemanticIndexEntities(r->typedIndex),prepared ? 32u*1024u*1024u : 0,r->memo) :
#else
            r->cachedIr=r->typedModule ? xlsFrontendIrResultBuildTyped(r->typedModule,&attempted,irBaseline,32u*1024u*1024u,
                xlsSemanticIndexEntities(r->typedIndex),prepared ? 32u*1024u*1024u : 0) :
#endif
                xlsFrontendIrResultBuildEntities(r->parse.root,&attempted,irBaseline,32u*1024u*1024u,xlsSemanticIndexEntities(r->typedIndex));
            okay=r->cachedIr && !attempted.count;
            if(!okay){xlsFrontendIrResultDestroy(r->cachedIr);r->cachedIr=NULL;}
            xl6DiagFree(&attempted);
            if(!okay && !stopped(cancelled,user))okay=xl6IrBuildModuleFromAst(&r->ir,r->parse.root,&r->parse.diags);
        }else okay=xl6IrBuildModuleFromAst(&r->ir,r->parse.root,&r->parse.diags);
    }
    if(stopped(cancelled,user)) goto cancel;
    r->accepted=okay && !r->parse.diags.count;
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    if(raw && raw->ordinary && raw->deferred && !r->accepted)goto nativeRetry;
#endif
    if(r->accepted && captureIndex) {
        if(!r->typedIndex) {
            /* An index budget/allocation failure is infrastructure failure,
             * never a diagnostic claiming that valid user code is wrong. */
            fail(error,capacity,*indexError ? indexError : "cannot retain semantic index");
            xlsSemanticCheckDestroy(r); return NULL;
        }
    }
    if(!r->accepted){xlsFrontendIndexDestroy(r->typedIndex);r->typedIndex=NULL;}
    if(stopped(cancelled,user)) goto cancel;
    if(!xlsSemanticCheckValidate(r)) {
        fail(error,capacity,"semantic check inputs are incomplete or changed");
        xlsSemanticCheckDestroy(r); return NULL;
    }
    if(r->accepted) r->phase="checked";
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    if(r->accepted)xlsFrontendSemMemoBindFunctions(r->memo,r->typedModule);
    r->nativeWork=xlsFrontendSemMemoNativeWork(r->memo);
#endif
    return r;
nativeRetry:
    if(stopped(cancelled,user))goto cancel;
    if(retry)*retry=1;
    fail(error,capacity,"native function reuse proof declined;retry original complete input");
    xlsSemanticCheckDestroy(r);return NULL;
invalid:
    fail(error,capacity,"invalid semantic check overlay, path or capacity");
    xlsSemanticCheckDestroy(r); return NULL;
cancel:
    fail(error,capacity,"semantic check cancelled");
    xlsSemanticCheckDestroy(r); return NULL;
}
static xls_semantic_check* createConfiguredInContext(xls_context* context,xls_entry_cache* cache,const char* entry,
    const xls_semantic_input* inputs,size_t count,int captureIndex,const xls_syntax* syntax,
    xls_semantic_check* previous,int (*cancelled)(void*),void* user,char* error,size_t capacity,int dependenciesOnly,const xls_input_batch* batch)
{
    int retried=0;
    xls_ast_materialize_work totalMaterialization={0};
    for(int attempt=0;attempt<2;++attempt){
    if(!xlsFrontendContextValid(context,entry,error,capacity)) return NULL;
    xls_frontend_context_scope scope; xlsFrontendContextBegin(&scope,context);
    xls_raw_scope raw;
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    xlsRawBodyScopeBegin(&raw,NULL,!dependenciesOnly && (cache || syntax) && xlsFrontendSemNativeBudget() ? 32u*1024u*1024u : 0);
#else
    xlsRawBodyScopeBegin(&raw,NULL,0);
#endif
    raw.ordinary=1;
    xls_ast_materialize_scope materialization;
    xlsAstMaterializeBegin(&materialization,(cache || syntax) ? xlsAstMaterializeBudget() : 0);
    xls_entry_cache_scope entryScope;xlsFrontendEntryBegin(&entryScope,cache,context,entry);
    xls_input_usage_scope usage;xlsFrontendInputUsageBegin(&usage);
    xls_input_topology_scope topology;xlsInputTopologyBegin(&topology,(cache || syntax) ? 8u*1024u*1024u : 0);
    xls_module_graph_scope modules;xlsModuleGraphBegin(&modules,(cache || syntax) ? xlsModuleScopeCurrent() : NULL,context,8u*1024u*1024u);
    xls_frontend_cancel_scope cancellation;xlsFrontendCancelBegin(&cancellation,cancelled,user);
    int retry=0;
    xls_semantic_check* result=createBody(context,entry,inputs,count,dependenciesOnly,captureIndex,syntax,previous,cache || syntax,&modules,cancelled,user,error,capacity,batch,attempt==0,&retry);
    uint64_t used=0;int known=xlsFrontendInputUsageEnd(&usage,&used);
    xls_input_topology* captured=xlsInputTopologyEnd(&topology);
    if(result && known)result->topology=captured;else xlsInputTopologyDestroy(captured);
    /* Early invalid/cancelled creation may leave the capture active. Ordinary
     * success already ended it after semantics,before the read-only IR phase. */
    xlsModuleGraphRelease(xlsModuleGraphEnd(&modules,NULL));
    if((result || retry) && stopped(cancelled,user)) {xlsSemanticCheckDestroy(result);result=NULL;retry=0;fail(error,capacity,"semantic check cancelled");}
    xlsFrontendCancelEnd(&cancellation,NULL);
    xlsRawBodyScopeEnd(&raw);
    int scoped=xlsFrontendContextEnd(&scope);
    xls_entry_parse_work work=xlsFrontendEntryEnd(&entryScope,result && scoped);
    xls_ast_materialize_work materializationWork;xlsAstMaterializeEnd(&materialization,&materializationWork);
#define XLS_MATERIALIZED_ADD(field) totalMaterialization.field+=materializationWork.field
    XLS_MATERIALIZED_ADD(calls);XLS_MATERIALIZED_ADD(pooledCopies);XLS_MATERIALIZED_ADD(heapCopies);
    XLS_MATERIALIZED_ADD(poolFallbacks);XLS_MATERIALIZED_ADD(nodes);XLS_MATERIALIZED_ADD(pages);XLS_MATERIALIZED_ADD(chargedBytes);
#undef XLS_MATERIALIZED_ADD
    if(!scoped) {
        xlsSemanticCheckDestroy(result); fail(error,capacity,(scope.failed&2) ? "cannot retain bounded completion namespace" : "cannot resolve native context path or package environment"); return NULL;
    }
    if(result) {result->entryWork=work;result->moduleWork=entryScope.moduleWork;result->moduleSyntaxWork=entryScope.moduleSyntaxWork;result->materializationWork=totalMaterialization;result->usedInputs=used;result->usageKnown=known && result->report.complete && result->report.count && result->overlay.count==count;}
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    if(result)result->nativeWork.retries=retried;
#endif
    if(retry && !attempt){retried=1;continue;}
    return result;
    }
    return NULL;
}

xls_semantic_check* xlsSemanticCheckCreateCachedInContext(xls_context* context,xls_entry_cache* cache,const char* entry,
    const xls_semantic_input* inputs,size_t count,int captureIndex,const xls_syntax* syntax,
    xls_semantic_check* previous,int (*cancelled)(void*),void* user,char* error,size_t capacity)
{return createConfiguredInContext(context,cache,entry,inputs,count,captureIndex,syntax,previous,cancelled,user,error,capacity,0,NULL);}
xls_semantic_check* xlsSemanticCheckCreateBatch(xls_entry_cache* cache,const xls_input_batch* batch,
 int captureIndex,const xls_syntax* syntax,xls_semantic_check* previous,
 int (*cancelled)(void*),void* user,char* error,size_t capacity)
{
 if(!batch){fail(error,capacity,"missing immutable check batch");return NULL;}
 xls_semantic_input inputs[64];size_t count=xlsInputBatchInputs(batch,inputs,64);
 return createConfiguredInContext((xls_context*)xlsInputBatchContext(batch),cache,xlsInputBatchEntry(batch),
     inputs,count,captureIndex,syntax,previous,cancelled,user,error,capacity,0,batch);
}
struct xls_dependency_capture {xatomic32 references;xls_semantic_check* owner;};
xls_dependency_capture* xlsDependencyCaptureCreateBatch(xls_entry_cache* cache,const xls_input_batch* batch,
 const xls_syntax* syntax,int (*cancelled)(void*),void* user,char* error,size_t capacity)
{
 if(!batch){fail(error,capacity,"missing immutable dependency batch");return NULL;}
 xls_dependency_capture* result=xrtCalloc(1,sizeof(*result));if(!result){fail(error,capacity,"cannot allocate dependency capture");return NULL;}
 xrtAtomic32Init(&result->references,1);xls_semantic_input inputs[64];size_t count=xlsInputBatchInputs(batch,inputs,64);
 result->owner=createConfiguredInContext((xls_context*)xlsInputBatchContext(batch),cache,xlsInputBatchEntry(batch),
     inputs,count,0,syntax,NULL,cancelled,user,error,capacity,1,batch);
 if(!result->owner){xrtFree(result);return NULL;}return result;
}

xls_dependency_capture* xlsDependencyCaptureCreateParsedInContext(xls_context* context,xls_entry_cache* cache,const char* entry,
 const xls_semantic_input* inputs,size_t count,const xls_syntax* syntax,int (*cancelled)(void*),void* user,char* error,size_t capacity)
{
 xls_dependency_capture* result=xrtCalloc(1,sizeof(*result));if(!result){fail(error,capacity,"cannot allocate dependency capture");return NULL;}
 xrtAtomic32Init(&result->references,1);
 result->owner=createConfiguredInContext(context,cache,entry,inputs,count,0,syntax,NULL,cancelled,user,error,capacity,1,NULL);
 if(!result->owner){xrtFree(result);return NULL;}return result;
}
xls_dependency_capture* xlsDependencyCaptureCreate(xls_context* context,xls_entry_cache* cache,const char* entry,
 const xls_semantic_input* inputs,size_t count,int (*cancelled)(void*),void* user,char* error,size_t capacity)
{return xlsDependencyCaptureCreateParsedInContext(context,cache,entry,inputs,count,NULL,cancelled,user,error,capacity);}
xls_dependency_capture* xlsDependencyCaptureRetain(xls_dependency_capture* r)
{if(r)xrtAtomic32FetchAdd(&r->references,1,XMEMORY_RELAXED);return r;}
void xlsDependencyCaptureRelease(xls_dependency_capture* r)
{if(r && xrtAtomic32FetchSub(&r->references,1,XMEMORY_ACQ_REL)==1){xlsSemanticCheckDestroy(r->owner);xrtFree(r);}}
xls_dependency_info xlsDependencyCaptureInfo(const xls_dependency_capture* r)
{if(!r)return(xls_dependency_info){0};xls_check_info i=xlsSemanticCheckInfo(r->owner);return(xls_dependency_info){i.path,i.phase,i.error,i.diagnostics,r->owner->dependenciesExpanded && !i.error};}
int xlsDependencyCaptureInputs(const xls_dependency_capture* r,xls_check_inputs* out)
{return xlsSemanticCheckInputs(r?r->owner:NULL,out);}
int xlsDependencyCaptureSource(const xls_dependency_capture* r,size_t at,xls_check_source* out)
{return xlsSemanticCheckSource(r?r->owner:NULL,at,out);}
int xlsDependencyCaptureProbe(const xls_dependency_capture* r,size_t at,xls_check_probe* out)
{return xlsSemanticCheckProbe(r?r->owner:NULL,at,out);}
int xlsDependencyCaptureDiagnostic(const xls_dependency_capture* r,size_t at,xls_check_diagnostic* out)
{return xlsSemanticCheckDiagnostic(r?r->owner:NULL,at,out);}
const xls_module_graph* xlsDependencyCaptureModules(const xls_dependency_capture* r)
{return xlsSemanticCheckModules(r?r->owner:NULL);}
int xlsDependencyCaptureValidate(xls_dependency_capture* r)
{return r && xlsSemanticCheckValidate(r->owner);}
int xlsDependencyCaptureInputUsage(const xls_dependency_capture* r,uint64_t* used)
{return xlsSemanticCheckInputUsage(r?r->owner:NULL,used);}
const xls_input_topology* xlsDependencyCaptureTopology(const xls_dependency_capture* r)
{return xlsSemanticCheckTopology(r?r->owner:NULL);}
int xlsSemanticCheckInputUsage(const xls_semantic_check* result,uint64_t* used)
{
    if(used)*used=0;
    if(!used || !result || invalid(result) || !result->usageKnown)return 0;
    *used=result->usedInputs;return 1;
}
const xls_input_topology* xlsSemanticCheckTopology(const xls_semantic_check* result)
{return result && !invalid(result) && result->usageKnown ? result->topology : NULL;}
const xls_module_graph* xlsSemanticCheckModules(const xls_semantic_check* result)
{return result && !invalid(result) ? result->modules : NULL;}
xls_semantic_check* xlsSemanticCheckCreateIncrementalInContext(xls_context* context,const char* entry,
    const xls_semantic_input* inputs,size_t count,int captureIndex,const xls_syntax* syntax,
    xls_semantic_check* previous,int (*cancelled)(void*),void* user,char* error,size_t capacity)
{ return xlsSemanticCheckCreateCachedInContext(context,NULL,entry,inputs,count,captureIndex,syntax,previous,cancelled,user,error,capacity); }
xls_entry_parse_work xlsSemanticCheckEntryWork(const xls_semantic_check* result)
{ return result ? result->entryWork : (xls_entry_parse_work){0}; }
xls_entry_parse_work xlsSemanticCheckModuleWork(const xls_semantic_check* result)
{ return result ? result->moduleWork : (xls_entry_parse_work){0}; }
xls_parse_work xlsSemanticCheckModuleParseWork(const xls_semantic_check* result)
{ return result ? result->moduleSyntaxWork : (xls_parse_work){0}; }
xls_ast_materialize_work xlsSemanticCheckMaterializationWork(const xls_semantic_check* result)
{ return result ? result->materializationWork : (xls_ast_materialize_work){0}; }
xls_ast_intern_work xlsSemanticCheckMemoTypes(const xls_semantic_check* result)
{return xlsFrontendSemMemoTypes(result ? result->memo : NULL);}
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
xls_sem_final_work xlsSemanticCheckFinalWork(const xls_semantic_check* result)
{return xlsFrontendSemMemoFinalWork(result ? result->memo : NULL);}
xls_sem_native_work xlsSemanticCheckNativeWork(const xls_semantic_check* result)
{return result ? result->nativeWork : (xls_sem_native_work){0};}
xls_sem_geometry_work xlsSemanticCheckGeometryWork(const xls_semantic_check* result)
{return xlsFrontendSemMemoGeometryWork(result ? result->memo : NULL);}
#endif
xls_semantic_check* xlsSemanticCheckCreateIncremental(const char* entry,
    const xls_semantic_input* inputs,size_t count,int captureIndex,const xls_syntax* syntax,
    xls_semantic_check* previous,int (*cancelled)(void*),void* user,char* error,size_t capacity)
{ return xlsSemanticCheckCreateIncrementalInContext(NULL,entry,inputs,count,captureIndex,syntax,previous,cancelled,user,error,capacity); }
xls_semantic_check* xlsSemanticCheckCreateInContext(xls_context* context,const char* entry,
    const xls_semantic_input* inputs,size_t count,int captureIndex,
    int (*cancelled)(void*),void* user,char* error,size_t capacity)
{ return xlsSemanticCheckCreateIncrementalInContext(context,entry,inputs,count,captureIndex,NULL,NULL,cancelled,user,error,capacity); }
const xls_context* xlsSemanticCheckContext(const xls_semantic_check* result)
{ return result ? result->context : NULL; }
xls_semantic_check* xlsSemanticCheckCreate(const char* entry,
    const xls_semantic_input* inputs,size_t count,int captureIndex,
    int (*cancelled)(void*),void* user,char* error,size_t capacity)
{ return xlsSemanticCheckCreateParsed(entry,inputs,count,captureIndex,NULL,cancelled,user,error,capacity); }
xls_semantic_check* xlsSemanticCheckCreateParsed(const char* entry,
    const xls_semantic_input* inputs,size_t count,int captureIndex,const xls_syntax* syntax,
    int (*cancelled)(void*),void* user,char* error,size_t capacity)
{ return xlsSemanticCheckCreateIncremental(entry,inputs,count,captureIndex,syntax,NULL,cancelled,user,error,capacity); }
xls_check_semantic_work xlsSemanticCheckWork(const xls_semantic_check* r)
{ return r ? (xls_check_semantic_work){r->semanticWork.checked,r->semanticWork.reused,r->semanticWork.contextHits,r->semanticWork.bytes} : (xls_check_semantic_work){0}; }
xls_index_canonical_work xlsSemanticCheckCanonicalWork(const xls_semantic_check* r)
{return r && !invalid(r) && r->accepted ? xlsFrontendIndexCanonicalWork(r->typedIndex) : (xls_index_canonical_work){0};}
xls_sem_read_work xlsSemanticCheckReads(const xls_semantic_check* r)
{return r && !invalid(r) && r->accepted ? xlsFrontendSemMemoReads(r->memo) : (xls_sem_read_work){0};}
const XL6_IrModule* xlsSemanticCheckIr(const xls_semantic_check* r)
{ return r && !invalid(r) && r->accepted ? (r->cachedIr ? xlsFrontendIrResultModule(r->cachedIr) : &r->ir) : NULL; }
xls_check_ir_work xlsSemanticCheckIrWork(const xls_semantic_check* r)
{
    xls_ir_memo_work w=xlsFrontendIrResultWork(r ? r->cachedIr : NULL);
    return (xls_check_ir_work){w.checked,w.reused,w.captured,w.nodesReused,w.bytes,w.declined,w.textNodes,w.textBytes,w.ownerBytes};
}
xls_check_ir_derived_work xlsSemanticCheckIrDerivedWork(const xls_semantic_check* r)
{
#ifdef XLS_NATIVE_AST_PACKAGE_FIELDS
    xls_ir_derived_work w=xlsFrontendIrResultDerivedWork(r ? r->cachedIr : NULL);
    return (xls_check_ir_derived_work){w.contexts,w.checked,w.reused,w.captured,w.declined,w.nodesSkipped,w.rowsApplied,w.bytes};
#else
    (void)r;return (xls_check_ir_derived_work){0};
#endif
}
xls_check_ir_persistent_work xlsSemanticCheckIrPersistentWork(const xls_semantic_check* r)
{
    xls_ir_persistent_work w=xlsFrontendIrResultPersistentWork(r ? r->cachedIr : NULL);
    return (xls_check_ir_persistent_work){w.built,w.reused,w.captured,w.verified,w.nodesCopied,w.tablesShared,w.keyBytes,w.metadataBytes,w.declined,r ? r->irPrepared : 0};
}
size_t xlsSemanticCheckIrDependencies(const xls_semantic_check* r,uint64_t function)
{return r && !invalid(r) && r->accepted ? xlsFrontendIrResultDependencies(r->cachedIr,function) : 0;}
int xlsSemanticCheckIrDependency(const xls_semantic_check* r,uint64_t function,size_t at,xls_check_ir_dependency* out)
{
    if(out)*out=(xls_check_ir_dependency){0};
    xls_ir_declaration_dependency row;
    if(!out || !r || invalid(r) || !r->accepted || !xlsFrontendIrResultDependency(r->cachedIr,function,at,&row))return 0;
    *out=(xls_check_ir_dependency){row.declaration,row.version};return 1;
}
const XL6_AstNode* xlsSemanticCheckAst(const xls_semantic_check* r)
{ return r && !invalid(r) ? r->parse.root : NULL; }
xls_check_info xlsSemanticCheckInfo(const xls_semantic_check* r)
{
    if(!r) return (xls_check_info){0};
    int stale=invalid(r);
    const XL6_IrModule* ir=r->cachedIr ? xlsFrontendIrResultModule(r->cachedIr) : &r->ir;
    return (xls_check_info){r->path,r->phase,stale ? "semantic inputs changed" : NULL,
        r->parse.diags.count,ir->types.count,ir->nodeCount,r->accepted && !stale,
        r->typedIndex && r->accepted && !stale};
}
int xlsSemanticCheckDiagnostic(const xls_semantic_check* r,size_t index,xls_check_diagnostic* out)
{
    if(!r || invalid(r) || !out || index>=r->parse.diags.count) return 0;
    const XL6_Diag* d=&r->parse.diags.items[index];
    *out=(xls_check_diagnostic){d->file ? d->file : r->path,d->message,d->line,d->column}; return 1;
}
int xlsSemanticCheckInputs(const xls_semantic_check* r,xls_check_inputs* out)
{
    return xlsInputReportInputs(r && !invalid(r) ? &r->report : NULL,out);
}
int xlsSemanticCheckSource(const xls_semantic_check* r,size_t index,xls_check_source* out)
{
    return xlsInputReportSource(r && !invalid(r) ? &r->report : NULL,index,out);
}
xls_text* xlsSemanticCheckRetainSourceText(const xls_semantic_check* r,size_t index,size_t* bomBytes)
{
    if(bomBytes)*bomBytes=0;
    xls_check_source row;
    if(!bomBytes || !xlsSemanticCheckSource(r,index,&row) || !(row.kind&1) || !r->inputOwner)return NULL;
    for(size_t i=0;;++i){
        const xls_analysis_document* document=xlsInputBatchAt(r->inputOwner,i);
        if(!document)return NULL;
        if(strcmp(document->path,row.path))continue;
        xls_text* text=document->text;size_t size=xlsTextSize(text),skip=0;
        const char* data=xlsTextData(text);
        if(size>=3 && !memcmp(data,"\xef\xbb\xbf",3))skip=3;
        if(size-skip!=row.size || memcmp(data+skip,row.text,row.size) || invalid(r))return NULL;
        *bomBytes=skip;return xlsTextRetain(text);
    }
}
int xlsSemanticCheckProbe(const xls_semantic_check* r,size_t index,xls_check_probe* out)
{
    return xlsInputReportProbe(r && !invalid(r) ? &r->report : NULL,index,out);
}
const xls_semantic_index* xlsSemanticCheckTypedIndex(const xls_semantic_check* r)
{ return r && !invalid(r) && r->accepted ? r->typedIndex : NULL; }
static const char* indexLocked(xls_semantic_check* r)
{
    if(!xlsSemanticCheckTypedIndex(r)) return NULL;
    if(!r->index) r->index=xl6SemIndexJson(r->parse.root,&r->report,NULL,0);
    return r->index;
}
const char* xlsSemanticCheckIndex(xls_semantic_check* r)
{
    if(!r || !xrtMutexLock(&r->lock)) return NULL;
    const char* index=indexLocked(r); xrtMutexUnlock(&r->lock); return index;
}
static int validateLocked(xls_semantic_check* r)
{
    if(invalid(r)) return 0;
    xls_frontend_context_scope scope; xlsFrontendContextBegin(&scope,r->context);
    int okay=xl6SourceReportValidate(&r->report); int scoped=xlsFrontendContextEnd(&scope);
    if(!okay || !scoped) { xrtAtomic32Store(&r->invalid,1,XMEMORY_RELEASE); return 0; }
    return 1;
}
int xlsSemanticCheckValidate(xls_semantic_check* r)
{
    if(!r || !xrtMutexLock(&r->lock)) return 0;
    int okay=validateLocked(r); xrtMutexUnlock(&r->lock); return okay;
}
const xls_typed_module* xlsFrontendCheckFunctionModule(const xls_semantic_check* r)
{return r && !invalid(r) && r->accepted ? r->typedModule : NULL;}
int xlsFrontendCheckFunctionInputs(const xls_semantic_check* r,XL6_SourceReport* out)
{
    if(out)*out=(XL6_SourceReport){0};
    if(!r || !out || invalid(r) || !r->accepted)return 0;
    /* These captured arrays/metadata never mutate after publication. Do not
     * read the report's mutable complete/error validation fields concurrently.
     * The caller retains the result and validates again before publication. */
    const XL6_SourceReport* p=&r->report;
    *out=(XL6_SourceReport){.items=p->items,.count=p->count,.capacity=p->capacity,.bytes=p->bytes,.complete=1,
        .probes=p->probes,.probeCount=p->probeCount,.probeCapacity=p->probeCapacity,.probeBytes=p->probeBytes,
        .packagePath=p->packagePath,.packagePathObserved=p->packagePathObserved};return 1;
}
static char* reportLocked(xls_semantic_check* r,size_t* size,int includeIndex)
{
    if(size) *size=0;
    if(!validateLocked(r)) return NULL;
    const char* index=includeIndex && r->captureIndex ? (r->accepted ? indexLocked(r) :
        "{\"schema\":1,\"scope\":\"checked-compilation\",\"complete\":false,\"nodes\":[]}") : NULL;
    if(includeIndex && r->captureIndex && r->accepted && !index) return NULL;
    XL6_Output out; char* text=NULL; size_t length=0;
    if(xl6OutputOpenMemory(&out)) {
        xl6DiagPrintJsonWithIndex(&out,&r->parse.diags,r->path,r->phase,r->accepted,&r->report,index);
        if(!xl6OutputHasFailed(&out)) text=xl6OutputTakeMemoryText(&out,&length);
        xl6OutputDiscard(&out);
    }
    if(length>XLS_CHECK_REPORT_BYTES || !validateLocked(r)) { xrtFree(text); text=NULL; length=0; }
    if(size) *size=length;
    return text;
}
static char* reportJson(xls_semantic_check* r,size_t* size,int includeIndex)
{
    if(size) *size=0;
    if(!r || !xrtMutexLock(&r->lock)) return NULL;
    char* text=reportLocked(r,size,includeIndex); xrtMutexUnlock(&r->lock); return text;
}
char* xlsSemanticCheckJson(xls_semantic_check* r,size_t* size) { return reportJson(r,size,1); }
char* xlsSemanticCheckReportJson(xls_semantic_check* r,size_t* size) { return reportJson(r,size,0); }

# 多层列表段落换行与解析器前缀

2026-10-06 合入更新：本候选已随行内编辑批次合入主工作区，最终 257 项输入与正常 DLL 1,325 项闭包一致；清单为 `build/source-document-inline-edit-20261006/landed-v1.json`。合入前专项全部完成，合入后 Windows/Linux/Web 正式验证已启动，整批尚未完成。以下“尚未合入”与运行状态为历史记录；原 11 工作包和统一 Document 整体目标继续。

核对日期：2026-10-06。本批仍是独立候选，未合入主工作区，也未替代已验收的行内边界 v9。

## 问题与实现

在 `- > + > abcd` 或 `- > 7) [x] abcd` 中插入段落换行时，原来源计划只处理第一个列表开头，剩余标记使它退回整块序列化，增加多余空行。`baseline-v1-proof.json` 的普通/碰撞配置均实际编译 0、运行预期 1；两个独立最小源码黄金都不符，但完整语义、光标、重解析和 Undo/Redo 检查通过，退出前完成释放。

新候选仍使用同一 Document 事务、CST 和 Markdown 解析器。多层列表复用现有段落写入器的解析器确认前缀：各列表开头转换为正确续行缩进，任务标记仅保留在首行，引用和 Tab 按原始逻辑列处理。不能完整确认前缀时保留原回退；每个来源补丁仍需完整私有重解析和语义、定义核对。没有引入第二个文档模型或 Markdown 扫描器。

单模块产品变化位于 `build/source-document-container-prefix-20261006/snapshot-v7/src/xui/document/xui_document_markdown_edit.c`。父输入是已验收、不可变的行内边界 `snapshot-v9`；当前候选 255 项输入，产品与 v2 相同，主工作区源码保持冻结。

## 已实际完成的专项

| 检查 | 当前证据 |
| --- | --- |
| 两个最小补丁、完整语义、光标、重解析和历史 | 两配置均通过，见 `scoped-v2-observed-proof.json` |
| 既有边界回归 | 两配置各 1,356 源码黄金、90 表格原子拒绝、2,670 OOM 点通过；原汇总误用了父版本 2,667，已按日志单独纠正，原日志和汇总保留 |
| 新永久矩阵 | 两配置各 84 个独立源码黄金：七种容器，包括纯嵌套列表、宽有序标记、混合 Tab、外层引用、三层列表；LF/CRLF/CR、BOM、正反端点；检查完整来源索引、稳定尾段 ID/精确位置映射、有效 caret、旧快照和单次 Undo |
| 新路径失败原子 | 两配置各 295/275 OOM 点；失败事务拒绝提交、同 Document 重试、源码/版本/保存点/历史不变、Undo/Redo 和零泄漏 |

加强后的永久矩阵和 OOM 证据为 `matrix-v6-proof.json`，四条编译/运行命令及控制进程实际退出 0；早期 24 黄金的 `matrix-v5-proof.json` 保留。v3 的测试辅助入口重复定义编译失败保留在 `matrix-v3-helper-entrypoint-failure.json`；v4 增加明确的 helpers-only 主入口条件，产品未因此改变。

v7 同步两个已被独立语义与源码黄金证明的 Core/Editor 共用预期，其他样本和断言不变；新增永久驱动进入 32 个普通/碰撞入口及 Windows 12 个实际 DLL 入口。完整 Core 与其余八类相关驱动的两配置 36 条检查及控制进程已实际退出 0，见 `core-v7-proof.json`。全新正常 Windows DLL 从 136 个编译单元构建、未复用旧 DLL；实际 Editor 整个入口、原 100,000 段落规模程序、相关内核驱动及发布符号核对共 40 条命令和控制进程均实际退出 0，294 个公开符号通过，见 `native-v7-proof.json`。Editor 使用测试 surface/proxy，尚不证明真实 IME 或读屏。变动模块静态分析及控制进程实际退出 0，见 `analyzer-v7-proof.json`。Windows 32 驱动加 12 个实际 DLL 的常规入口 212 条及控制进程实际退出 0，见 `windows-standard-v7-proof.json`；Linux 32 驱动常规入口 188 条及控制进程也已实际退出 0，见 `standard-v7-proof.json`。限定前缀专项全部结束，255 输入及 1,323 项实际 DLL 闭包散列不变，终态证据为 `scoped-completed-v7-terminal-proof.json`。

## 仍需完成

尚需其他格式组合覆盖、合入及正式回归。合入后仍需正式 Windows/Linux/Web 回归。此批只推进 K2/E1 的来源保真，不关闭完整 CST、增量、编辑器、渲染器或其余工作包。

新的独立诊断已确认六种格式段落拆分来源差距，另在 [行内格式拆分](XUI_DOCUMENT_INLINE_SPLIT_CST.md) 的统一内核候选推进；不能由此前缀限定专项推定完整 K2/E1 已完成。

# Emoji 支持

XGE 内置 Unicode Emoji 图形包，文本和 XUI 编辑控件可通过同一文本路径显示 Emoji。应用无需加载独立 Emoji 资源，也不需要单独启用开关。

## 运行时行为

- 内置包按需解压和解析，并带有有界缓存。
- 肤色修饰符在没有精确条目时回退到对应基础 Emoji；自定义包中的精确条目优先。
- 包损坏或 SVG 解析失败时，XGE 通过日志和 `xgeSetErrorCallback` 报告可恢复错误，并在可用时回退到字体字形。

## 自定义包

`tools/generate/emoji_pack/` 包含生成和检查内置/自定义 Emoji 包的工具。它们用于资源生产；普通应用只需使用 XGE 的文本 API。资源包格式和构建命令以该目录中的 README 及对应脚本为准。

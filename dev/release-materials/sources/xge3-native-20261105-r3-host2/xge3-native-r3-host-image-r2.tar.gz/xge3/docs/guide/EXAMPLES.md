# 范例索引

每个范例目录都包含构建脚本和源码。Windows 下在仓库根目录执行相应范例的构建脚本；带可视界面的范例可使用 `--frames N` 或 `--seconds N` 自动退出（以范例自身帮助为准）。

## XGE

| 目录 | 主题 |
| --- | --- |
| `examples/xge/xge_shape` | 基础形状绘制。 |
| [`examples/xge/xge_3d`](../../examples/xge/xge_3d/README.md) | 相机、父子节点、共享网格和三维深度。 |
| [`examples/xge/xge_3d_scene`](../../examples/xge/xge_3d_scene/README.md) | GLB/glTF 共享模型放置、鼠标拾取与天空盒。 |
| [`examples/xge/xge_3d_lighting`](../../examples/xge/xge_3d_lighting/README.md) | 直接 PBR、太阳级联阴影、天空、静态 IBL 与应用昼夜参数。 |
| [`examples/xge/xge_3d_animation`](../../examples/xge/xge_3d_animation/README.md) | 六类独立外部动作、T/A 骨架离线重定向、蒙皮阴影和双层混合。 |
| [`examples/xge/xge_3d_walk`](../../examples/xge/xge_3d_walk/README.md) | 天空盒、随机岛屿、海天线、距离雾、骨骼角色行走/跳跃及第三人称相机。 |
| [`examples/xge/xge_3d_core`](../../examples/xge/xge_3d_core/README.md) | 模型缓存复用、胶囊碰撞扫掠、场景描述表、名称查找和子树克隆。 |
| [`examples/xge/xge_3d_render_quality`](../../examples/xge/xge_3d_render_quality/README.md) | 线性透明合成、FXAA 对照与节点阴影投射/接收开关。 |
| [`examples/xge/xge_3d_playback`](../../examples/xge/xge_3d_playback/README.md) | 自动动画过渡、连续打断、手臂加法叠加、整体/分层暂停及播放完成状态。 |
| [`examples/xge/xge_3d_light_effects`](../../examples/xge/xge_3d_light_effects/README.md) | 色调映射、基础调色、Bloom、高度雾独立开关，以及同场景 all/none 对照。 |
| [`examples/xge/xge_particles`](../../examples/xge/xge_particles/README.md) | 七个独立粒子程序：火花、火烟、爆炸、雨雪、尾尘、光环、彩纸。 |
| `examples/xge/xge_shape_ex`、`xge_shape_ex_*` | 路径、混合、特效、渐变、裁剪和绘制顺序。 |
| `examples/xge/xge_svg` | SVG 加载与绘制。 |
| `examples/xge/xge_emoji` | 文本中的 Emoji 显示。 |
| `examples/xge/yuv420p_texture_lab` | YUV420P 纹理。 |
| `examples/tutorial/tutorial_capture` | 教程用的最小渲染场景。 |

## XUI

`examples/xui/xui_proxy_surface`、`examples/xui/xui_proxy_shape` 与 `examples/xui/xui_proxy_font` 演示 XGE/XUI 的接入层。其余 `examples/xui/xui_*` 按控件命名，例如：

- 输入与编辑：`xui_input`、`xui_numericinput`、`xui_textedit`、`xui_codeedit`；
- 布局与容器：`xui_layout`、`xui_scrollview`、`xui_split_layout`、`xui_window`、`xui_dockpanel`；
- 数据控件：`xui_listview`、`xui_treeview`、`xui_tableview`、`xui_propertygrid`、`xui_chart`；
- 弹出与反馈：`xui_popup`、`xui_menu`、`xui_combobox`、`xui_msgbox`、`xui_toast`；
- 专用功能：`xui_flowgraph`、`xui_workflow_editor`、`xui_terminal`、`xui_qrcode`。

以范例中的公开 API 调用为准；`tests/xui/` 适合用于验证行为和边界条件，而不是替代应用代码。

## 视觉审计程序

`examples/audit/audit_*` 是固定场景的视觉审计程序，用于人工检查渲染质量以及生成截图回归素材。它们覆盖基础形状、ShapeEx、SVG、文字、相机、九宫格和多组 XUI 控件，不是对应单个 API 的入门范例。

审计程序默认创建可见窗口并持续运行，按 `Esc` 或关闭窗口退出。仍可使用原有自动审计参数：

```bat
build\audit_shape_basic.exe --frames 120
build\audit_shape_basic.exe --capture build\audit_shape_basic.png
```

指定 `--capture` 后，程序在成功保存离屏渲染结果后自动退出；截图内容与窗口预览使用同一个渲染目标。

## 通用游戏基础六项机制

[xge_game_foundation](../../examples/xge/xge_game_foundation/README.md)：公开 C API 演示动作映射、独立碰撞体与滑动、调试线框、动态纹理、渲染纹理屏幕、顶点/表面着色扩展和 CPU 3D 粒子。WASD/手柄移动，F1 开关调试绘制，支持固定帧数和截图。

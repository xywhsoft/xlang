#!/usr/bin/env python3
"""Forward GCC invocations, scheduling shared-library translation units in parallel."""
import concurrent.futures,os,pathlib,subprocess,sys,tempfile
args=sys.argv[1:]
sources=[arg for arg in args if arg.endswith('.c')]
if '-shared' not in args or len(sources)<2:
    os.execv('/usr/bin/gcc',['/usr/bin/gcc',*args])
flags=[];skip=False
for arg in args:
    if skip:skip=False;continue
    if arg=='-o':skip=True;continue
    if arg in sources or arg.endswith(('.o','.a','.so')) or arg.startswith(('-l','@')):continue
    flags.append(arg)
output=pathlib.Path(args[args.index('-o')+1])
with tempfile.TemporaryDirectory(prefix='gcc-objects-',dir=output.parent) as tmp:
    objects={source:str(pathlib.Path(tmp)/(str(i)+'.o'))for i,source in enumerate(sources)}
    def compile(source):
        result=subprocess.run(['/usr/bin/gcc',*flags,'-c',source,'-o',objects[source]],capture_output=True)
        if result.stdout:sys.stdout.buffer.write(result.stdout)
        if result.stderr:sys.stderr.buffer.write(result.stderr)
        return result.returncode
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        codes=list(pool.map(compile,sources))
    if any(codes):raise SystemExit(1)
    raise SystemExit(subprocess.call(['/usr/bin/gcc',*[objects.get(arg,arg)for arg in args]]))

"""Compile unchanged production response commands per TU, then link identically."""
from pathlib import Path
import concurrent.futures as futures
import hashlib,json,os,shlex,subprocess,time
root=Path('C:/Users/Administrator/.codex/worktrees/example-runtime-fixes/x-lang')
out=Path('D:/GIT/x-lang/build/example-runtime-fixes-20261106/native-final');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cc=Path(subprocess.check_output(['where.exe','gcc'],text=True).splitlines()[0])
jobs=[];profiles={};start=time.monotonic()
for profile in ('runtime','compiler'):
    rsp=root/'build/tmp'/(profile+'_dll.rsp')
    args=shlex.split(rsp.read_text(encoding='utf-8-sig'),posix=True)
    args=[str(out.parent/'native-final-resources'/Path(arg).name).replace('\\','/') if arg.endswith(('/tcc_builtin_resources.c','/tcc_builtin_resources_runtime.c')) else arg for arg in args]
    sources=[arg for arg in args if arg.endswith('.c')]
    skip=False;flags=[]
    for arg in args:
        if skip:skip=False;continue
        if arg=='-o':skip=True;continue
        if arg in sources or arg.endswith(('.o','.a','.def')) or arg.startswith(('-l','@')):continue
        flags.append(arg)
    folder=out/profile;folder.mkdir();objects={}
    for i,source in enumerate(sources):
        obj=folder/(str(i)+'.o');objects[source]=str(obj).replace('\\','/')
        jobs.append((profile,source,obj,[str(cc),*flags,'-c',source,'-o',str(obj)]))
    profiles[profile]=dict(responseSha256=sha(rsp),arguments=args,objects=objects)
inputs={}
for folder in [root/'src',root/'lib',root/'release/win_x64/include']:
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix in ('.h','.c','.inc','.def'):inputs[str(p)]=sha(p)
for name in ('tcc_builtin_resources_runtime.c','tcc_builtin_resources.c'):
    p=out.parent/'native-final-resources'/name;inputs[str(p)]=sha(p)
report=dict(complete=False,passed=False,compiler=str(cc),compilerSha256=sha(cc),
            commandScope='Exact production response flags and source order; only -c/-o split per unit, then original link command with sources replaced by their GCC objects.',
            inputs=inputs,profiles=profiles,units=[],links=[])
def save():(out/'build.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
def compile(job):
    profile,source,obj,command=job
    t=time.monotonic();r=subprocess.run(command,cwd=root,capture_output=True)
    obj.with_suffix('.log').write_bytes(r.stdout+r.stderr)
    return dict(profile=profile,source=source,object=str(obj),command=command,
                exitCode=r.returncode,seconds=round(time.monotonic()-t,3),
                sha256=sha(obj) if r.returncode==0 else None)
with futures.ThreadPoolExecutor(max_workers=8) as pool:
    pending=[pool.submit(compile,job)for job in jobs]
    for i,future in enumerate(futures.as_completed(pending),1):
        row=future.result();report['units'].append(row)
        if row['exitCode']:print('FAILED',row['source'],flush=True)
        if i%100==0:print('compiled',i,'/',len(jobs),flush=True)
save()
assert all(row['exitCode']==0 for row in report['units']),'C compilation failed'
assert all(sha(Path(p))==value for p,value in inputs.items()),'sources changed while compiling'
def link(profile):
    info=profiles[profile];args=[info['objects'].get(arg,arg) for arg in info['arguments']]
    rsp=out/(profile+'-link.rsp')
    rsp.write_text('\n'.join('"'+arg.replace('\\','\\\\').replace('"','\\"')+'"'for arg in args)+'\n',encoding='utf-8')
    r=subprocess.run([str(cc),'@'+str(rsp)],cwd=root,capture_output=True)
    (out/(profile+'-link.log')).write_bytes(r.stdout+r.stderr)
    return dict(profile=profile,exitCode=r.returncode,responseSha256=sha(rsp))
deadline=time.monotonic()+180
while 'DEMO6 xl.dll/xlc.dll build ok' not in (out.parent/'production-build-v6.log').read_text(encoding='utf-8',errors='replace'):
    assert time.monotonic()<deadline,'original production build has not completed; avoid concurrent DLL writers'
    time.sleep(2)
for profile in profiles:
    row=link(profile);report['links'].append(row);save();print('linked',profile,row['exitCode'],flush=True)
report.update(complete=True,passed=all(row['exitCode']==0 for row in report['links']),seconds=round(time.monotonic()-start,3));save()
raise SystemExit(0 if report['passed'] else 1)

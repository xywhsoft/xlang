# Compiler-managed C strings and bytes

`cstring` and `cbytes` mark C-backed `string` and `bytes` values in the compiler.
They do not introduce XRT value kinds or change ordinary string/bytes layouts.
Typed code carries a private pointer, length and owner reference. Reading its
contents borrows the C allocation; replacing or writing a binding constructs
its replacement automatically. There is no per-read tag test on ordinary
string/bytes paths.

```xlang
extern "library_text" @no_raise func libraryText() as point
extern "library_free" @no_raise func libraryFree(point data)

func readText() as cstring
    return cstring.take(libraryText(), libraryFree)
end

func example()
    string text = readText()
    print(text)          // reads the original C allocation
    auto saved = text   // shares its owner; no payload copy
    text[0] = 'H'        // constructs the replacement; saved keeps the original
    text = "replacement"
end
```

## Adoption and release

`cstring.take(pointer, releaser)` adopts a NUL-terminated UTF-8 allocation.
It scans the byte length once; the producer guarantees the encoding and
terminator. Embedded NUL terminates this two-argument C text form.
`cstring.take(pointer, byteLength, releaser)` adopts length-bearing UTF-8 text
without a `strlen` scan and preserves embedded NULs. The producer supplies
readable storage through `pointer[byteLength]` and valid UTF-8; adoption checks
that final byte is NUL. Negative/overflowing lengths, null with positive length,
and a missing final terminator fail and release the incoming allocation.
The pointer is anchored before evaluating the length, including a throwing
length expression. Ordinary text reads use the supplied length; legacy raw
C-string consumers still have their own NUL-terminated C semantics.
`cbytes.take(pointer, length,
releaser)` adopts arbitrary bytes with an explicit nonnegative byte length.
Unsigned C sizes (including `c_size` and `uint64`) are accepted; values above
`INT64_MAX` fail through a checked conversion after the pointer is anchored.
Text length/indexing use Unicode scalar units; binary indexing returns `uint8`.

A non-null zero-length allocation is still released. Null with zero length
represents empty data; null with a positive length is rejected. The pointer
must be the allocation address accepted by the releaser. After adoption the
producer must neither mutate nor free it.

The releaser is an unambiguous named `extern @no_raise func(point)` with no
result, using the target C calling convention. Its code must remain loaded
until the last reference is dropped. Other signatures require a small C adapter.
The compiler does not assume that the producer and xlang use the same allocator.

Adoption allocates one C-only owner record. Aliasing increments its reference
count without copying the payload or allocating another record. Scope exits,
early returns and exception unwinding release the allocation exactly once when
the last owner disappears. Storage is detached before invoking the releaser.
Owner-record allocation failure also releases the incoming C allocation.
Binary adoption anchors the pointer before evaluating its length; a throwing or
invalid length therefore cannot leak it.

## Read, write and escape rules

| Operation | Behavior |
| --- | --- |
| Typed local `string/bytes` or `auto` initialized from a C-backed result | Preserves C storage and shares ownership |
| Synchronous result declared `as cstring/cbytes`, including optional results | Preserves the C owner across the return |
| Length, integer indexing, comparisons, iteration | Reads the original allocation |
| Borrowed string parameters and string reader methods | Receive a length-bearing borrowed string view |
| Direct named language functions, concrete generic instances and nonvirtual/static methods | Compiler specializes matching string/bytes parameters (including aliases) and each eligible result to preserve C storage |
| Direct `print` / `println` | Text goes directly to the console; bytes stream through the XLON sink encoder |
| String interpolation and concatenation; binary concatenation | Read original inputs and construct the new output; no preliminary input materialization |
| `type(value)` / `value is string/bytes` | Reports the corresponding ordinary type |
| Whole replacement, indexed write, string `+=` | Automatically constructs/replaces the value; other aliases keep their old contents |
| Explicit `string(cstring)` / `bytes(cbytes)` | Requests an independent payload copy |
| Closure captures, mutable captured cells, async/generator locals | Shares the C owner, including across suspension and worker tasks |
| Nullable joins, `??`, `?=`, null tests and flow narrowing | Preserve C storage; null and present-empty remain distinct |
| `var`, containers, fields, module globals (including `auto` and multi-result bindings) | Materializes the ordinary representation at the boundary |

A writable by-value language parameter first acquires its own owner. Changing
it cannot free or mutate the caller's value. Replacement publishes the new
value only after construction succeeds. Negative indexes and failures follow
the existing sequence rules. C text and C binary data are never interchangeable.

Compiler specialization covers fixed positional/named arguments and default
arguments of directly resolved functions, including async inputs and explicit and
inferred generic instances. Fixed prefixes of `...` and `***` readers also
specialize without materializing their C-backed input; variadic elements keep
the ordinary dynamic container boundary. Signature keys include concrete types and have no
63-parameter mask limit. A C-backed default argument also selects the C input
and result specialization when that default is used; explicit overrides do not
evaluate it. Default evaluation order and exception cleanup are unchanged.
`task.spawn` specializes statically resolved named language readers to keep C
inputs in their task frames, including exported language readers. Function-value variables keep their declared signature
and its ordinary conversion rules; Future payloads keep their ordinary result
representation. A synchronous owner-result producer passed to `task.spawn` is
automatically adapted to that ordinary result ABI, including nullable results.
Borrowed string inputs also keep their C view through
function-value calls. Indirect results with an ordinary signature, virtual calls and unmigrated native
binary readers can still cross an ordinary-value boundary. A function-value
signature explicitly returning `cstring/cbytes` retains the C owner. Assigning
that callable to an ordinary result signature automatically creates a result
adapter; the original callable expression is evaluated once and snapshotted.
Named producers use a private body specialization. `xcall` performs the same
adaptation before erasure, including product and nullable results. Overload
resolution prefers an exact owner signature to a materializing conversion.
Stored and captured variadic callables support the same automatic adaptation,
including both `...` and `***`, fixed prefixes, nullable and product results.
For example, `auto raw = producer; func(...) as string callback = raw` and
`var erased = xcall(raw)` work without first binding the named declaration.
The adapter borrows the existing array/dict argument pack directly: it neither
repackages nor boxes its elements again. Parameter names, literal defaults and
default expressions with captured variables retain the original callable's
binding behavior and snapshot. Each product result converts independently
after a single producer invocation. Direct calls through the original
owner-returning signature still retain the C allocation without copying it;
only the ordinary result boundary materializes. `task.spawn` also adapts
stored `...` and `***` owner producers to ordinary Future results. Its fixed
prefix is positional, followed by keyword arguments for `***`. The compiler
builds and owns the final keyword dict before task submission, preserving
left-to-right, single evaluation and exception cleanup. Duplicate keywords,
missing fixed arguments and positional values in the dict tail are rejected.
Result adaptation also recurses through returned callable results, so a
factory returning `func() as cstring` can bind to
`func() as func() as string`, enter `xcall`, or publish an ordinary callback
through a Future. Each returned callback keeps the original parameter names,
defaults and snapshot; callable input signatures are unchanged.
Nullable callable values participate in the same conversion. The compiler
evaluates the source once, preserves null, and adapts only its present branch.
This also covers stored factories returning nullable callables, including
`xcall`, worker results and captured variadic defaults. Creating the adapter
does not invoke the producer or copy its C payload; invocation through an
ordinary result signature performs the normal result conversion.
Result matching is recursive and pairwise: a factory returning
`func() as (cstring,cbytes)` may bind to a factory returning
`func() as (string,cbytes)` or `func() as (cstring,bytes)`. Only changed result
slots materialize; unchanged C owner slots retain their original allocation.
The same rule applies inside nullable and multiply nested callbacks. Exact
owner signatures still take precedence during overload resolution. Conversion
does not change callback input types, turn text into binary, or remove a
nullable callable's presence check.
An override returning a C marker adopts an ordinary base slot's result ABI;
the body materializes on return. Slots explicitly returning C markers on both
base and derived declarations keep their owner ABI. These rules are not a promise of
universal zero-copy dispatch. Explicit source-language C parameter
types remain restricted to extern declarations; ordinary language readers
continue declaring `string` / `bytes`.

## Native borrowed span parameters

An extern `cstring` parameter has the C physical type `xstrview`; an extern
`cbytes` parameter has `xbytesview`. Both are readonly, default-mode borrowed
parameters. They accept either C-backed or ordinary values without copying the
payload or allocating an owner record at the call boundary.

```xlang
extern "library_inspect_text" @no_raise func inspectText(cstring text) as bool
extern "library_inspect_bytes" @no_raise func inspectBytes(cbytes data) as bool
```

```c
bool library_inspect_text(xstrview text);
bool library_inspect_bytes(xbytesview data);
```

The callee may read the span only for the duration of the call and must not
retain, modify or free it. `byval`, `byref` and `out` modes are rejected.
C result markers are not raw extern return ABIs: use a synchronous language
`take` adapter as above to state the releaser explicitly.

## Public functions and C exports

Source packages may publish synchronous `export func` results as `cstring` or
`cbytes`, including nullable and multi-result signatures. Imported direct calls
and exactly typed function values keep the private C owner result. Locals and
readonly calls share that owner without copying its payload.

Ordinary callback signatures, erased calls and Future results automatically
materialize; callers need no explicit `string(...)` / `bytes(...)` conversion.
Direct imported calls and owner-typed callbacks retain the original allocation.

```xlang
func() as cstring borrowed = readText  // callback results keep the C owner
func() as string ordinary = readText  // copies automatically on invocation
var erased = xcall(readText)          // ordinary callable result schema
// await task.spawn(readText) also publishes an ordinary string Future payload
```

```xlang
extern "library_text" @no_raise func libraryText() as point
extern "library_free" @no_raise func libraryFree(point data)

export func readText() as cstring
    return cstring.take(libraryText(), libraryFree)
end
```

The generated C export is a separate adapter with ordinary public carriers:
`string` is a pointer/length pair released with `xrtFree`, and `bytes` is an
owned `xvalue*` released with `xrtValueRelease`. Only calling that foreign entry
copies a C-backed result. It releases the private owner before returning; a
custom releaser and its code address never escape into the public C header.
Null and present-empty results stay distinct. Product materialization rolls
back both the public prefix and the private suffix on allocation failure, and
body failures keep the shared foreign error transaction. Raw extern and async
result markers remain rejected. Source parameters still use `string`/`bytes`;
the compiler supplies C owner input specializations.

`__xl_runtime.takeCstr(pointer)` remains useful for independent XRT-allocated,
NUL-terminated UTF-8 text: it transfers directly to an ordinary string without
a payload copy at the return boundary. It assumes `xrtFree` and does not retain
the marker's shared-owner semantics on later ordinary assignments. Arbitrary
bytes and custom releasers must use their explicit `take` adapters.

`tools/check_xlir_c_owned_exports.ps1 -PublicDirectory <source-build>
-Directory <fresh-directory>` checks public header isolation, rejected IR
bridge mutations, static pointer identity, source-package imports, generated
C host calls, null/empty results, binary NUL, exception cleanup and a 32-step
allocation-failure sweep at O0/O2, plus source JIT and standalone EXE execution.

Existing native declarations keep their ABI: legacy `string` parameters use
C string pointers where applicable; legacy `bytes` parameters expect managed
`xvalue*`. A raw C bytes allocation must materialize when passed to the latter.
Migrate such native readers to a span entry point before claiming zero-copy
extension-library coverage. Eighty resident synchronous entries now have span
overloads: Buffer input construction/writes, codec encoders, CRC32, digests and
stream updates, HMAC, HKDF/PBKDF2, timing-safe comparison, selected key setup and
signing, compression, Unicode validation and encoding conversion/detection.
Mixed C/ordinary byte parameters select the span overload without allocating
input owners; ordinary-only calls retain their legacy ABI.
No XRT modification is needed for the new span ABI. Async/retaining external
APIs still require an ownership-aware adapter; a borrowed span is never a
promise to keep the input after the call returns.

## Costs and supported scope

Zero-copy means no duplicate input payload on the documented static read paths.
C adoption still pays for its owner record, reference-count maintenance and
length scanning for NUL-terminated text. Output creation, explicit copying and
ordinary escape boundaries have their normal allocation costs. The reference
count is atomic only on C owner acquisition/release. C owner locals and captures
use a private frame leaf profile; they remain outside XRT dynamic values and
collections. Reads have no atomic operation or ordinary-value tag test.
C markers are not allowed in fields, explicit global declarations, aliases, uninitialized
nullable marker declarations or generic elements. An inferred module global
uses ordinary string/bytes storage just like an explicitly typed ordinary global;
the initializer's C owner is released after the copy, including on failure. This
rule also covers nullable and multi-result globals. Optional synchronous return
markers (`as cstring?` / `as cbytes?`) and inferred optional locals are supported.
The compiler-private optional descriptor uses `{NULL, SIZE_MAX, NULL}` for null;
present-empty uses zero length. It remains three words and shares the existing
owner/capture machinery. Presence checks occur only on optional paths. Ordinary
XRT nullable types, dynamic values and string/bytes layouts are unchanged.

Mixed printing prepares ordinary argument formatting before the first write.
The console may then receive several writes; a line-atomic output guarantee
is not provided. The binary format budget is checked before output, while
console I/O failures propagate through the normal error path.

## Validation

From `demo6`, with a compatible debug-capable `release/xl.dll`:

```powershell
pwsh -NoProfile -File tools/check_xlir_c_owned.ps1
```

This builds current compiler sources, runtime units and generated-C programs.
Tests check original pointer identity at native/console boundaries, allocation
counters for reads, shared release counts, writes and writable parameters,
conditional joins, iteration with source rebinding, dynamic boundaries,
adoption/copy failure and invalid declaration rejection.

For source-runtime JIT and standalone EXE acceptance, build
`tools/build_xlir_public_source_driver.ps1` in a fresh directory, then pass its
`public_source.exe` to `check_xlir_c_owned.ps1 -PublicDriver <path>`. Source
shipping builds without memory debug still run value and lifetime assertions;
allocation-counter checks use the separate debug runtime lane. Acceptance
records belong under `build/c-owned/`; this targeted check is not a claim that
all repository-wide inventories and unrelated release gates are green.

Nullable/partial-result follow-up acceptance
(`build/c-owned/followup-final-acceptance.log`) passes 34 generated-C programs,
35 C owner JIT/standalone EXE pairs, 21 ordinary JIT/EXE pairs without C owner
headers, 21 negative declarations and 13 export checks. The source build uses
1,190 translation units and verifies 2,373 unchanged inputs. All eight original
failure repros also pass unchanged through source JIT. The new cases cover
nullable callback absence/presence, single evaluation, delayed invocation,
shared-owner lifetime, variadic defaults, erased/stored/worker factories,
partial product conversion and exact-owner overload preference. Native pointer
checks prove that unconverted result slots retain their C allocation. O0/O2
boundary hosts each execute 1,920 allocation limits (296 failures and 1,624
completions), with balanced foreign allocations and unchanged XRT live counts.
The complete RuntimeOp/ownership contract gates still pass at both optimization
levels. Mainline receipts are under `build/c-owned/followup-main-acceptance/`.
The standard release build uses the reviewed isolated source snapshot and
verifies 3,358 unchanged build inputs, preserving the existing shipping C header
fix. All 36 release-gate steps pass against both staging and the published
toolchain; source-package owner imports also pass published JIT and standalone
EXE execution. Concurrent main-checkout TLS edits are excluded from this
artifact snapshot. Receipts retain source/binary hashes and replacement backups.

Completion acceptance (`build/c-owned/completion-final-acceptance.log`) uses a
1,175-unit source build (`completion-public-current/build.json`, 2,355 unchanged
inputs). All 32 generated-C programs, 33 C owner JIT/standalone EXE pairs,
19 ordinary JIT/EXE pairs without C owner headers, 17 negative declarations and
13 export checks pass. The operand-effect catalog checks all 496 RuntimeOps
and 3,968 effects at both O0/O2. Each boundary host sweeps 1,152 allocation
limits (178 failures and 974 completions), including nested callback factories
and length-bearing text, with balanced foreign allocations and no XRT live
growth. The ordinary result stress still passes 197 rejected mutations, 680
executions and 480 allocation faults per optimization.

The standard `build.bat` release build passes at its normal optimization level;
recorded source inputs remain unchanged during the build. All 28 steps in
`tools/check_xlir_c_owned_release.ps1` pass against both the staging directory
and the published `release/` toolchain. Imported owner exports pass JIT and
standalone EXE execution too. `check_xlir_task_spawn_closure_abi.ps1` checks the
resident V3 frame layout, deterministic C, cleanup-before-publication and a
strict GCC/runtime lane in a fresh output directory. Published acceptance
receipts are under `build/c-owned/completion-main-acceptance/`.

Stored-variadic acceptance (`build/c-owned/variadic-acceptance.log`) uses a
1,165-unit source build (`variadic-public-current/build.json`, 2,337 unchanged
inputs). It passes 28 generated-C programs, 29 C owner JIT/standalone EXE pairs,
18 ordinary JIT/EXE pairs without C owner headers, 13 negative declarations and
13 export checks. `xlir_c_owned_variadic_results.xl` covers stored/captured
array/dict variadics, fixed prefixes, nullable/product results, snapshots,
single evaluation, literal/captured defaults, keyword binding and task results;
its verifier rejects 171 mutations. O0/O2 hosts verify argument-pack pointer
identity for empty/populated array/dict packs and each sweep 960 allocation
limits (154 failures, 806 completions), with balanced foreign allocations and
no XRT live growth. The ordinary callable-result contract still rejects 197
mutations; each optimization passes 680 executions and 480 allocation faults.

Boundary completion acceptance (`build/c-owned/boundaries-acceptance-complete.log`)
uses a 1,156-unit source build (`boundaries-public-current/build.json`). It
passes 27 generated-C programs, 28 C owner JIT/standalone EXE pairs, 14 ordinary
JIT/EXE pairs without C owner headers, 13 negative declarations and all 13
export checks. New pointer-identity cases cover aliases (including nullable
aliases), product forwarding, exported worker inputs, instance/static/inherited
and generic-class readers. Callable result cases cover ordinary and explicit
owner signatures, overload preference, single evaluation/snapshot capture,
nullable/product results, named variadic erasure, virtual overrides and Future
results. O0/O2 boundary hosts each sweep 480 allocation limits: 47 failures and
433 completions, with foreign allocations balanced and no XRT live growth.
The ordinary callable-result contract rejects 197 IR mutations; O0/O2 hosts
each pass 680 executions and 480 allocation faults with balanced allocation
counts (`ordinary-result-current.log`). Owned string boxing transfers the
ordinary allocation through `xrtValueStringTake` instead of copying it again.

Export-result acceptance (`build/c-owned/export-results-acceptance4/results.json`)
passes 13 checks against a 1,144-unit source build. Eight export recipes reject
16 incorrect bridge/carrier mutations. Both O0/O2 C hosts sweep 32 allocation
thresholds (11 failures and 21 completions each), checking foreign allocation
balance and XRT live counts. Source JIT/EXE also cover imported nullable/default
results, aliases, function values, class methods, replacement and ordinary
dynamic/container escapes. The companion `export-results-regression1.log`
records 22 generated-C programs, 23 C interoperability JIT/EXE pairs, 14 ordinary
JIT/EXE pairs without C owner headers, 13 negative declarations and the existing
32-step global initialization fault sweep. These receipts are scoped tests,
not a repository-wide release claim.

Earlier acceptance (`build/c-owned/audit-fixes-acceptance-2/acceptance.json`)
built 1,097 source translation units and verified 2,192 unchanged build inputs.
Two runtime units (the owner unit at both O0 and O2), 21 generated-C programs
and 12 negative declarations passed. O0/O2 contract harnesses each checked 495
RuntimeOps / 3,960 operand effects, 22 capture mutations, 73 managed-storage
mutations and four nullable-join mutations. Twenty-two C interoperability
programs and 14 ordinary programs passed both source JIT and standalone EXE;
ordinary generated C included no C owner runtime header. The source runtime
receipt is `build/c-owned/audit-fixes-public-1/build.json`.

The global initialization fault gate explicitly enables memory debugging before
module initialization and sweeps 32 allocation limits. Four limits trigger
allocation failures and 28 complete normally; all C producer allocations are
released, including when a preceding global result has already been published.
`tools/check_xlir_c_owned_globals_fault.ps1` also runs from the main C owner gate.

The first complete acceptance is recorded in `audit-fixes-acceptance-1.log`.
The final pass resumed after the system exhausted commit memory during linking;
`--no-keep-memory` reduced linker memory use without changing compiler inputs.
Its original and resumed logs, source hashes and fault results are retained in
the second acceptance directory. These targeted contracts do not assert that
unrelated repository-wide release gates have passed.

`xlir_c_owned_sizes.xl`, `xlir_c_owned_defaults.xl`, `xlir_c_owned_spawn.xl` and
`xlir_c_owned_globals.xl` cover unsigned lengths and overflow cleanup, C defaults
and explicit overrides, worker input ownership and fixed result boundaries,
and ordinary nullable/multi-result global storage and replacement.

`xlir_c_owned_calls.xl` checks explicit/inferred generic identities, concrete
signature separation, recursive generic forwarding, a 65-parameter function,
function-value string loans and cleanup of nested temporary C arguments.

`xlir_c_owned_frames.xl` checks original pointers through closure capture, task
workers, mutable cells, a genuinely suspended await, and generator locals. The
runtime unit races four threads acquiring/dropping the same C allocation and
verifies one final release. The resident profile is compiler-private and adds
no C kind to xvalue or ordinary string/bytes representations.

Async input specialization retains the C owner into the worker frame before
publishing the task, including inferred generic calls. Future and generator
payloads remain ordinary container elements; local C owners across suspension
do not materialize.

`xlir_c_owned_stdlib.xl` exercises resident span dispatch, mixed HMAC/KDF inputs,
Buffer construction/writes, Unicode, encoding, compression, prefix bounds and
error propagation. Its emitted C must contain no `xl6CBytesCopyV1` input
materialization. Ordinary codec, compression, encoding and validator programs
also run through JIT/EXE, and their emitted C must not include the C owner
runtime merely because span overloads were imported.

`xlir_c_owned_nullable.xl` covers optional returns, generic forwarding, indirect
string reads, present-empty, null tests and `is` narrowing, joins with ordinary
nullable values, coalescing, null-aware assignment, transparent writes, aliases,
worker captures, generator locals and exception cleanup. Emitted C must contain
no string/bytes input materialization. `xlir_c_owned_nullable_boundaries.xl`
separately checks copying into dynamic values, typed arrays and ordinary fields,
including absent values and logical `type()` identity. The runtime unit checks
the null sentinel independently of present-empty and validates its copy/drop
and ordinary-null conversions.

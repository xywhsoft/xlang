#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "$(uname -m)" != "x86_64" ]]; then
    echo "error: demo6 Linux RC currently supports x86_64 only" >&2
    exit 1
fi

if ! getconf GNU_LIBC_VERSION >/dev/null 2>&1; then
    echo "error: demo6 Linux RC currently requires a glibc-based system" >&2
    exit 1
fi

BUILD_DIR="${XL6_LINUX_BUILD_DIR:-$ROOT/build/linux}"
RELEASE_DIR="${XL6_RELEASE_DIR:-$ROOT/release/linux_x64}"
SDK_DIR="$ROOT/release/linux_x64"
TCC_SOURCE_DIR="$BUILD_DIR/tcc-source"
TCC_DIST_DIR="$BUILD_DIR/tcc-dist"
PACK_TOOL="$BUILD_DIR/tcc_vfs_lzma_pack"
CC="${CC:-gcc}"
MAKE="${MAKE:-make}"
PYTHON="${PYTHON:-python3}"
JOBS="${JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '2')}"

require_tool() {
    if ! command -v "$1" >/dev/null 2>&1; then
        printf 'DEMO6 Linux build failed: required tool "%s" was not found in PATH.\n' "$1" >&2
        exit 1
    fi
}

require_tool "$CC"
require_tool "$MAKE"
require_tool "$PYTHON"

"$PYTHON" "$ROOT/tools/generate_ir_contract_catalog.py" --root "$ROOT" --cc "$CC" --directory "$BUILD_DIR/ir-contract-catalog"

"$PYTHON" "$ROOT/tools/check_stdlib_shipping_sources.py" --root "$ROOT"

mkdir -p "$BUILD_DIR" "$TCC_DIST_DIR/include" "$TCC_DIST_DIR/lib" "$RELEASE_DIR"

"$PYTHON" "$ROOT/tools/sync_xrt_snapshot.py" --root "$ROOT" --check
"$PYTHON" "$ROOT/tools/generate_stdlib_index.py" --root "$ROOT"
"$PYTHON" "$ROOT/tools/gen_xrt_symbol_table.py" --root "$ROOT"

printf 'Preparing native Linux TCC...\n'
rm -rf "$TCC_SOURCE_DIR"
cp -a "$ROOT/lib/tcc" "$TCC_SOURCE_DIR"
sed -i 's/\r$//' "$TCC_SOURCE_DIR/configure"
chmod +x "$TCC_SOURCE_DIR/configure"
(
    cd "$TCC_SOURCE_DIR"
    ./configure --cc="$CC" --prefix="$TCC_DIST_DIR" --tccdir="$TCC_DIST_DIR"
    # Vendored TCC is not its own Git checkout. Do not stamp the parent xlang
    # branch/date or scan its unrelated dirty tree into the compiler binary.
    "$MAKE" -j"$JOBS" GITHASH=no tcc libtcc1.a
)
cp -a "$TCC_SOURCE_DIR/include/." "$TCC_DIST_DIR/include/"
cp "$TCC_SOURCE_DIR/libtcc1.a" "$TCC_DIST_DIR/libtcc1.a"
cp "$TCC_SOURCE_DIR/libtcc1.a" "$TCC_DIST_DIR/lib/libtcc1.a"
cp "$TCC_SOURCE_DIR/tcc" "$BUILD_DIR/tcc"

# Propagate the configured target layout to libtcc embedded in user artifacts.
# The source snapshot has only generic defaults; losing CONFIG_TRIPLET breaks
# nested compilation on multiarch glibc systems. An empty triplet is valid on
# systems whose headers and startup objects use the non-multiarch layout.
TCC_CONFIGURED_TRIPLET="$(sed -n 's/^#define CONFIG_TRIPLET "\([^"]*\)"$/\1/p' "$TCC_SOURCE_DIR/config.h")"
if [[ -n "$TCC_CONFIGURED_TRIPLET" && ! "$TCC_CONFIGURED_TRIPLET" =~ ^[A-Za-z0-9_.-]+$ ]]; then
    echo 'error: unexpected configured TCC target triplet' >&2
    exit 1
fi

printf 'Building Linux XRT object and VFS packer...\n'
"$BUILD_DIR/tcc" -std=c11 -fPIC -I"$ROOT" -I"$SDK_DIR" \
    -c "$ROOT/tools/xrt_single_header_impl.c" \
    -o "$BUILD_DIR/xrt.o"

"$CC" -std=c11 -O2 -DZ7_ST -I"$ROOT/lib/lzma" \
    "$ROOT/tools/tcc_vfs_lzma_pack.c" \
    "$ROOT/lib/lzma/LzmaEnc.c" \
    "$ROOT/lib/lzma/LzFind.c" \
    "$ROOT/lib/lzma/CpuArch.c" \
    -o "$PACK_TOOL"

"$PYTHON" "$ROOT/tools/precompile_builtin.py" --root "$ROOT" --tcc "$BUILD_DIR/tcc" \
    --tcc-dist "$TCC_DIST_DIR" --output "$BUILD_DIR/precompiled" --triplet "$TCC_CONFIGURED_TRIPLET" \
    --native-cc "$(command -v "$CC")"

printf 'Generating Linux embedded TCC resources...\n'
"$PYTHON" "$ROOT/tools/gen_tcc_vfs_resources.py" \
    --root "$ROOT" \
    --manifest "$ROOT/tools/tcc_vfs_manifest_linux_runtime.txt" \
    --output "$BUILD_DIR/tcc_builtin_resources_runtime.c" \
    --tcc-dist "$TCC_DIST_DIR" \
    --xrt-obj "$BUILD_DIR/xrt.o" \
    --pack-tool "$PACK_TOOL"

"$PYTHON" "$ROOT/tools/gen_tcc_vfs_resources.py" \
    --root "$ROOT" \
    --manifest "$ROOT/tools/tcc_vfs_manifest_linux_xlc.txt" \
    --output "$BUILD_DIR/tcc_builtin_resources.c" \
    --tcc-dist "$TCC_DIST_DIR" \
    --xrt-obj "$BUILD_DIR/xrt.o" \
    --pack-tool "$PACK_TOOL"

COMMON_FLAGS=(
    -std=c11
    -D_GNU_SOURCE
    -Wall
    -Wno-pointer-sign
    -Wno-unused-function
    -Wno-unused-variable
    -Wno-unused-but-set-variable
    -Wno-format-truncation
    -O2
    -fPIC
    -ffunction-sections
    -fdata-sections
	-DXL_BUILD_DLL
	-DXL_STATIC_TCC
	-DLIBTCC_AS_DLL
	-DCONFIG_TCC_BUILTIN_VFS=1
    -I"$ROOT"
    -I"$SDK_DIR"
    -I"$SDK_DIR/include"
    -I"$ROOT/src"
    -I"$ROOT/lib/lzma"
    -I"$TCC_SOURCE_DIR"
)
if [[ -n "$TCC_CONFIGURED_TRIPLET" ]]; then
    COMMON_FLAGS+=("-DXL6_TCC_CONFIGURED_TRIPLET=\"$TCC_CONFIGURED_TRIPLET\"")
fi
SHARED_FLAGS=(-shared -s -Wl,--gc-sections -Wl,-z,defs)
SYSTEM_LIBS=(-pthread -ldl -lm)

TCC_SOURCES=(
    "$TCC_SOURCE_DIR/libtcc.c"
    "$TCC_SOURCE_DIR/tcctools.c"
    "$TCC_SOURCE_DIR/tcc_builtin_vfs.c"
    "$ROOT/lib/lzma/LzmaDec.c"
)
# Share Windows' physical translation-unit list, including its source bundles.
# Capture first so a manifest error cannot be hidden by process substitution.
RUNTIME_SOURCE_TEXT="$("$PYTHON" "$ROOT/tools/runtime_sources.py" --root "$ROOT")"
mapfile -t RUNTIME_SOURCES <<< "$RUNTIME_SOURCE_TEXT"
COMPILER_ONLY_SOURCES=(
    "$ROOT/src/abi/xl6_abi_dump.c"
    "$ROOT/src/ast/xl6_ast_dump.c"
    "$ROOT/src/sem/xl6_sem_index.c"
    "$ROOT/src/ir/xl6_ir_dump.c"
    "$ROOT/src/resource/xl6_win_resource.c"
)

printf 'Building libxl.so...\n'
"$CC" "${COMMON_FLAGS[@]}" "${SHARED_FLAGS[@]}" \
    -DXL_RUNTIME_ONLY_DLL \
    "${RUNTIME_SOURCES[@]}" \
    "${TCC_SOURCES[@]}" \
    "$BUILD_DIR/tcc_builtin_resources_runtime.c" \
    "${SYSTEM_LIBS[@]}" \
    -Wl,-soname,libxl.so \
    -o "$RELEASE_DIR/libxl.so"

printf 'Building libxlc.so...\n'
"$CC" "${COMMON_FLAGS[@]}" "${SHARED_FLAGS[@]}" \
    "${RUNTIME_SOURCES[@]}" \
    "${COMPILER_ONLY_SOURCES[@]}" \
    "${TCC_SOURCES[@]}" \
    "$BUILD_DIR/tcc_builtin_resources.c" \
    "${SYSTEM_LIBS[@]}" \
    -Wl,-soname,libxlc.so \
    -o "$RELEASE_DIR/libxlc.so"

printf 'Building xl command line tool...\n'
"$CC" -std=c11 -D_GNU_SOURCE -Wall -O2 -s -ffunction-sections -fdata-sections -Wl,--gc-sections -I"$ROOT" -I"$SDK_DIR" \
    "$ROOT/src/driver/xl6_xlc_shell.c" \
    "$ROOT/src/common/xl6_console.c" \
    -L"$RELEASE_DIR" -lxlc \
    -Wl,-rpath,'$ORIGIN' \
    -pthread -ldl -lm \
    -o "$RELEASE_DIR/xl"

printf 'DEMO6 Linux build ok: %s/xl %s/libxl.so %s/libxlc.so\n' "$RELEASE_DIR" "$RELEASE_DIR" "$RELEASE_DIR"

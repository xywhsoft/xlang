#include "src/ast/xl6_ast_dump.h"
#include "src/common/xl6_output.h"

static void xl6DumpIndent(XL6_Output* out, int indent)
{
    int i;

    for ( i = 0; i < indent; ++i ) {
        xl6OutputPuts("  ", out);
    }
}

static void xl6AstDumpFlagsText(XL6_Output* out, unsigned int flags)
{
    if ( flags == 0 ) {
        return;
    }
    xl6OutputPuts(" flags=[", out);
    if ( flags & XL6_AST_FLAG_PUBLIC ) {
        xl6OutputPuts("public ", out);
    }
    if ( flags & XL6_AST_FLAG_PRIVATE ) {
        xl6OutputPuts("private ", out);
    }
    if ( flags & XL6_AST_FLAG_PROTECTED ) {
        xl6OutputPuts("protected ", out);
    }
    if ( flags & XL6_AST_FLAG_STATIC ) {
        xl6OutputPuts("static ", out);
    }
    if ( flags & XL6_AST_FLAG_OVERRIDE ) {
        xl6OutputPuts("override ", out);
    }
    if ( flags & XL6_AST_FLAG_FINAL ) {
        xl6OutputPuts("final ", out);
    }
    if ( flags & XL6_AST_FLAG_VIRTUAL ) {
        xl6OutputPuts("virtual ", out);
    }
    if ( flags & XL6_AST_FLAG_NATIVE ) {
        xl6OutputPuts("native ", out);
    }
    if ( flags & XL6_AST_FLAG_ASYNC ) {
        xl6OutputPuts("async ", out);
    }
    if ( flags & XL6_AST_FLAG_EXTERN ) {
        xl6OutputPuts("extern ", out);
    }
    if ( flags & XL6_AST_FLAG_IMPORT_SELECTIVE ) {
        xl6OutputPuts("import-selective ", out);
    }
    xl6OutputPutc(']', out);
}

void xl6AstDumpTextFile(XL6_Output* out, const XL6_AstNode* node, int indent)
{
    size_t i;

    if ( out == NULL ) {
        return;
    }
    if ( node == NULL ) {
        return;
    }
    xl6DumpIndent(out, indent);
    xl6OutputPuts(xl6AstKindName(node->kind), out);
    if ( node->text != NULL && node->text[0] != '\0' ) {
        xl6OutputPrintf(out, " \"%s\"", node->text);
    }
    if ( node->line > 0 ) {
        xl6OutputPrintf(out, " @%d:%d", node->line, node->column);
    }
    xl6AstDumpFlagsText(out, node->flags);
    if ( node->doc != NULL && node->doc[0] != '\0' ) {
        xl6OutputPuts(" #doc", out);
    }
    xl6OutputPutc('\n', out);

    for ( i = 0; i < node->childCount; ++i ) {
        xl6AstDumpTextFile(out, node->children[i], indent + 1);
    }
}

void xl6AstDumpText(const XL6_AstNode* node, int indent)
{
    XL6_Output out;

    xl6OutputInitStdFile(&out, stdout);
    xl6AstDumpTextFile(&out, node, indent);
    xl6OutputClose(&out);
}

static void xl6AstDumpJsonEscaped(XL6_Output* out, const char* text)
{
    const unsigned char* p;

    if ( text == NULL ) {
        return;
    }
    for ( p = (const unsigned char*)text; *p != '\0'; ++p ) {
        unsigned char ch = *p;
        if ( ch == '"' ) {
            xl6OutputPuts("\\\"", out);
        } else if ( ch == '\\' ) {
            xl6OutputPuts("\\\\", out);
        } else if ( ch == '\b' ) {
            xl6OutputPuts("\\b", out);
        } else if ( ch == '\f' ) {
            xl6OutputPuts("\\f", out);
        } else if ( ch == '\n' ) {
            xl6OutputPuts("\\n", out);
        } else if ( ch == '\r' ) {
            xl6OutputPuts("\\r", out);
        } else if ( ch == '\t' ) {
            xl6OutputPuts("\\t", out);
        } else if ( ch < 0x20 ) {
            xl6OutputPrintf(out, "\\u%04X", (unsigned)ch);
        } else {
            xl6OutputPutc((int)ch, out);
        }
    }
}

static void xl6AstDumpJsonIndent(XL6_Output* out, int indent)
{
    int i;

    for ( i = 0; i < indent; ++i ) {
        xl6OutputPuts("  ", out);
    }
}

static void xl6AstDumpRange(XL6_Output* out, const XL6_AstRange* range)
{
    if (!range->known) { xl6OutputPuts("null", out); return; }
    xl6OutputPrintf(out, "{\"startOffset\":%zu,\"endOffset\":%zu,"
                   "\"startLine\":%d,\"startColumn\":%d,"
                   "\"endLine\":%d,\"endColumn\":%d}",
                   range->startOffset, range->endOffset, range->startLine,
                   range->startColumn, range->endLine, range->endColumn);
}

static void xl6AstDumpJsonNode(XL6_Output* out, const XL6_AstNode* node, int indent, int ranges)
{
    size_t i;

    if ( node == NULL ) {
        xl6OutputPuts("null", out);
        return;
    }

    xl6OutputPuts("{\n", out);
    xl6AstDumpJsonIndent(out, indent + 1);
    xl6OutputPrintf(out, "\"kind\":\"%s\"", xl6AstKindName(node->kind));
    if ( node->text != NULL && node->text[0] != '\0' ) {
        xl6OutputPuts(",\n", out);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPuts("\"text\":\"", out);
        xl6AstDumpJsonEscaped(out, node->text);
        xl6OutputPutc('"', out);
    }
    if ( node->line > 0 ) {
        xl6OutputPuts(",\n", out);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPrintf(out, "\"line\":%d,\n", node->line);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPrintf(out, "\"column\":%d", node->column);
    }
    if (ranges) {
        xl6OutputPuts(",\n", out);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPuts("\"source\":", out);
        if (xl6AstSourcePath(node)) {
            xl6OutputPutc('"', out);
            xl6AstDumpJsonEscaped(out, xl6AstSourcePath(node));
            xl6OutputPutc('"', out);
        } else xl6OutputPuts("null", out);
        xl6OutputPuts(",\n", out);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPuts("\"range\":", out);
        xl6AstDumpRange(out, &node->range);
        xl6OutputPuts(",\n", out);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPuts("\"tokenRange\":", out);
        xl6AstDumpRange(out, &node->tokenRange);
    }
    if ( node->flags != 0 ) {
        xl6OutputPuts(",\n", out);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPrintf(out, "\"flags\":%u", node->flags);
    }
    if ( node->doc != NULL && node->doc[0] != '\0' ) {
        xl6OutputPuts(",\n", out);
        xl6AstDumpJsonIndent(out, indent + 1);
        xl6OutputPuts("\"doc\":\"", out);
        xl6AstDumpJsonEscaped(out, node->doc);
        xl6OutputPutc('"', out);
    }
    xl6OutputPuts(",\n", out);
    xl6AstDumpJsonIndent(out, indent + 1);
    xl6OutputPuts("\"children\":[", out);
    if ( node->childCount > 0 ) {
        xl6OutputPutc('\n', out);
        for ( i = 0; i < node->childCount; ++i ) {
            xl6AstDumpJsonIndent(out, indent + 2);
            xl6AstDumpJsonNode(out, node->children[i], indent + 2, ranges);
            if ( i + 1 < node->childCount ) {
                xl6OutputPutc(',', out);
            }
            xl6OutputPutc('\n', out);
        }
        xl6AstDumpJsonIndent(out, indent + 1);
    }
    xl6OutputPutc(']', out);
    xl6OutputPutc('\n', out);
    xl6AstDumpJsonIndent(out, indent);
    xl6OutputPutc('}', out);
}

void xl6AstDumpJson(XL6_Output* out, const XL6_AstNode* node)
{
    if ( out == NULL ) {
        return;
    }
    xl6AstDumpJsonNode(out, node, 0, 0);
    xl6OutputPutc('\n', out);
}

/* Conservative upper bound includes pretty-print indentation and worst-case
 * JSON escaping. Reject before writing anything, rather than truncate an AST. */
static int xl6AstRangeOutputFits(const XL6_AstNode* node, size_t depth,
                                 size_t* nodes, size_t* budget)
{
    const char* strings[3];
    size_t i, charge = 1024 + depth * 96;
    if (!node) return 1;
    if (depth > 256 || ++*nodes > 100000 || charge > *budget) return 0;
    *budget -= charge;
    strings[0] = node->text; strings[1] = node->doc; strings[2] = xl6AstSourcePath(node);
    for (i = 0; i < 3; ++i) {
        size_t length = strings[i] ? strlen(strings[i]) : 0;
        if (length > *budget / 6) return 0;
        *budget -= length * 6;
    }
    for (i = 0; i < node->childCount; ++i)
        if (!xl6AstRangeOutputFits(node->children[i], depth + 1, nodes, budget)) return 0;
    return 1;
}

int xl6AstDumpJsonRanges(XL6_Output* out, const XL6_AstNode* node)
{
    size_t nodes = 0, budget = 16u * 1024u * 1024u;
    if (!out || !xl6AstRangeOutputFits(node, 0, &nodes, &budget)) return 0;
    xl6OutputPuts("{\"schema\":1,\"scope\":\"entry-syntax\","
                 "\"offsetEncoding\":\"utf-8-after-bom\","
                 "\"columnEncoding\":\"unicode-scalar-1-based\","
                 "\"rangeConvention\":\"half-open\",\"ast\":", out);
    xl6AstDumpJsonNode(out, node, 0, 1);
    xl6OutputPuts("}\n", out);
    return !xl6OutputHasFailed(out);
}

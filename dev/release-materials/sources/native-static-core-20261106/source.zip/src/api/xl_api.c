#include "include/xl.h"

#include "src/common/xl6_xrt.h"
#include "src/runtime/xl6_list.h"
#include "src/runtime/xl6_set.h"
#include "src/runtime/xl6_dict.h"
#include "src/runtime/xl6_slot_map.h"
#include "src/runtime/xl6_slot_map_key_value.h"
#include "src/runtime/xl6_array_native_value_admission.h"
#include "lib/tcc/libtcc.h"
#include "src/api/xl_api_internal.h"
#include "src/api/xl_api_path.h"
#include "src/api/xl_foreign_error.h"
#include "src/runtime/xl6_code_owner.h"
#include "src/runtime/xl6_closure.h"
#include "src/runtime/xl6_cell.h"
#include "src/runtime/xl6_stack.h"
#include "src/runtime/xl6_sequence.h"
#include "src/runtime/xl6_tree.h"
#include "src/runtime/xl6_semaphore.h"
#include "src/runtime/xl6_semaphore_admission.h"
#include "src/runtime/xl6_sync.h"
#include "src/runtime/xl6_sync_admission.h"
#include "src/runtime/xl6_thread.h"
#include "src/runtime/xl6_thread_admission.h"
#include "src/runtime/xl6_array_admission.h"
#include "src/runtime/xl6_concurrent_queue.h"
#include "src/runtime/xl6_channel.h"
#include "src/runtime/xl6_wait_queue.h"
#include "src/runtime/xl6_value_iterator.h"
#include "src/runtime/xl6_generator.h"
#include "src/runtime/xl6_ownership_plan.h"
#include "src/runtime/xl6_ownership_domains.h"
#include "src/runtime/xl6_ownership_read.h"
#include "src/runtime/xl6_foreign_callback_scope.h"
#include "src/api/xl_module_state.h"
#include "src/api/xl_api_lock.h"
#include "src/runtime/xl6_native_handle.h"
#include "src/runtime/xl6_xlang_handler.h"
#include "src/runtime/xl6_dynamic_fields.h"
#include "src/runtime/xl6_error_value.h"
#include "src/runtime/xl6_future_payload.h"
#include "src/runtime/xl6_future_callback.h"
#include "src/runtime/xl6_future_aggregate.h"
#include "src/runtime/xl6_task.h"
#include "src/runtime/xl6_continuation_future.h"
#include "src/runtime/xl6_continuation_executor.h"
#include "src/abi/xl6_abi_dump.h"
#include "src/ast/xl6_ast_dump.h"
#include "src/sem/xl6_sem_index.h"
#include "src/sem/xl6_completion.h"
#include "src/backend/xl6_toolchain.h"
#include "src/cgen/xl6_ir_cgen_native_header.h"
#include "src/common/xl6_common.h"
#include "src/common/xl6_console.h"
#include "src/compile/xl6_compile_unit.h"
#include "src/compile/xl6_build_inputs.h"
#include "src/compile/xl6_artifact_runtime.h"
#include "src/compile/xl6_xrt_trim.h"
#include "src/diag/xl6_diag.h"
#include "src/ir/xl6_ir_dump.h"
#include "src/lexer/xl6_lexer_api.h"
#include "src/resource/xl6_win_resource.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int (*XL_XlangMainProc)(xvalue* pArg);
/* Checked artifact ABI keeps language failure separate from process status
 * and from optional diagnostics. */
typedef int (*XL_ScriptMainCheckedProc)(xvalue* pArg, int* exitCode);
typedef int (*XL_ScriptUnitCheckedProc)(void);
typedef int (*XL_CMainProc)(int argc, char** argv);
typedef int (*XL_ScriptHasErrorProc)(void);
typedef int (*XL_ScriptModuleInitProc)(xvalue* pArg);
typedef void (*XL_ScriptVoidProc)(void);

#if defined(CONFIG_TCC_STATIC) && !defined(XL_STATIC_TCC)
#define XL_STATIC_TCC 1
#endif

#if defined(XL_STATIC_TCC) && !defined(TCC_DISABLE_BUILTIN_VFS)
#define XL_STATIC_TCC_VFS 1
#endif

#ifdef XL_STATIC_TCC_VFS
#include "lib/tcc/tcc_builtin_vfs.h"
#endif

#ifndef XL_ENABLE_EXE_COMPILER
# if defined(XL_RUNTIME_ONLY_DLL)
#  define XL_ENABLE_EXE_COMPILER 0
# else
#  define XL_ENABLE_EXE_COMPILER 1
# endif
#endif

#ifdef _WIN32
#include <windows.h>
int tcc_tool_impdef(int argc, char** argv);
#else
#include <dlfcn.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#endif

typedef struct XL_StringList {
    char** items;
    size_t count;
} XL_StringList;

typedef struct XL_CSymbol {
    char* name;
    void* value;
} XL_CSymbol;

typedef struct XL_LoadedLibrary {
    char* path;
#ifdef _WIN32
    HMODULE module;
#else
    void* module;
#endif
} XL_LoadedLibrary;

struct XL_Context {
    /* Owning fields are native configuration/OS resources only. The resident
     * xl6XlangContextHandlePolicyV1Get publishes that exact leaf contract.
     * Calls own compile units/modules on their stack, not in this record.
     * An added owning language field requires revisiting that graph policy. */
    char* baseDir;
    char* workDir;
    char* tempDir;
    char* tccDllPath;
    char* tccLibPath;
    char* tccIncludePath;
    char* tccWinIncludePath;
    char* tccWinapiIncludePath;
    char* tccLibSearchPath;
    char* tccLibtcc1Path;
    int saveTemps;
    char* lastError;
    int lastExitCode;
    XL_StringList includePaths;
    XL_StringList libraryPaths;
    XL_StringList linkLibraries;
    XL_StringList resourceFiles;
    XL_CSymbol* symbols;
    size_t symbolCount;
    XL_LoadedLibrary* loadedLibraries;
    size_t loadedLibraryCount;
    unsigned int activeCalls;
    int destroyRequested;
    XL6_BuildInputs* buildInputs; /* Borrowed from an XLC context. */
    XL6_CompiledPackageSet compiledPackages;
};



#if XL_ENABLE_EXE_COMPILER
typedef enum XLC_SourceKind {
    XLC_SOURCE_NONE = 0,
    XLC_SOURCE_FILE,
    XLC_SOURCE_STRING
} XLC_SourceKind;

typedef XL_ContextOptions XLC_ContextOptions;

typedef struct XLC_Context {
    XL_Context* runtime;
    XLC_SourceKind sourceKind;
    char* sourcePath;
    char* sourceText;
    char* virtualPath;
    XL_StringList cSourceFiles;
    XL6_SourceOverlay sourceOverlay;
    XL6_CompileUnit unit;
    int unitReady;
    XL6_BuildInputs* buildInputs;
    unsigned int activeCalls;
    int destroyRequested;
} XLC_Context;

XL_API XLC_ContextOptions xlcDefaultContextOptions(void);
XL_API XLC_Context* xlcCreateContext(const XLC_ContextOptions* options);
XL_API void xlcDestroyContext(XLC_Context* ctx);
XL_API int xlcSetWorkDir(XLC_Context* ctx, const char* path);
XL_API int xlcSetTempDir(XLC_Context* ctx, const char* path);
XL_API int xlcSetSaveTemps(XLC_Context* ctx, int enabled);
XL_API int xlcSetBackend(XLC_Context* ctx, XLC_Backend backend);
XL_API int xlcAddIncludePath(XLC_Context* ctx, const char* path);
XL_API int xlcAddLibraryPath(XLC_Context* ctx, const char* path);
XL_API int xlcAddLinkLibrary(XLC_Context* ctx, const char* nameOrPath);
XL_API int xlcAddResourceFile(XLC_Context* ctx, const char* path);
XL_API int xlcAddCSourceFile(XLC_Context* ctx, const char* path);
XL_API int xlcLoadDependencyLibrary(XLC_Context* ctx, const char* path);
XL_API int xlcRegisterCFunction(XLC_Context* ctx, const char* symbolName, void* fn);
XL_API int xlcAddSourceFile(XLC_Context* ctx, const char* path);
XL_API int xlcAddSourceString(XLC_Context* ctx, const char* virtualPath, const char* source);
XL_API int xlcSetSourceOverlay(XLC_Context* ctx, const char* path, const char* source, size_t size);
XL_API int xlcRemoveSourceOverlay(XLC_Context* ctx, const char* path);
XL_API int xlcClearSourceOverlays(XLC_Context* ctx);
XL_API int xlcCompile(XLC_Context* ctx);
XL_API int xlcCheck(XLC_Context* ctx, const char* outputPath, int jsonOutput);
XL_API int xlcCheckWithSources(XLC_Context* ctx, const char* outputPath);
XL_API int xlcCheckWithIndex(XLC_Context* ctx, const char* outputPath);
XL_API int xlcCBridge(XLC_Context* ctx, const char* outputPath);
XL_API int xlcCBridgeWithEnvironment(XLC_Context* ctx, const char* outputPath, int shared);
XL_API int xlcComplete(XLC_Context* ctx,const char* queryPath,size_t byteOffset,const char* outputPath);
XL_API int xlcEmitTokens(XLC_Context* ctx, const char* outputPath, int jsonOutput);
XL_API int xlcEmitAst(XLC_Context* ctx, const char* outputPath, int jsonOutput);
XL_API int xlcEmitAstWithRanges(XLC_Context* ctx, const char* outputPath);
XL_API int xlcEmitIr(XLC_Context* ctx, const char* outputPath, int jsonOutput);
XL_API int xlcEmitLoweredIr(XLC_Context* ctx, const char* outputPath, int jsonOutput);
XL_API int xlcEmitC(XLC_Context* ctx, const char* outputPath);
XL_API int xlcEmitXlirC(XLC_Context* ctx, const char* outputPath);
XL_API int xlcEmitXlirHeader(XLC_Context* ctx, const char* outputPath, const char* guardName);
XL_API int xlcEmitDebugC(XLC_Context* ctx, const char* outputPath, const char* debugSourcePath);
XL_API int xlcEmitHeader(XLC_Context* ctx, const char* outputPath, const char* guardName);
XL_API int xlcEmitAbi(XLC_Context* ctx, const char* outputPath, int jsonOutput);
XL_API int xlcEmitExe(XLC_Context* ctx, const char* outputExe);
XL_API int xlcEmitDebugExe(XLC_Context* ctx, const char* outputExe, const char* debugSourcePath);
XL_API int xlcEmitSharedLibrary(XLC_Context* ctx, const char* outputDll);
XL_API XL_Context* xlcRuntimeContext(XLC_Context* ctx);
XL_API XL_Module* xlcRelocateModule(XLC_Context* ctx);
XL_API int xlcRun(XLC_Context* ctx, int argc, char** argv);
XL_API const char* xlcGetLastError(XLC_Context* ctx);
XL_API void xlcClearLastError(XLC_Context* ctx);
XL_API int xlcGetLastExitCode(XLC_Context* ctx);
#endif

typedef struct XL_CwdScope {
    int active;
    int locked;
    XL_Context* context;
    char* oldDir;
} XL_CwdScope;

XL_TccApi xl__tcc;
static int xl__runtimeManualCount = 0;
static int xl__runtimeContextCount = 0;

#define XL_TCC_VFS_LIBTCC1 "lib/libtcc1.a"
#define XL_TCC_VFS_MODULE_C "__xlvfs__/module.c"
#define XL_TCC_VFS_C_MODULE_C "__xlvfs__/c_module.c"
#define XL_TCC_VFS_RUNTIME_C "__xlvfs__/runtime.c"
#define XL_TCC_VFS_XRT_C "__xlvfs__/xl6_xrt_impl.c"
#define XL_TCC_VFS_COMPILER_SOURCE_ROOT "__xl_compiler"
/* 官方大型 C 库通常包含上百个独立编译单元，上限只负责阻止异常输入。 */
#ifndef XLC_MAX_C_SOURCE_FILES
#define XLC_MAX_C_SOURCE_FILES 256
#endif
#define XLC_MAX_RESOURCE_FILES 32

/* DLL API 会修改全局 TCC 状态和进程 cwd，公开入口必须串行化。 */
#ifdef _WIN32

static CRITICAL_SECTION xl__cwdLock;
static volatile LONG xl__cwdLockState = 0;

static void xlCwdEnsureLock(void)
{
    LONG state;

    state = InterlockedCompareExchange(&xl__cwdLockState, 1, 0);
    if ( state == 0 ) {
        InitializeCriticalSection(&xl__cwdLock);
        InterlockedCompareExchange(&xl__cwdLockState, 2, 1);
        return;
    }
    while ( xl__cwdLockState != 2 ) {
        Sleep(0);
    }
}

static void xlCwdLock(void)
{
    xlCwdEnsureLock();
    EnterCriticalSection(&xl__cwdLock);
}

static void xlCwdUnlock(void)
{
    LeaveCriticalSection(&xl__cwdLock);
}
#else

static pthread_mutex_t xl__cwdLock;
static pthread_once_t xl__cwdLockOnce = PTHREAD_ONCE_INIT;

static void xlCwdInitLock(void)
{
    pthread_mutexattr_t attr;

    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&xl__cwdLock, &attr);
    pthread_mutexattr_destroy(&attr);
}

static void xlCwdLock(void)
{
    pthread_once(&xl__cwdLockOnce, xlCwdInitLock);
    pthread_mutex_lock(&xl__cwdLock);
}

static void xlCwdUnlock(void)
{
    pthread_mutex_unlock(&xl__cwdLock);
}
#endif

static void xlSetError(XL_Context* ctx, const char* text)
{
    if ( ctx == NULL ) {
        return;
    }
    xrtFree(ctx->lastError);
    ctx->lastError = xlDupText(text != NULL && text[0] != '\0' ? text : "xlang api error");
}

static void xlSetError2(XL_Context* ctx, const char* prefix, const char* detail)
{
    char text[1024];

    snprintf(text, sizeof(text), "%s%s%s",
             prefix != NULL ? prefix : "xlang api error",
             detail != NULL && detail[0] != '\0' ? ": " : "",
             detail != NULL ? detail : "");
    xlSetError(ctx, text);
}

static char* xlGetCurrentDirText(XL_Context* ctx)
{
#ifdef _WIN32
    DWORD need;
    DWORD got;
    wchar_t* wide;
    char* text;

    need = GetCurrentDirectoryW(0, NULL);
    if ( need == 0 ) {
        xlSetError(ctx, "cannot query current directory");
        return NULL;
    }
    wide = (wchar_t*)xrtMalloc(((size_t)need + 1) * sizeof(wchar_t));
    if ( wide == NULL ) {
        xlSetError(ctx, "cannot allocate current directory buffer");
        return NULL;
    }
    got = GetCurrentDirectoryW(need + 1, wide);
    if ( got == 0 || got > need ) {
        xrtFree(wide);
        xlSetError(ctx, "cannot save current directory");
        return NULL;
    }
    text = xrtUtf16To8((const uint16*)wide, NULL);
    xrtFree(wide);
    if ( text == NULL ) {
        xlSetError(ctx, "cannot convert current directory");
    }
    return text;
#else
    size_t size = 1024;
    char* buffer;

    while ( size <= 65536 ) {
        buffer = (char*)xrtMalloc(size);
        if ( buffer == NULL ) {
            xlSetError(ctx, "cannot allocate current directory buffer");
            return NULL;
        }
        if ( getcwd(buffer, size) != NULL ) {
            return buffer;
        }
        xrtFree(buffer);
        if ( errno != ERANGE ) {
            xlSetError(ctx, "cannot save current directory");
            return NULL;
        }
        size *= 2;
    }
    xlSetError(ctx, "current directory path is too long");
    return NULL;
#endif
}

static char* xlPathSnapshotFromCurrentDir(XL_Context* ctx, const char* path, const char* errorText)
{
    char* baseDir;
    char* copy;

    baseDir = xlGetCurrentDirText(ctx);
    if ( baseDir == NULL ) {
        return NULL;
    }
    copy = xlPathSnapshot(baseDir, path);
    xrtFree(baseDir);
    if ( copy == NULL ) {
        xlSetError(ctx, errorText != NULL ? errorText : "cannot snapshot path");
    }
    return copy;
}

static char* xlLinkValueSnapshotFromCurrentDir(XL_Context* ctx, const char* value, const char* errorText)
{
    char* copy;

    if ( !xlTextLooksLikePath(value) ) {
        copy = xlDupText(value);
        if ( copy == NULL ) {
            xlSetError(ctx, errorText != NULL ? errorText : "cannot copy link library");
        }
        return copy;
    }
    return xlPathSnapshotFromCurrentDir(ctx, value, errorText);
}

static void xlStringListFree(XL_StringList* list)
{
    size_t i;

    if ( list == NULL ) {
        return;
    }
    for ( i = 0; i < list->count; ++i ) {
        xrtFree(list->items[i]);
    }
    xrtFree(list->items);
    memset(list, 0, sizeof(*list));
}

static int xlStringListAppend(XL_StringList* list, const char* text)
{
    char** newItems;
    char* copy;

    if ( list == NULL || text == NULL || text[0] == '\0' ) {
        return 0;
    }
    copy = xlDupText(text);
    if ( copy == NULL ) {
        return 0;
    }
    newItems = (char**)xrtRealloc(list->items, (list->count + 1) * sizeof(char*));
    if ( newItems == NULL ) {
        xrtFree(copy);
        return 0;
    }
    list->items = newItems;
    list->items[list->count] = copy;
    list->count += 1;
    return 1;
}

static int xlContextAddSymbol(XL_Context* ctx, const char* name, void* value)
{
    XL_CSymbol* newItems;
    char* nameCopy;
    size_t i;

    if ( ctx == NULL || name == NULL || name[0] == '\0' || value == NULL ) {
        return 0;
    }
    for ( i = 0; i < ctx->symbolCount; ++i ) {
        if ( strcmp(ctx->symbols[i].name, name) == 0 ) {
            ctx->symbols[i].value = value;
            return 1;
        }
    }
    nameCopy = xlDupText(name);
    if ( nameCopy == NULL ) {
        return 0;
    }
    newItems = (XL_CSymbol*)xrtRealloc(ctx->symbols, (ctx->symbolCount + 1) * sizeof(XL_CSymbol));
    if ( newItems == NULL ) {
        xrtFree(nameCopy);
        return 0;
    }
    ctx->symbols = newItems;
    ctx->symbols[ctx->symbolCount].name = nameCopy;
    ctx->symbols[ctx->symbolCount].value = value;
    ctx->symbolCount += 1;
    return 1;
}

static void xlFreeSymbols(XL_Context* ctx)
{
    size_t i;

    if ( ctx == NULL ) {
        return;
    }
    for ( i = 0; i < ctx->symbolCount; ++i ) {
        xrtFree(ctx->symbols[i].name);
    }
    xrtFree(ctx->symbols);
    ctx->symbols = NULL;
    ctx->symbolCount = 0;
}

static void xlCloseLoadedLibrary(XL_LoadedLibrary* item)
{
    if ( item == NULL ) {
        return;
    }
#ifdef _WIN32
    if ( item->module != NULL ) {
        FreeLibrary(item->module);
    }
#else
    if ( item->module != NULL ) {
        dlclose(item->module);
    }
#endif
    xrtFree(item->path);
    memset(item, 0, sizeof(*item));
}

static void xlLoadedLibrariesFree(XL_Context* ctx)
{
    size_t i;

    if ( ctx == NULL ) {
        return;
    }
    for ( i = 0; i < ctx->loadedLibraryCount; ++i ) {
        xlCloseLoadedLibrary(&ctx->loadedLibraries[i]);
    }
    xrtFree(ctx->loadedLibraries);
    ctx->loadedLibraries = NULL;
    ctx->loadedLibraryCount = 0;
}

static int xlContextAddLoadedLibrary(XL_Context* ctx, const char* path, XL_LoadedLibrary* loaded)
{
    XL_LoadedLibrary* newItems;
    XL_LoadedLibrary* item;
    char* pathCopy;

    if ( ctx == NULL || path == NULL || path[0] == '\0' || loaded == NULL || loaded->module == NULL ) {
        return 0;
    }
    pathCopy = xlDupText(path);
    if ( pathCopy == NULL ) {
        return 0;
    }
    newItems = (XL_LoadedLibrary*)xrtRealloc(ctx->loadedLibraries, (ctx->loadedLibraryCount + 1) * sizeof(XL_LoadedLibrary));
    if ( newItems == NULL ) {
        xrtFree(pathCopy);
        return 0;
    }
    ctx->loadedLibraries = newItems;
    item = &ctx->loadedLibraries[ctx->loadedLibraryCount];
    memset(item, 0, sizeof(*item));
    item->path = pathCopy;
    item->module = loaded->module;
    loaded->module = NULL;
    ctx->loadedLibraryCount += 1;
    return 1;
}

static int xlEnterWorkDir(XL_Context* ctx, XL_CwdScope* scope)
{
    char* workDir;

    if ( scope == NULL ) {
        return 0;
    }
    memset(scope, 0, sizeof(*scope));
    if ( ctx == NULL || ctx->workDir == NULL || ctx->workDir[0] == '\0' ) {
        return 1;
    }
    workDir = xlDupText(ctx->workDir);
    if ( workDir == NULL ) {
        xlSetError(ctx, "cannot allocate work dir snapshot");
        return 0;
    }
    /*
        进程 cwd 是全局状态。脚本执行期可以释放 API 锁以避免嵌套运行死锁，
        但只要进入了 workDir，就必须用独立 cwd 锁保护到恢复 cwd 为止。
        等待 cwd 锁时不能持有 API 锁，否则执行线程回收时会反向等待 API 锁。
    */
    xlApiUnlock();
    xlCwdLock();
    xlApiLock();
    scope->locked = 1;
    scope->context = ctx;
    scope->oldDir = xrtPathCwd();
    if ( scope->oldDir == NULL || !xrtPathSetCwd(workDir) ) {
        xrtFree(scope->oldDir);
        scope->oldDir = NULL;
        xlSetError2(ctx, "cannot enter work dir", workDir);
        xrtFree(workDir);
        xlCwdUnlock();
        scope->locked = 0;
        return 0;
    }
    xrtFree(workDir);
    scope->active = 1;
    return 1;
}

static void xlModuleLoadedLibrariesFree(XL_Module* module)
{
    size_t i;

    if ( module == NULL ) {
        return;
    }
    for ( i = 0; i < module->loadedLibraryCount; ++i ) {
        xlCloseLoadedLibrary(&module->loadedLibraries[i]);
    }
    xrtFree(module->loadedLibraries);
    module->loadedLibraries = NULL;
    module->loadedLibraryCount = 0;
}

/*
    已重定位模块可能直接调用上下文加载的动态库。模块必须单独保留加载引用，
    否则先销毁上下文会让模块中的函数地址悬空。
*/
static int xlModuleRetainLoadedLibraries(XL_Module* module, XL_Context* ctx)
{
    size_t i;

    if ( module == NULL || ctx == NULL || ctx->loadedLibraryCount == 0 ) {
        return 1;
    }
    module->loadedLibraries = (XL_LoadedLibrary*)xrtCalloc(
        ctx->loadedLibraryCount,
        sizeof(XL_LoadedLibrary));
    if ( module->loadedLibraries == NULL ) {
        xlSetError(ctx, "cannot retain module dependency libraries");
        return 0;
    }
    for ( i = 0; i < ctx->loadedLibraryCount; ++i ) {
        XL_LoadedLibrary* dst = &module->loadedLibraries[i];
        const char* path = ctx->loadedLibraries[i].path;

        dst->path = xlDupText(path);
        if ( dst->path == NULL ) {
            xlSetError(ctx, "cannot retain module dependency path");
            xlModuleLoadedLibrariesFree(module);
            return 0;
        }
        module->loadedLibraryCount += 1;
#ifdef _WIN32
        {
            uint16* pathW = xrtUtf8To16(path, NULL);
            if ( pathW != NULL ) {
                dst->module = LoadLibraryW((LPCWSTR)pathW);
                xrtFree(pathW);
            }
        }
#else
        dst->module = dlopen(path, RTLD_NOW | RTLD_GLOBAL);
#endif
        if ( dst->module == NULL ) {
            xlSetError2(ctx, "cannot retain module dependency library", path);
            xlModuleLoadedLibrariesFree(module);
            return 0;
        }
    }
    return 1;
}

static void xlLeaveWorkDir(XL_CwdScope* scope)
{
    if ( scope == NULL ) {
        return;
    }
    if ( scope->active ) {
        if ( scope->oldDir != NULL ) {
            if ( !xrtPathSetCwd(scope->oldDir) && scope->context != NULL ) {
                xlSetError2(
                    scope->context,
                    "cannot restore work dir",
                    scope->oldDir
                );
            }
            xrtFree(scope->oldDir);
        }
    }
    if ( scope->locked ) {
        xlCwdUnlock();
    }
    memset(scope, 0, sizeof(*scope));
}

static void xlTccError(void* opaque, const char* msg)
{
    XL_Context* ctx = (XL_Context*)opaque;

    if ( ctx != NULL && msg != NULL && msg[0] != '\0' ) {
        xlSetError2(ctx, "tcc", msg);
    }
}

#ifndef XL_STATIC_TCC
static void* xlLoadProc(XL_TccApi* api, const char* name)
{
#ifdef _WIN32
    return api != NULL && api->module != NULL ? (void*)GetProcAddress(api->module, name) : NULL;
#else
    return api != NULL && api->module != NULL ? dlsym(api->module, name) : NULL;
#endif
}
#endif

static void xlUnloadTccApi(XL_TccApi* api)
{
    if ( api == NULL ) {
        return;
    }
#ifndef XL_STATIC_TCC
#ifdef _WIN32
    if ( api->module != NULL ) {
        FreeLibrary(api->module);
    }
#else
    if ( api->module != NULL ) {
        dlclose(api->module);
    }
#endif
#endif
    xrtFree(api->path);
    memset(api, 0, sizeof(*api));
}

static const char* xlEnvPathOrNull(const char* name)
{
    const char* value;

    if ( name == NULL || name[0] == '\0' ) {
        return NULL;
    }
    value = getenv(name);
    return value != NULL && value[0] != '\0' ? value : NULL;
}

static const char* xlEnvPathOrDefault(const char* name, const char* fallback)
{
    const char* envPath = xlEnvPathOrNull(name);

    if ( envPath == NULL ) {
        return fallback;
    }
#ifdef XL_STATIC_TCC_VFS
    /* 静态内嵌 TCC 时，环境变量只覆盖真实存在的外部资源；否则回到 VFS 虚拟路径。 */
    return xrtFileExists((char*)envPath) ? envPath : fallback;
#else
    return envPath;
#endif
}

static const char* xlDefaultTccRootPath(void)
{
#ifdef XL_STATIC_TCC_VFS
    return XL6_TCC_ROOT_PATH;
#else
    return xlEnvPathOrDefault("XL6_TCC_ROOT", XL6_TCC_ROOT_PATH);
#endif
}

static const char* xlDefaultTccIncludePath(void)
{
#ifdef XL_STATIC_TCC_VFS
    return XL6_TCC_INCLUDE_PATH;
#else
    return xlEnvPathOrDefault("XL6_TCC_INCLUDE", XL6_TCC_INCLUDE_PATH);
#endif
}

static const char* xlDefaultTccWinIncludePath(void)
{
#ifdef XL_STATIC_TCC_VFS
    return XL6_TCC_WIN_INCLUDE_PATH;
#else
    return xlEnvPathOrDefault("XL6_TCC_WIN_INCLUDE", XL6_TCC_WIN_INCLUDE_PATH);
#endif
}

static const char* xlDefaultTccWinapiIncludePath(void)
{
#ifdef XL_STATIC_TCC_VFS
    return XL6_TCC_WINAPI_INCLUDE_PATH;
#else
    return xlEnvPathOrDefault("XL6_TCC_WINAPI_INCLUDE", XL6_TCC_WINAPI_INCLUDE_PATH);
#endif
}

static const char* xlDefaultTccLibPath(void)
{
#ifdef XL_STATIC_TCC_VFS
    return XL6_TCC_LIB_PATH;
#else
    return xlEnvPathOrDefault("XL6_TCC_LIB", XL6_TCC_LIB_PATH);
#endif
}

static const char* xlDefaultTccLibtcc1Path(void)
{
#ifdef XL_STATIC_TCC_VFS
    return XL6_TCC_LIBTCC1_PATH;
#else
    return xlEnvPathOrDefault("XL6_TCC_LIBTCC1", XL6_TCC_LIBTCC1_PATH);
#endif
}

static void xlAddDefaultTccRuntime(TCCState* s, XL_Context* ctx, int outputType)
{
    const char* path;

    if ( s == NULL ) {
        return;
    }

#ifdef XL_STATIC_TCC_VFS
    if ( outputType == TCC_OUTPUT_MEMORY ) {
        (void)xl__tcc.tcc_add_file(s, XL_TCC_VFS_LIBTCC1);
        return;
    }
#else
    (void)outputType;
#endif

    path = ctx != NULL && ctx->tccLibtcc1Path != NULL && ctx->tccLibtcc1Path[0] != '\0' ?
           ctx->tccLibtcc1Path :
           xlDefaultTccLibtcc1Path();
    if ( xl6BuildInputExists(path) ) {
        (void)xl__tcc.tcc_add_file(s, path);
        return;
    }
#ifdef XL_STATIC_TCC_VFS
    (void)xl__tcc.tcc_add_file(s, XL_TCC_VFS_LIBTCC1);
#endif
}

#ifdef XL_STATIC_TCC
static int xlLoadStaticTcc(XL_Context* ctx)
{
    XL_TccApi loaded;

    if ( xl__tcc.ready ) {
        return 1;
    }

    memset(&loaded, 0, sizeof(loaded));
    loaded.tcc_new = tcc_new;
    loaded.tcc_delete = tcc_delete;
    loaded.tcc_set_lib_path = tcc_set_lib_path;
    loaded.tcc_set_error_func = tcc_set_error_func;
    loaded.tcc_set_options = tcc_set_options;
    loaded.tcc_native_link_features = tcc_native_link_features;
    loaded.tcc_add_include_path = tcc_add_include_path;
    loaded.tcc_add_sysinclude_path = tcc_add_sysinclude_path;
    loaded.tcc_define_symbol = tcc_define_symbol;
    loaded.tcc_undefine_symbol = tcc_undefine_symbol;
    loaded.tcc_add_library_path = tcc_add_library_path;
    loaded.tcc_add_library = tcc_add_library;
    loaded.tcc_add_file = tcc_add_file;
    loaded.tcc_add_symbol = tcc_add_symbol;
    loaded.tcc_set_output_type = tcc_set_output_type;
    loaded.tcc_compile_string = tcc_compile_string;
    loaded.tcc_output_file = tcc_output_file;
    loaded.tcc_run = tcc_run;
    loaded.tcc_relocate = tcc_relocate;
    loaded.tcc_get_symbol = tcc_get_symbol;
    loaded.tcc_list_symbols = tcc_list_symbols;
    loaded.tcc_set_backtrace_func = tcc_set_backtrace_func;
#ifdef XL_STATIC_TCC_VFS
    loaded.tcc_vfs_open = tcc_vfs_open;
    loaded.tcc_vfs_close = tcc_vfs_close;
    loaded.tcc_vfs_read = tcc_vfs_read;
    loaded.tcc_vfs_lseek = tcc_vfs_lseek;
    loaded.tcc_vfs_fopen = tcc_vfs_fopen;
    loaded.tcc_vfs_fclose = tcc_vfs_fclose;
    loaded.tcc_vfs_mount_memory = tcc_vfs_mount_memory;
    loaded.tcc_vfs_clear_dynamic = tcc_vfs_clear_dynamic;
#endif
    loaded.path = xlDupText("<static libtcc>");
    if ( loaded.path == NULL ) {
        xlSetError(ctx, "cannot remember static libtcc path");
        return 0;
    }
    loaded.ready = 1;
    xl__tcc = loaded;
    return 1;
}

static int xlEnsureTcc(XL_Context* ctx)
{
    return xlLoadStaticTcc(ctx);
}
#else
static int xlLoadTccFromPath(XL_Context* ctx, const char* path)
{
    XL_TccApi* api;
    XL_TccApi loaded;

    api = &xl__tcc;
    if ( api->ready ) {
        return 1;
    }
    if ( path == NULL || path[0] == '\0' ) {
        return 0;
    }
    memset(&loaded, 0, sizeof(loaded));
#ifdef _WIN32
    {
        uint16* pathW = xrtUtf8To16(path, NULL);
        if ( pathW != NULL ) {
            loaded.module = LoadLibraryW((LPCWSTR)pathW);
            xrtFree(pathW);
        }
    }
#else
    loaded.module = dlopen(path, RTLD_NOW | RTLD_LOCAL);
#endif
    if ( loaded.module == NULL ) {
        return 0;
    }

    loaded.tcc_new = (XL_TccNewProc)xlLoadProc(&loaded, "tcc_new");
    loaded.tcc_delete = (XL_TccDeleteProc)xlLoadProc(&loaded, "tcc_delete");
    loaded.tcc_set_lib_path = (XL_TccSetLibPathProc)xlLoadProc(&loaded, "tcc_set_lib_path");
    loaded.tcc_set_error_func = (XL_TccSetErrorFuncProc)xlLoadProc(&loaded, "tcc_set_error_func");
    loaded.tcc_set_options = (XL_TccSetOptionsProc)xlLoadProc(&loaded, "tcc_set_options");
    loaded.tcc_native_link_features = (XL_TccNativeLinkFeaturesProc)xlLoadProc(&loaded, "tcc_native_link_features");
    loaded.tcc_add_include_path = (XL_TccAddIncludePathProc)xlLoadProc(&loaded, "tcc_add_include_path");
    loaded.tcc_add_sysinclude_path = (XL_TccAddSysIncludePathProc)xlLoadProc(&loaded, "tcc_add_sysinclude_path");
    loaded.tcc_define_symbol = (XL_TccDefineSymbolProc)xlLoadProc(&loaded, "tcc_define_symbol");
    loaded.tcc_undefine_symbol = (XL_TccUndefineSymbolProc)xlLoadProc(&loaded, "tcc_undefine_symbol");
    loaded.tcc_add_library_path = (XL_TccAddLibraryPathProc)xlLoadProc(&loaded, "tcc_add_library_path");
    loaded.tcc_add_library = (XL_TccAddLibraryProc)xlLoadProc(&loaded, "tcc_add_library");
    loaded.tcc_add_file = (XL_TccAddFileProc)xlLoadProc(&loaded, "tcc_add_file");
    loaded.tcc_add_symbol = (XL_TccAddSymbolProc)xlLoadProc(&loaded, "tcc_add_symbol");
    loaded.tcc_set_output_type = (XL_TccSetOutputTypeProc)xlLoadProc(&loaded, "tcc_set_output_type");
    loaded.tcc_compile_string = (XL_TccCompileStringProc)xlLoadProc(&loaded, "tcc_compile_string");
    loaded.tcc_output_file = (XL_TccOutputFileProc)xlLoadProc(&loaded, "tcc_output_file");
    loaded.tcc_run = (XL_TccRunProc)xlLoadProc(&loaded, "tcc_run");
    loaded.tcc_relocate = (XL_TccRelocateProc)xlLoadProc(&loaded, "tcc_relocate");
    loaded.tcc_get_symbol = (XL_TccGetSymbolProc)xlLoadProc(&loaded, "tcc_get_symbol");
    loaded.tcc_list_symbols = (XL_TccListSymbolsProc)xlLoadProc(&loaded, "tcc_list_symbols");
    loaded.tcc_set_backtrace_func = (XL_TccSetBacktraceFuncProc)xlLoadProc(&loaded, "tcc_set_backtrace_func");
    loaded.tcc_vfs_open = (XL_TccVfsOpenProc)xlLoadProc(&loaded, "tcc_vfs_open");
    loaded.tcc_vfs_close = (XL_TccVfsCloseProc)xlLoadProc(&loaded, "tcc_vfs_close");
    loaded.tcc_vfs_read = (XL_TccVfsReadProc)xlLoadProc(&loaded, "tcc_vfs_read");
    loaded.tcc_vfs_lseek = (XL_TccVfsLseekProc)xlLoadProc(&loaded, "tcc_vfs_lseek");
    loaded.tcc_vfs_fopen = (XL_TccVfsFopenProc)xlLoadProc(&loaded, "tcc_vfs_fopen");
    loaded.tcc_vfs_fclose = (XL_TccVfsFcloseProc)xlLoadProc(&loaded, "tcc_vfs_fclose");
    loaded.tcc_vfs_mount_memory = (XL_TccVfsMountMemoryProc)xlLoadProc(&loaded, "tcc_vfs_mount_memory");
    loaded.tcc_vfs_clear_dynamic = (XL_TccVfsClearDynamicProc)xlLoadProc(&loaded, "tcc_vfs_clear_dynamic");

    if ( loaded.tcc_new == NULL || loaded.tcc_delete == NULL || loaded.tcc_set_lib_path == NULL ||
         loaded.tcc_set_error_func == NULL || loaded.tcc_add_include_path == NULL ||
         loaded.tcc_set_options == NULL || loaded.tcc_add_library_path == NULL || loaded.tcc_add_library == NULL ||
         loaded.tcc_add_file == NULL || loaded.tcc_add_symbol == NULL ||
         loaded.tcc_set_output_type == NULL || loaded.tcc_compile_string == NULL ||
         loaded.tcc_relocate == NULL || loaded.tcc_get_symbol == NULL ) {
        xlSetError2(ctx, "invalid libtcc dll", path);
        xlUnloadTccApi(&loaded);
        return 0;
    }
#if XL_ENABLE_EXE_COMPILER
    if ( loaded.tcc_output_file == NULL ) {
        xlSetError2(ctx, "invalid compiler-capable libtcc dll", path);
        xlUnloadTccApi(&loaded);
        return 0;
    }
#endif
    loaded.path = xlDupText(path);
    if ( loaded.path == NULL ) {
        xlSetError(ctx, "cannot remember libtcc path");
        xlUnloadTccApi(&loaded);
        return 0;
    }
    loaded.ready = 1;
    *api = loaded;
    return 1;
}

static int xlLoadTccFromBasePath(XL_Context* ctx, const char* path)
{
    char* snapshot;
    int ok;

    if ( path == NULL || path[0] == '\0' ) {
        return 0;
    }
    snapshot = xlPathSnapshot(ctx != NULL ? ctx->baseDir : NULL, path);
    if ( snapshot == NULL ) {
        xlSetError(ctx, "cannot snapshot libtcc path");
        return 0;
    }
    ok = xlLoadTccFromPath(ctx, snapshot);
    xrtFree(snapshot);
    return ok;
}

static int xlEnsureTcc(XL_Context* ctx)
{
    const char* path;
    const char* envPath;

    if ( xl__tcc.ready ) {
        return 1;
    }
    path = ctx != NULL && ctx->tccDllPath != NULL && ctx->tccDllPath[0] != '\0' ? ctx->tccDllPath : NULL;
    if ( xlLoadTccFromPath(ctx, path) ) {
        return 1;
    }
    envPath = xlEnvPathOrNull("XL6_TCC_DLL");
    if ( xlLoadTccFromBasePath(ctx, envPath) ) {
        return 1;
    }
#ifdef _WIN32
    if ( xlLoadTccFromPath(ctx, "libtcc.dll") ) {
        return 1;
    }
    if ( xlLoadTccFromBasePath(ctx, "release\\libtcc.dll") ) {
        return 1;
    }
#else
    if ( xlLoadTccFromPath(ctx, "libtcc.so") ) {
        return 1;
    }
    if ( xlLoadTccFromBasePath(ctx, "release/libtcc.so") ) {
        return 1;
    }
#endif
    if ( xlLoadTccFromBasePath(ctx, XL6_TCC_DLL_PATH) ) {
        return 1;
    }
#ifdef _WIN32
    xlSetError(ctx, "cannot load libtcc.dll");
#else
    xlSetError(ctx, "cannot load libtcc.so");
#endif
    return 0;
}
#endif

static int xlAddContextSymbols(XL_Context* ctx, TCCState* s)
{
    size_t i;

    if ( !xlApiAddDefaultRuntimeSymbols(s) ) {
        xlSetError(ctx, "cannot add XRT symbols to TCC state");
        return 0;
    }
    for ( i = 0; ctx != NULL && i < ctx->symbolCount; ++i ) {
        if ( !xlApiAddTccSymbol(s, ctx->symbols[i].name, ctx->symbols[i].value) ) {
            xlSetError2(ctx, "cannot add C function symbol", ctx->symbols[i].name);
            return 0;
        }
    }
    for (size_t p = 0; ctx != NULL && p < ctx->compiledPackages.count; ++p)
        for (size_t e = 0; e < ctx->compiledPackages.items[p].entryCount; ++e) {
            const XL_PackageEntry* entry = &ctx->compiledPackages.items[p].entries[e];
            if (!xlApiAddTccSymbol(s, entry->name, entry->address)) {
                xlSetError2(ctx, "cannot bind compiled package entry", entry->name); return 0;
            }
        }
    return 1;
}

typedef int (*XL_CEnvVisit)(void*, const char*, const char*, const char*, int);
_Static_assert(XL6_NATIVE_LINK_FUNCTION_SECTIONS == TCC_NATIVE_LINK_FUNCTION_SECTIONS &&
    XL6_NATIVE_LINK_DATA_SECTIONS == TCC_NATIVE_LINK_DATA_SECTIONS &&
    XL6_NATIVE_LINK_GC_SECTIONS == TCC_NATIVE_LINK_GC_SECTIONS &&
    XL6_NATIVE_LINK_PRINT_GC_SECTIONS == TCC_NATIVE_LINK_PRINT_GC_SECTIONS,
    "package native link requirements must match the provider capability ABI");
static int xlVisitPackageNativeLink(const XL6_CompileUnit* unit,
    XL_CEnvVisit visit, void* user)
{
    static const struct { unsigned int flag; const char* option; } options[] = {
        {XL6_NATIVE_LINK_FUNCTION_SECTIONS, "-ffunction-sections"},
        {XL6_NATIVE_LINK_DATA_SECTIONS, "-fdata-sections"},
        {XL6_NATIVE_LINK_GC_SECTIONS, "-Wl,--gc-sections"},
        {XL6_NATIVE_LINK_PRINT_GC_SECTIONS, "-Wl,--print-gc-sections"}
    };
    unsigned int flags = unit ? unit->importDeps.nativeLinkFlags : 0;
    if (flags && !visit(user, "define", "XL6_NATIVE_LINK_SCHEMA", "1", 1)) return 0;
    for (size_t i = 0; i < sizeof(options) / sizeof(options[0]); ++i)
        if ((flags & options[i].flag) && !visit(user, "options", options[i].option, NULL, 1))
            return 0;
    return 1;
}
static int xlTccCEnvVisit(void* user, const char* kind, const char* text, const char* value, int required)
{
    TCCState* s = (TCCState*)user;
    if (!strcmp(kind, "options")) return xl__tcc.tcc_set_options(s, text) >= 0;
    if (!strcmp(kind, "define")) { xl__tcc.tcc_define_symbol(s, text, value); return 1; }
    if (!strcmp(kind, "include")) { int result = xl__tcc.tcc_add_include_path(s, text); return !required || result == 0; }
    return 0;
}

#include "src/api/xl_module_native_abi.inc"

static int xlVisitDefaultProjectToolchainPaths(XL_CEnvVisit visit, void* user, TCCState* s)
{
    char root[512];
    char path[1024];
    char moduleDir[512];

    /* A default context, including one constructed by an embedded xlang
     * host, must find its own declaration SDK without a caller-supplied -I.
     * This root belongs to the loaded compiler module (or its executable),
     * never the context work directory or an arbitrary project include path. */
    if (xlGetModuleDir(moduleDir,sizeof(moduleDir)) &&
        xlJoinPathBuffer(path,sizeof(path),moduleDir,"include")) {
        if(!visit(user,"include",path,NULL,1))return 0;
    }

    if ( !xlGetProjectRoot(root, sizeof(root)) ) {
        return 1;
    }
    if (!visit(user, "include", root, NULL, 0)) return 0;
    if ( xlJoinPathBuffer(path, sizeof(path), root, "src") ) {
        if (!visit(user, "include", path, NULL, 0)) return 0;
    }
    if ( xlJoinPathBuffer(path, sizeof(path), root, "lib/xrt") ) {
        if (!visit(user, "include", path, NULL, 0)) return 0;
    }
    if ( xlJoinPathBuffer(path, sizeof(path), root, "lib/xruntime") ) {
        if (!visit(user, "include", path, NULL, 0)) return 0;
    }
#ifdef _WIN32
    if ( xlJoinPathBuffer(path, sizeof(path), root, "release\\tcc\\include_win") ) {
        if (!visit(user, "include", path, NULL, 0)) return 0;
    }
#endif
    if ( xlJoinPathBuffer(path, sizeof(path), root, XL6_TCC_INCLUDE_PATH) ) {
        if (!visit(user, "include", path, NULL, 0)) return 0;
    }
    if ( xlJoinPathBuffer(path, sizeof(path), root, XL6_TCC_WIN_INCLUDE_PATH) ) {
        if (!visit(user, "include", path, NULL, 0)) return 0;
    }
    if ( xlJoinPathBuffer(path, sizeof(path), root, XL6_TCC_WINAPI_INCLUDE_PATH) ) {
        if (!visit(user, "include", path, NULL, 0)) return 0;
    }
    if ( s != NULL && xlJoinPathBuffer(path, sizeof(path), root, XL6_TCC_LIB_PATH) ) {
        (void)xl__tcc.tcc_add_library_path(s, path);
    }
    return 1;
}

static void xlAddDefaultTccLinkLibraries(TCCState* s);

static int xlVisitDefaultCEnvironment(XL_Context* ctx, XL_CEnvVisit visit, void* user, TCCState* libraryState)
{
    if (!visit(user, "options", "-std=c11 -D_CRT_SECURE_NO_WARNINGS", NULL, 0)) return 0;
#if !XL_ENABLE_EXE_COMPILER
    if (!visit(user, "options", "-DXL_RUNTIME_ONLY_DLL", NULL, 0)) return 0;
#endif
#ifdef XL_STATIC_EMBED
    if (!visit(user, "options", "-DXL_STATIC_EMBED", NULL, 0)) return 0;
#endif
    if (!visit(user, "include", ctx != NULL && ctx->baseDir != NULL ? ctx->baseDir : ".", NULL, 0)) return 0;
    if (!xlVisitDefaultProjectToolchainPaths(visit, user, libraryState)) return 0;
    if (!visit(user, "include", "src", NULL, 0)) return 0;
    if (!visit(user, "include", "lib/xrt", NULL, 0)) return 0;
    if (!visit(user, "include", "lib/xruntime", NULL, 0)) return 0;
    if (!visit(user, "include", ctx != NULL && ctx->tccIncludePath != NULL ? ctx->tccIncludePath : xlDefaultTccIncludePath(), NULL, 0)) return 0;
    if (!visit(user, "include", ctx != NULL && ctx->tccWinIncludePath != NULL ? ctx->tccWinIncludePath : xlDefaultTccWinIncludePath(), NULL, 0)) return 0;
    if (!visit(user, "include", ctx != NULL && ctx->tccWinapiIncludePath != NULL ? ctx->tccWinapiIncludePath : xlDefaultTccWinapiIncludePath(), NULL, 0)) return 0;
    return 1;
}
static int xlVisitContextCIncludes(XL_Context* ctx, XL_CEnvVisit visit, void* user)
{
    size_t i;
    for (i = 0; ctx != NULL && i < ctx->includePaths.count; ++i) {
        if (!visit(user, "include", ctx->includePaths.items[i], NULL, 1)) {
            xlSetError2(ctx, "cannot add include path", ctx->includePaths.items[i]); return 0;
        }
    }
    return 1;
}
static int xlVisitCOutputKind(int outputType, XL_CEnvVisit visit, void* user)
{
    return outputType != TCC_OUTPUT_DLL || visit(user, "define", "XL6_BUILD_SHARED", "1", 0);
}

/* TCC expands {B} include paths during output selection, so choose its
 * root before that operation as well as in the public environment helpers. */
static const char* xlTccRootForOutput(const XL_Context* ctx, int outputType)
{
#ifdef XL_STATIC_TCC_VFS
    if (outputType == TCC_OUTPUT_MEMORY) return XL6_TCC_ROOT_PATH;
#endif
    (void)outputType;
    return ctx != NULL && ctx->tccLibPath != NULL && ctx->tccLibPath[0] != '\0' ?
           ctx->tccLibPath : xlDefaultTccRootPath();
}

static int xlConfigureTccStateEnvironment(XL_Context* ctx, TCCState* s, int outputType)
{
    size_t i;
    const char* tccLibPath;
    const char* tccLibSearchPath;

    if ( s == NULL ) {
        xlSetError(ctx, "TCC state is empty");
        return 0;
    }

    tccLibPath = xlTccRootForOutput(ctx, outputType);
    tccLibSearchPath = ctx != NULL && ctx->tccLibSearchPath != NULL ? ctx->tccLibSearchPath : xlDefaultTccLibPath();
#ifdef XL_STATIC_TCC_VFS
    if ( outputType == TCC_OUTPUT_MEMORY ) {
        tccLibSearchPath = XL6_TCC_LIB_PATH;
    }
#endif
    xl__tcc.tcc_set_lib_path(s, tccLibPath);
    if (!xlVisitDefaultCEnvironment(ctx, xlTccCEnvVisit, s, s)) return 0;
    /* A dynamically loaded compiler VFS owns public declarations too. Add
     * its real SDK root before compiling the generated module, rather than
     * waiting until compiler implementation objects are appended. */
    if (xl__tcc.tcc_vfs_open != NULL) {
        if (xl__tcc.tcc_add_include_path(s, "include") != 0) {
            xlSetError(ctx, "cannot configure embedded compiler SDK include path");
            return 0;
        }
    }
    (void)xl__tcc.tcc_add_library_path(s, tccLibSearchPath);
    xlAddDefaultTccRuntime(s, ctx, outputType);
    xlAddDefaultTccLinkLibraries(s);
    if (!xlVisitContextCIncludes(ctx, xlTccCEnvVisit, s)) return 0;
    for ( i = 0; ctx != NULL && i < ctx->libraryPaths.count; ++i ) {
        if ( xl__tcc.tcc_add_library_path(s, ctx->libraryPaths.items[i]) != 0 ) {
            xlSetError2(ctx, "cannot add library path", ctx->libraryPaths.items[i]);
            return 0;
        }
    }
#ifndef XL_STATIC_TCC_VFS
    /* Dynamic providers can supply the standard support library from their
       VFS even when the default physical distribution is absent. Keep every
       explicit library path ahead of this fallback. */
    if (xl__tcc.tcc_vfs_open != NULL &&
        xl__tcc.tcc_add_library_path(s, "lib") != 0) {
        xlSetError(ctx, "cannot configure embedded compiler support library path");
        return 0;
    }
#endif
    return 1;
}

static TCCState* xlCreateTccState(XL_Context* ctx, int outputType)
{
    TCCState* s;

    if ( !xlEnsureTcc(ctx) ) {
        return NULL;
    }
    s = xl__tcc.tcc_new();
    if ( s == NULL ) {
        xlSetError(ctx, "cannot create TCC state");
        return NULL;
    }
    xl__tcc.tcc_set_error_func(s, ctx, xlTccError);
    xl__tcc.tcc_set_lib_path(s, xlTccRootForOutput(ctx, outputType));
    (void)xlVisitCOutputKind(outputType, xlTccCEnvVisit, s);
    if ( xl__tcc.tcc_set_output_type(s, outputType) != 0 ) {
        xlSetError(ctx, "cannot set TCC output type");
        xl__tcc.tcc_delete(s);
        return NULL;
    }
    if ( !xlConfigureTccStateEnvironment(ctx, s, outputType) ) {
        xl__tcc.tcc_delete(s);
        return NULL;
    }
    if ( outputType == TCC_OUTPUT_MEMORY && !xlAddContextSymbols(ctx, s) ) {
        xl__tcc.tcc_delete(s);
        return NULL;
    }
    return s;
}

/* A failed internal stage may be unable to allocate a diagnostic (or may
 * have an incomplete diagnostic path). Preserve an existing source diagnostic
 * verbatim, otherwise retain the exact caller stage instead of collapsing
 * verification/emission failures into an unlocatable "compile failed". */
static void xlSetCompileStageError(XL_Context* ctx, const XL6_CompileUnit* unit,
                                   const char* failedStage)
{
    char text[1200];
    const char* path;
    const char* phase;

    if ( unit != NULL && unit->parse.diags.count > 0 ) {
        const XL6_Diag* diag = &unit->parse.diags.items[0];
        path = diag->file ? diag->file : (unit->path != NULL ? unit->path : "<memory>");
        phase = unit->phase != NULL ? unit->phase : failedStage;
        snprintf(text,
                 sizeof(text),
                 "%s:%d:%d: [%s] %s",
                 path,
                 diag->line,
                 diag->column,
                 phase,
                 diag->message != NULL ? diag->message : "compile error");
        xlSetError(ctx, text);
    } else {
        path = unit != NULL && unit->path != NULL ? unit->path : "<memory>";
        snprintf(text, sizeof(text), "%s: [%s] compiler stage failed without a diagnostic",
                 path, failedStage != NULL ? failedStage : "compile");
        xlSetError(ctx, text);
    }
}
static void xlSetCompileDiagError(XL_Context* ctx, const XL6_CompileUnit* unit)
{
    xlSetCompileStageError(ctx, unit, unit != NULL && unit->phase != NULL ? unit->phase : "compile");
}

static int xlEnsureUnitXlirLowered(XL_Context* ctx, XL6_CompileUnit* unit)
{
    if ( unit == NULL || !unit->irReady ) {
        xlSetError(ctx, "verified XLIR is unavailable");
        return 0;
    }
    if ( unit->ir.stage == XL6_IR_STAGE_TYPED ) {
        if ( !xl6IrLowerModule(&unit->ir, &unit->parse.diags) ) {
            unit->irReady = 0;
            xlSetCompileStageError(ctx, unit, "ir-lower");
            return 0;
        }
    }
    if ( unit->ir.stage != XL6_IR_STAGE_LOWERED ||
         !xl6CompileUnitPrepareCompiledPackages(unit) ||
         !xl6IrVerifyModule(&unit->ir, &unit->parse.diags) ||
         !xl6CompileUnitPrepareCSourceGroups(unit) ) {
        unit->irReady = 0;
        xlSetCompileStageError(ctx, unit, "ir-verify");
        return 0;
    }
    return 1;
}

static int xlCgenToMemory(XL_Context* ctx, XL6_CompileUnit* unit,
                          char** outText,
                          const XL6_IrCgenOptions* requestedOptions)
{
    XL6_IrCgenOptions options = {0};
    XL6_Output out;
    int ok;

    if ( outText == NULL ) return 0;
    *outText = NULL;
    if ( !xlEnsureUnitXlirLowered(ctx, unit) ) return 0;
    if ( !xl6IrCgenVerifyEmittable(&unit->ir, &unit->parse.diags) ) {
        xlSetCompileStageError(ctx, unit, "cgen-verify");
        return 0;
    }
    if ( !xl6OutputOpenMemory(&out) ) {
        xlSetError(ctx, "cannot create XLIR Cgen memory output");
        return 0;
    }
    if ( requestedOptions != NULL ) options = *requestedOptions;
    ok = xl6IrCgenEmitCEx(&out, &unit->ir, &unit->parse.diags, &options);
    if ( ok && !xl6OutputHasFailed(&out) )
        *outText = xl6OutputTakeMemoryText(&out, NULL);
    if ( xl6OutputHasFailed(&out) ) {
        xlSetError2(ctx, "cannot generate XLIR C code", xl6OutputError(&out));
        ok = 0;
    } else if ( !ok ) {
        xlSetCompileStageError(ctx, unit, "cgen-emit");
    } else if ( *outText == NULL ) {
        xlSetError(ctx, "cannot copy generated XLIR C code");
        ok = 0;
    }
    xl6OutputClose(&out);
    return ok && *outText != NULL;
}

static void xlTccDynamicVfsClear(void)
{
#ifdef XL_STATIC_TCC_VFS
    tcc_vfs_clear_dynamic();
#endif
}

static int xlTccCompileSourceText(XL_Context* ctx, TCCState* s, const char* virtualPath, const char* source, const char* fallbackError)
{
    if ( s == NULL || source == NULL ) {
        xlSetError(ctx, fallbackError != NULL ? fallbackError : "TCC source is empty");
        return 0;
    }
#ifdef XL_STATIC_TCC_VFS
    if ( virtualPath == NULL || virtualPath[0] == '\0' ) {
        xlSetError(ctx, "dynamic TCC VFS path is empty");
        return 0;
    }
    if ( !tcc_vfs_mount_memory(virtualPath, source, strlen(source)) ) {
        xlSetError2(ctx, "cannot mount dynamic TCC VFS source", virtualPath);
        return 0;
    }
    if ( xl__tcc.tcc_add_file(s, virtualPath) != 0 ) {
        if ( ctx != NULL && ctx->lastError == NULL ) {
            xlSetError(ctx, fallbackError != NULL ? fallbackError : "TCC compile failed");
        }
        return 0;
    }
    return 1;
#else
    if ( xl__tcc.tcc_compile_string(s, source) != 0 ) {
        if ( ctx != NULL && ctx->lastError == NULL ) {
            xlSetError(ctx, fallbackError != NULL ? fallbackError : "TCC compile failed");
        }
        return 0;
    }
    return 1;
#endif
}

static int xlTccCompileGeneratedModule(XL_Context* ctx, TCCState* s, const char* source)
{
    int ok;
    if ( s == NULL || source == NULL ) {
        xlSetError(ctx, "generated C module is empty");
        return 0;
    }
    /* Lowered XLIR owns every native signature. Apply the same ABI gate to
     * JIT and external outputs, but not to user/vendor C translation units. */
    if ( xl__tcc.tcc_set_options(s, "-Werror=implicit-function-declaration") < 0 ) {
        xlSetError(ctx, "cannot enforce generated C declaration ABI");
        return 0;
    }
    ok = xlTccCompileSourceText(ctx, s, XL_TCC_VFS_MODULE_C, source, "TCC compile failed");
    if ( xl__tcc.tcc_set_options(s, "-Wno-error=implicit-function-declaration") < 0 ) {
        if ( ctx != NULL && ctx->lastError == NULL )
            xlSetError(ctx, "cannot restore C declaration diagnostic policy");
        return 0;
    }
    return ok;
}

#include "src/api/xl_compiled_package.inc"

static int xlLoadUnitFromSource(XL_Context* ctx, XL6_CompileUnit* unit, const char* source, const char* virtualPath, const XL6_SourceOverlay* overlay)
{
    xl6CompileUnitInit(unit);
    unit->importDeps.sourceOverlay = overlay;
    unit->importDeps.compiledPackages = &ctx->compiledPackages;
    if ( source == NULL ) {
        xlSetError(ctx, "script source is empty");
        return 0;
    }
    if ( !xl6CompileUnitLoadSource(unit, source, virtualPath, 1) ) {
        xlSetCompileDiagError(ctx, unit);
        return 0;
    }
    return 1;
}

static int xlLoadUnitFromFile(XL_Context* ctx, XL6_CompileUnit* unit, const char* path, const XL6_SourceOverlay* overlay)
{
    xl6CompileUnitInit(unit);
    unit->importDeps.sourceOverlay = overlay;
    unit->importDeps.compiledPackages = &ctx->compiledPackages;
    if ( path == NULL || path[0] == '\0' ) {
        xlSetError(ctx, "script file path is empty");
        return 0;
    }
    if ( !xl6CompileUnitLoadFile(unit, path, 1) ) {
        xlSetCompileDiagError(ctx, unit);
        return 0;
    }
    return 1;
}

static int xlAddDependenciesToTcc(XL_Context* ctx, TCCState* s, const XL6_CompileUnit* unit)
{
    size_t i;

    for ( i = 0; ctx != NULL && i < ctx->linkLibraries.count; ++i ) {
        const char* value = ctx->linkLibraries.items[i];
        if ( xlTextLooksLikePath(value) ) {
            if ( xl__tcc.tcc_add_file(s, value) != 0 ) {
                xlSetError2(ctx, "cannot add link file", value);
                return 0;
            }
        } else if ( xl__tcc.tcc_add_library(s, value) != 0 ) {
            xlSetError2(ctx, "cannot add link library", value);
            return 0;
        }
    }
    for ( i = 0; ctx != NULL && i < ctx->loadedLibraryCount; ++i ) {
        if ( xl__tcc.tcc_add_file(s, ctx->loadedLibraries[i].path) != 0 ) {
            xlSetError2(ctx, "cannot add dependency library", ctx->loadedLibraries[i].path);
            return 0;
        }
    }
    for ( i = 0; unit != NULL && i < unit->importDeps.links.count; ++i ) {
        const char* value = unit->importDeps.links.items[i];
        if ( xlTextLooksLikePath(value) ) {
            if ( xl__tcc.tcc_add_file(s, value) != 0 ) {
                if (ctx == NULL || ctx->lastError == NULL)
                    xlSetError2(ctx, "cannot add import link file", value);
                return 0;
            }
        } else if ( xl__tcc.tcc_add_library(s, value) != 0 ) {
            if (ctx == NULL || ctx->lastError == NULL)
                xlSetError2(ctx, "cannot add import link library", value);
            return 0;
        }
    }
    for ( i = 0; unit != NULL && i < unit->importDeps.loadlibs.count; ++i ) {
        if ( xl__tcc.tcc_add_file(s, unit->importDeps.loadlibs.items[i]) != 0 ) {
            if (ctx == NULL || ctx->lastError == NULL)
                xlSetError2(ctx, "cannot add import loadlib", unit->importDeps.loadlibs.items[i]);
            return 0;
        }
    }
    return 1;
}

#if XL_ENABLE_EXE_COMPILER
static int xlEmitUnitHeaderToFile(XL_Context* ctx, XL6_CompileUnit* unit,
                                  const char* outputPath, const char* guardName);
#endif

static char* xlJoinTempFilePath(XL_Context* ctx, const char* fileName)
{
    str path;

    if ( ctx == NULL || ctx->tempDir == NULL || ctx->tempDir[0] == '\0' ) {
        xlSetError(ctx, "compiler temp dir is empty");
        return NULL;
    }
    path = xrtPathJoin(ctx->tempDir, fileName);
    if ( path == NULL ) {
        xlSetError2(ctx, "cannot create temp path", fileName);
    }
    return (char*)path;
}

static int xlWriteTempTextFile(XL_Context* ctx, const char* path, const char* text)
{
    xbytesview data;
    size_t size;

    if ( path == NULL || path[0] == '\0' || text == NULL ) {
        xlSetError(ctx, "temp file write input is empty");
        return 0;
    }
    size = strlen(text);
    data.Data = (const unsigned char*)text;
    data.Size = size;
    if ( !xrtFileWriteAll(path, data) ) {
        xlSetError2(ctx, "cannot write temp file", path);
        return 0;
    }
    return 1;
}

static int xlSaveTempTextByName(XL_Context* ctx, const char* fileName, const char* text)
{
    char* path;
    int ok;

    if ( ctx == NULL || !ctx->saveTemps ) {
        return 1;
    }
    if ( ctx->tempDir == NULL || ctx->tempDir[0] == '\0' ) {
        xlSetError(ctx, "compiler temp dir is empty");
        return 0;
    }
    if ( !xrtDirExists((str)ctx->tempDir) && !xrtDirCreateAll((str)ctx->tempDir) ) {
        xlSetError2(ctx, "cannot create compiler temp dir", ctx->tempDir);
        return 0;
    }
    path = xlJoinTempFilePath(ctx, fileName);
    if ( path == NULL ) {
        return 0;
    }
    ok = xlWriteTempTextFile(ctx, path, text);
    xrtFree(path);
    return ok;
}

typedef struct XL_CHeaderBindings {
    xvalue* records;
    size_t namesBytes;
    int unavailable;
} XL_CHeaderBindings;

static int xlCHeaderBinding(void* user, XL6_SymbolId symbol, const char* name,
    const char* kind, size_t start, size_t end)
{
    XL_CHeaderBindings* b = (XL_CHeaderBindings*)user;
    xvalue* row;
    size_t size = name != NULL ? strlen(name) : 0;
    int ok;
    if (b->unavailable) return 1;
    if (!b->records || !symbol || !size || size > 4u * 1024u * 1024u - b->namesBytes ||
        xrtValueCount(b->records) >= 32768u || end < start || end - start != size) {
        b->unavailable = 1;
        xrtValueRelease(b->records); b->records = NULL;
        return 1;
    }
    row = xrtValueObject();
    ok = row != NULL &&
        xrtValueObjectSetNew(row, xrtStrView("symbolId"), xrtValueInt(symbol)) &&
        xrtValueObjectSetNew(row, xrtStrView("cName"), xrtValueString(xrtStrView(name))) &&
        xrtValueObjectSetNew(row, xrtStrView("kind"), xrtValueString(xrtStrView(kind))) &&
        xrtValueObjectSetNew(row, xrtStrView("startByte"), xrtValueInt((int64)start)) &&
        xrtValueObjectSetNew(row, xrtStrView("endByte"), xrtValueInt((int64)end)) &&
        xrtValueArrayAppend(b->records, row);
    xrtValueRelease(row);
    if (ok) b->namesBytes += size;
    else {
        b->unavailable = 1;
        xrtValueRelease(b->records); b->records = NULL;
    }
    return 1;
}

static int xlEmitUnitHeaderToMemoryMapped(XL_Context* ctx, XL6_CompileUnit* unit,
    const char* guardName, char** outText, xvalue** outBindings, int nativeContract)
{
    XL6_Output out;
    int ok;

    if ( outText == NULL ) {
        return 0;
    }
    *outText = NULL;
    if ( unit == NULL || unit->parse.root == NULL ) {
        xlSetError(ctx, "compile unit is empty");
        return 0;
    }
    if ( !xlEnsureUnitXlirLowered(ctx, unit) )
        return 0;
    if ( !xl6OutputOpenMemory(&out) ) {
        xlSetError(ctx, "cannot create header memory output");
        return 0;
    }
    XL_CHeaderBindings bindings = {0};
    if (outBindings != NULL) {
        *outBindings = NULL;
        bindings.records = xrtValueArray();
    }
    ok = nativeContract
        ? xl6IrCgenEmitNativeContractHeader(&out, &unit->ir,
            guardName != NULL && guardName[0] != '\0' ? guardName : "XL6_GENERATED_HEADER_H",
            &unit->parse.diags)
        : xl6IrCgenEmitHeaderWithBindings(&out, &unit->ir,
            guardName != NULL && guardName[0] != '\0' ? guardName : "XL6_GENERATED_HEADER_H",
            &unit->parse.diags, outBindings != NULL ? xlCHeaderBinding : NULL, &bindings);
    if ( ok && !xl6OutputHasFailed(&out) ) {
        *outText = xl6OutputTakeMemoryText(&out, NULL);
    }
    if ( xl6OutputHasFailed(&out) ) {
        xlSetError2(ctx, "cannot generate header output", xl6OutputError(&out));
        ok = 0;
    } else if ( !ok ) {
        xlSetCompileDiagError(ctx, unit);
    } else if ( *outText == NULL ) {
        xlSetError(ctx, "cannot copy generated header output");
        ok = 0;
    }
    xl6OutputClose(&out);
    if (ok && *outText != NULL && outBindings != NULL) {
        *outBindings = bindings.records;
        bindings.records = NULL;
    }
    xrtValueRelease(bindings.records);
    return ok && *outText != NULL;
}

static int xlEmitUnitNativeHeaderToMemory(XL_Context* ctx, XL6_CompileUnit* unit,
    const char* guardName, char** outText)
{
    return xlEmitUnitHeaderToMemoryMapped(ctx, unit, guardName, outText, NULL, 1);
}

static int xlMountDynamicTccBinary(XL_Context* ctx, const char* virtualPath, const void* data, size_t size)
{
#ifdef XL_STATIC_TCC_VFS
    if ( virtualPath == NULL || virtualPath[0] == '\0' || (data == NULL && size != 0) ) {
        xlSetError(ctx, "dynamic TCC VFS binary input is empty");
        return 0;
    }
    if ( !tcc_vfs_mount_memory(virtualPath, data, size) ) {
        xlSetError2(ctx, "cannot mount dynamic TCC VFS binary", virtualPath);
        return 0;
    }
    return 1;
#else
    (void)virtualPath;
    (void)data;
    (void)size;
    xlSetError(ctx, "dynamic TCC VFS is not available");
    return 0;
#endif
}

static int xlOutputNormalizedCIncludePath(XL_Context* ctx, XL6_Output* out, const char* path)
{
    size_t i;

    if ( out == NULL || path == NULL || path[0] == '\0' ) {
        xlSetError(ctx, "C source file path is empty");
        return 0;
    }
    for ( i = 0; path[i] != '\0'; ++i ) {
        if ( path[i] == '"' || path[i] == '\n' || path[i] == '\r' ) {
            xlSetError2(ctx, "C source include path contains invalid character", path);
            return 0;
        }
        if ( xl6OutputPutc(path[i] == '\\' ? '/' : path[i], out) == EOF ) {
            xlSetError(ctx, "cannot write C source include path");
            return 0;
        }
    }
    return 1;
}

/* External outputs must own relocatable code, never process-local addresses. */
static int xlAddNativeObject(TCCState* state,int outputType)
{
    if(outputType==TCC_OUTPUT_PREPROCESS)return 1;
    return xl__tcc.tcc_add_file(state,outputType==TCC_OUTPUT_DLL
        ? "__xl_objects/shared-native/xrt.o" : "__xl_objects/static-native/xrt.o")==0;
}

static const char xlNativeCPreamble[] = "#include <__xl_runtime/xrt_decl.h>\n#include <__xl_runtime/xruntime_decl.h>\n";
static const char xlNativeCHeaderGuard[] = "XL6_MODULE_H";

static int xlBuildCSourceWrapperText(XL_Context* ctx, const char* sourcePath,
                                     const char* headerText, char** outText)
{
    XL6_Output out;
    int ok;

    if ( outText == NULL ) {
        return 0;
    }
    *outText = NULL;
    if ( !xl6OutputOpenMemory(&out) ) {
        xlSetError(ctx, "cannot create C source wrapper output");
        return 0;
    }
    /* Native implementations need declarations, not an implementation header
     * whose feature guards were fixed before the sidecar can select modules.
     * Use the same canonical, packaged declaration ABI as generated XLIR C. */
    ok = xl6OutputPuts(xlNativeCPreamble, &out) != EOF &&
         xl6OutputPuts(headerText, &out) != EOF &&
         xl6OutputPuts("#include \"", &out) != EOF &&
         xlOutputNormalizedCIncludePath(ctx, &out, sourcePath) &&
         xl6OutputPuts("\"\n", &out) != EOF;
    if ( ok && !xl6OutputHasFailed(&out) ) {
        *outText = xl6OutputTakeMemoryText(&out, NULL);
    }
    if ( xl6OutputHasFailed(&out) ) {
        xlSetError2(ctx, "cannot generate C source wrapper", xl6OutputError(&out));
        ok = 0;
    } else if ( ok && *outText == NULL ) {
        xlSetError(ctx, "cannot copy C source wrapper");
        ok = 0;
    }
    xl6OutputClose(&out);
    return ok && *outText != NULL;
}

/* All C implementations of language declarations share the same verified ABI
 * header, regardless of whether they came from a package or the public API.
 * TCC owns disk/VFS transport; no second wrapper or ABI inference path exists. */
static int xlCompileUnitCSourceFiles(
    XL_Context* ctx, TCCState* s, XL6_CompileUnit* unit,
    const XL_StringList* cSourceFiles)
{
    char* headerText = NULL;
    size_t group, i, ordinal = 0;
    size_t importedCount = unit != NULL ? unit->importDeps.cSources.count : 0;
    size_t additionalCount = cSourceFiles != NULL ? cSourceFiles->count : 0;
    int ok = 0;
    if ( importedCount == 0 && additionalCount == 0 ) return 1;
    if ( ctx == NULL || s == NULL || unit == NULL ) {
        xlSetError(ctx, "compiler context is empty");
        return 0;
    }
    if ( additionalCount > XLC_MAX_C_SOURCE_FILES ||
         importedCount > SIZE_MAX - additionalCount ) {
        xlSetError(ctx, "too many C source files");
        return 0;
    }
    if ( !xlEmitUnitNativeHeaderToMemory(ctx, unit, xlNativeCHeaderGuard, &headerText) )
        return 0;
    if ( !xlSaveTempTextByName(ctx, "module.h", headerText) ) goto cleanup;
    for ( group = 0; group < 2; ++group ) {
        size_t count = group == 0 ? importedCount : additionalCount;
        for ( i = 0; i < count; ++i, ++ordinal ) {
            const char* path = group == 0 ? unit->importDeps.cSources.items[i] : cSourceFiles->items[i];
            char* wrapperText = NULL;
            char wrapperName[64], virtualPath[96];
            int compiled;
            snprintf(wrapperName, sizeof(wrapperName), "csrc_%zu.c", ordinal);
            snprintf(virtualPath, sizeof(virtualPath), "__xlvfs__/%s", wrapperName);
            if ( !xlBuildCSourceWrapperText(ctx, path, headerText, &wrapperText) )
                goto cleanup;
            compiled = xlSaveTempTextByName(ctx, wrapperName, wrapperText) &&
                 xlTccCompileSourceText(ctx, s, virtualPath, wrapperText, "cannot compile C source file");
            xrtFree(wrapperText);
            if ( !compiled ) goto cleanup;
        }
    }
    ok = 1;
cleanup:
    xrtFree(headerText);
    return ok;
}

#if XL_ENABLE_EXE_COMPILER
static int xlAddResourceFilesToTcc(XL_Context* ctx, TCCState* s)
{
    if ( ctx == NULL || ctx->resourceFiles.count == 0 ) {
        return 1;
    }
    if ( s == NULL ) {
        xlSetError(ctx, "TCC state is empty");
        return 0;
    }
#if defined(_WIN32)
    size_t i;
    if ( ctx->resourceFiles.count > XLC_MAX_RESOURCE_FILES ) {
        xlSetError(ctx, "too many resource config files");
        return 0;
    }
    for ( i = 0; i < ctx->resourceFiles.count; ++i ) {
        void* objectData;
        size_t objectSize;
        char virtualPath[96];
        char error[512];

        objectData = NULL;
        objectSize = 0;
        error[0] = '\0';
        if ( !xl6WinResourceConfigToCoffMemory(ctx->resourceFiles.items[i], &objectData, &objectSize, error, sizeof(error)) ) {
            xlSetError2(ctx, "cannot build Windows resource", error[0] != '\0' ? error : ctx->resourceFiles.items[i]);
            xrtFree(objectData);
            return 0;
        }
        snprintf(virtualPath, sizeof(virtualPath), "__xlvfs__/resource_%u.obj", (unsigned int)i);
        if ( !xlMountDynamicTccBinary(ctx, virtualPath, objectData, objectSize) ) {
            xrtFree(objectData);
            return 0;
        }
        xrtFree(objectData);
        if ( xl__tcc.tcc_add_file(s, virtualPath) != 0 ) {
            xlSetError2(ctx, "cannot add Windows resource object", virtualPath);
            return 0;
        }
    }
    return 1;
#else
    xlSetError(ctx, "windows resources are only supported on Windows");
    return 0;
#endif
}

static void xlAddEmbeddedSourceIncludePaths(TCCState* s)
{
    if ( s == NULL ) {
        return;
    }
    (void)xl__tcc.tcc_add_include_path(s, XL_TCC_VFS_COMPILER_SOURCE_ROOT);
    (void)xl__tcc.tcc_add_include_path(s, XL_TCC_VFS_COMPILER_SOURCE_ROOT "/include");
    (void)xl__tcc.tcc_add_include_path(s, XL_TCC_VFS_COMPILER_SOURCE_ROOT "/src");
    (void)xl__tcc.tcc_add_include_path(s, XL_TCC_VFS_COMPILER_SOURCE_ROOT "/lib/tcc");
    (void)xl__tcc.tcc_add_include_path(s, XL_TCC_VFS_COMPILER_SOURCE_ROOT "/lib/lzma");
    (void)xl__tcc.tcc_add_include_path(s, XL_TCC_VFS_COMPILER_SOURCE_ROOT "/release");
    /* Filesystem SDKs use the same reserved package root as the VFS. Resolve
     * it only beside the compiler module, never from user include directories
     * or source spelling. tcc_add_file does not search its include paths. */
    char root[512], package[1536], path[2048];
    if (xlGetProjectRoot(root,sizeof(root)) &&
        xlJoinPathBuffer(package,sizeof(package),root,"include/" XL_TCC_VFS_COMPILER_SOURCE_ROOT)) {
        const char* suffixes[]={"","include","src","lib/tcc","lib/lzma","release"};
        for(size_t i=0;i<sizeof(suffixes)/sizeof(*suffixes);++i)
            if (xlJoinPathBuffer(path,sizeof(path),package,suffixes[i]))
                (void)xl__tcc.tcc_add_include_path(s,path);
    }
}

static int xlEmbeddedSourcePath(char* out, size_t outSize, const char* relativePath)
{
    char root[512];
    char externalPath[1536];
    size_t i;
    int written;

    if ( out == NULL || outSize == 0 || relativePath == NULL || relativePath[0] == '\0' ) {
        return 0;
    }

    /* 开发目录存在源码时优先使用外部最新版；发布环境回落到只读静态 VFS。 */
    if ( xlGetProjectRoot(root, sizeof(root)) &&
         xlJoinPathBuffer(externalPath, sizeof(externalPath), root, relativePath) &&
         xl6BuildInputExists(externalPath) ) {
        return xlCopyToBuffer(out, outSize, externalPath);
    }

    char package[1536];
    if (xlGetProjectRoot(root,sizeof(root)) &&
        xlJoinPathBuffer(package,sizeof(package),root,"include/" XL_TCC_VFS_COMPILER_SOURCE_ROOT) &&
        xlJoinPathBuffer(externalPath,sizeof(externalPath),package,relativePath) &&
        xrtFileExists((str)externalPath))
        return xlCopyToBuffer(out,outSize,externalPath);

    written = snprintf(out, outSize, "%s/%s", XL_TCC_VFS_COMPILER_SOURCE_ROOT, relativePath);
    if ( written <= 0 || (size_t)written >= outSize ) {
        return 0;
    }
    for ( i = 0; out[i] != '\0'; ++i ) {
        if ( out[i] == '\\' ) {
            out[i] = '/';
        }
    }
    return 1;
}

static int xlAddPrecompiledSourceFile(XL_Context* ctx,TCCState* s,
    const char* path,const char* profile)
{
    char objectPath[2048];
    int length;
    if(!path||!profile) { xlSetError(ctx,"missing fixed object contract");return 0; }
    length=snprintf(objectPath,sizeof(objectPath),"__xl_objects/%s/%s.o",profile,path);
    if(length<=0||(size_t)length>=sizeof(objectPath)) {
        xlSetError(ctx,"fixed object path exceeds limit");return 0;
    }
    if(xl__tcc.tcc_add_file(s,objectPath)!=0) {
        if(!ctx->lastError)xlSetError2(ctx,"cannot load fixed precompiled object",objectPath);
        return 0;
    }
    return 1;
}
static int xlAddTccSourceFile(XL_Context* ctx,TCCState* s,const char* path)
{ return xlAddPrecompiledSourceFile(ctx,s,path,"static-compiler"); }



/* XLIR output consumes the complete precomputed artifact contract. No source
 * text, AST spelling or missing-symbol fallback is consulted at this boundary. */
static int xlAddPrivateLanguageRuntimeSources(XL_Context* ctx, TCCState* s,
    const XL6_CompileUnit* unit, const XL6_ArtifactRuntimePlan* plan)
{
    if (!ctx || !s || !unit || !plan) return 0;
    if (unit->importDeps.features &
        (XL6_IMPORT_FEATURE_XLANG_RUNTIME | XL6_IMPORT_FEATURE_XLANG_COMPILER)) return 1;
    (void)xl__tcc.tcc_set_options(s, "-DXL_STATIC_EMBED");
    (void)xl__tcc.tcc_add_include_path(s, ".");
    (void)xl__tcc.tcc_add_include_path(s, "src");
    (void)xl__tcc.tcc_add_include_path(s, "release");
    (void)xl__tcc.tcc_add_include_path(s, "release/include");
    xlAddEmbeddedSourceIncludePaths(s);
    for (size_t i=0;i<plan->sourceCount;++i)
        if (!xlAddTccSourceFile(ctx,s,plan->sources[i])) return 0;
    return 1;
}

static int xlAddEmbeddedTccRuntimeSources(
    XL_Context* ctx,
    TCCState* s,
    const XL6_CompileUnit* unit,
    int outputType)
{
    unsigned int features;
    const char* profile=outputType==TCC_OUTPUT_DLL?"shared-compiler":"static-compiler";

    if ( ctx == NULL || s == NULL || unit == NULL ) {
        return 1;
    }
    features = unit->importDeps.features;
    if ( (features & (XL6_IMPORT_FEATURE_TCC_RUNTIME |
                      XL6_IMPORT_FEATURE_XLANG_RUNTIME |
                      XL6_IMPORT_FEATURE_XLANG_COMPILER)) == 0 ) {
        return 1;
    }

    /*
     * 这些宏描述“被编进用户产物里的 libtcc”。它们只在产物需要脚本能力时启用，
     * 普通 xlang 程序不会携带 TCC 源码和内置 VFS 资源。
     */
#ifdef _WIN32
    (void)xl__tcc.tcc_set_options(s, "-DXL_STATIC_TCC -DCONFIG_TCC_STATIC");
#else
    /* Static inclusion of libtcc is not CONFIG_TCC_STATIC: that vendor option
     * replaces POSIX dlopen/dlsym with profiling stubs, disabling nested JIT. */
    (void)xl__tcc.tcc_set_options(s, "-DXL_STATIC_TCC");
#endif
#if !defined(_WIN32) && defined(XL6_TCC_CONFIGURED_TRIPLET)
    /* Preserve both libtcc's configured include/CRT layout and this host's
     * ability to propagate that same contract to a nested embedded host. */
    xl__tcc.tcc_define_symbol(s, "CONFIG_TRIPLET", "\"" XL6_TCC_CONFIGURED_TRIPLET "\"");
    xl__tcc.tcc_define_symbol(s, "XL6_TCC_CONFIGURED_TRIPLET", "\"" XL6_TCC_CONFIGURED_TRIPLET "\"");
#endif
    if ( outputType == TCC_OUTPUT_DLL ) {
        (void)xl__tcc.tcc_set_options(s, "-DLIBTCC_AS_DLL");
    }
    (void)xl__tcc.tcc_add_include_path(s, "lib/tcc");
    (void)xl__tcc.tcc_add_include_path(s, "lib/lzma");
    (void)xl__tcc.tcc_add_include_path(s, "release");
    (void)xl__tcc.tcc_add_include_path(s, "release/include");
    xlAddEmbeddedSourceIncludePaths(s);

	if ( !xlAddPrecompiledSourceFile(ctx,s,"lib/tcc/libtcc.c",profile) ||
		 !xlAddPrecompiledSourceFile(ctx,s,"lib/tcc/tcctools.c",profile) ||
		 !xlAddPrecompiledSourceFile(ctx,s,"lib/tcc/tcc_builtin_vfs.c",profile) ||
		 !xlAddPrecompiledSourceFile(ctx,s,"lib/lzma/LzmaDec.c",profile) ) {
		return 0;
	}
    {
        char* source;
        size_t size=0;
        int compiler=(features & XL6_IMPORT_FEATURE_XLANG_COMPILER)!=0;
        /* Serialize the catalog of the selected TCC core. A source host can
         * link the runtime DLL while loading a compiler-capable core; those
         * catalogs deliberately contain different fixed-object populations. */
        typedef int (*XL_WriteCatalog)(int,char*,size_t,size_t*);
#ifdef XL_STATIC_TCC_VFS
        XL_WriteCatalog writeCatalog=tcc_vfs_write_catalog_source;
#elif !defined(XL_STATIC_TCC)
        XL_WriteCatalog writeCatalog=(XL_WriteCatalog)xlLoadProc(&xl__tcc,"tcc_vfs_write_catalog_source");
#else
        XL_WriteCatalog writeCatalog=NULL;
#endif
        if(!writeCatalog) {
            xlSetError(ctx,"selected TCC core has no builtin catalog serializer");return 0;
        }
        if(!writeCatalog(compiler,NULL,0,&size) || size==SIZE_MAX ||
            !(source=(char*)xrtMalloc(size+1))) {
            xlSetError(ctx,"cannot allocate nested VFS catalog");return 0;
        }
        if(!writeCatalog(compiler,source,size+1,&size) ||
            xl__tcc.tcc_compile_string(s,source)!=0) {
            xrtFree(source);xlSetError(ctx,"cannot compile nested VFS catalog");return 0;
        }
        xrtFree(source);
    }
	if ( (features & XL6_IMPORT_FEATURE_TCC_RUNTIME) != 0 &&
		 (features & (XL6_IMPORT_FEATURE_XLANG_RUNTIME |
					  XL6_IMPORT_FEATURE_XLANG_COMPILER)) == 0 &&
		 !xlAddPrecompiledSourceFile(ctx,s,"src/api/xl_tcc_standalone_env.c",profile) ) {
		return 0;
	}
#ifdef _WIN32
    if ( !xlAddPrecompiledSourceFile(ctx,s,"lib/tcc/tcc_utf8_io.c",profile) ) {
        return 0;
    }
#endif
    return 1;
}

static int xlAddEmbeddedXlangRuntimeSources(
    XL_Context* ctx,
    TCCState* s,
    const XL6_CompileUnit* unit,
    int outputType)
{
    static const char* runtimeSources[] = {
        "src/api/xl_api.c",
        "src/api/xl_api_symbols.c",
        "src/api/xl_api_path.c",
        "src/abi/xl6_abi_json.c",
        "src/abi/xl6_callable.c",
        "src/backend/xl6_build_backend.c",
        "src/compile/xl6_build_inputs.c",
        "src/compile/xl6_compile_unit.c",
        "src/compile/xl6_imports.c",
        "src/compile/xl6_source_overlay.c",
        "src/compile/xl6_source_report.c",
        "src/compile/xl6_xrt_trim.c",
        "src/common/xl6_console.c",
        "src/common/xl6_output.c",
        "src/diag/xl6_diag.c",
        "src/ast/xl6_ast.c",
        "src/cgen/xl6_cgen_shared_runtime.c",
        "src/cgen/xl6_ir_cgen.c",
        "src/lexer/xl6_token.c",
        "src/lexer/xl6_lexer_api.c",
        "src/lexer/xl6_lexer_gen.c",
        "src/parser/xl6_parser.c",
        "src/parser/xl6_parser_api.c",
        "src/ir/xl6_ir.c",
        "src/ir/xl6_ir_class_identity.c",
        "src/ir/xl6_ir_lower.c",
        "src/package/xl6_package.c",
        "src/stdlib/xl6_stdlib.c",
        "src/stdlib/xl6_stdlib_data.c",
        "src/type/xl6_type_model.c",
        "src/sem/xl6_protocol.c",
        "src/sem/xl6_type_registry.c",
        "src/sem/xl6_sem_docs.c",
        "src/sem/xl6_sem_field_attrs.c",
        "src/sem/xl6_completion.c",
        "src/sem/xl6_sem.c",
        "src/runtime/xl6_fs_path_parts.c",
        "src/runtime/xl6_ownership_domain_resource_fs_path_parts.c",
        "src/runtime/xl6_fs_path_iter.c",
        "src/runtime/xl6_ownership_domain_resource_fs_path_iter.c",
        "src/runtime/xl6_ownership_domain_resource_async_file.c",
        "src/runtime/xl6_siphash_state.c",
        "src/runtime/xl6_ownership_domain_resource_siphasher64.c",
        "src/runtime/xl6_os_process_args.c",
    };
    static const char* compilerSources[] = {
        "src/resource/xl6_win_resource.c",
        "src/sem/xl6_sem_index.c",
        "src/abi/xl6_abi_dump.c",
        "src/ast/xl6_ast_dump.c",
        "src/ir/xl6_ir_dump.c"
    };
    unsigned int features;
    const char* profile;
    size_t i;

    if ( ctx == NULL || s == NULL || unit == NULL ) {
        return 1;
    }
    features = unit->importDeps.features;
    profile=outputType==TCC_OUTPUT_DLL
        ? ((features&XL6_IMPORT_FEATURE_XLANG_COMPILER)?"shared-compiler":"shared-runtime")
        : ((features&XL6_IMPORT_FEATURE_XLANG_COMPILER)?"static-compiler":"static-runtime");
    if ( (features & (XL6_IMPORT_FEATURE_XLANG_RUNTIME |
                      XL6_IMPORT_FEATURE_XLANG_COMPILER)) == 0 ) {
        return 1;
    }

    /*
     * import xlang 表示最终产物要内嵌一份可独立运行的 xlang 宿主 API。
     * 普通运行能力只开启 runtime-only 口径；只有 import xlang.compiler 才携带
     * 外部 exe/dll/obj 输出和调试 dump 相关源码。
     */
    (void)xl__tcc.tcc_set_options(s,
        "-DXL_STATIC_TCC -DCONFIG_TCC_STATIC -DXL6_COMPILER_SOURCE_VFS");
    if ( outputType == TCC_OUTPUT_DLL ) {
        (void)xl__tcc.tcc_set_options(s, "-DXL_BUILD_DLL -DLIBTCC_AS_DLL");
    } else {
        (void)xl__tcc.tcc_set_options(s, "-DXL_STATIC_EMBED");
    }
    if ( (features & XL6_IMPORT_FEATURE_XLANG_COMPILER) == 0 ) {
        (void)xl__tcc.tcc_set_options(s, "-DXL_RUNTIME_ONLY_DLL -DXL_RUNTIME_ONLY_API");
    }
    (void)xl__tcc.tcc_add_include_path(s, ".");
    (void)xl__tcc.tcc_add_include_path(s, "src");
    (void)xl__tcc.tcc_add_include_path(s, "release");
    (void)xl__tcc.tcc_add_include_path(s, "release/include");
    (void)xl__tcc.tcc_add_include_path(s, "lib/tcc");
    (void)xl__tcc.tcc_add_include_path(s, "lib/lzma");
    xlAddEmbeddedSourceIncludePaths(s);

    for ( i = 0; i < sizeof(runtimeSources) / sizeof(runtimeSources[0]); ++i ) {
        if ( !xlAddPrecompiledSourceFile(ctx,s,runtimeSources[i],profile) ) {
            return 0;
        }
    }
    /* Explicit import xlang embeds a full language host, including the
     * callable standard-library environment registered by xl_api_symbols.
     * Use its canonical resident catalog once instead of a second, stale
     * hand-maintained source list. Ordinary artifacts still consume only
     * their verified, pruned XLIR plan in xlAddPrivateLanguageRuntimeSources. */
    for ( i = 0; i < XL6_ARTIFACT_RUNTIME_COUNT; ++i ) {
        const XL6_ArtifactRuntimeComponent* component =
            xl6ArtifactRuntimeComponentGet((unsigned)i);
        if (component == NULL || component->source == NULL) return 0;
        /* A full embedded host supplies its resolver through xl_api_symbols.
         * Native-TU components must never request a standalone (empty) .o,
         * just as with a pruned artifact's explicit placement contract. */
        if(component->placement==XL6_ARTIFACT_RUNTIME_IN_XRT_TRANSLATION_UNIT)continue;
        if(component->placement!=XL6_ARTIFACT_RUNTIME_RESIDENT_SOURCE ||
           !xlAddPrecompiledSourceFile(ctx,s,component->source,"static-compiler"))return 0;
    }
    if ( (features & XL6_IMPORT_FEATURE_XLANG_COMPILER) != 0 ) {
        for ( i = 0; i < sizeof(compilerSources) / sizeof(compilerSources[0]); ++i ) {
            if ( !xlAddPrecompiledSourceFile(ctx,s,compilerSources[i],profile) ) {
                return 0;
            }
        }
    }
    return 1;
}
#endif

static int xlPrepareRuntimeArg(
    XL_Context* ctx,
    xvalue* pSuppliedArg,
    xvalue** pArg
)
{
    if ( pArg == NULL ) {
        return 0;
    }
    *pArg = NULL;
    if ( pSuppliedArg != NULL ) {
        if ( xrtValueType(pSuppliedArg) != XVALUE_ARRAY ) {
            /* Canonical language Arrays are resident typed carriers, not
             * XVALUE_ARRAY wire values. Admit only a live, bound ARRAY role;
             * the generated entry still checks/imports its element contract.
             * Never retag another handle or probe foreign callback tables. */
            XL6_Sequence* sequence = NULL;
            XL6_SequenceLayoutV1 layout;
            const xvalueconverter* converter = NULL;
            int status = xl6SequenceBeginErasedArrayV1(pSuppliedArg, &sequence, &layout, &converter);
            if ( status > 0 ) xl6SequenceEndV1(sequence);
            else {
                if ( status == 0 ) xrtSetErrorKind(XERR_TYPE);
                xlSetError(ctx, "script arg must be an admitted array");
                ctx->lastExitCode = 1;
                return 0;
            }
        }
        *pArg = xrtValueRetain(pSuppliedArg);
        return *pArg != NULL;
    }
    *pArg = xrtValueArray();
    if ( *pArg == NULL ) {
        xlSetError(ctx, "cannot create script arg array");
        return 0;
    }
    return 1;
}

static int xlRunMainInState(XL_Context* ctx, TCCState* state, int argc, char** argv, const char* missingError, const char* returnPrefix)
{
    XL_CMainProc entry;
    int rc;

    if ( ctx == NULL || state == NULL ) {
        xlSetError(ctx, "module is empty");
        return 0;
    }
    entry = (XL_CMainProc)xl__tcc.tcc_get_symbol(state, "main");
    if ( entry == NULL ) {
        xlSetError(ctx, missingError != NULL ? missingError : "entry main not found");
        return 0;
    }

    /*
     * TCC 编译和重定位必须串行，但用户 C 入口不能持有全局 API 锁。
     * 上层执行租约会保证 ctx 在重新加锁前始终有效，并允许用户代码
     * 回调 xl.dll、并发请求销毁上下文或运行另一段脚本。
     */
    xlApiUnlock();
    rc = entry(argc > 0 ? argc : 0, argv);
    xlApiLock();
    ctx->lastExitCode = rc;
    (void)returnPrefix;
    return 1;
}

static void xlAddDefaultTccLinkLibraries(TCCState* s)
{
#ifdef _WIN32
    /*
     * XRT 是 xlang 的基础运行库。Windows 版本的 XRT 会使用 socket、
     * IP Helper 和 shell 等系统能力；C99 数学函数需要 UCRT 中超出
     * 旧 msvcrt 的导出。生成外部 exe/dll 和内存运行使用同一默认链接集。
     * 这里不强制检查返回值，让最终链接阶段给出精确诊断。
     */
# ifdef XL_STATIC_TCC
    (void)tcc_add_library(s, "Ws2_32");
    (void)tcc_add_library(s, "IPHLPAPI");
    (void)tcc_add_library(s, "Shell32");
    /* Resident transfer capsules release OS-owned STGMEDIUM outputs. Only
     * an actual unresolved reference creates an import; no COM root is added. */
    (void)tcc_add_library(s, "Ole32");
    (void)tcc_add_library(s, "ucrtbase");
# else
    if ( xl__tcc.tcc_add_library != NULL ) {
        (void)xl__tcc.tcc_add_library(s, "Ws2_32");
        (void)xl__tcc.tcc_add_library(s, "IPHLPAPI");
        (void)xl__tcc.tcc_add_library(s, "Shell32");
        (void)xl__tcc.tcc_add_library(s, "Ole32");
        (void)xl__tcc.tcc_add_library(s, "ucrtbase");
    }
# endif
#else
    /*
        Linux 版 XRT 依赖 pthread、dl 和 libm。内存运行时这些符号来自
        宿主进程；生成 ELF 产物时由 TCC 按同一规则链接。
    */
# ifdef XL_STATIC_TCC
    (void)tcc_add_library(s, "pthread");
    (void)tcc_add_library(s, "dl");
    (void)tcc_add_library(s, "m");
# else
    if ( xl__tcc.tcc_add_library != NULL ) {
        (void)xl__tcc.tcc_add_library(s, "pthread");
        (void)xl__tcc.tcc_add_library(s, "dl");
        (void)xl__tcc.tcc_add_library(s, "m");
    }
# endif
#endif
}

static int xlCheckScriptActiveError(XL_Context* ctx, TCCState* state)
{
    XL_ScriptHasErrorProc hasError;
    XL_ScriptVoidProc printUncaught;
    XL_ScriptVoidProc clearError;

    if ( state == NULL ) {
        return 0;
    }
    hasError = (XL_ScriptHasErrorProc)xl__tcc.tcc_get_symbol(state, xlModuleNativeAbiNames[XL_MODULE_ABI_HAS_ERROR]);
    if ( hasError == NULL || !hasError() ) {
        return 0;
    }
    printUncaught = (XL_ScriptVoidProc)xl__tcc.tcc_get_symbol(state, xlModuleNativeAbiNames[XL_MODULE_ABI_PRINT_UNCAUGHT]);
    clearError = (XL_ScriptVoidProc)xl__tcc.tcc_get_symbol(state, xlModuleNativeAbiNames[XL_MODULE_ABI_CLEAR_ERROR]);
    /* Printing is not an API diagnostic. Capture owned text while the
     * original error/module is alive, before the artifact clears its TLS.
     * Allocation failure must not replace the error being reported. */
    if (ctx != NULL && ctx->lastError == NULL) {
        xerror* original = xrtTakeError();
        xlSetError2(ctx, "uncaught xlang error", original != NULL ? xrtErrorMessage(original) : NULL);
        xrtClearError(); xrtSetErrorTake(original);
    }
    if ( printUncaught != NULL ) {
        printUncaught();
    }
    if ( clearError != NULL ) {
        clearError();
    }
    return 1;
}


/* 纯 C 不经过语言调用图裁剪；声明的能力必须与宿主/独立产物的完整运行库一致。 */
static int xlVisitFullRuntime(XL_CEnvVisit visit, void* user)
{
    return visit(user, "define", "XRT_MODULE_ALL", "1", 0) &&
           visit(user, "define", "XRUNTIME_MODULE_ALL", "1", 0);
}
static void xlTccSelectFullRuntime(TCCState* state)
{
    (void)xlVisitFullRuntime(xlTccCEnvVisit, state);
}
/* Query and real compilation share feature selection and directory order. */
static int xlVisitNativeSources(XL_Context* ctx, XL_CEnvVisit visit, void* user,
    const XL6_CompileUnit* unit, const XL_StringList* cSourceFiles)
{
    size_t i;
    if (unit == NULL) return 0;
    if (xl6XrtTrimRequiresFull(&unit->importDeps, cSourceFiles != NULL ? cSourceFiles->count : 0)) {
        if (!xlVisitFullRuntime(visit, user)) return 0;
    } else {
        for (i = 0; i < unit->importDeps.xrtModules.count; ++i)
            if (!visit(user, "define", unit->importDeps.xrtModules.items[i], "1", 0)) return 0;
    }
    for (i = 0; i < unit->importDeps.includeDirs.count; ++i) {
        if (!visit(user, "include", unit->importDeps.includeDirs.items[i], NULL, 1)) {
            if (ctx != NULL && ctx->lastError == NULL)
                xlSetError2(ctx, "cannot add import include directory", unit->importDeps.includeDirs.items[i]);
            return 0;
        }
    }
    return 1;
}
static int xlTccPrepareNativeSources(XL_Context* ctx, TCCState* state,
    const XL6_CompileUnit* unit, const XL_StringList* cSourceFiles)
{
    unsigned int flags = unit ? unit->importDeps.nativeLinkFlags : 0;
    if (flags && (!xl__tcc.tcc_native_link_features ||
        (xl__tcc.tcc_native_link_features() & flags) != flags)) {
        xlSetError(ctx, "selected TCC provider cannot satisfy the package nativeLink requirements");
        return 0;
    }
    return state != NULL && xlVisitPackageNativeLink(unit, xlTccCEnvVisit, state) &&
        xlVisitNativeSources(ctx, xlTccCEnvVisit, state, unit, cSourceFiles);
}


#if XL_ENABLE_EXE_COMPILER
static int xlCompileUnitHasExecutableEntry(XL_Context* ctx, XL6_CompileUnit* unit);

static int xlCompileUnitToExternalOutputWithC(
    XL_Context* ctx,
    XL6_CompileUnit* unit,
    const char* outputPath,
    int outputType,
    const char* outputKind,
    const XL6_IrCgenOptions* requestedOptions,
    const XL_StringList* cSourceFiles)
{
    TCCState* s;
    char* cText;
    char* runtimeSource;
    XL6_ArtifactRuntimePlan artifactRuntime;
    XL6_ArtifactOwnershipPlan entryOwnership={0};
    XL6_IrCgenEntryContractV1 entryContract={sizeof(entryContract),false,NULL,0,NULL};
    XL6_IrCgenOptions options = {0};
    int ok;

    s = NULL;
    if(unit->importDeps.features & XL6_IMPORT_FEATURE_COMPILED_PACKAGE_CONSUMER) {
        xlSetError(ctx,"compiled package addresses are process-local and cannot be emitted into an external binary");
        return 0;
    }
    if ( outputPath == NULL || outputPath[0] == '\0' ) {
        char text[128];
        snprintf(text, sizeof(text), "output %s path is empty", outputKind != NULL ? outputKind : "file");
        xlSetError(ctx, text);
        return 0;
    }
    cText = NULL;
    runtimeSource = NULL;
    memset(&artifactRuntime, 0, sizeof(artifactRuntime));
    if ( requestedOptions != NULL ) options = *requestedOptions;
    options.emitScriptEntry = 1;
    /* 显式混编 C 且没有语言入口时，由 C 提供 main；纯脚本仍可只执行全局初始化。 */
    options.emitMainWrapper = outputType == TCC_OUTPUT_EXE &&
        (cSourceFiles == NULL || cSourceFiles->count == 0 ||
         xlCompileUnitHasExecutableEntry(ctx, unit) > 0);
    ok = 0;
    xlTccDynamicVfsClear();
    if (!xlEnsureUnitXlirLowered(ctx,unit) || !xl6ArtifactRuntimePlanBuildWithOptions(&unit->ir, options.emitMainWrapper
            ? XL6_ARTIFACT_ENTRY_EXECUTABLE_V1 : XL6_ARTIFACT_ENTRY_CHECKED_MODULE_V1,
            &options, &artifactRuntime, &unit->parse.diags)) {
        xlSetCompileDiagError(ctx, unit);
        goto cleanup;
    }
    if(!xl6ArtifactRuntimeRequireSymbols(&artifactRuntime,
        (const char* const*)unit->importDeps.runtimeSymbols.items,unit->importDeps.runtimeSymbols.count)){
        xlSetError(ctx,"package declares an unknown resident runtime symbol");goto cleanup;
    }
    if ((artifactRuntime.hostAbi & XL6_ARTIFACT_HOST_XLANG_RUNTIME_V1) &&
        !(unit->importDeps.features & (XL6_IMPORT_FEATURE_XLANG_RUNTIME | XL6_IMPORT_FEATURE_XLANG_COMPILER))) {
        xlSetError(ctx,"artifact requires the declared embedded xlang runtime host ABI");goto cleanup;
    }
    if(options.emitMainWrapper){
        entryContract.managed=artifactRuntime.entryOwnershipAbi==XL6_ARTIFACT_ENTRY_OWNERSHIP_GRAPH;
        if(entryContract.managed){
            if(!xl6ArtifactOwnershipPlanBuild(&artifactRuntime,&entryOwnership)){
                xlSetError(ctx,"cannot build executable ownership deployment");goto cleanup;
            }
            artifactRuntime=entryOwnership.runtime;
            entryContract.domains=entryOwnership.domains;entryContract.domainCount=entryOwnership.domainCount;
            if(xl6ArtifactRuntimeSetHas(&artifactRuntime.components,XL6_ARTIFACT_CODE_FINALIZER))
                entryContract.discoverSymbol="xl6ClassOwnershipDiscoverV1";
        }
        options.entryContract=&entryContract;
    }
    if(!xlCgenToMemory(ctx,unit,&cText,&options))goto cleanup;
    if ( !xlSaveTempTextByName(ctx, "module.c", cText) ) {
        goto cleanup;
    }
    s = xlCreateTccState(ctx, outputType);
    if ( s == NULL ) {
        goto cleanup;
    }
    if ( !xlTccPrepareNativeSources(ctx, s, unit, cSourceFiles) ) {
        goto cleanup;
    }
    if ( !xlTccCompileSourceText(ctx, s, XL_TCC_VFS_RUNTIME_C,
            "__attribute__((weak)) unsigned int __mzerosf = 0x80000000u;\n"
            "__attribute__((weak)) unsigned long long __mzerodf = 0x8000000000000000ull;\n",
            "cannot compile TCC runtime constants") ) {
        goto cleanup;
    }
    if ( !xlTccCompileGeneratedModule(ctx, s, cText) ) {
        goto cleanup;
    }
    xlAddDefaultTccRuntime(s, ctx, outputType);
    if ( !xlCompileUnitCSourceFiles(ctx, s, unit, cSourceFiles) ) {
        goto cleanup;
    }
    if ( !xlAddDependenciesToTcc(ctx, s, unit) ) {
        goto cleanup;
    }
    if ( !xlAddResourceFilesToTcc(ctx, s) ) {
        goto cleanup;
    }
    if ( !xlAddEmbeddedTccRuntimeSources(ctx, s, unit, outputType) ) {
        goto cleanup;
    }
    if ( !xlAddPrivateLanguageRuntimeSources(ctx, s, unit, &artifactRuntime) ) {
        goto cleanup;
    }
    if ( !xlAddEmbeddedXlangRuntimeSources(ctx, s, unit, outputType) ) {
        goto cleanup;
    }
    if(xl6XrtTrimRequiresFull(&unit->importDeps,cSourceFiles?cSourceFiles->count:0) &&
       !xl6XrtTrimNeedsGeneratedRuntime(&unit->importDeps,&artifactRuntime)) {
        if(!xlAddNativeObject(s,outputType)) {
            xlSetError(ctx,"cannot load shared precompiled XRT implementation");goto cleanup;
        }
    } else {
    if ( !xl6XrtTrimBuildImplementationSourceFromPlan(&unit->importDeps,
            cSourceFiles != NULL ? cSourceFiles->count : 0,
            &artifactRuntime, &runtimeSource) ) {
        xlSetError(ctx, "cannot generate XRT implementation source");
        goto cleanup;
    }
    if ( !xlSaveTempTextByName(ctx, "xl6_xrt_impl.c", runtimeSource) ) {
        goto cleanup;
    }
	if ( !xlTccCompileSourceText(ctx, s, XL_TCC_VFS_XRT_C, runtimeSource, "cannot compile selected XRT/xruntime product") ) {
        goto cleanup;
    }
    }
    ok = xl6BuildInputOutputValid(outputPath) && xl__tcc.tcc_output_file(s, outputPath) == 0;
    if ( !ok ) {
        if ( ctx->lastError == NULL ) {
            xlSetError2(ctx, outputType == TCC_OUTPUT_DLL ? "cannot output shared library" : "cannot output exe", outputPath);
        }
        goto cleanup;
    }
    ok = 1;

cleanup:
    if ( s != NULL ) {
        xl__tcc.tcc_delete(s);
    }
    xrtFree(cText);
    xrtFree(runtimeSource);
    xlTccDynamicVfsClear();
    return ok;
}

static int xlCompileUnitToExternalOutputEx(
    XL_Context* ctx,
    XL6_CompileUnit* unit,
    const char* outputPath,
    int outputType,
    const char* outputKind,
    const XL6_IrCgenOptions* options)
{
    return xlCompileUnitToExternalOutputWithC(ctx, unit, outputPath,
        outputType, outputKind, options, NULL);
}

static int xlCompileUnitToExternalOutput(XL_Context* ctx, XL6_CompileUnit* unit, const char* outputPath, int outputType, const char* outputKind)
{
    return xlCompileUnitToExternalOutputEx(ctx, unit, outputPath, outputType, outputKind, NULL);
}

static int xlCompileUnitToExe(XL_Context* ctx, XL6_CompileUnit* unit, const char* outputExe)
{
    return xlCompileUnitToExternalOutput(ctx, unit, outputExe, TCC_OUTPUT_EXE, "exe");
}

static int xlCompileUnitToDebugExe(XL_Context* ctx, XL6_CompileUnit* unit, const char* outputExe, const char* debugSourcePath)
{
    XL6_IrCgenOptions options;

    memset(&options, 0, sizeof(options));
    options.debugMode = 1;
    options.debugSourcePath = debugSourcePath;
    return xlCompileUnitToExternalOutputEx(ctx, unit, outputExe, TCC_OUTPUT_EXE, "debug exe", &options);
}

static int xlAstIsTopLevelRuntimeStmt(const XL6_AstNode* node)
{
    if ( node == NULL ) {
        return 0;
    }
    switch ( node->kind ) {
    case XL6_AST_IMPORT:
    case XL6_AST_FUNC:
    case XL6_AST_ASYNC_FUNC:
    case XL6_AST_EXTERN_FUNC:
    case XL6_AST_EXPORT_FUNC:
    case XL6_AST_EXTERN_VAR:
    case XL6_AST_EXPORT_VAR:
    case XL6_AST_EXPORT_CONST:
    case XL6_AST_VAR_DECL:
    case XL6_AST_CONST_DECL:
    case XL6_AST_TYPE_ALIAS:
    case XL6_AST_EXTERN_TYPE_ALIAS:
    case XL6_AST_UNION: case XL6_AST_C_RECORD:
    case XL6_AST_CLASS:
    case XL6_AST_PROTOCOL:
    case XL6_AST_ENUM:
        return 0;
    default:
        return 1;
    }
}

static const XL6_AstNode* xlAstFindMainFunc(const XL6_AstNode* root)
{
    size_t i;

    if ( root == NULL ) {
        return NULL;
    }
    for ( i = 0; i < root->childCount; ++i ) {
        const XL6_AstNode* node = root->children[i];
        const XL6_AstNode* nameNode;
        if ( node == NULL || node->kind != XL6_AST_FUNC || node->childCount == 0 ) {
            continue;
        }
        nameNode = node->children[0];
        if ( nameNode != NULL && nameNode->text != NULL && strcmp(nameNode->text, "main") == 0 ) {
            return node;
        }
    }
    return NULL;
}

static int xlAstHasTopLevelRuntimeStmt(const XL6_AstNode* root)
{
    size_t i;

    if ( root == NULL ) {
        return 0;
    }
    for ( i = 0; i < root->childCount; ++i ) {
        if ( xlAstIsTopLevelRuntimeStmt(root->children[i]) ) {
            return 1;
        }
    }
    return 0;
}

static int xlCompileUnitHasExecutableEntry(XL_Context* ctx, XL6_CompileUnit* unit)
{
    if ( ctx == NULL || unit == NULL ) {
        return -1;
    }
    return xlAstFindMainFunc(unit->parse.root) != NULL ||
           xlAstHasTopLevelRuntimeStmt(unit->parse.root);
}

static int xlCompileUnitToSharedLibraryWithC(
    XL_Context* ctx, XL6_CompileUnit* unit, const char* outputDll,
    const XL_StringList* cSourceFiles)
{
    int hasEntry;

    hasEntry = xlCompileUnitHasExecutableEntry(ctx, unit);
    if ( hasEntry < 0 ) {
        return 0;
    }
    if ( hasEntry ) {
        xlSetError(ctx, "shared build cannot contain xlang main or top-level executable statements");
        return 0;
    }
    return xlCompileUnitToExternalOutputWithC(ctx, unit, outputDll,
        TCC_OUTPUT_DLL, "shared library", NULL, cSourceFiles);
}

static int xlCompileUnitToSharedLibrary(XL_Context* ctx, XL6_CompileUnit* unit, const char* outputDll)
{
    return xlCompileUnitToSharedLibraryWithC(ctx, unit, outputDll, NULL);
}
#endif

const char* xlGetVersionString(void) { return XL_VERSION_TEXT; }
unsigned int xlGetVersionCode(void) { return XL_VERSION_CODE; }

XL_ContextOptions xlDefaultContextOptions(void)
{
    XL_ContextOptions options;

    memset(&options, 0, sizeof(options));
    options.size = (unsigned int)sizeof(options);
    options.version = XL_API_VERSION;
    options.workDir = ".";
#ifdef _WIN32
    options.tempDir = "build\\tmp";
#else
    options.tempDir = "build/tmp";
#endif
    options.tccDllPath = NULL;
    options.tccLibPath = NULL;
    options.saveTemps = 0;
    return options;
}

static void xlClearLastErrorUnlocked(XL_Context* ctx)
{
    if ( ctx == NULL ) {
        return;
    }
    xrtFree(ctx->lastError);
    ctx->lastError = NULL;
    ctx->lastExitCode = 0;
}

static int xlRuntimeRefTotal(void)
{
    return xl__runtimeManualCount + xl__runtimeContextCount;
}

static int xlRuntimeAcquireManualUnlocked(void)
{
    if ( xlRuntimeRefTotal() == 0 ) {
        xl6ConsoleSessionBegin();
    }
    xl__runtimeManualCount += 1;
    return 1;
}

static void xlRuntimeReleaseManualUnlocked(void)
{
    if ( xl__runtimeManualCount <= 0 ) {
        return;
    }
    xl__runtimeManualCount -= 1;
    if ( xlRuntimeRefTotal() == 0 ) {
        xl6ConsoleSessionEnd();
    }
}

static int xlRuntimeAcquireContextUnlocked(void)
{
    if ( xlRuntimeRefTotal() == 0 ) {
        xl6ConsoleSessionBegin();
    }
    xl__runtimeContextCount += 1;
    return 1;
}

static void xlRuntimeReleaseContextUnlocked(void)
{
    if ( xl__runtimeContextCount <= 0 ) {
        return;
    }
    xl__runtimeContextCount -= 1;
    if ( xlRuntimeRefTotal() == 0 ) {
        xl6ConsoleSessionEnd();
    }
}

int xlRuntimeInit(void)
{
    int ok;

    xlApiLock();
    ok = xlRuntimeAcquireManualUnlocked();
    xlApiUnlock();
    return ok;
}

static void xlCollectRetiringModulesUnlocked(void);
static int xlModuleAcquireCode(void*);
static void xlModuleReleaseCode(void*);
#include "src/api/xl_module_read.inc"


void xlRuntimeUnit(void)
{
    xlApiLock();
    xlCollectRetiringModulesUnlocked();
    xlRuntimeReleaseManualUnlocked();
    xlApiUnlock();
}

static XL_Module* xlCreateModuleFromState(XL_Context* ctx, TCCState* s)
{
    XL_Module* module;

    if ( s == NULL ) {
        return NULL;
    }
    if ( !xlRuntimeAcquireManualUnlocked() ) {
        xlSetError(ctx, "cannot keep runtime alive for module");
        return NULL;
    }
    module = (XL_Module*)xrtCalloc(1, sizeof(XL_Module));
    if ( module == NULL ) {
        xlRuntimeReleaseManualUnlocked();
        xlSetError(ctx, "cannot allocate module");
        return NULL;
    }
    if ( !xlModuleRetainLoadedLibraries(module, ctx) ) {
        xrtFree(module);
        xlRuntimeReleaseManualUnlocked();
        return NULL;
    }
    module->state = s;
    module->ownsRuntimeRef = 1;
    module->ownershipTrace = (XL6_ModuleOwnershipTrace)xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_OWNER_TRACE]);
    {
        XL6_ModuleReadContractGetV1 getRead = (XL6_ModuleReadContractGetV1)
            xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_OWNER_READ]);
        const XL6_ModuleReadContractV1* read = getRead ? getRead() : NULL;
        if (getRead) {
            if (!read || read->size != sizeof(*read) || read->abiTag != 0x584C364D524431ULL ||
                !read->trace || read->trace != module->ownershipTrace) {
                xlModuleLoadedLibrariesFree(module); xrtFree(module);
                xlRuntimeReleaseManualUnlocked(); xlSetError(ctx, "invalid module ownership read V1 contract");
                return NULL;
            }
            module->ownershipReadContract = read;
        }
    }
    {
        XL6_ModuleRetirementGet get = (XL6_ModuleRetirementGet)xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_RETIREMENT_V1]);
        XL6_ModuleRetirementGetV2 getV2 = (XL6_ModuleRetirementGetV2)xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_RETIREMENT_V2]);
        XL6_ModuleRetirementGetV3 getV3 = (XL6_ModuleRetirementGetV3)xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_RETIREMENT_V3]);
        XL6_ModuleRetirementGetV4 getV4 = (XL6_ModuleRetirementGetV4)xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_RETIREMENT_V4]);
        const XL6_ModuleRetirementV1* contract = get ? get() : NULL;
        const XL6_ModuleRetirementV2* preparation = getV2 ? getV2() : NULL;
        const XL6_ModuleRetirementV3* preflight = getV3 ? getV3() : NULL;
        const XL6_ModuleRetirementV4* step = getV4 ? getV4() : NULL;
        if (contract && contract->size == sizeof(*contract) && contract->abiTag == 0x584C364D525431ULL &&
            contract->trace == module->ownershipTrace && contract->trace && contract->finish &&
            ((getV2 != NULL) + (getV3 != NULL) + (getV4 != NULL) <= 1) &&
            (!getV2 || (preparation && preparation->size == sizeof(*preparation) &&
                preparation->abiTag == 0x584C364D525432ULL && preparation->graph == contract && preparation->prepare)) &&
            (!getV3 || (preflight && preflight->size == sizeof(*preflight) &&
                preflight->abiTag == 0x584C364D525433ULL && preflight->graph == contract && preflight->preflight)) &&
            (!getV4 || (step && step->size == sizeof(*step) && step->abiTag == 0x584C364D525434ULL &&
                step->graph == contract && step->preflight && step->step))) {
            module->retirementContract = contract;
            module->retirementPreparation = preparation;
            module->retirementPreflight = preflight;
            module->retirementStep = step;
        }
        /* An advertised typed contract cannot silently fall back to bool:
         * that would reinterpret BUSY as a semantic failure or safe unload. */
        if (getV4 && !module->retirementStep) {
            xlModuleLoadedLibrariesFree(module); xrtFree(module);
            xlRuntimeReleaseManualUnlocked(); xlSetError(ctx, "invalid module retirement V4 contract");
            return NULL;
        }
    }
    module->codeOwnerGraph = (XL6_CodeOwnerGraph){
        {/* Only a graph-aware artifact may receive the tagged tail. A legacy
          * binder can copy just the prefix without normalizing its size. */
         module->ownershipTrace != NULL ? sizeof(XL6_CodeOwnerGraph) : sizeof(XL6_CodeOwner),
         module, xlModuleAcquireCode, xlModuleReleaseCode},
        0x584C36434F574E31ULL, &xlModuleOwnershipOps};
    {
        XL6_BindCodeOwnerProc bind = (XL6_BindCodeOwnerProc)xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_BIND_CODE]);
        XL6_BindOwnershipReadV1 bindRead = (XL6_BindOwnershipReadV1)
            xl__tcc.tcc_get_symbol(s, xlModuleNativeAbiNames[XL_MODULE_ABI_BIND_READ]);
        if (bindRead && (!bind || !module->ownershipReadContract || !module->retirementContract)) {
            xlModuleLoadedLibrariesFree(module); xrtFree(module);
            xlRuntimeReleaseManualUnlocked(); xlSetError(ctx, "module read binding requires certified owning slots and lifecycle");
            return NULL;
        }
        if (bind != NULL && !bind(&module->codeOwnerGraph.base)) {
            /* Binding only stores the capability. No acquisition is accepted
             * until it succeeds; the caller still owns TCC state on failure. */
            xlModuleLoadedLibrariesFree(module); xrtFree(module);
            xlRuntimeReleaseManualUnlocked(); xlSetError(ctx, "module code-owner binding failed");
            return NULL;
        }
        if (bindRead && !bindRead(xlModuleOwnershipReadBoundaryV1())) {
            /* Only the resident API supplies this independent capability.
             * No execution/acquisition has been admitted before both binds.
             * Failed binding leaves the caller owning the TCC state. */
            xlModuleLoadedLibrariesFree(module); xrtFree(module);
            xlRuntimeReleaseManualUnlocked(); xlSetError(ctx, "module ownership read binding failed");
            return NULL;
        }
    }
    if(module->retirementContract){
        const XL6_OwnershipDomainV1* domains[]={
#define XL6_OWNERSHIP_DOMAIN_ENTRY(Producer, Component, Getter) Getter(),
#include "src/runtime/xl6_ownership_domains.inc"
#undef XL6_OWNERSHIP_DOMAIN_ENTRY
        };
        module->ownershipCatalog=xl6OwnershipCatalogCreateV1(domains,sizeof(domains)/sizeof(*domains));
        if(!module->ownershipCatalog){
            xlModuleLoadedLibrariesFree(module);xrtFree(module);
            xlRuntimeReleaseManualUnlocked();xlSetError(ctx,"cannot initialize module ownership policy catalog");
            return NULL;
        }
    }
    module->codeOwnerReady = 1;
    return module;
}

/* Intrusive ownership: failed one-shot retirement must not lose the only
 * pointer to a module. No allocation is needed on this failure path. */
static XL_Module* xl__retiringModules;
static size_t xl__retirementPass;
static int xl__collectingRetirements;
static uint64 xl__collectingRetirementsThread;
/* API lifecycle exclusion serializes all host modules, including plans paused
 * for nonblocking Freeze admission. During callbacks the mutex is released,
 * but this guard prevents another driver from deleting any pinned module. */
static int xl__ownershipDriverRunning;
static uint64 xl__ownershipDriverThread;

/* Caller owns an entry/retirement pin and invokes outside the API mutex.
 * Semantic failure is captured by the surrounding error scope, never inferred
 * from the presence or absence of a diagnostic allocation. */
static XL6_ModuleRetireResult xlModuleRetirementStep(XL_Module* module, bool graph)
{
    if (module->retirementStep) {
        XL6_ModuleRetireResult result = module->retirementStep->step();
        if (result == XL6_MODULE_RETIRE_READY || result == XL6_MODULE_RETIRE_BUSY ||
            result == XL6_MODULE_RETIRE_FAILED) return result;
        xrtSetErrorKind(XERR_INTERNAL); return XL6_MODULE_RETIRE_FAILED;
    }
    if (graph) return module->retirementContract->finish() ? XL6_MODULE_RETIRE_READY : XL6_MODULE_RETIRE_FAILED;
    XL_ScriptUnitCheckedProc checked = (XL_ScriptUnitCheckedProc)xl__tcc.tcc_get_symbol(module->state, xlModuleNativeAbiNames[XL_MODULE_ABI_UNIT_CHECKED]);
    if (checked) return checked() ? XL6_MODULE_RETIRE_READY : XL6_MODULE_RETIRE_FAILED;
    XL_ScriptVoidProc unit = (XL_ScriptVoidProc)xl__tcc.tcc_get_symbol(module->state, xlModuleNativeAbiNames[XL_MODULE_ABI_UNIT]);
    if (unit) unit();
    return XL6_MODULE_RETIRE_READY;
}

static bool xlModuleSnapshotHold(const void* data)
{
    XL_Module* module = (XL_Module*)data; size_t count;
    if (!xlModuleOwnershipCount(module, &count) || count == SIZE_MAX) return false;
    ++module->snapshotRefs; return true;
}
static void xlModuleSnapshotDrop(const void* data)
{
    XL_Module* module = (XL_Module*)data;
    xlApiLock();
    if (!module->snapshotRefs) abort();
    --module->snapshotRefs;
    xlApiUnlock();
}
static bool xlModuleClaim(const void* data, const void* token)
{
    XL_Module* module = (XL_Module*)data;
    if (module->ownershipCleared ||
        (module->ownershipClaim && module->ownershipClaim != token)) return false;
    module->ownershipClaim = token; return true;
}
static void xlModuleRestore(const void* data, const void* token)
{
    XL_Module* module = (XL_Module*)data;
    if (module->ownershipClaim != token || module->ownershipCleared) abort();
    module->ownershipClaim = NULL;
}
static void xlModuleClear(const void* data, const void* token)
{
    XL_Module* module = (XL_Module*)data;
    if (module->ownershipClaim != token || module->ownershipCleared) abort();
    module->ownershipCleared = 1;
    /* Globals are quarantined retired slots until checked Finish. All owning
     * descendants have actual plan pins; no generated cleanup under Freeze. */
}
static xrtownershipfinishresult xlModuleFinishOwnershipV2(const void* data, const void* token)
{
    XL_Module* module = (XL_Module*)data;
    xl6_error_scope cleanup = {0}; xl6_error_result outcome;
    xlApiLock();
    if (module->ownershipClaim != token || !module->ownershipCleared) abort();
    if (module->retirementRunning) {
        xlApiUnlock(); return XRT_OWNERSHIP_FINISH_BUSY;
    }
    module->retirementRunning = 1;
    xlApiUnlock();
    if (!xl6ErrorScopeBegin(&cleanup)) abort();
    XL6_ModuleRetireResult result = xlModuleRetirementStep(module, true);
    if (result == XL6_MODULE_RETIRE_FAILED) xl6ErrorScopeCaptureFailure(&cleanup);
    outcome = xl6ErrorScopeEnd(&cleanup);
    xlApiLock();
    module->retirementRunning = 0;
    module->activation = outcome.ok && result == XL6_MODULE_RETIRE_READY
        ? XL_MODULE_INACTIVE : XL_MODULE_DEACTIVATION_PENDING;
    xlApiUnlock();
    if (!outcome.ok) xl6ErrorScopePropagateFailure(outcome);
    return !outcome.ok ? XRT_OWNERSHIP_FINISH_FAILED : result == XL6_MODULE_RETIRE_READY
        ? XRT_OWNERSHIP_FINISH_READY : XRT_OWNERSHIP_FINISH_BUSY;
}
static bool xlModuleFinishOwnership(const void* data, const void* token)
{ return xlModuleFinishOwnershipV2(data, token) == XRT_OWNERSHIP_FINISH_READY; }
static const XL6_OwnershipAdapterV1 xlModuleOwnershipAdapter = {sizeof(xlModuleOwnershipAdapter),
    xlModuleSnapshotHold, xlModuleSnapshotDrop, xlModuleClaim, xlModuleRestore,
    NULL, xlModuleClear, xlModuleFinishOwnership};
static bool xlModuleResolveOwnershipV3(xrtownershipref ref,void* context,
    const XL6_OwnershipAdapterV1** lifecycle,const xrtownershippreparationv1** preparation,
    const XL6_OwnershipFinishV1** completion)
{
    static const XL6_OwnershipFinishV1 moduleFinish={sizeof(moduleFinish),
        &xlModuleOwnershipAdapter,xlModuleFinishOwnershipV2};
    *lifecycle=NULL;*preparation=NULL;*completion=NULL;
    if(ref.Ops==&xlModuleOwnershipOps && ref.Data){
        const XL_Module* module=ref.Data;size_t count;
        if(!module->retirementContract || !xlModuleOwnershipCount(module,&count))return false;
        *lifecycle=&xlModuleOwnershipAdapter;
        *completion=module->retirementStep ? &moduleFinish : NULL;return true;
    }
    const XL_Module* module=context;
    return module && xl6OwnershipCatalogResolveV1(ref,module->ownershipCatalog,lifecycle,preparation,completion);
}
static XL6_OwnershipAdmissionV1 xlModuleProbeOwnershipV1(xrtownershipref ref,void* context,
    const XL6_OwnershipAdapterV1** adapter,const xrtownershippreparationv1** preparation,
    const XL6_OwnershipFinishV1** completion)
{
    *adapter=NULL;*preparation=NULL;*completion=NULL;
    if(ref.Ops==&xlModuleOwnershipOps){
        const XL_Module* candidate=ref.Data;
        if(!candidate || !candidate->state || !candidate->codeOwnerReady || !candidate->ownershipTrace ||
            !candidate->retirementContract || candidate->ownershipCleared)return XL6_OWNERSHIP_ADMISSION_REFUSED;
        if(candidate->retirementRunning ||
            ((candidate->activeCalls || xl6CodeOwnerScopeActive(&candidate->codeOwnerGraph.base)) && !xlModuleReadQuiescent(candidate)) ||
            candidate->activation==XL_MODULE_DEACTIVATING ||
            (candidate->activation==XL_MODULE_DEACTIVATION_PENDING && !candidate->retirementPrepared))return XL6_OWNERSHIP_ADMISSION_BUSY;
        return xlModuleResolveOwnershipV3(ref,context,adapter,preparation,completion)
            ? XL6_OWNERSHIP_ADMISSION_ADMITTED : XL6_OWNERSHIP_ADMISSION_REFUSED;
    }
    const XL_Module* module=context;
    return module ? xl6OwnershipCatalogProbeV1(ref,module->ownershipCatalog,adapter,preparation,completion)
        : XL6_OWNERSHIP_ADMISSION_REFUSED;
}
static bool xlModuleFinalizationOwnershipV1(xrtownershipref ref,void* context,
    const XL6_OwnershipAdapterV1* adapter,const xrtownershipfinalizationv1** output)
{
    const XL_Module* module=context;
    return xl6OwnershipCatalogResolveFinalizationV1(ref,module->ownershipCatalog,adapter,output);
}
/* Every host-module snapshot needs API state exclusion, including modules
 * which never import xlang. The probe remains nonblocking; callbacks run
 * after releasing both this boundary and the XRT ownership freeze. */
static bool xlModuleBoundaryEnter(void* unused){(void)unused;return xlApiTryLock()!=0;}
static void xlModuleBoundaryLeave(void* unused){(void)unused;xlApiUnlock();}
static const XL6_OwnershipBoundaryV1 xlModuleApiBoundary={sizeof(xlModuleApiBoundary),
    xlModuleBoundaryEnter,xlModuleBoundaryLeave,NULL,NULL};
#include "src/api/xl_xlang_handler.inc"

static XL6_OwnershipStepResult xlModuleOwnershipStepV2(XL6_OwnershipPlan* plan,
    XL6_OwnershipStepResult (*step)(XL6_OwnershipPlan*),xl6_error_result* outcome)
{
    xl6_error_scope scope={0};
    if(!xl6ErrorScopeBegin(&scope))abort();
    XL6_OwnershipStepResult status=step(plan);
    if(status==XL6_OWNERSHIP_STEP_FAILED)xl6ErrorScopeCaptureFailure(&scope);
    bool semanticFailure=scope.failed;
    *outcome=xl6ErrorScopeEnd(&scope);
    /* Snapshot allocation/admission failure only defers collection. Preserve
     * an independently reported callback failure even if a later rebuild
     * also fails; diagnostic allocation is never the semantic failure bit. */
    if(status==XL6_OWNERSHIP_STEP_ERROR && !semanticFailure){
        xrtErrorFree(outcome->error);*outcome=(xl6_error_result){true,NULL};
    }
    return status;
}
static XL6_OwnershipStepResult xlModuleOwnershipFinalizeStep(XL6_OwnershipPlan* plan,xl6_error_result* outcome)
{
    xl6_error_scope scope={0};if(!xl6ErrorScopeBegin(&scope))abort();
    bool failed=false;XL6_OwnershipStepResult status=xl6OwnershipPlanFinalizeStepV1(plan,&failed);
    if(failed || status==XL6_OWNERSHIP_STEP_FAILED)xl6ErrorScopeCaptureFailure(&scope);
    bool semanticFailure=scope.failed;*outcome=xl6ErrorScopeEnd(&scope);
    if(status==XL6_OWNERSHIP_STEP_ERROR && !semanticFailure){xrtErrorFree(outcome->error);*outcome=(xl6_error_result){true,NULL};}
    return status;
}
static void xlModuleOwnershipMergeOutcome(xl6_error_result* first,xl6_error_result next)
{
    if(!next.ok && first->ok)*first=next;else xrtErrorFree(next.error);
}
static bool xlModuleDiscoverOwnership(XL6_ModuleOwnershipVisit visit,void* visitorContext,void* context)
{
    const XL_Module* module=context;size_t count;
    /* Reject active generated code, construction/retirement transitions and
     * unsupported module contracts BEFORE inspecting the class registry.
     * Freeze and the existing host lifecycle driver exclusion span this
     * borrowed enumeration and its subsequent snapshot/pin transaction. */
    if(!module || !module->retirementContract || !xlModuleOwnershipCount(module,&count))return false;
    return xl6ClassOwnershipDiscoverV1(&module->codeOwnerGraph.base,visit,visitorContext);
}
static void xlModuleAdvanceOwnershipUnlocked(XL_Module* module)
{
    XL6_OwnershipPlanResult result; xerror* prior;
    xl6_error_result outcome = {true, NULL};
    if (xl__ownershipDriverRunning) return;
    xl__ownershipDriverRunning = 1; xl__ownershipDriverThread = xrtThreadCurrentId(); prior = xrtTakeError();
    module->ownershipAdmissionRefused=0;
    if (!module->ownershipPlan) {
        const XL6_OwnershipBoundaryV1* boundary=xl6OwnershipCatalogBoundaryV1Get(module->ownershipCatalog);
        result = xl6OwnershipPlanTryCreateV8((xrtownershipref){module, &xlModuleOwnershipOps},
            xlModuleProbeOwnershipV1, xlModuleDiscoverOwnership, xlModuleFinalizationOwnershipV1, false, module,
            boundary ? boundary : &xlModuleApiBoundary, &module->ownershipPlan);
        if (result <= XL6_OWNERSHIP_PLAN_BUSY) {
            module->ownershipAdmissionRefused=result==XL6_OWNERSHIP_PLAN_ERROR;goto done;
        }
        module->ownershipPhase = result == XL6_OWNERSHIP_PLAN_ROOTED ? 5 :
            result == XL6_OWNERSHIP_PLAN_PREPARATIONS ? 6 : 1;
    }
    /* A bounded driver turn. New semantic duties can request another pass;
     * BUSY/failure keeps the exact plan and real pins in the registry. */
    if (module->ownershipPhase == 6) {
        XL6_OwnershipStepResult prepared;xl6_error_result stage={true,NULL};
        xlApiUnlock();
        prepared=xlModuleOwnershipStepV2(module->ownershipPlan,xl6OwnershipPlanPrepare,&stage);xlApiLock();
        xlModuleOwnershipMergeOutcome(&outcome,stage);
        if(prepared==XL6_OWNERSHIP_STEP_ERROR)module->ownershipAdmissionRefused=1;
        if(!outcome.ok || prepared==XL6_OWNERSHIP_STEP_ERROR)module->ownershipPhase=5;
        else if(prepared==XL6_OWNERSHIP_STEP_READY)module->ownershipPhase=1;
        else goto done;
    }
    if (module->ownershipPhase == 1) {
        XL6_OwnershipStepResult finalized;xl6_error_result stage={true,NULL};
        xlApiUnlock();finalized=xlModuleOwnershipFinalizeStep(module->ownershipPlan,&stage);xlApiLock();
        xlModuleOwnershipMergeOutcome(&outcome,stage);
        if(finalized==XL6_OWNERSHIP_STEP_ERROR){module->ownershipAdmissionRefused=1;goto done;}
        if(finalized==XL6_OWNERSHIP_STEP_FAILED)module->ownershipPhase=5;
        else if(finalized==XL6_OWNERSHIP_STEP_BUSY || finalized==XL6_OWNERSHIP_STEP_WAITING)goto done;
        else module->ownershipPhase=2;
    }
    if (module->ownershipPhase == 2) {
        result = xl6OwnershipPlanTryCommit(module->ownershipPlan);
        if(result==XL6_OWNERSHIP_PLAN_ERROR)module->ownershipAdmissionRefused=1;
        if (result == XL6_OWNERSHIP_PLAN_READY) module->ownershipPhase = 3;
        else if (result == XL6_OWNERSHIP_PLAN_FINALIZERS) module->ownershipPhase = 1;
        else if (result == XL6_OWNERSHIP_PLAN_PREPARATIONS) module->ownershipPhase = 6;
        else if (result != XL6_OWNERSHIP_PLAN_BUSY) module->ownershipPhase = 5;
    }
    if (module->ownershipPhase == 3) {
        XL6_OwnershipStepResult finished;xl6_error_result stage={true,NULL};
        xlApiUnlock(); finished = xlModuleOwnershipStepV2(module->ownershipPlan, xl6OwnershipPlanFinishV2, &stage); xlApiLock();
        bool finishedOk=stage.ok;xlModuleOwnershipMergeOutcome(&outcome,stage);
        if(finished==XL6_OWNERSHIP_STEP_ERROR)module->ownershipAdmissionRefused=1;
        if (finishedOk && finished == XL6_OWNERSHIP_STEP_READY) module->ownershipPhase = 4;
    }
    if (module->ownershipPhase == 4 || module->ownershipPhase == 5) {
        /* Abort restores quarantine under its Freeze. Drop may invoke host
         * release hooks, so the API mutex must not span this operation. */
        xl6_error_scope dropping={0};if(!xl6ErrorScopeBegin(&dropping))abort();
        xlApiUnlock(); result = xl6OwnershipPlanTryDestroy(module->ownershipPlan); xlApiLock();
        bool dropFailed=dropping.failed;
        xl6_error_result dropOutcome=xl6ErrorScopeEnd(&dropping);
        if(result==XL6_OWNERSHIP_PLAN_ERROR && !dropFailed){xrtErrorFree(dropOutcome.error);dropOutcome=(xl6_error_result){true,NULL};}
        xlModuleOwnershipMergeOutcome(&outcome,dropOutcome);
        if(result==XL6_OWNERSHIP_PLAN_ERROR)module->ownershipAdmissionRefused=1;
        if (result == XL6_OWNERSHIP_PLAN_READY) {
            module->ownershipPlan = NULL; module->ownershipPhase = 0;
        }
    }
done:
    /* Snapshot refusal/OOM merely defers collection. A semantic finalizer's
     * explicit failure is different: latch it independently of allocation,
     * publish it at this void API boundary, and never repeat its physical duty.
     * The immutable diagnostic DAG is admitted on the next fresh plan. */
    if (!outcome.ok && !module->retirementFailed) {
        module->retirementFailed = 1;
        module->retirementError = xrtErrorRef(outcome.error);
    }
    xrtClearError(); xrtSetErrorTake(prior); xl__ownershipDriverThread = 0; xl__ownershipDriverRunning = 0;
    if (!outcome.ok) {
        if (prior != NULL) { xrtErrorFree(outcome.error); outcome.error = xrtErrorRef(prior); }
        xl6ErrorScopePropagateFailure(outcome);
    }
}

static void xlModuleUnqueueRetirementUnlocked(XL_Module* module)
{
    XL_Module** link = &xl__retiringModules;
    while (*link != NULL && *link != module) link = &(*link)->retirementNext;
    if (*link == module) *link = module->retirementNext;
    module->retirementQueued = 0; module->retirementNext = NULL;
}

static int xlModulePrepareRetirementUnlocked(XL_Module* module)
{
    xrtownershipscope admission = {0}; xl6_error_scope cleanup = {0};
    xl6_error_result outcome; XL6_ModulePrepareResult result;
    if ((!module->retirementPreparation && !module->retirementPreflight && !module->retirementStep) || module->retirementPrepared) return 1;
    /* A resident release may arrive inside its caller's mutation (or freeze).
     * Never join workers from that boundary. This short, nonblocking probe is
     * NOT a snapshot or permission to trace; release it before preparation. */
    if (!xrtOwnershipFreezeTryBegin(&admission)) return 0;
    if (!xrtOwnershipScopeEnd(&admission)) abort();
    if (module->preparationRefs || module->ownershipPlan || xl__ownershipDriverRunning) return 0;
    ++module->preparationRefs; module->retirementRunning = 1; xl__ownershipDriverRunning = 1;
    xl__ownershipDriverThread = xrtThreadCurrentId();
    xlApiUnlock();
    if (!xl6ErrorScopeBegin(&cleanup)) abort();
    result = module->retirementStep ? module->retirementStep->preflight()
        : module->retirementPreflight ? module->retirementPreflight->preflight()
        : module->retirementPreparation->prepare();
    if (result != XL6_MODULE_PREPARE_READY && result != XL6_MODULE_PREPARE_BUSY)
        xl6ErrorScopeCaptureFailure(&cleanup);
    outcome = xl6ErrorScopeEnd(&cleanup);
    xlApiLock();
    if (!module->preparationRefs || !module->retirementRunning || !xl__ownershipDriverRunning) abort();
    --module->preparationRefs; module->retirementRunning = 0;
    xl__ownershipDriverThread = 0; xl__ownershipDriverRunning = 0;
    if (outcome.ok && result == XL6_MODULE_PREPARE_READY) module->retirementPrepared = 1;
    if (!outcome.ok) {
        if (!module->retirementFailed) {
            module->retirementFailed = 1; module->retirementError = xrtErrorRef(outcome.error);
        }
        if (xrtGetError() != NULL) {
            xerror* primary = xrtErrorRef(xrtGetError());
            xrtErrorFree(outcome.error); outcome.error = primary;
        }
        xl6ErrorScopePropagateFailure(outcome);
    }
    return module->retirementPrepared;
}

static int xlModuleTryRetireUnlocked(XL_Module* module)
{
    XL_ScriptVoidProc errorUnit;
    XL_ScriptUnitCheckedProc checkedUnit;
    XL6_ModuleRetireResult retired;
    xl6_error_scope cleanup = {0}; xl6_error_result outcome;
    int ownsRuntimeRef;

    if (module == NULL) return 1;
    if(xl6ForeignCallbackActiveV1()){
        module->nativeTailRetirementPending=1;
        return 0;
    }
    if(module->nativeTailRetirementPending)return 0;
    if (module->activeCalls != 0 || module->retirementRunning || xl__ownershipDriverRunning ||
        (module->snapshotRefs && !module->ownershipPlan)) return 0;
    if (module->destroyRequested && !xlModulePrepareRetirementUnlocked(module)) return 0;
    if (module->ownershipPlan || (module->codeLeases != 0 && module->retirementContract && module->destroyRequested))
        xlModuleAdvanceOwnershipUnlocked(module);
    if (module->nativeTailRetirementPending || module->ownershipPlan || module->snapshotRefs != 0 || module->preparationRefs != 0 || module->codeLeases != 0) return 0;
    module->retirementRunning = 1;
    if ( module->state != NULL ) {
        checkedUnit = (XL_ScriptUnitCheckedProc)xl__tcc.tcc_get_symbol(module->state, xlModuleNativeAbiNames[XL_MODULE_ABI_UNIT_CHECKED]);
        /* Checked artifacts own an idempotent phase guard. One-shot execution
         * never activates the host module, but its cleanup may still be busy;
         * host INACTIVE alone is therefore not proof that code can be freed. */
        if ( module->activation != XL_MODULE_INACTIVE || checkedUnit != NULL || module->retirementStep ) {
            module->activation = XL_MODULE_DEACTIVATING;
            /* A failed caller's ambient diagnostic must not be mistaken for
             * failure to retire this module. Observe this operation's own
             * outcome in isolation, restoring the earlier diagnostic. */
            xl__ownershipDriverRunning = 1; xl__ownershipDriverThread = xrtThreadCurrentId();
            xlApiUnlock();
            if (!xl6ErrorScopeBegin(&cleanup)) abort();
            retired = xlModuleRetirementStep(module, false);
            if (retired == XL6_MODULE_RETIRE_FAILED) xl6ErrorScopeCaptureFailure(&cleanup);
            outcome = xl6ErrorScopeEnd(&cleanup);
            xlApiLock();
            xl__ownershipDriverThread = 0; xl__ownershipDriverRunning = 0;
            if (!outcome.ok) {
                module->activation = XL_MODULE_DEACTIVATION_PENDING;
                module->retirementRunning = 0;
                if (!module->retirementFailed) {
                    module->retirementFailed = 1; module->retirementError = xrtErrorRef(outcome.error);
                }
                if (xrtGetError() != NULL) {
                    xerror* primary = xrtErrorRef(xrtGetError());
                    xrtErrorFree(outcome.error); outcome.error = primary;
                }
                xl6ErrorScopePropagateFailure(outcome);
                return 0;
            }
            if (retired == XL6_MODULE_RETIRE_BUSY) {
                module->activation = XL_MODULE_DEACTIVATION_PENDING;
                module->retirementRunning = 0;
                return 0;
            }
            module->activation = XL_MODULE_INACTIVE;
        }
        errorUnit = (XL_ScriptVoidProc)xl__tcc.tcc_get_symbol(module->state, xlModuleNativeAbiNames[XL_MODULE_ABI_ERROR_UNIT]);
        if ( errorUnit != NULL ) {
            xerror* saved = xrtTakeError();
            errorUnit();
            xrtClearError(); xrtSetErrorTake(saved);
        }
        xl__tcc.tcc_delete(module->state);
        module->state = NULL;
    }
    xlModuleLoadedLibrariesFree(module);
    xlModuleUnqueueRetirementUnlocked(module);
    xrtErrorFree(module->retirementError);
    xl6OwnershipCatalogDestroyV1(module->ownershipCatalog);
    ownsRuntimeRef = module->ownsRuntimeRef;
    module->ownsRuntimeRef = 0;
    /* 最后一个运行时引用会关闭 XRT 内存池，模块外壳必须在此之前释放。 */
    xrtFree(module);
    if ( ownsRuntimeRef ) {
        xlRuntimeReleaseManualUnlocked();
    }
    return 1;
}

static void xlDestroyModuleUnlocked(XL_Module* module)
{
    if (module == NULL) return;
    module->destroyRequested = 1;
    if (!module->retirementQueued) {
        module->retirementNext = xl__retiringModules; xl__retiringModules = module;
        module->retirementQueued = 1;
    }
    (void)xlModuleTryRetireUnlocked(module);
}

static void xlCollectRetiringModulesUnlocked(void)
{
    XL_Module* module; size_t remaining = 0, pass;
    if (xl__collectingRetirements || xl__retiringModules == NULL) return;
    xl__collectingRetirements = 1;
    xl__collectingRetirementsThread = xrtThreadCurrentId();
    if (++xl__retirementPass == 0) {
        ++xl__retirementPass;
        for (module = xl__retiringModules; module != NULL; module = module->retirementNext) module->retirementPass = 0;
    }
    pass = xl__retirementPass;
    for (module = xl__retiringModules; module != NULL; module = module->retirementNext) ++remaining;
    while (remaining-- != 0) {
        /* Never retain a next pointer across callbacks: reentry can retire
         * another module or enqueue a new one. Each pass is bounded. */
        for (module = xl__retiringModules; module != NULL; module = module->retirementNext)
            if (module->retirementPass != pass) break;
        if (module == NULL) break;
        module->retirementPass = pass; (void)xlModuleTryRetireUnlocked(module);
    }
    xl__collectingRetirementsThread = 0; xl__collectingRetirements = 0;
}

XL_RuntimeDrainResult xlRuntimeDrainRetiringChecked(long long milliseconds)
{
    xl6_error_scope scope={0};bool ready=false;
    if(!xl6ErrorScopeBegin(&scope))return (XL_RuntimeDrainResult){0,0};
    if(milliseconds< -1){xrtSetErrorKind(XERR_ARGUMENT);xl6ErrorScopeCaptureFailure(&scope);goto drain_end;}
    if(xl6ForeignCallbackActiveV1())goto drain_end;
    /* This explicit host operation requires native publishers to be stopped
     * and joined, as well as no further language entries. A different thread's
     * arbitrary checked boundary cannot certify a native DLL's return tail.
     * Acknowledge only the initial batch; new tails created by cleanup callbacks
     * need a later explicit drain rather than being cleared inside this loop. */
    xlApiLock();
    for(XL_Module* module=xl__retiringModules;module;module=module->retirementNext){
        module->nativeTailRetirementPending=0;
        if(!xl__ownershipDriverRunning && module->ownershipPlan && module->ownershipPhase==1 &&
           !xl6OwnershipPlanRetryFinalizationV1(module->ownershipPlan))xl6ErrorScopeCaptureFailure(&scope);
    }
    xlApiUnlock();
    uint64 timeout=milliseconds<0 ? UINT64_MAX : (uint64)milliseconds;
    XL6_DeadlineV1 deadline=xl6DeadlineAfterMillisecondsV1(timeout);
    const uint64 caller=xrtThreadCurrentId();
    for(;;){
        xlApiLock();bool active=xl__collectingRetirements || xl__ownershipDriverRunning,recovery=false,nativeTailBusy=false;
        /* Only a callback on the current driver thread must return BUSY to
         * avoid self-deadlock. Another thread's outside-lock cleanup is real
         * progress to wait for, subject to this caller's deadline. Owner IDs
         * and both admission flags are read/written under the API mutex. */
        bool reentry=(xl__collectingRetirements && xl__collectingRetirementsThread==caller) ||
            (xl__ownershipDriverRunning && xl__ownershipDriverThread==caller);
        if(!active){
            /* Observe an earlier no-diagnostic failure before a successful
             * retry can finish and free that module's physical record. */
            for(XL_Module* module=xl__retiringModules;module && !scope.failed;module=module->retirementNext)
                if(module->retirementFailed){
                    if(!xrtGetError())xrtSetErrorTake(xrtErrorRef(module->retirementError));
                    xl6ErrorScopeCaptureFailure(&scope);
                }
            xlCollectRetiringModulesUnlocked();
            for(XL_Module* module=xl__retiringModules;module;module=module->retirementNext)
                nativeTailBusy|=module->nativeTailRetirementPending!=0;
            for(XL_Module* module=xl__retiringModules;module;module=module->retirementNext)
                if(module->retirementFailed || module->ownershipAdmissionRefused){
                    recovery=true;
                    if(!scope.failed){
                        if(!xrtGetError()){
                            if(module->retirementFailed)xrtSetErrorTake(xrtErrorRef(module->retirementError));
                            else xrtSetErrorKind(XERR_STATE);
                        }
                        xl6ErrorScopeCaptureFailure(&scope);
                    }
                }
            ready=xl__retiringModules==NULL;
        }
        xlApiUnlock();
        if(ready || reentry || recovery || nativeTailBusy || (milliseconds>=0 && xl6DeadlineExpiredV1(deadline)))break;
        xrtThreadYield();
    }
drain_end:;
    xl6_error_result outcome=xl6ErrorScopeEnd(&scope);bool ok=outcome.ok;
    if(!ok){
        /* An ambient caller failure is still first, but failure without a
         * diagnostic must also reach an enclosing checked foreign scope. */
        xerror* prior=xrtTakeError();
        if(prior){xrtErrorFree(outcome.error);outcome.error=prior;}
        xl6ErrorScopePropagateFailure(outcome);
    }else xrtErrorFree(outcome.error);
    return (XL_RuntimeDrainResult){ready,ok};
}
static int xlModuleAcquireCode(void* data)
{
    XL_Module* module = (XL_Module*)data; int ok = 0;
    xlApiLock();
    if (module != NULL && module->codeOwnerReady && !module->destroyRequested && !module->retirementRunning && !module->ownershipClaim &&
        module->activation != XL_MODULE_DEACTIVATING && module->activation != XL_MODULE_DEACTIVATION_PENDING &&
        module->codeLeases != SIZE_MAX) {
        ++module->codeLeases; ok = 1;
    }
    xlApiUnlock(); return ok;
}

static void xlModuleReleaseCode(void* data)
{
    XL_Module* module = (XL_Module*)data;
    xerror* saved = xrtTakeError();
    xlApiLock();
    if (module == NULL || module->codeLeases == 0) abort();
    --module->codeLeases;
    if (module->destroyRequested) (void)xlModuleTryRetireUnlocked(module);
    xlApiUnlock();
    xrtClearError(); xrtSetErrorTake(saved);
}

static void xlModuleEndCallUnlocked(XL_Module* module)
{
    if (module == NULL || module->activeCalls == 0) return;
    module->activeCalls -= 1;
    if ( module->activeCalls == 0 && module->destroyRequested ) {
        xlDestroyModuleUnlocked(module);
    }
}

static void xlModuleRequestDestroyUnlocked(XL_Module* module)
{
    xlDestroyModuleUnlocked(module);
}

static XL_Module* xlCompileUnitToModuleWithC(
    XL_Context* ctx, XL6_CompileUnit* unit,
    const XL6_IrCgenOptions* requestedOptions,
    const XL_StringList* cSourceFiles)
{
    TCCState* s;
    XL_Module* module;
    char* cText;
    XL6_IrCgenOptions options = {0};

    s = NULL;
    module = NULL;
    cText = NULL;
    if ( requestedOptions != NULL ) options = *requestedOptions;
    options.emitScriptEntry = 1;
    options.emitMainWrapper = 0;
    xlTccDynamicVfsClear();
    if ( !xlCgenToMemory(ctx, unit, &cText, &options) ) {
        goto cleanup;
    }
#if XL_ENABLE_EXE_COMPILER
    if ( !xlSaveTempTextByName(ctx, "module.c", cText) ) {
        goto cleanup;
    }
#endif
    s = xlCreateTccState(ctx, TCC_OUTPUT_MEMORY);
    if ( s == NULL ) {
        goto cleanup;
    }
    if ( !xlTccPrepareNativeSources(ctx, s, unit, cSourceFiles) ) {
        goto cleanup;
    }
    if ( !xlTccCompileGeneratedModule(ctx, s, cText) ) {
        goto cleanup;
    }
    if ( !xlCompileUnitCSourceFiles(ctx, s, unit, cSourceFiles) ) {
        goto cleanup;
    }
    /* Publish language roots before archive selection as well as refreshing
       them after imports. The linker can then ignore dependencies occurring
       only in dead Native policy functions without discarding input state. */
    if (!xlTccRootLanguageModule(ctx, s, unit)) goto cleanup;
    if ( !xlAddDependenciesToTcc(ctx, s, unit) ) {
        goto cleanup;
    }
    if (!xlTccRootLanguageModule(ctx, s, unit)) goto cleanup;
    if ( xl__tcc.tcc_relocate(s) != 0 ) {
        if ( ctx != NULL && ctx->lastError == NULL ) {
            xlSetError(ctx, "TCC relocate failed");
        }
        goto cleanup;
    }
    module = xlCreateModuleFromState(ctx, s);
    if ( module != NULL ) {
        s = NULL;
    }

cleanup:
    if ( s != NULL ) {
        xl__tcc.tcc_delete(s);
    }
    xrtFree(cText);
    xlTccDynamicVfsClear();
    return module;
}

static XL_Module* xlCompileUnitToModuleEx(XL_Context* ctx, XL6_CompileUnit* unit, const XL6_IrCgenOptions* options)
{
    return xlCompileUnitToModuleWithC(ctx, unit, options, NULL);
}

static XL_Module* xlCompileUnitToModule(XL_Context* ctx, XL6_CompileUnit* unit)
{
    return xlCompileUnitToModuleEx(ctx, unit, NULL);
}

static XL_Module* xlCompileCSourceTextToModule(XL_Context* ctx, const char* source, const char* virtualPath)
{
    TCCState* s;
    XL_Module* module;
    const char* path;

    if ( source == NULL ) {
        xlSetError(ctx, "C source is empty");
        return NULL;
    }
    path = virtualPath != NULL && virtualPath[0] != '\0' ? virtualPath : XL_TCC_VFS_C_MODULE_C;
    s = NULL;
    module = NULL;
    xlTccDynamicVfsClear();
    s = xlCreateTccState(ctx, TCC_OUTPUT_MEMORY);
    if ( s == NULL ) {
        goto cleanup;
    }
    xlTccSelectFullRuntime(s);
    if ( !xlTccCompileSourceText(ctx, s, path, source, "TCC C compile failed") ) {
        goto cleanup;
    }
    if ( !xlAddDependenciesToTcc(ctx, s, NULL) ) {
        goto cleanup;
    }
    if ( xl__tcc.tcc_relocate(s) != 0 ) {
        if ( ctx != NULL && ctx->lastError == NULL ) {
            xlSetError(ctx, "TCC C relocate failed");
        }
        goto cleanup;
    }
    module = xlCreateModuleFromState(ctx, s);
    if ( module != NULL ) {
        s = NULL;
    }

cleanup:
    if ( s != NULL ) {
        xl__tcc.tcc_delete(s);
    }
    xlTccDynamicVfsClear();
    return module;
}

static int xlAddCSourceFilesToTcc(XL_Context* ctx, TCCState* s, const char** paths, int pathCount)
{
    int i;

    if ( s == NULL ) {
        xlSetError(ctx, "TCC state is empty");
        return 0;
    }
    if ( paths == NULL || pathCount <= 0 ) {
        xlSetError(ctx, "C source file list is empty");
        return 0;
    }
    if ( pathCount > XLC_MAX_C_SOURCE_FILES ) {
        xlSetError(ctx, "too many C source files");
        return 0;
    }
    xlTccSelectFullRuntime(s);
    for ( i = 0; i < pathCount; ++i ) {
        if ( paths[i] == NULL || paths[i][0] == '\0' ) {
            xlSetError(ctx, "C source file path is empty");
            return 0;
        }
        if ( xl__tcc.tcc_add_file(s, paths[i]) != 0 ) {
            if ( ctx != NULL && ctx->lastError == NULL ) {
                xlSetError2(ctx, "cannot compile C source file", paths[i]);
            }
            return 0;
        }
    }
    return 1;
}

static XL_Module* xlCompileCSourceFilesToModuleUnlocked(XL_Context* ctx, const char** paths, int pathCount)
{
    TCCState* s;
    XL_Module* module;

    s = NULL;
    module = NULL;
    xlTccDynamicVfsClear();
    s = xlCreateTccState(ctx, TCC_OUTPUT_MEMORY);
    if ( s == NULL ) {
        goto cleanup;
    }
    if ( !xlAddCSourceFilesToTcc(ctx, s, paths, pathCount) ) {
        goto cleanup;
    }
    if ( !xlAddDependenciesToTcc(ctx, s, NULL) ) {
        goto cleanup;
    }
    if ( xl__tcc.tcc_relocate(s) != 0 ) {
        if ( ctx != NULL && ctx->lastError == NULL ) {
            xlSetError(ctx, "TCC C relocate failed");
        }
        goto cleanup;
    }
    module = xlCreateModuleFromState(ctx, s);
    if ( module != NULL ) {
        s = NULL;
    }

cleanup:
    if ( s != NULL ) {
        xl__tcc.tcc_delete(s);
    }
    xlTccDynamicVfsClear();
    return module;
}

static XL_Module* xlCompileCSourceFileToModuleUnlocked(XL_Context* ctx, const char* path)
{
    const char* paths[1];

    paths[0] = path;
    return xlCompileCSourceFilesToModuleUnlocked(ctx, paths, 1);
}

static int xlRunModuleMainUnlocked(
    XL_Context* ctx,
    XL_Module* module,
    xvalue* pSuppliedArg
)
{
    XL_XlangMainProc entry;
    XL_ScriptMainCheckedProc checkedEntry;
    XL6_ModuleRetireResult retired;
    xl6_error_scope cleanup = {0};
    xl6_error_result outcome;
    xvalue* pRunArg;
    int rc, ok;

    if ( ctx == NULL || module == NULL || module->state == NULL ) {
        xlSetError(ctx, "module is empty");
        return 0;
    }
    if ( module->activation != XL_MODULE_INACTIVE ) {
        xlSetError(ctx, "active module cannot run as a one-shot script");
        return 0;
    }
    entry = (XL_XlangMainProc)xl__tcc.tcc_get_symbol(module->state, xlModuleNativeAbiNames[XL_MODULE_ABI_ENTRY]);
    checkedEntry = (XL_ScriptMainCheckedProc)xl__tcc.tcc_get_symbol(module->state, xlModuleNativeAbiNames[XL_MODULE_ABI_ENTRY_CHECKED]);
    if ( entry == NULL && checkedEntry == NULL ) {
        xlSetError(ctx, "script entry xlang_main not found");
        return 0;
    }
    pRunArg = NULL;
    if ( !xlPrepareRuntimeArg(ctx, pSuppliedArg, &pRunArg) ) {
        return 0;
    }
    /*
     * module 已经完成编译和 relocate。执行用户入口时释放 API 全局锁，
     * 允许服务线程中的 XLangHandler 复用已编译模块。
     */
    xlApiUnlock();
    if ( checkedEntry != NULL ) ok = checkedEntry(pRunArg, &rc);
    else { rc = entry(pRunArg); ok = 1; }
    if ( !xl6ErrorScopeBeginCleanup(&cleanup, !ok) ) abort();
    xrtValueRelease(pRunArg);
    if ( xrtGetError() != NULL ) xl6ErrorScopeCaptureFailure(&cleanup);
    /* A one-shot run never becomes an activated module. Close its language
     * lifetime here, before TCC destruction and while callbacks may use the
     * unlocked API. Verified XLIR cleanup preserves the original exception;
     * older entries that already unload have an idempotent module unit. */
    retired = xlModuleRetirementStep(module, false);
    if (retired == XL6_MODULE_RETIRE_FAILED) xl6ErrorScopeCaptureFailure(&cleanup);
    outcome = xl6ErrorScopeEnd(&cleanup);
    xrtSetErrorTake(outcome.error);
    xlApiLock();
    if (retired != XL6_MODULE_RETIRE_READY || !outcome.ok)
        module->activation = XL_MODULE_DEACTIVATION_PENDING;
    if ( xlCheckScriptActiveError(ctx, module->state) ) {
        return 0;
    }
    if ( !outcome.ok ) {
        xlSetError(ctx, "script execution or cleanup failed without a diagnostic");
        return 0;
    }
    ctx->lastExitCode = rc;
    return 1;
}

/* Consumes the caller's sole module handle. The entry lease stays held until
 * Destroy has transferred ownership to the resident retirement queue. Never
 * touch module after EndCall: cleanup or the last code lease may free it. */
static int xlRunAndRetireModuleUnlocked(XL_Context* ctx, XL_Module* module, xvalue* arg)
{
    int ok;
    XL6_ModuleCall call = {0};
    if (!xlModuleBeginCallUnlocked(module)) {
        xlDestroyModuleUnlocked(module);
        return 0;
    }
    xlModuleCallAttachUnlocked(module,&call);
    ok = xlRunModuleMainUnlocked(ctx, module, arg);
    xlDestroyModuleUnlocked(module);
    xlModuleCallDetachUnlocked(module,&call);
    xlModuleEndCallUnlocked(module);
    return ok;
}

static int xlCompileAndRunUnit(XL_Context* ctx, XL6_CompileUnit* unit, xvalue* arg)
{
    XL_Module* module;
    /* One compiler/binder and one checked execution/retirement path. Neither
     * a busy finalizer nor an accepted continuation permits raw tcc_delete. */
    module = xlCompileUnitToModuleWithC(ctx, unit, NULL, NULL);
    if (module == NULL) return 0;
    return xlRunAndRetireModuleUnlocked(ctx, module, arg);
}

static int xlActivateModuleUnlocked(
    XL_Context* ctx,
    XL_Module* module,
    xvalue* pSuppliedArg
)
{
    XL_ScriptModuleInitProc entry;
    XL6_ModuleRetireResult retired = XL6_MODULE_RETIRE_READY;
    xl6_error_scope cleanup = {0};
    xl6_error_result outcome;
    xvalue* pRunArg;
    int result;

    if ( ctx == NULL || module == NULL || module->state == NULL ) {
        xlSetError(ctx, "module is empty");
        return 0;
    }
    if (module->activation == XL_MODULE_DEACTIVATING || module->activation == XL_MODULE_DEACTIVATION_PENDING) {
        xlSetError(ctx, "module deactivation must complete before activation");
        return 0;
    }
    if ( module->activation == XL_MODULE_ACTIVE ) {
        return 1;
    }
    entry = (XL_ScriptModuleInitProc)xl__tcc.tcc_get_symbol(module->state, xlModuleNativeAbiNames[XL_MODULE_ABI_INIT]);
    if ( entry == NULL ) {
        module->activation = XL_MODULE_ACTIVE;
        return 1;
    }
    pRunArg = NULL;
    if ( !xlPrepareRuntimeArg(ctx, pSuppliedArg, &pRunArg) ) {
        return 0;
    }
    xlApiUnlock();
    result = entry(pRunArg);
    if ( !xl6ErrorScopeBeginCleanup(&cleanup, !result) ) abort();
    xrtValueRelease(pRunArg);
    if ( xrtGetError() != NULL ) xl6ErrorScopeCaptureFailure(&cleanup);
    /* V4 initialization may fail with partially created services even after
     * IR rollback has cleared every language global. Retain their physical
     * cleanup state and preserve the original initialization failure. */
    if (cleanup.failed && (result || module->retirementStep)) {
        retired = xlModuleRetirementStep(module, false);
        if (retired == XL6_MODULE_RETIRE_FAILED) xl6ErrorScopeCaptureFailure(&cleanup);
    }
    outcome = xl6ErrorScopeEnd(&cleanup);
    xrtSetErrorTake(outcome.error);
    xlApiLock();
    if (retired != XL6_MODULE_RETIRE_READY) module->activation = XL_MODULE_DEACTIVATION_PENDING;
    if ( xlCheckScriptActiveError(ctx, module->state) ) {
        return 0;
    }
    if ( !outcome.ok ) {
        xlSetError(ctx, "module initialization failed");
        return 0;
    }
    module->activation = XL_MODULE_ACTIVE;
    return 1;
}

static int xlDeactivateModuleUnlocked(XL_Context* ctx, XL_Module* module)
{
    XL6_ModuleRetireResult retired;
    xl6_error_scope cleanup = {0};
    xl6_error_result outcome;

    if ( ctx == NULL || module == NULL || module->state == NULL ) {
        xlSetError(ctx, "module is empty");
        return 0;
    }
    if ( module->activation == XL_MODULE_INACTIVE ) {
        return 1;
    }
    /* A residency lease is not an execution lease. Module-owned globals with
     * generated finalizers necessarily hold code leases until this retirement
     * step releases them, and external leases keep the image mapped after
     * deactivation. Destruction, not semantic deactivation, resolves that
     * ownership graph. Only concurrent API execution/deactivation is busy. */
    if (module->activation == XL_MODULE_DEACTIVATING || module->activeCalls > 1) {
        xlSetError(ctx, "module is busy executing an entry or deactivation");
        return 0;
    }
    module->activation = XL_MODULE_DEACTIVATING;
    xlApiUnlock();
    if ( !xl6ErrorScopeBeginCleanup(&cleanup, false) ) abort();
    retired = xlModuleRetirementStep(module, false);
    if (retired == XL6_MODULE_RETIRE_FAILED) xl6ErrorScopeCaptureFailure(&cleanup);
    outcome = xl6ErrorScopeEnd(&cleanup);
    xrtSetErrorTake(outcome.error);
    xlApiLock();
    /* Commit only after the checked outcome is acknowledged. Preserve the
     * retry state even if script error reporting consumes the diagnostic. */
    module->activation = XL_MODULE_DEACTIVATION_PENDING;
    if ( xlCheckScriptActiveError(ctx, module->state) ) return 0;
    if ( !outcome.ok ) {
        xlSetError(ctx, "module cleanup failed without a diagnostic");
        return 0;
    }
    if (retired == XL6_MODULE_RETIRE_BUSY) {
        xlSetError(ctx, "module cleanup is pending; retry after outstanding work completes");
        return 0;
    }
    module->activation = XL_MODULE_INACTIVE;
    return 1;
}

static int xlRunCModuleMainUnlocked(XL_Context* ctx, XL_Module* module, int argc, char** argv)
{
    if ( ctx == NULL || module == NULL || module->state == NULL ) {
        xlSetError(ctx, "module is empty");
        return 0;
    }
    return xlRunMainInState(ctx, module->state, argc, argv, "C entry main not found", "C main returned");
}

#if XL_ENABLE_EXE_COMPILER
static int xlEmitUnitCToFile(XL_Context* ctx, XL6_CompileUnit* unit,
                             const char* outputPath,
                             const XL6_IrCgenOptions* requestedOptions)
{
    XL6_IrCgenOptions options = {0};
    XL6_Output out;
    int ok;
    if ( outputPath == NULL || outputPath[0] == '\0' ) { xlSetError(ctx, "output C path is empty"); return 0; }
    if ( !xlEnsureUnitXlirLowered(ctx, unit) ) return 0;
    if ( !xl6IrCgenVerifyEmittable(&unit->ir, &unit->parse.diags) ) { xlSetCompileStageError(ctx, unit, "cgen-verify"); return 0; }
    if ( !xl6OutputOpenFile(&out, outputPath) ) { xlSetError2(ctx, "cannot open XLIR C output", outputPath); return 0; }
    if ( requestedOptions != NULL ) options = *requestedOptions;
    ok = xl6IrCgenEmitCEx(&out, &unit->ir, &unit->parse.diags, &options);
    if ( xl6OutputHasFailed(&out) ) { xlSetError2(ctx, "cannot write XLIR C output", xl6OutputError(&out)); ok = 0; }
    else if ( !ok ) xlSetCompileStageError(ctx, unit, "cgen-emit");
    if ( !ok ) {
        xl6OutputDiscard(&out);
        return 0;
    }
    xl6OutputClose(&out);
    if ( xl6OutputHasFailed(&out) ) {
        xlSetError2(ctx, "cannot write XLIR C output", xl6OutputError(&out));
        return 0;
    }
    return 1;
}

static int xlEmitUnitDebugCToFile(XL_Context* ctx, XL6_CompileUnit* unit, const char* outputPath, const char* debugSourcePath)
{
    XL6_IrCgenOptions options;

    memset(&options, 0, sizeof(options));
    options.debugMode = 1;
    options.debugSourcePath = debugSourcePath;
    return xlEmitUnitCToFile(ctx, unit, outputPath, &options);
}

static int xlEmitUnitHeaderToFile(XL_Context* ctx, XL6_CompileUnit* unit,
                                  const char* outputPath, const char* guardName)
{
    XL6_Output out;
    int ok;

    if ( outputPath == NULL || outputPath[0] == '\0' ) {
        xlSetError(ctx, "output header path is empty");
        return 0;
    }
    if ( unit == NULL || unit->parse.root == NULL ) {
        xlSetError(ctx, "compile unit is empty");
        return 0;
    }
    if ( !xlEnsureUnitXlirLowered(ctx, unit) )
        return 0;
    if ( !xl6OutputOpenFile(&out, outputPath) ) {
        xlSetError2(ctx, "cannot open header output", outputPath);
        return 0;
    }
    ok = xl6IrCgenEmitHeader(&out, &unit->ir,
                             guardName != NULL && guardName[0] != '\0' ? guardName : "XL6_GENERATED_HEADER_H",
                             &unit->parse.diags);
    if ( xl6OutputHasFailed(&out) ) {
        xlSetError2(ctx, "cannot write header output", xl6OutputError(&out));
        ok = 0;
    } else if ( !ok ) {
        xlSetCompileDiagError(ctx, unit);
    }
    if ( !ok ) {
        xl6OutputDiscard(&out);
        return 0;
    }
    xl6OutputClose(&out);
    if ( xl6OutputHasFailed(&out) ) {
        xlSetError2(ctx, "cannot write header output", xl6OutputError(&out));
        return 0;
    }
    return 1;
}

static int xlcOutputOpen(XL_Context* ctx, XL6_Output* out, const char* outputPath, const char* desc)
{
    int ok;

    if ( outputPath == NULL || outputPath[0] == '\0' || strcmp(outputPath, "-") == 0 ) {
        xl6OutputInitStdFile(out, stdout);
        return !xl6OutputHasFailed(out);
    }
    ok = xl6OutputOpenFile(out, outputPath);
    if ( !ok ) {
        xlSetError2(ctx, desc != NULL ? desc : "cannot open output", outputPath);
    }
    return ok;
}

static int xlcOutputClose(XL_Context* ctx, XL6_Output* out, const char* desc)
{
    xl6OutputClose(out);
    if ( xl6OutputHasFailed(out) ) {
        xlSetError2(ctx, desc != NULL ? desc : "cannot write output", xl6OutputError(out));
        return 0;
    }
    return 1;
}

static const char* xlcSourceLabel(const XLC_Context* ctx)
{
    if ( ctx == NULL ) {
        return "<none>";
    }
    if ( ctx->sourceKind == XLC_SOURCE_FILE ) {
        return ctx->sourcePath != NULL ? ctx->sourcePath : "<file>";
    }
    if ( ctx->sourceKind == XLC_SOURCE_STRING ) {
        return ctx->virtualPath != NULL ? ctx->virtualPath : "<string>";
    }
    return "<none>";
}

static void xlcEmitDiagText(XL6_Output* out, const XL6_DiagList* diags, const char* path, const char* phase, int success)
{
    size_t i;

    if ( success ) {
        xl6OutputPuts("ok\n", out);
        return;
    }
    if ( diags == NULL || diags->count == 0 ) {
        xl6OutputPrintf(out, "%s: [%s] compile failed\n",
                        path != NULL ? path : "<memory>",
                        phase != NULL ? phase : "compile");
        return;
    }
    for ( i = 0; i < diags->count; ++i ) {
        const XL6_Diag* diag = &diags->items[i];
        xl6OutputPrintf(out,
                        "%s:%d:%d: [%s] %s\n",
                        diag->file ? diag->file : (path != NULL ? path : "<memory>"),
                        diag->line,
                        diag->column,
                        phase != NULL ? phase : "compile",
                        diag->message != NULL ? diag->message : "compile error");
    }
}

static int xlcParseSourceUnlocked(XLC_Context* ctx, XL6_ParseResult* result)
{
    int ok;

    xl6ParseResultInit(result);
    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    if ( ctx->sourceKind == XLC_SOURCE_FILE ) {
        ok = xl6SourceOverlayParse(&ctx->sourceOverlay, ctx->sourcePath, result);
    } else if ( ctx->sourceKind == XLC_SOURCE_STRING ) {
        ok = xl6ParseSource(ctx->sourceText, ctx->virtualPath, result);
    } else {
        xlSetError(ctx->runtime, "compiler source is empty");
        return 0;
    }
    if ( !ok ) {
        if ( result->diags.count > 0 ) {
            char text[1200];
            const XL6_Diag* diag = &result->diags.items[0];
            snprintf(text,
                     sizeof(text),
                     "%s:%d:%d: [parse] %s",
                     xlcSourceLabel(ctx),
                     diag->line,
                     diag->column,
                     diag->message != NULL ? diag->message : "parse error");
            xlSetError(ctx->runtime, text);
        } else {
            xlSetError(ctx->runtime, "xlang parse failed");
        }
    }
    return ok;
}

static xvalue* xlcCreateArgArray(XL_Context* runtime, int argc, char** argv)
{
    xvalue* pArgs;
    int i;

    pArgs = xrtValueArray();
    if ( pArgs == NULL ) {
        xlSetError(runtime, "cannot create script arg array");
        return NULL;
    }
    for ( i = 0; i < argc; ++i ) {
        const char* text = argv != NULL && argv[i] != NULL ? argv[i] : "";
        if ( !xrtValueArrayAppendNew(
            pArgs,
            xrtValueString(xrtStrView(text))
        ) ) {
            xrtValueRelease(pArgs);
            xlSetError(runtime, "cannot append script argument");
            return NULL;
        }
    }
    return pArgs;
}
#endif

static void xlDestroyContextUnlocked(XL_Context* ctx)
{
    if ( ctx == NULL ) {
        return;
    }
    xrtFree(ctx->baseDir);
    xrtFree(ctx->workDir);
    xrtFree(ctx->tempDir);
    xrtFree(ctx->tccDllPath);
    xrtFree(ctx->tccLibPath);
    xrtFree(ctx->tccIncludePath);
    xrtFree(ctx->tccWinIncludePath);
    xrtFree(ctx->tccWinapiIncludePath);
    xrtFree(ctx->tccLibSearchPath);
    xrtFree(ctx->tccLibtcc1Path);
    xrtFree(ctx->lastError);
    xlStringListFree(&ctx->includePaths);
    xlCompiledPackagesFree(&ctx->compiledPackages);
    xlStringListFree(&ctx->libraryPaths);
    xlStringListFree(&ctx->linkLibraries);
    xlStringListFree(&ctx->resourceFiles);
    xlFreeSymbols(ctx);
    xlLoadedLibrariesFree(ctx);
    xrtFree(ctx);
    xlRuntimeReleaseContextUnlocked();
}

/*
 * 用户入口执行期间会暂时释放全局 API 锁。执行租约保证并发销毁只会
 * 标记上下文关闭，真正释放延迟到最后一个入口返回之后。
 */
static int xlContextBeginCallUnlocked(XL_Context* ctx)
{
    if ( ctx == NULL || ctx->destroyRequested ) {
        return 0;
    }
    ctx->activeCalls += 1;
    return 1;
}

static void xlContextEndCallUnlocked(XL_Context* ctx)
{
    if ( ctx == NULL || ctx->activeCalls == 0 ) {
        return;
    }
    ctx->activeCalls -= 1;
    if ( ctx->activeCalls == 0 && ctx->destroyRequested ) {
        xlDestroyContextUnlocked(ctx);
    }
}

static void xlContextRequestDestroyUnlocked(XL_Context* ctx)
{
    if ( ctx == NULL || ctx->destroyRequested ) {
        return;
    }
    ctx->destroyRequested = 1;
    if ( ctx->activeCalls == 0 ) {
        xlDestroyContextUnlocked(ctx);
    }
}

XL_Context* xlCreateContext(const XL_ContextOptions* options)
{
    XL_ContextOptions localOptions;
    XL_Context* ctx;

    xlApiLock();
    if ( !xlRuntimeAcquireContextUnlocked() ) {
        xlApiUnlock();
        return NULL;
    }
    localOptions = options != NULL ? *options : xlDefaultContextOptions();
    if ( localOptions.size != 0 && localOptions.size < sizeof(XL_ContextOptions) ) {
        xlRuntimeReleaseContextUnlocked();
        xlApiUnlock();
        return NULL;
    }
    if ( localOptions.version != 0 && localOptions.version != XL_API_VERSION ) {
        xlRuntimeReleaseContextUnlocked();
        xlApiUnlock();
        return NULL;
    }
    ctx = (XL_Context*)xrtCalloc(1, sizeof(XL_Context));
    if ( ctx == NULL ) {
        xlRuntimeReleaseContextUnlocked();
        xlApiUnlock();
        return NULL;
    }
    ctx->baseDir = xlGetCurrentDirText(NULL);
    ctx->workDir = xlPathSnapshot(ctx->baseDir, localOptions.workDir != NULL ? localOptions.workDir : ".");
    ctx->tempDir = localOptions.tempDir != NULL ?
                   xlPathSnapshot(ctx->baseDir, localOptions.tempDir) :
                   xlDefaultTempDirSnapshot(ctx->baseDir);
    ctx->tccDllPath = xlPathSnapshot(ctx->baseDir, localOptions.tccDllPath != NULL ? localOptions.tccDllPath : "");
    ctx->tccLibPath = localOptions.tccLibPath != NULL && localOptions.tccLibPath[0] != '\0' ?
                      xlPathSnapshot(ctx->baseDir, localOptions.tccLibPath) :
                      xlToolchainPathSnapshot(ctx->baseDir, xlDefaultTccRootPath());
    ctx->tccIncludePath = xlToolchainPathSnapshot(ctx->baseDir, xlDefaultTccIncludePath());
    ctx->tccWinIncludePath = xlToolchainPathSnapshot(ctx->baseDir, xlDefaultTccWinIncludePath());
    ctx->tccWinapiIncludePath = xlToolchainPathSnapshot(ctx->baseDir, xlDefaultTccWinapiIncludePath());
    ctx->tccLibSearchPath = xlToolchainPathSnapshot(ctx->baseDir, xlDefaultTccLibPath());
    ctx->tccLibtcc1Path = xlToolchainPathSnapshot(ctx->baseDir, xlDefaultTccLibtcc1Path());
    ctx->saveTemps = localOptions.saveTemps != 0;
    if ( ctx->baseDir == NULL || ctx->workDir == NULL || ctx->tempDir == NULL ||
         ctx->tccDllPath == NULL || ctx->tccLibPath == NULL ||
         ctx->tccIncludePath == NULL || ctx->tccWinIncludePath == NULL ||
         ctx->tccWinapiIncludePath == NULL || ctx->tccLibSearchPath == NULL ||
         ctx->tccLibtcc1Path == NULL ) {
        xlDestroyContextUnlocked(ctx);
        ctx = NULL;
    }
    xlApiUnlock();
    return ctx;
}

void xlDestroyContext(XL_Context* ctx)
{
    if ( ctx == NULL ) {
        return;
    }
    xlApiLock();
    xlContextRequestDestroyUnlocked(ctx);
    xlApiUnlock();
}

int xlSetWorkDir(XL_Context* ctx, const char* path)
{
    char* copy;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( path == NULL || path[0] == '\0' ) {
        xlSetError(ctx, "work dir path is empty");
        xlApiUnlock();
        return 0;
    }
    copy = xlPathSnapshotFromCurrentDir(ctx, path, "cannot allocate work dir");
    if ( copy == NULL ) {
        xlApiUnlock();
        return 0;
    }
    xrtFree(ctx->workDir);
    ctx->workDir = copy;
    xlApiUnlock();
    return 1;
}

int xlSetTempDir(XL_Context* ctx, const char* path)
{
    char* copy;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( path == NULL || path[0] == '\0' ) {
        xlSetError(ctx, "temp dir path is empty");
        xlApiUnlock();
        return 0;
    }
    copy = xlPathSnapshotFromCurrentDir(ctx, path, "cannot allocate temp dir");
    if ( copy == NULL ) {
        xlApiUnlock();
        return 0;
    }
    xrtFree(ctx->tempDir);
    ctx->tempDir = copy;
    xlApiUnlock();
    return 1;
}

int xlSetSaveTemps(XL_Context* ctx, int enabled)
{
    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    ctx->saveTemps = enabled != 0;
    xlApiUnlock();
    return 1;
}

int xlAddIncludePath(XL_Context* ctx, const char* path)
{
    char* snapshot;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    snapshot = xlPathSnapshotFromCurrentDir(ctx, path, "cannot snapshot include path");
    ok = snapshot != NULL && xlStringListAppend(&ctx->includePaths, snapshot);
    xrtFree(snapshot);
    if ( !ok ) {
        xlSetError(ctx, "cannot add include path");
    }
    xlApiUnlock();
    return ok;
}

int xlAddLibraryPath(XL_Context* ctx, const char* path)
{
    char* snapshot;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    snapshot = xlPathSnapshotFromCurrentDir(ctx, path, "cannot snapshot library path");
    ok = snapshot != NULL && xlStringListAppend(&ctx->libraryPaths, snapshot);
    xrtFree(snapshot);
    if ( !ok ) {
        xlSetError(ctx, "cannot add library path");
    }
    xlApiUnlock();
    return ok;
}

int xlAddLinkLibrary(XL_Context* ctx, const char* nameOrPath)
{
    char* snapshot;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    snapshot = xlLinkValueSnapshotFromCurrentDir(ctx, nameOrPath, "cannot snapshot link library");
    ok = snapshot != NULL && xlStringListAppend(&ctx->linkLibraries, snapshot);
    xrtFree(snapshot);
    if ( !ok ) {
        xlSetError(ctx, "cannot add link library");
    }
    xlApiUnlock();
    return ok;
}

int xlAddResourceFile(XL_Context* ctx, const char* path)
{
    char* snapshot;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( path == NULL || path[0] == '\0' ) {
        xlSetError(ctx, "resource config path is empty");
        xlApiUnlock();
        return 0;
    }
    if ( ctx->resourceFiles.count >= XLC_MAX_RESOURCE_FILES ) {
        xlSetError(ctx, "too many resource config files");
        xlApiUnlock();
        return 0;
    }
    snapshot = xlPathSnapshotFromCurrentDir(ctx, path, "cannot snapshot resource config");
    ok = snapshot != NULL && xlStringListAppend(&ctx->resourceFiles, snapshot);
    xrtFree(snapshot);
    if ( !ok ) {
        xlSetError(ctx, "cannot add resource config");
    }
    xlApiUnlock();
    return ok;
}

int xlLoadDependencyLibrary(XL_Context* ctx, const char* path)
{
    XL_LoadedLibrary loaded;
    char* snapshot;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( path == NULL || path[0] == '\0' ) {
        xlSetError(ctx, "dependency library path is empty");
        xlApiUnlock();
        return 0;
    }
    memset(&loaded, 0, sizeof(loaded));
    snapshot = xlPathSnapshotFromCurrentDir(ctx, path, "cannot snapshot dependency library");
    if ( snapshot == NULL ) {
        xlApiUnlock();
        return 0;
    }
#ifdef _WIN32
    {
        uint16* pathW = xrtUtf8To16(snapshot, NULL);
        if ( pathW != NULL ) {
            loaded.module = LoadLibraryW((LPCWSTR)pathW);
            xrtFree(pathW);
        }
        if ( loaded.module == NULL ) {
            xlSetError2(ctx, "cannot load dependency library", snapshot);
            xrtFree(snapshot);
            xlApiUnlock();
            return 0;
        }
    }
#else
    loaded.module = dlopen(snapshot, RTLD_NOW | RTLD_GLOBAL);
    if ( loaded.module == NULL ) {
        xlSetError2(ctx, "cannot load dependency library", snapshot);
        xrtFree(snapshot);
        xlApiUnlock();
        return 0;
    }
#endif
    if ( !xlContextAddLoadedLibrary(ctx, snapshot, &loaded) ) {
        xlSetError(ctx, "cannot remember dependency library");
        xlCloseLoadedLibrary(&loaded);
        xrtFree(snapshot);
        xlApiUnlock();
        return 0;
    }
    xrtFree(snapshot);
    xlApiUnlock();
    return 1;
}

int xlRegisterCFunction(XL_Context* ctx, const char* symbolName, void* fn)
{
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    for(size_t p=0;symbolName && p<ctx->compiledPackages.count;++p)
        for(size_t e=0;e<ctx->compiledPackages.items[p].entryCount;++e) {
            const XL_PackageEntry* entry=&ctx->compiledPackages.items[p].entries[e];
            if(!strcmp(entry->name,symbolName) && entry->address!=fn) {
                xlSetError(ctx,"compiled package native symbol conflict");xlApiUnlock();return 0;
            }
        }
    ok = xlContextAddSymbol(ctx, symbolName, fn);
    if ( !ok ) {
        xlSetError(ctx, "cannot register C function");
    }
    xlApiUnlock();
    return ok;
}

int xlRunScriptString(XL_Context* ctx, const char* source)
{
    return xlRunScriptStringArg(ctx, source, NULL);
}

int xlRunScriptStringArg(XL_Context* ctx, const char* source, xvalue* pArg)
{
    XL6_CompileUnit unit;
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( !xlContextBeginCallUnlocked(ctx) ) {
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    ok = xlLoadUnitFromSource(ctx, &unit, source, "__xl_string.xl", NULL);
    if ( ok ) {
        ok = xlCompileAndRunUnit(ctx, &unit, pArg);
    }
    xl6CompileUnitFree(&unit);
    xlLeaveWorkDir(&cwd);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

int xlRunScriptFile(XL_Context* ctx, const char* path)
{
    return xlRunScriptFileArg(ctx, path, NULL);
}

int xlRunScriptFileArg(XL_Context* ctx, const char* path, xvalue* pArg)
{
    XL6_CompileUnit unit;
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( !xlContextBeginCallUnlocked(ctx) ) {
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    ok = xlLoadUnitFromFile(ctx, &unit, path, NULL);
    if ( ok ) {
        ok = xlCompileAndRunUnit(ctx, &unit, pArg);
    }
    xl6CompileUnitFree(&unit);
    xlLeaveWorkDir(&cwd);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

XL_Module* xlCompileScriptStringToModule(XL_Context* ctx, const char* source)
{
    XL6_CompileUnit unit;
    XL_CwdScope cwd;
    XL_Module* module;
    int ok;

    if ( ctx == NULL ) {
        return NULL;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return NULL;
    }
    module = NULL;
    ok = xlLoadUnitFromSource(ctx, &unit, source, "__xl_string.xl", NULL);
    if ( ok ) {
        module = xlCompileUnitToModule(ctx, &unit);
    }
    xl6CompileUnitFree(&unit);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return module;
}

XL_Module* xlCompileScriptFileToModule(XL_Context* ctx, const char* path)
{
    XL6_CompileUnit unit;
    XL_CwdScope cwd;
    XL_Module* module;
    int ok;

    if ( ctx == NULL ) {
        return NULL;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return NULL;
    }
    module = NULL;
    ok = xlLoadUnitFromFile(ctx, &unit, path, NULL);
    if ( ok ) {
        module = xlCompileUnitToModule(ctx, &unit);
    }
    xl6CompileUnitFree(&unit);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return module;
}

XL_Module* xlCompileCSourceStringToModule(XL_Context* ctx, const char* source)
{
    XL_CwdScope cwd;
    XL_Module* module;

    if ( ctx == NULL ) {
        return NULL;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return NULL;
    }
    module = xlCompileCSourceTextToModule(ctx, source, XL_TCC_VFS_C_MODULE_C);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return module;
}

XL_Module* xlCompileCSourceFileToModule(XL_Context* ctx, const char* path)
{
    XL_CwdScope cwd;
    XL_Module* module;

    if ( ctx == NULL ) {
        return NULL;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return NULL;
    }
    module = xlCompileCSourceFileToModuleUnlocked(ctx, path);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return module;
}

XL_API XL_Module* xlCompileCSourceFilesToModule(XL_Context* ctx, const char** paths, int pathCount)
{
    XL_CwdScope cwd;
    XL_Module* module;

    if ( ctx == NULL ) {
        return NULL;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return NULL;
    }
    module = xlCompileCSourceFilesToModuleUnlocked(ctx, paths, pathCount);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return module;
}

int xlRunCSourceString(XL_Context* ctx, const char* source, int argc, char** argv)
{
    XL_CwdScope cwd;
    XL_Module* module;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( !xlContextBeginCallUnlocked(ctx) ) {
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    module = xlCompileCSourceTextToModule(ctx, source, XL_TCC_VFS_C_MODULE_C);
    ok = module != NULL && xlRunCModuleMainUnlocked(ctx, module, argc, argv);
    xlDestroyModuleUnlocked(module);
    xlLeaveWorkDir(&cwd);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

int xlRunCSourceFile(XL_Context* ctx, const char* path, int argc, char** argv)
{
    XL_CwdScope cwd;
    XL_Module* module;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( !xlContextBeginCallUnlocked(ctx) ) {
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    module = xlCompileCSourceFileToModuleUnlocked(ctx, path);
    ok = module != NULL && xlRunCModuleMainUnlocked(ctx, module, argc, argv);
    xlDestroyModuleUnlocked(module);
    xlLeaveWorkDir(&cwd);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

XL_API int xlRunCSourceFiles(XL_Context* ctx, const char** paths, int pathCount, int argc, char** argv)
{
    XL_CwdScope cwd;
    XL_Module* module;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( !xlContextBeginCallUnlocked(ctx) ) {
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    module = xlCompileCSourceFilesToModuleUnlocked(ctx, paths, pathCount);
    ok = module != NULL && xlRunCModuleMainUnlocked(ctx, module, argc, argv);
    xlDestroyModuleUnlocked(module);
    xlLeaveWorkDir(&cwd);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

int xlRunModuleMain(XL_Context* ctx, XL_Module* module, xvalue* pArg)
{
    int ok;
    int hasContextLease;
    XL6_ModuleCall call = {0};

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    hasContextLease = xlContextBeginCallUnlocked(ctx);
    if ( !hasContextLease || !xlModuleBeginCallUnlocked(module) ) {
        if ( hasContextLease ) {
            xlContextEndCallUnlocked(ctx);
        }
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    xlModuleCallAttachUnlocked(module,&call);
    ok = xlRunModuleMainUnlocked(ctx, module, pArg);
    xlModuleCallDetachUnlocked(module,&call);
    xlModuleEndCallUnlocked(module);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

int xlActivateModule(XL_Context* ctx, XL_Module* module, xvalue* pArg)
{
    int ok;
    int hasContextLease;
    XL6_ModuleCall call = {0};

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    hasContextLease = xlContextBeginCallUnlocked(ctx);
    if ( !hasContextLease || !xlModuleBeginCallUnlocked(module) ) {
        if ( hasContextLease ) {
            xlContextEndCallUnlocked(ctx);
        }
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    xlModuleCallAttachUnlocked(module,&call);
    ok = xlActivateModuleUnlocked(ctx, module, pArg);
    xlModuleCallDetachUnlocked(module,&call);
    xlModuleEndCallUnlocked(module);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

int xlDeactivateModule(XL_Context* ctx, XL_Module* module)
{
    int ok;
    int hasContextLease;
    XL6_ModuleCall call = {0};

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    hasContextLease = xlContextBeginCallUnlocked(ctx);
    if ( !hasContextLease || !xlModuleBeginCallUnlocked(module) ) {
        if ( hasContextLease ) {
            xlContextEndCallUnlocked(ctx);
        }
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx);
    xlModuleCallAttachUnlocked(module,&call);
    ok = xlDeactivateModuleUnlocked(ctx, module);
    xlModuleCallDetachUnlocked(module,&call);
    xlModuleEndCallUnlocked(module);
    xlContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

void* xlModuleGetSymbol(XL_Module* module, const char* symbolName)
{
    void* symbol;

    if ( module == NULL || module->state == NULL || symbolName == NULL || symbolName[0] == '\0' ) {
        return NULL;
    }
    xlApiLock();
    symbol = xl__tcc.tcc_get_symbol(module->state, symbolName);
    xlApiUnlock();
    return symbol;
}

void xlDestroyModule(XL_Module* module)
{
    if ( module == NULL ) {
        return;
    }
    xlApiLock();
    xlModuleRequestDestroyUnlocked(module);
    xlApiUnlock();
}

XL_API int xlTccRegisterXrtEnvironment(TCCState* state, int outputType)
{
    int ok;

    if ( state == NULL ||
         outputType < TCC_OUTPUT_MEMORY ||
         outputType > TCC_OUTPUT_PREPROCESS ) {
        return 0;
    }
    xlApiLock();
    ok = xlEnsureTcc(NULL) &&
         xlConfigureTccStateEnvironment(NULL, state, outputType) &&
         (outputType==TCC_OUTPUT_MEMORY ? xlApiAddDefaultRuntimeSymbols(state) : xlAddNativeObject(state,outputType));
    xlApiUnlock();
    return ok;
}

XL_API int xlTccRegisterContextEnvironment(XL_Context* ctx, TCCState* state, int outputType)
{
    int ok;

    if ( ctx == NULL || state == NULL ||
         outputType < TCC_OUTPUT_MEMORY ||
         outputType > TCC_OUTPUT_PREPROCESS ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if(outputType!=TCC_OUTPUT_MEMORY && (ctx->compiledPackages.count || ctx->symbolCount)) {
        xlSetError(ctx,"process-local symbols may only be registered for in-process execution");
        xlApiUnlock();return 0;
    }
    ok = xlEnsureTcc(ctx) &&
         xlConfigureTccStateEnvironment(ctx, state, outputType) &&
         (outputType==TCC_OUTPUT_MEMORY ? xlAddContextSymbols(ctx,state) : xlAddNativeObject(state,outputType));
    xlApiUnlock();
    return ok;
}

XL_API int xlTccImpdef(const char* dllPath, const char* outputDef)
{
#ifdef _WIN32
    char* args[5];

    if ( dllPath == NULL || dllPath[0] == '\0' || outputDef == NULL || outputDef[0] == '\0' ) {
        return 0;
    }
    args[0] = (char*)"tcc";
    args[1] = (char*)dllPath;
    args[2] = (char*)"-o";
    args[3] = (char*)outputDef;
    args[4] = NULL;
    return tcc_tool_impdef(4, args) == 0;
#else
    (void)dllPath;
    (void)outputDef;
    return 0;
#endif
}

#if XL_ENABLE_EXE_COMPILER
static int xlBeginBuildInputs(XL_Context* ctx,XL6_BuildInputs** previous)
{
    *previous=xl6BuildInputsActivate(ctx->buildInputs);
    if(!ctx->buildInputs) return 1;
    { size_t i; for(i=0;i<ctx->linkLibraries.count;++i) if(!strcmp(ctx->linkLibraries.items[i],"-")) {
        xl6BuildInputsActivate(*previous); xlSetError(ctx,"input report cannot observe stdin link inputs"); return 0;
    } }
    if(ctx->loadedLibraryCount||!xl6BuildInputsValidate(ctx->buildInputs)) {
        xl6BuildInputsActivate(*previous);
        xlSetError(ctx,"build input report does not support loadlib or changed inputs"); return 0;
    }
#ifdef XL_STATIC_TCC_VFS
    tcc_vfs_set_disk_reader(xl6BuildInputsRead,ctx->buildInputs);
    return 1;
#else
    xl6BuildInputsActivate(*previous); xlSetError(ctx,"native input transport is unavailable"); return 0;
#endif
}
static int xlEndBuildInputs(XL_Context* ctx,XL6_BuildInputs* previous,int ok,const char* output)
{
#ifdef XL_STATIC_TCC_VFS
    if(ctx->buildInputs) tcc_vfs_set_disk_reader(NULL,NULL);
#endif
    if(ok&&ctx->buildInputs) ok=xl6BuildInputsBindArtifact(ctx->buildInputs,output);
    if(!ok&&ctx->buildInputs&&!ctx->buildInputs->complete) xlSetError2(ctx,"build input validation failed",ctx->buildInputs->error);
    xl6BuildInputsActivate(previous); return ok;
}
#endif

#if XL_ENABLE_EXE_COMPILER
int xlCompileScriptStringToExe(XL_Context* ctx, const char* source, const char* outputExe)
{
    XL6_CompileUnit unit;
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlLoadUnitFromSource(ctx, &unit, source, "__xl_string.xl", NULL);
    if ( ok ) {
        ok = xlCompileUnitToExe(ctx, &unit, outputExe);
    }
    xl6CompileUnitFree(&unit);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

int xlCompileScriptFileToExe(XL_Context* ctx, const char* path, const char* outputExe)
{
    XL6_CompileUnit unit;
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlLoadUnitFromFile(ctx, &unit, path, NULL);
    if ( ok ) {
        ok = xlCompileUnitToExe(ctx, &unit, outputExe);
    }
    xl6CompileUnitFree(&unit);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

static int xlCompileCSourceFilesToExternalOutput(
    XL_Context* ctx,
    const char** paths,
    int pathCount,
    const char* outputPath,
    int outputType,
    const char* outputKind)
{
    XL_CwdScope cwd;
    TCCState* s;
    int ok;
    XL6_BuildInputs* previous;

    if ( ctx == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    if ( outputPath == NULL || outputPath[0] == '\0' ) {
        xlSetError(ctx, "C output path is empty");
        xlApiUnlock();
        return 0;
    }
    if ( !xlEnterWorkDir(ctx, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    if(!xlBeginBuildInputs(ctx,&previous)) { xlLeaveWorkDir(&cwd); xlApiUnlock(); return 0; }
    s = xlCreateTccState(ctx, outputType);
    ok = s != NULL &&
         xlAddCSourceFilesToTcc(ctx, s, paths, pathCount) &&
         xlAddDependenciesToTcc(ctx, s, NULL) &&
         xlAddResourceFilesToTcc(ctx, s) &&
         xlAddNativeObject(s,outputType);
    if ( ok ) {
        ok = xl6BuildInputOutputValid(outputPath) && xl__tcc.tcc_output_file(s, outputPath) == 0;
    }
    if ( !ok && ctx->lastError == NULL ) {
        xlSetError2(ctx, outputKind != NULL ? outputKind : "cannot output C target", outputPath);
    }
    if ( s != NULL ) {
        xl__tcc.tcc_delete(s);
    }
    ok=xlEndBuildInputs(ctx,previous,ok,outputPath);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlCompileCSourceFilesToExe(XL_Context* ctx, const char** paths, int pathCount, const char* outputExe)
{
    return xlCompileCSourceFilesToExternalOutput(ctx, paths, pathCount, outputExe, TCC_OUTPUT_EXE, "cannot output C exe");
}

XL_API int xlCompileCSourceFileToExe(XL_Context* ctx, const char* path, const char* outputExe)
{
    const char* paths[1];

    paths[0] = path;
    return xlCompileCSourceFilesToExe(ctx, paths, 1, outputExe);
}

XL_API int xlCompileCSourceFilesToSharedLibrary(XL_Context* ctx, const char** paths, int pathCount, const char* outputDll)
{
    return xlCompileCSourceFilesToExternalOutput(ctx, paths, pathCount, outputDll, TCC_OUTPUT_DLL, "cannot output C shared library");
}

XL_API int xlCompileCSourceFileToSharedLibrary(XL_Context* ctx, const char* path, const char* outputDll)
{
    const char* paths[1];

    paths[0] = path;
    return xlCompileCSourceFilesToSharedLibrary(ctx, paths, 1, outputDll);
}

#endif

#if XL_ENABLE_EXE_COMPILER
static void xlcClearUnitUnlocked(XLC_Context* ctx)
{
    if ( ctx == NULL ) {
        return;
    }
    if ( ctx->unitReady ) {
        xl6CompileUnitFree(&ctx->unit);
    }
    memset(&ctx->unit, 0, sizeof(ctx->unit));
    ctx->unitReady = 0;
}

static void xlcClearSourceUnlocked(XLC_Context* ctx)
{
    if ( ctx == NULL ) {
        return;
    }
    xlcClearUnitUnlocked(ctx);
    xrtFree(ctx->sourcePath);
    xrtFree(ctx->sourceText);
    xrtFree(ctx->virtualPath);
    ctx->sourcePath = NULL;
    ctx->sourceText = NULL;
    ctx->virtualPath = NULL;
    ctx->sourceKind = XLC_SOURCE_NONE;
}

static int xlcCompileUnlocked(XLC_Context* ctx)
{
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    if ( ctx->unitReady ) {
        return 1;
    }
    if ( ctx->sourceKind == XLC_SOURCE_FILE ) {
        ok = xlLoadUnitFromFile(ctx->runtime, &ctx->unit, ctx->sourcePath, &ctx->sourceOverlay);
    } else if ( ctx->sourceKind == XLC_SOURCE_STRING ) {
        ok = xlLoadUnitFromSource(ctx->runtime, &ctx->unit, ctx->sourceText, ctx->virtualPath, &ctx->sourceOverlay);
    } else {
        xlSetError(ctx->runtime, "compiler source is empty");
        return 0;
    }
    if ( !ok ) {
        xl6CompileUnitFree(&ctx->unit);
        memset(&ctx->unit, 0, sizeof(ctx->unit));
        return 0;
    }
    ctx->unitReady = 1;
    return 1;
}

XL_API XLC_ContextOptions xlcDefaultContextOptions(void)
{
    return xlDefaultContextOptions();
}

XL_API XLC_Context* xlcCreateContext(const XLC_ContextOptions* options)
{
    XL_Context* runtime;
    XLC_Context* ctx;

    runtime = xlCreateContext(options);
    if ( runtime == NULL ) {
        return NULL;
    }
    ctx = (XLC_Context*)xrtCalloc(1, sizeof(XLC_Context));
    if ( ctx == NULL ) {
        xlDestroyContext(runtime);
        return NULL;
    }
    ctx->runtime = runtime;
    return ctx;
}

XL6_CLI_API int xlcBeginInputReport(XLC_Context* ctx)
{
    int ok=0;
    if(!ctx||!ctx->runtime) return 0;
    xlApiLock();
#ifdef XL_STATIC_TCC_VFS
    if(!ctx->buildInputs&&!ctx->unitReady&&!ctx->sourceOverlay.count&&!ctx->runtime->loadedLibraryCount) {
        ctx->buildInputs=xrtCalloc(1,sizeof(*ctx->buildInputs));
        if(ctx->buildInputs) {
            xl6BuildInputsInit(ctx->buildInputs);
            ctx->sourceOverlay.report=&ctx->buildInputs->sources;
            ctx->runtime->buildInputs=ctx->buildInputs; ok=1;
        }
    }
#endif
    if(!ok) xlSetError(ctx->runtime,"input report requires a fresh static-VFS compiler context without overlays/loadlib");
    xlApiUnlock(); return ok;
}
XL6_CLI_API char* xlcReadProjectInput(XLC_Context* ctx,const char* path,size_t* size)
{
    XL6_BuildInputs* previous; char* text;
    if(!ctx||!ctx->runtime) return NULL;
    xlApiLock(); previous=xl6BuildInputsActivate(ctx->buildInputs);
    text=xl6BuildInputReadText(path,size); xl6BuildInputsActivate(previous); xlApiUnlock(); return text;
}
XL6_CLI_API int xlcWriteInputReport(XLC_Context* ctx,const char* artifact,const char* receipt)
{
    int ok;
    if(!ctx||!ctx->runtime||!ctx->buildInputs) return 0;
    xlApiLock(); ok=xl6BuildInputsWrite(ctx->buildInputs,artifact,receipt);
    if(!ok) xlSetError2(ctx->runtime,"build input report failed",ctx->buildInputs->error);
    xlApiUnlock(); return ok;
}
static void xlcDestroyContextUnlocked(XLC_Context* ctx)
{
    XL_Context* runtime;

    if ( ctx == NULL ) {
        return;
    }
    runtime = ctx->runtime;
    ctx->runtime = NULL;
    xlcClearSourceUnlocked(ctx);
    xlStringListFree(&ctx->cSourceFiles);
    xl6SourceOverlayClear(&ctx->sourceOverlay);
    runtime->buildInputs=NULL;
    xl6BuildInputsFree(ctx->buildInputs); xrtFree(ctx->buildInputs);
    xrtFree(ctx);
    xlContextRequestDestroyUnlocked(runtime);
}

static int xlcContextBeginCallUnlocked(XLC_Context* ctx)
{
    if ( ctx == NULL || ctx->destroyRequested ) {
        return 0;
    }
    ctx->activeCalls += 1;
    return 1;
}

static void xlcContextEndCallUnlocked(XLC_Context* ctx)
{
    if ( ctx == NULL || ctx->activeCalls == 0 ) {
        return;
    }
    ctx->activeCalls -= 1;
    if ( ctx->activeCalls == 0 && ctx->destroyRequested ) {
        xlcDestroyContextUnlocked(ctx);
    }
}

XL_API void xlcDestroyContext(XLC_Context* ctx)
{
    if ( ctx == NULL ) {
        return;
    }
    xlApiLock();
    if ( !ctx->destroyRequested ) {
        ctx->destroyRequested = 1;
        if ( ctx->activeCalls == 0 ) {
            xlcDestroyContextUnlocked(ctx);
        }
    }
    xlApiUnlock();
}

XL_API int xlcSetWorkDir(XLC_Context* ctx, const char* path)
{
    int ok;
    if (!ctx || !ctx->runtime) return 0;
    xlApiLock();
    ok = xlSetWorkDir(ctx->runtime, path);
    if (ok) xlcClearUnitUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

XL_API int xlcSetTempDir(XLC_Context* ctx, const char* path)
{
    return ctx != NULL ? xlSetTempDir(ctx->runtime, path) : 0;
}

XL_API int xlcSetSaveTemps(XLC_Context* ctx, int enabled)
{
    return ctx != NULL ? xlSetSaveTemps(ctx->runtime, enabled) : 0;
}

XL_API int xlcSetBackend(XLC_Context* ctx, XLC_Backend backend)
{
    if ( ctx == NULL || ctx->runtime == NULL ) return 0;
    if ( backend != XLC_BACKEND_XLIR ) {
        xlSetError(ctx->runtime, "only the XLIR compiler backend is available");
        return 0;
    }
    return 1;
}

XL_API int xlcAddIncludePath(XLC_Context* ctx, const char* path)
{
    return ctx != NULL ? xlAddIncludePath(ctx->runtime, path) : 0;
}

XL_API int xlcAddLibraryPath(XLC_Context* ctx, const char* path)
{
    return ctx != NULL ? xlAddLibraryPath(ctx->runtime, path) : 0;
}

XL_API int xlcAddLinkLibrary(XLC_Context* ctx, const char* nameOrPath)
{
    return ctx != NULL ? xlAddLinkLibrary(ctx->runtime, nameOrPath) : 0;
}

XL_API int xlcAddResourceFile(XLC_Context* ctx, const char* path)
{
    return ctx != NULL ? xlAddResourceFile(ctx->runtime, path) : 0;
}

XL_API int xlcAddCSourceFile(XLC_Context* ctx, const char* path)
{
    char* snapshot;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( path == NULL || path[0] == '\0' ) {
        xlSetError(ctx->runtime, "C source file path is empty");
        xlApiUnlock();
        return 0;
    }
    if ( ctx->cSourceFiles.count >= XLC_MAX_C_SOURCE_FILES ) {
        xlSetError(ctx->runtime, "too many C source files");
        xlApiUnlock();
        return 0;
    }
    snapshot = xlPathSnapshotFromCurrentDir(ctx->runtime, path, "cannot snapshot C source file");
    ok = snapshot != NULL && xlStringListAppend(&ctx->cSourceFiles, snapshot);
    xrtFree(snapshot);
    if ( !ok && ctx->runtime->lastError == NULL ) {
        xlSetError(ctx->runtime, "cannot add C source file");
    }
    xlApiUnlock();
    return ok;
}

XL_API int xlcLoadDependencyLibrary(XLC_Context* ctx, const char* path)
{
    return ctx != NULL ? xlLoadDependencyLibrary(ctx->runtime, path) : 0;
}

XL_API int xlcRegisterCFunction(XLC_Context* ctx, const char* symbolName, void* fn)
{
    return ctx != NULL ? xlRegisterCFunction(ctx->runtime, symbolName, fn) : 0;
}

XL_API int xlcAddSourceFile(XLC_Context* ctx, const char* path)
{
    char* copy;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( path == NULL || path[0] == '\0' ) {
        xlSetError(ctx->runtime, "compiler source file path is empty");
        xlApiUnlock();
        return 0;
    }
    copy = xlDupText(path);
    if ( copy == NULL ) {
        xlSetError(ctx->runtime, "cannot copy compiler source file path");
        xlApiUnlock();
        return 0;
    }
    xlcClearSourceUnlocked(ctx);
    ctx->sourceKind = XLC_SOURCE_FILE;
    ctx->sourcePath = copy;
    xlApiUnlock();
    return 1;
}

XL_API int xlcAddSourceString(XLC_Context* ctx, const char* virtualPath, const char* source)
{
    char* pathCopy;
    char* sourceCopy;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( source == NULL ) {
        xlSetError(ctx->runtime, "compiler source is empty");
        xlApiUnlock();
        return 0;
    }
    pathCopy = xlDupText(virtualPath != NULL && virtualPath[0] != '\0' ? virtualPath : "__xlc_string.xl");
    sourceCopy = xlDupText(source);
    if ( pathCopy == NULL || sourceCopy == NULL ) {
        xrtFree(pathCopy);
        xrtFree(sourceCopy);
        xlSetError(ctx->runtime, "cannot copy compiler source");
        xlApiUnlock();
        return 0;
    }
    xlcClearSourceUnlocked(ctx);
    ctx->sourceKind = XLC_SOURCE_STRING;
    ctx->virtualPath = pathCopy;
    ctx->sourceText = sourceCopy;
    xlApiUnlock();
    return 1;
}

XL_API int xlcSetSourceOverlay(XLC_Context* ctx, const char* path, const char* source, size_t size)
{
    XL_CwdScope cwd;
    int ok = 0;
    if (!ctx || !ctx->runtime) return 0;
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if (xlEnterWorkDir(ctx->runtime, &cwd)) {
        ok = xl6SourceOverlaySet(&ctx->sourceOverlay, path, source, size);
        if (ok) xlcClearUnitUnlocked(ctx);
        else xlSetError(ctx->runtime, "invalid source overlay, allocation failure, or overlay limit exceeded");
        xlLeaveWorkDir(&cwd);
    }
    xlApiUnlock();
    return ok;
}

XL_API int xlcRemoveSourceOverlay(XLC_Context* ctx, const char* path)
{
    XL_CwdScope cwd;
    int ok = 0;
    if (!ctx || !ctx->runtime) return 0;
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if (xlEnterWorkDir(ctx->runtime, &cwd)) {
        ok = xl6SourceOverlayRemove(&ctx->sourceOverlay, path);
        if (ok) xlcClearUnitUnlocked(ctx);
        else xlSetError(ctx->runtime, "cannot remove source overlay");
        xlLeaveWorkDir(&cwd);
    }
    xlApiUnlock();
    return ok;
}

XL_API int xlcClearSourceOverlays(XLC_Context* ctx)
{
    if (!ctx || !ctx->runtime) return 0;
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    xl6SourceOverlayClear(&ctx->sourceOverlay);
    xlcClearUnitUnlocked(ctx);
    xlApiUnlock();
    return 1;
}

XL_API int xlcCompile(XLC_Context* ctx)
{
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcCompileUnlocked(ctx);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

typedef struct XL_CEnvCollector { xvalue* operations; size_t count, bytes; } XL_CEnvCollector;
static int xlCEnvPut(xvalue* object, const char* key, xvalue* value)
{
    return value != NULL && xrtValueObjectSetNew(object, xrtStrView(key), value);
}
static xvalue* xlCEnvString(const char* text)
{
    return xrtValueString(xrtStrView(text != NULL ? text : ""));
}
#include "xl_c_source_groups.inc"
static int xlCEnvCollect(void* user, const char* kind, const char* text, const char* value, int required)
{
    XL_CEnvCollector* c = (XL_CEnvCollector*)user;
    size_t bytes = strlen(text) + (value != NULL ? strlen(value) : 0);
    xvalue* row;
    int ok;
    if (c->count >= 2048 || bytes > 1024u * 1024u - c->bytes) return 0;
    row = xrtValueObject();
    ok = row != NULL && xlCEnvPut(row, "kind", xlCEnvString(kind)) &&
        xlCEnvPut(row, "text", xlCEnvString(text)) &&
        xlCEnvPut(row, "value", xlCEnvString(value)) &&
        xlCEnvPut(row, "required", xrtValueBool(required != 0)) &&
        xrtValueArrayAppend(c->operations, row);
    xrtValueRelease(row);
    if (ok) { ++c->count; c->bytes += bytes; }
    return ok;
}
static char* xlBuildNativeCEnvironment(XL_Context* ctx, const XL6_CompileUnit* unit,
    const XL_StringList* cSources, int shared)
{
    xvalue *root = xrtValueObject(), *operations = xrtValueArray(), *headers = xrtValueArray();
    XL_CEnvCollector collector = {operations, 0, 0};
    xjsonwriteconfig config;
    xjsonwriter* writer = NULL;
    char* text = NULL;
    size_t count = 0, total = 0;
    int ok = root != NULL && operations != NULL && headers != NULL &&
        xlVisitCOutputKind(shared ? TCC_OUTPUT_DLL : TCC_OUTPUT_EXE, xlCEnvCollect, &collector) &&
        xlVisitDefaultCEnvironment(ctx, xlCEnvCollect, &collector, NULL) &&
        xlVisitContextCIncludes(ctx, xlCEnvCollect, &collector) &&
        xlVisitPackageNativeLink(unit, xlCEnvCollect, &collector) &&
        xlVisitNativeSources(ctx, xlCEnvCollect, &collector, unit, cSources);
#ifdef XL_STATIC_TCC_VFS
    unsigned int i;
    for (i = 0; ok && i < tcc_builtin_resources_count; ++i) {
        const TCCBuiltinResource* res = &tcc_builtin_resources[i];
        const char* name=tcc_builtin_resource_name(res);
        size_t length = name != NULL ? strlen(name) : 0, size = 0;
        unsigned char *data = NULL, digest[32];
        char *encoded = NULL, hex[65];
        xvalue* row = NULL;
        unsigned int h;
        if (length < 3 || strcmp(name + length - 2, ".h") ||
            (strncmp(name, "include/", 8) && strncmp(name, "lib/xrt/", 8) &&
             strncmp(name, "lib/xruntime/", 13))) continue;
        ok = count < 512 && res->size <= 16u * 1024u * 1024u &&
            res->size <= 32u * 1024u * 1024u - total &&
            tcc_vfs_read_builtin(name, NULL, 0, &size) && size == res->size;
        if (ok) { data = xrtMalloc(size ? size : 1); ok = data != NULL; }
        if (ok) ok = tcc_vfs_read_builtin(name, data, size, &size) &&
            size == res->size && xrtSha256(data, size, digest);
        if (ok) { encoded = xrtBase64EncodeNew(data, size, NULL); row = xrtValueObject(); ok = encoded != NULL && row != NULL; }
        if (ok) {
            for (h = 0; h < 32; ++h) snprintf(hex + h * 2, 3, "%02x", (unsigned)digest[h]);
            ok = xlCEnvPut(row, "name", xlCEnvString(name)) &&
                xlCEnvPut(row, "size", xrtValueInt((int64)size)) &&
                xlCEnvPut(row, "sha256", xlCEnvString(hex)) &&
                xlCEnvPut(row, "base64", xlCEnvString(encoded)) && xrtValueArrayAppend(headers, row);
        }
        xrtValueRelease(row); xrtFree(encoded); xrtFree(data);
        if (ok) { ++count; total += size; }
    }
#endif
#ifdef XL_STATIC_TCC_VFS
    if (ok) {
        TCCXlangScalarTarget target;
        if (tcc_xlang_scalar_target(&target)) {
            xvalue* profile = xrtValueObject();
            ok = profile != NULL &&
                xlCEnvPut(profile, "schema", xrtValueInt(1)) &&
                xlCEnvPut(profile, "scope", xlCEnvString("tcc-win64-scalar-target")) &&
                xlCEnvPut(profile, "tinyCVersion", xrtValueInt(target.tinyc_version)) &&
                xlCEnvPut(profile, "pointerBytes", xrtValueInt(target.pointer_bytes)) &&
                xlCEnvPut(profile, "longBytes", xrtValueInt(target.long_bytes)) &&
                xlCEnvPut(profile, "longDoubleBytes", xrtValueInt(target.long_double_bytes)) &&
                xlCEnvPut(profile, "longDoubleAlign", xrtValueInt(target.long_double_align)) &&
                xrtValueObjectSet(root, xrtStrView("scalarTarget"), profile);
            xrtValueRelease(profile);
        }
    }
#endif
#ifdef XL_STATIC_TCC_VFS
    if (ok) {
        TCCState* selected = xlCreateTccState(ctx, shared ? TCC_OUTPUT_DLL : TCC_OUTPUT_EXE);
        TCCXlangRecordLayout layout;
        ok = selected != NULL && xlTccPrepareNativeSources(ctx, selected, unit, cSources);
        if (ok && tcc_xlang_record_layout(selected, &layout)) {
            xvalue* profile = xrtValueObject();
            ok = profile != NULL &&
                xlCEnvPut(profile, "schema", xrtValueInt(1)) &&
                xlCEnvPut(profile, "scope", xlCEnvString("tcc-win64-bitfield-default")) &&
                xlCEnvPut(profile, "msBitfields", xrtValueBool(layout.ms_bitfields != 0)) &&
                xrtValueObjectSet(root, xrtStrView("recordLayout"), profile);
            xrtValueRelease(profile);
        }
        if (selected != NULL) xl__tcc.tcc_delete(selected);
    }
#endif
    if (ok) ok = xlCEnvPut(root, "schema", xrtValueInt(1)) &&
        xlCEnvPut(root, "scope", xlCEnvString("compiler-configured-native-c")) &&
        xlCEnvPut(root, "complete", xrtValueBool(true)) &&
        xlCEnvPut(root, "cPreprocessorGraphComplete", xrtValueBool(false)) &&
        xlCEnvPut(root, "abiEquivalenceGuaranteed", xrtValueBool(false)) &&
        xlCEnvPut(root, "directory", xlCEnvString(ctx->baseDir)) &&
        xlCEnvPut(root, "outputKind", xlCEnvString(shared ? "shared" : "exe")) &&
        xlCEnvPut(root, "builtinHeaderScope", xlCEnvString("public-tcc-runtime-headers")) &&
        xlCEnvPut(root, "builtinBytes", xrtValueInt((int64)total)) &&
        xlCEnvPut(root, "embeddedHeadersAvailable", xrtValueBool(
#ifdef XL_STATIC_TCC_VFS
            true
#else
            false
#endif
        )) && xrtValueObjectSet(root, xrtStrView("operations"), operations) &&
        xrtValueObjectSet(root, xrtStrView("builtinHeaders"), headers) &&
        xlCSourceGroupReport(root, unit);
    if (ok) {
        xrtJsonWriteConfigInit(&config); config.MaxOutputBytes = 64u * 1024u * 1024u;
        writer = xrtJsonWriterCreate(&config);
        ok = writer != NULL && xrtJsonWriterValue(writer, root) && xrtJsonWriterFinish(writer);
        if (ok) text = xrtJsonWriterTake(writer, NULL);
    }
    xrtJsonWriterFree(writer);
    xrtValueRelease(root); xrtValueRelease(operations); xrtValueRelease(headers);
    if (!text) xlSetError(ctx, "cannot collect bounded native C configuration and builtin headers");
    return text;
}

static int xlcCheckInternal(XLC_Context* ctx, const char* outputPath, int jsonOutput, int withSources, int withIndex, int withBridge)
{
    XL_CwdScope cwd;
    XL6_CompileUnit unit;
    XL6_Output out;
    XL6_SourceReport report;
    XL6_SourceOverlay overlay;
    char* indexJson = NULL;
    char* headerText = NULL;
    char* environmentJson = NULL;
    char* mapJson = NULL;
    xvalue* bindings = NULL;
    char indexError[192];
    int success;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    xl6SourceReportInit(&report);
    overlay = ctx->sourceOverlay;
    overlay.report = withSources ? &report : NULL;
    /* Source ranges are query metadata, also needed for exact ABI bindings. */
    overlay.semanticIndex = withIndex || withBridge;
    xl6CompileUnitInit(&unit);
    if ( ctx->sourceKind == XLC_SOURCE_FILE ) {
        success = xlLoadUnitFromFile(ctx->runtime, &unit, ctx->sourcePath, &overlay);
    } else if ( ctx->sourceKind == XLC_SOURCE_STRING ) {
        success = (!withSources || xl6SourceReportText(&report, ctx->virtualPath,
                     ctx->sourceText, strlen(ctx->sourceText), "memory")) &&
                  xlLoadUnitFromSource(ctx->runtime, &unit, ctx->sourceText, ctx->virtualPath, &overlay);
    } else {
        xl6SourceReportFree(&report);
        xlSetError(ctx->runtime, "compiler source is empty");
        xlLeaveWorkDir(&cwd);
        xlApiUnlock();
        return 0;
    }
    if (withIndex && success) {
        indexJson = xl6SemIndexJson(unit.parse.root, &report, indexError, sizeof(indexError));
        if (!indexJson) {
            success = 0;
            unit.phase = "semantic-index";
            xl6DiagAddFile(&unit.parse.diags, xlcSourceLabel(ctx), 1, 1, indexError);
            xlSetCompileDiagError(ctx->runtime, &unit);
        }
    }
    if (withBridge && success) {
        success = xlEmitUnitHeaderToMemoryMapped(ctx->runtime, &unit, xlNativeCHeaderGuard, &headerText, &bindings, 0);
        if (success && strlen(headerText) > 1024u * 1024u) {
            xlSetError(ctx->runtime, "C bridge declarations exceed the 1 MiB query limit");
            success = 0;
        }
        if (!success) {
            unit.phase = "c-bridge";
            xl6DiagAddFile(&unit.parse.diags, xlcSourceLabel(ctx), 1, 1,
                xlGetLastError(ctx->runtime));
        }
    }
    if (withBridge && success) {
        mapJson = xl6SemCBridgeMapJson(unit.parse.root, &report, bindings, headerText,
                                     indexError, sizeof(indexError));
        if (!mapJson) {
            /* Optional navigation metadata must not narrow successful ABI
             * queries. Failure/limits are explicit and never retain old maps. */
            static const char unavailable[] =
                "{\"schema\":1,\"scope\":\"lowered-public-symbol-source-bindings\","
                "\"complete\":false,\"reason\":\"source-map-unavailable\",\"records\":[]}";
            mapJson = (char*)xrtMalloc(sizeof(unavailable));
            if (mapJson) memcpy(mapJson, unavailable, sizeof(unavailable));
            else {
                success = 0; unit.phase = "c-bridge-map";
                xl6DiagAddFile(&unit.parse.diags, xlcSourceLabel(ctx), 1, 1, indexError);
                xlSetCompileDiagError(ctx->runtime, &unit);
            }
        }
    }
    if (withBridge > 1 && success) {
        environmentJson = xlBuildNativeCEnvironment(ctx->runtime, &unit, &ctx->cSourceFiles, withBridge == 3);
        if (!environmentJson) {
            success = 0; unit.phase = "c-environment";
            xl6DiagAddFile(&unit.parse.diags, xlcSourceLabel(ctx), 1, 1, xlGetLastError(ctx->runtime));
        }
    }
    /* Revalidate after facts/header/environment construction: one input batch. */
    if (withSources && !xl6SourceReportValidate(&report)) {
        success = 0;
        unit.phase = "source-report";
        xl6DiagAddFile(&unit.parse.diags, report.errorPath ? report.errorPath : xlcSourceLabel(ctx),
                       1, 1, report.error[0] ? report.error : "source report is incomplete");
        xlSetCompileDiagError(ctx->runtime, &unit);
    }
    ok = xlcOutputOpen(ctx->runtime, &out, outputPath, "cannot open check output");
    if ( ok ) {
        if (withBridge) {
            xl6DiagPrintJsonWithBridge(&out, &unit.parse.diags, xlcSourceLabel(ctx), unit.phase,
                success, &report, success ? headerText : NULL, xlNativeCPreamble, xlNativeCHeaderGuard, environmentJson, withBridge > 1, mapJson);
        } else if ( jsonOutput ) {
            xl6DiagPrintJsonWithIndex(&out, &unit.parse.diags, xlcSourceLabel(ctx), unit.phase, success,
                withSources ? &report : NULL, withIndex ? (success ? indexJson :
                    "{\"schema\":1,\"scope\":\"checked-compilation\",\"complete\":false,\"nodes\":[]}") : NULL);
        } else {
            xlcEmitDiagText(&out, &unit.parse.diags, xlcSourceLabel(ctx), unit.phase, success);
        }
        ok = xlcOutputClose(ctx->runtime, &out, "cannot write check output");
    }
    xrtFree(mapJson);
    xrtValueRelease(bindings);
    xrtFree(environmentJson);
    xrtFree(headerText);
    xrtFree(indexJson);
    xl6CompileUnitFree(&unit);
    xl6SourceReportFree(&report);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok && success;
}

XL_API int xlcCheck(XLC_Context* ctx, const char* outputPath, int jsonOutput)
{
    return xlcCheckInternal(ctx, outputPath, jsonOutput, 0, 0, 0);
}

XL_API int xlcCheckWithSources(XLC_Context* ctx, const char* outputPath)
{
    return xlcCheckInternal(ctx, outputPath, 1, 1, 0, 0);
}

XL_API int xlcCheckWithIndex(XLC_Context* ctx, const char* outputPath)
{
    return xlcCheckInternal(ctx, outputPath, 1, 1, 1, 0);
}

XL_API int xlcCBridge(XLC_Context* ctx, const char* outputPath)
{
    return xlcCheckInternal(ctx, outputPath, 1, 1, 0, 1);
}
XL_API int xlcCBridgeWithEnvironment(XLC_Context* ctx, const char* outputPath, int shared)
{
    if (shared != 0 && shared != 1) return 0;
    return xlcCheckInternal(ctx, outputPath, 1, 1, 0, shared ? 3 : 2);
}

XL_API int xlcComplete(XLC_Context* ctx,const char* queryPath,size_t byteOffset,const char* outputPath)
{
    XL_CwdScope cwd;XL6_CompileUnit unit;XL6_Output out;XL6_SourceReport report;XL6_SourceOverlay overlay;XL6_CompletionQuery query;
    char *absolute=NULL,*json=NULL;int ok=0,available=0;
    if (!ctx||!ctx->runtime||!queryPath||!*queryPath) return 0;
    xlApiLock();xlClearLastErrorUnlocked(ctx->runtime);
    if (!xlEnterWorkDir(ctx->runtime,&cwd)) {xlApiUnlock();return 0;}
    memset(&query,0,sizeof(query));xl6SourceReportInit(&report);xl6CompileUnitInit(&unit);
    absolute=xrtPathAbs(queryPath);query.path=absolute;query.offset=byteOffset;
    overlay=ctx->sourceOverlay;overlay.report=&report;overlay.semanticIndex=0;overlay.completionQuery=&query;
    if (!absolute) query.error="cannot resolve completion source";
    else if (ctx->sourceKind==XLC_SOURCE_FILE) xlLoadUnitFromFile(ctx->runtime,&unit,ctx->sourcePath,&overlay);
    else if (ctx->sourceKind==XLC_SOURCE_STRING) {
        if (xl6SourceReportText(&report,ctx->virtualPath,ctx->sourceText,strlen(ctx->sourceText),"memory")) xlLoadUnitFromSource(ctx->runtime,&unit,ctx->sourceText,ctx->virtualPath,&overlay);
        else query.error="cannot retain memory completion source";
    } else query.error="compiler source is empty";
    if (!xl6SourceReportValidate(&report)) query.error="completion source report is incomplete or changed";
    json=xl6CompletionJson(&query,&report);
    /* Validate after serialization: facts and inputs are one immutable batch. */
    if (!xl6SourceReportValidate(&report)) {
        query.available=0;query.error="completion inputs changed during serialization";
        xrtFree(json);json=xl6CompletionJson(&query,&report);
    }
    available=json&&query.available;
    if (json&&xlcOutputOpen(ctx->runtime,&out,outputPath,"cannot open completion output")) {
        xl6DiagPrintJsonWithCompletion(&out,&report,available,json);
        ok=xlcOutputClose(ctx->runtime,&out,"cannot write completion output");
    }
    if (available && ok) xlClearLastErrorUnlocked(ctx->runtime);
    else if (!available) xlSetError(ctx->runtime,query.error?query.error:"completion query is unavailable");
    xrtFree(json);xl6CompletionFree(&query);xl6CompileUnitFree(&unit);xl6SourceReportFree(&report);xrtFree(absolute);
    xlLeaveWorkDir(&cwd);xlApiUnlock();return ok&&available;
}

XL_API int xlcEmitTokens(XLC_Context* ctx, const char* outputPath, int jsonOutput)
{
    XL_CwdScope cwd;
    XL6_Output out;
    int rc;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( ctx->sourceKind != XLC_SOURCE_FILE ) {
        xlSetError(ctx->runtime, "token dump currently requires source file input");
        xlApiUnlock();
        return 0;
    }
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcOutputOpen(ctx->runtime, &out, outputPath, "cannot open token output");
    if (ok) {
        const XL6_SourceOverlayItem* item;
        int status = xl6SourceOverlayLookup(&ctx->sourceOverlay, ctx->sourcePath, &item);
        if (status < 0) {
            xl6OutputDiscard(&out); ok = 0; rc = 1;
            xlSetError(ctx->runtime, "cannot resolve token source overlay identity");
        } else rc = item ? xl6LexerDumpSourceTo(&out, item->text, jsonOutput) :
                         xl6LexerDumpFileTo(&out, ctx->sourcePath, jsonOutput);
    } else rc = 1;
    if ( ok ) {
        ok = xlcOutputClose(ctx->runtime, &out, "cannot write token output");
    }
    if ( rc != 0 && ctx->runtime->lastError == NULL ) {
        xlSetError2(ctx->runtime, "cannot dump tokens", ctx->sourcePath);
    }
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok && rc == 0;
}

static int xlcEmitAstInternal(XLC_Context* ctx, const char* outputPath, int jsonOutput, int ranges)
{
    XL_CwdScope cwd;
    XL6_ParseResult result;
    XL6_Output out;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcParseSourceUnlocked(ctx, &result);
    if ( ok ) {
        ok = xlcOutputOpen(ctx->runtime, &out, outputPath, "cannot open AST output");
        if ( ok ) {
            if (ranges) {
                ok = xl6AstDumpJsonRanges(&out, result.root);
                if (!ok) xlSetError(ctx->runtime, "AST range output exceeds limits or cannot be written");
            } else if ( jsonOutput ) {
                xl6AstDumpJson(&out, result.root);
            } else {
                xl6AstDumpTextFile(&out, result.root, 0);
            }
            if (!ok) xl6OutputDiscard(&out);
            else ok = xlcOutputClose(ctx->runtime, &out, "cannot write AST output");
        }
    }
    xl6ParseResultFree(&result);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitAst(XLC_Context* ctx, const char* outputPath, int jsonOutput)
{
    return xlcEmitAstInternal(ctx, outputPath, jsonOutput, 0);
}

XL_API int xlcEmitAstWithRanges(XLC_Context* ctx, const char* outputPath)
{
    return xlcEmitAstInternal(ctx, outputPath, 1, 1);
}

XL_API int xlcEmitIr(XLC_Context* ctx, const char* outputPath, int jsonOutput)
{
    XL_CwdScope cwd;
    XL6_Output out;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcCompileUnlocked(ctx) && xlcOutputOpen(ctx->runtime, &out, outputPath, "cannot open IR output");
    if ( ok ) {
        if ( jsonOutput ) {
            xl6IrDumpModuleJson(&out, &ctx->unit.ir);
        } else {
            xl6IrDumpModuleText(&out, &ctx->unit.ir);
        }
        ok = xlcOutputClose(ctx->runtime, &out, "cannot write IR output");
    }
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitLoweredIr(XLC_Context* ctx, const char* outputPath, int jsonOutput)
{
    XL_CwdScope cwd;
    XL6_Output out;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcCompileUnlocked(ctx) && xlEnsureUnitXlirLowered(ctx->runtime, &ctx->unit) &&
         xlcOutputOpen(ctx->runtime, &out, outputPath, "cannot open lowered IR output");
    if ( ok ) {
        if ( jsonOutput ) {
            xl6IrDumpModuleJson(&out, &ctx->unit.ir);
        } else {
            xl6IrDumpModuleText(&out, &ctx->unit.ir);
        }
        ok = xlcOutputClose(ctx->runtime, &out, "cannot write lowered IR output");
    }
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitC(XLC_Context* ctx, const char* outputPath)
{
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcCompileUnlocked(ctx) &&
         xlEmitUnitCToFile(ctx->runtime, &ctx->unit, outputPath, NULL);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitDebugC(XLC_Context* ctx, const char* outputPath, const char* debugSourcePath)
{
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcCompileUnlocked(ctx) && xlEmitUnitDebugCToFile(ctx->runtime, &ctx->unit, outputPath, debugSourcePath);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitHeader(XLC_Context* ctx, const char* outputPath, const char* guardName)
{
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcCompileUnlocked(ctx) && xlEmitUnitHeaderToFile(
        ctx->runtime, &ctx->unit, outputPath, guardName);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitAbi(XLC_Context* ctx, const char* outputPath, int jsonOutput)
{
    XL_CwdScope cwd;
    XL6_Output out;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    ok = xlcCompileUnlocked(ctx) && xlcOutputOpen(ctx->runtime, &out, outputPath, "cannot open ABI output");
    if ( ok ) {
        if ( jsonOutput ) {
            xl6AbiDumpJson(&out, ctx->unit.parse.root);
        } else {
            xl6AbiDumpText(&out, ctx->unit.parse.root);
        }
        ok = xlcOutputClose(ctx->runtime, &out, "cannot write ABI output");
    }
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitExe(XLC_Context* ctx, const char* outputExe)
{
    XL_CwdScope cwd;
    int ok;
    XL6_BuildInputs* previous;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    if(!xlBeginBuildInputs(ctx->runtime,&previous)) { xlLeaveWorkDir(&cwd); xlApiUnlock(); return 0; }
    ok = xlcCompileUnlocked(ctx) &&
         xlCompileUnitToExternalOutputWithC(ctx->runtime, &ctx->unit,
             outputExe, TCC_OUTPUT_EXE, "exe", NULL,
             &ctx->cSourceFiles);
    ok=xlEndBuildInputs(ctx->runtime,previous,ok,outputExe);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitDebugExe(XLC_Context* ctx, const char* outputExe, const char* debugSourcePath)
{
    XL_CwdScope cwd;
    int ok;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    if ( xlcCompileUnlocked(ctx) ) {
        XL6_IrCgenOptions options;
        memset(&options, 0, sizeof(options));
        options.debugMode = 1;
        options.debugSourcePath = debugSourcePath;
        ok = xlCompileUnitToExternalOutputWithC(ctx->runtime, &ctx->unit,
            outputExe, TCC_OUTPUT_EXE, "debug exe", &options,
            &ctx->cSourceFiles);
    } else {
        ok = 0;
    }
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitSharedLibrary(XLC_Context* ctx, const char* outputDll)
{
    XL_CwdScope cwd;
    int ok;
    XL6_BuildInputs* previous;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return 0;
    }
    if(!xlBeginBuildInputs(ctx->runtime,&previous)) { xlLeaveWorkDir(&cwd); xlApiUnlock(); return 0; }
    ok = xlcCompileUnlocked(ctx) && xlCompileUnitToSharedLibraryWithC(
        ctx->runtime, &ctx->unit, outputDll, &ctx->cSourceFiles);
    ok=xlEndBuildInputs(ctx->runtime,previous,ok,outputDll);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API XL_Module* xlcRelocateModule(XLC_Context* ctx)
{
    XL_CwdScope cwd;
    XL_Module* module;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return NULL;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlApiUnlock();
        return NULL;
    }
    module = xlcCompileUnlocked(ctx) ? xlCompileUnitToModuleWithC(
        ctx->runtime, &ctx->unit, NULL, &ctx->cSourceFiles) : NULL;
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return module;
}

XL_API int xlcRun(XLC_Context* ctx, int argc, char** argv)
{
    XL_CwdScope cwd;
    XL_Module* module;
    xvalue* pArg;
    int ok;
    int hasRuntimeLease;

    if ( ctx == NULL || ctx->runtime == NULL ) {
        return 0;
    }
    xlApiLock();
    if ( !xlcContextBeginCallUnlocked(ctx) ) {
        xlApiUnlock();
        return 0;
    }
    hasRuntimeLease = xlContextBeginCallUnlocked(ctx->runtime);
    if ( !hasRuntimeLease ) {
        xlcContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) {
        xlContextEndCallUnlocked(ctx->runtime);
        xlcContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    pArg = xlcCreateArgArray(ctx->runtime, argc > 0 ? argc : 0, argv);
    if ( pArg == NULL ) {
        xlLeaveWorkDir(&cwd);
        xlContextEndCallUnlocked(ctx->runtime);
        xlcContextEndCallUnlocked(ctx);
        xlApiUnlock();
        return 0;
    }
    module = xlcCompileUnlocked(ctx) ? xlCompileUnitToModuleWithC(
        ctx->runtime, &ctx->unit, NULL, &ctx->cSourceFiles) : NULL;
    ok = module != NULL && xlRunModuleMainUnlocked(ctx->runtime, module, pArg);
    xlDestroyModuleUnlocked(module);
    xrtValueRelease(pArg);
    xlLeaveWorkDir(&cwd);
    xlContextEndCallUnlocked(ctx->runtime);
    xlcContextEndCallUnlocked(ctx);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitXlirC(XLC_Context* ctx, const char* outputPath)
{
    XL_CwdScope cwd;
    int ok;
    if ( ctx == NULL || ctx->runtime == NULL ) return 0;
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) { xlApiUnlock(); return 0; }
    ok = xlcCompileUnlocked(ctx) && xlEmitUnitCToFile(
        ctx->runtime, &ctx->unit, outputPath, NULL);
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API int xlcEmitXlirHeader(XLC_Context* ctx, const char* outputPath, const char* guardName)
{
    XL_CwdScope cwd;
    XL6_Output out;
    int ok;
    if ( ctx == NULL || ctx->runtime == NULL || guardName == NULL || guardName[0] == '\0' ) return 0;
    xlApiLock();
    xlClearLastErrorUnlocked(ctx->runtime);
    if ( !xlEnterWorkDir(ctx->runtime, &cwd) ) { xlApiUnlock(); return 0; }
    ok = xlcCompileUnlocked(ctx) && xlEnsureUnitXlirLowered(ctx->runtime, &ctx->unit);
    if ( ok && !xl6OutputOpenFile(&out, outputPath) ) {
        xlSetError2(ctx->runtime, "cannot open XLIR C header output", outputPath);
        ok = 0;
    }
    if ( ok ) {
        ok = xl6IrCgenEmitHeader(&out, &ctx->unit.ir, guardName, &ctx->unit.parse.diags);
        if ( xl6OutputHasFailed(&out) ) {
            xlSetError2(ctx->runtime, "cannot write XLIR C header output", xl6OutputError(&out));
            ok = 0;
        } else if ( !ok ) xlSetCompileDiagError(ctx->runtime, &ctx->unit);
        if ( ok ) {
            xl6OutputClose(&out);
            if ( xl6OutputHasFailed(&out) ) {
                xlSetError2(ctx->runtime, "cannot write XLIR C header output", xl6OutputError(&out));
                ok = 0;
            }
        } else {
            xl6OutputDiscard(&out);
        }
    }
    xlLeaveWorkDir(&cwd);
    xlApiUnlock();
    return ok;
}

XL_API XL_Context* xlcRuntimeContext(XLC_Context* ctx)
{
    return ctx != NULL ? ctx->runtime : NULL;
}

XL_API const char* xlcGetLastError(XLC_Context* ctx)
{
    return ctx != NULL ? xlGetLastError(ctx->runtime) : "";
}

XL_API void xlcClearLastError(XLC_Context* ctx)
{
    if ( ctx != NULL ) {
        xlClearLastError(ctx->runtime);
    }
}

XL_API int xlcGetLastExitCode(XLC_Context* ctx)
{
    return ctx != NULL ? xlGetLastExitCode(ctx->runtime) : 0;
}
#endif

const char* xlGetLastError(XL_Context* ctx)
{
    if ( ctx == NULL || ctx->lastError == NULL ) {
        return "";
    }
    return ctx->lastError;
}

void xlClearLastError(XL_Context* ctx)
{
    if ( ctx == NULL ) {
        return;
    }
    xlApiLock();
    xlClearLastErrorUnlocked(ctx);
    xlApiUnlock();
}

int xlGetLastExitCode(XL_Context* ctx)
{
    return ctx != NULL ? ctx->lastExitCode : 0;
}

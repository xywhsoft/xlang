static void xl6IrCgenPutStorageName(
    XL6_Output* out, const XL6_IrModule* module, XL6_SymbolId symbol)
{
    const XL6_IrGlobalExport* exported = xl6IrGlobalExportGet(module, symbol);
    const XL6_IrExternGlobal* imported = xl6IrExternGlobalGet(module, symbol);
    if ( exported != NULL ) xl6OutputPuts(exported->cName, out);
    else if ( imported != NULL ) xl6OutputPuts(imported->cName, out);
    else xl6OutputPrintf(out, "s%u", (unsigned int)symbol);
}

/* Result carriers are named by the verified XLIR type pool.  The sole void
 * carrier has no TypeId; every concrete carrier is consumed verbatim here. */
static const char* xl6IrCgenErrorResultType(const XL6_IrModule* module, XL6_IrTypeId type)
{
    const XL6_IrType* item = xl6IrTypeGet(&module->types, type);
    if ( type == XL6_IR_TYPE_INVALID ) return "xlir_result_void";
    return item != NULL && item->errorResultCName[0] != '\0'
        ? item->errorResultCName : NULL;
}

/* The SSA id of a MAY_RAISE direct void call or any first-class void call is
 * an error-carrier token.  It has no C `vN` object and is consumed solely by
 * ERROR_TEST; direct calls map to `rN`, closure calls to their `cN` flag. */
static int xl6IrCgenIsVoidErrorCarrierCall(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    const XL6_IrCallTarget* target;
    const XL6_IrType* signature;
    if ( module == NULL || instruction == NULL ||
         instruction->type != XL6_IR_TYPE_INVALID ||
         instruction->result == XL6_IR_VALUE_INVALID ) return 0;
    if ( instruction->kind == XL6_IR_INSTR_CLOSURE_CALL ) {
        signature = xl6IrTypeGet(&module->types, instruction->calleeType);
        return signature != NULL && signature->kind == XL6_IR_TYPE_FUNCTION &&
               signature->cAbi == XL6_IR_C_ABI_CLOSURE_PTR &&
               signature->callableResultType == XL6_IR_TYPE_INVALID;
    }
    if ( instruction->kind == XL6_IR_INSTR_VIRTUAL_CALL ||
         instruction->kind == XL6_IR_INSTR_PROTOCOL_CALL )
        return xl6IrCallInstructionErrorAbi(module, instruction) == XL6_IR_ERROR_ABI_MAY_RAISE;
    if ( instruction->kind != XL6_IR_INSTR_CALL ) return 0;
    target = xl6IrCallTargetGet(module, instruction->targetSymbol);
    return target != NULL && target->kind != XL6_IR_CALL_TARGET_INTERNAL_ASYNC &&
           target->returnType == XL6_IR_TYPE_INVALID &&
           xl6IrCallInstructionErrorAbi(module, instruction) == XL6_IR_ERROR_ABI_MAY_RAISE;
}

/* These SSA markers have no addressable payload: checked void outcomes,
 * void await outcomes, and descriptor-bound logical empty arguments. */
static int xl6IrCgenIsControlCarrier(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    return xl6IrCgenIsVoidErrorCarrierCall(module, instruction) ||
           xl6IrInstructionIsZeroPayload(module, instruction) ||
           (instruction != NULL && instruction->kind == XL6_IR_INSTR_AWAIT &&
            instruction->asyncResultAbi == XL6_IR_ASYNC_RESULT_VOID &&
            instruction->type == XL6_IR_TYPE_INVALID &&
             instruction->result != XL6_IR_VALUE_INVALID);
}

/* SSA results and physical C locals are deliberately separate contracts.  A
 * borrowed LOAD may exist only to make an owner activation explicit to XLIR,
 * while a result-carrier call may expose only its success/failure outcome.
 * Every other explicit IR reference requires a material C value.  Keep this
 * closed and representation-only: it never recovers source intent or decides
 * whether an operation itself is dead. */
static int xl6IrCgenResultHasMaterialUse(
    const XL6_IrModule* module, const XL6_IrInstruction* definition)
{
    XL6_IrValueId value;
    size_t i, operand;
    if ( module == NULL || definition == NULL ||
         (value = definition->result) == XL6_IR_VALUE_INVALID ) return 0;
    for ( i = 0; i < module->instructionCount; ++i ) {
        const XL6_IrInstruction* user = &module->instructions[i];
        if ( user->targetValue == value || user->pendingFailure == value )
            return 1;
        for ( operand = 0; operand < user->operandCount; ++operand ) {
            if ( module->operands[user->firstOperand + operand] != value )
                continue;
            /* RESULT_CARRIER error tests read r<instruction>.ok.  The payload
             * is material only when another explicit consumer names it. */
            if ( user->kind == XL6_IR_INSTR_ERROR_TEST &&
                 xl6IrCallInstructionErrorPhysicalAbi(module, definition) ==
                     XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER )
                continue;
            return 1;
        }
    }
    for ( i = 0; i < module->callbackCaptureCount; ++i )
        if ( module->callbackCaptures[i].value == value ) return 1;
    for ( i = 0; i < module->asyncMachineFrameSlotCount; ++i )
        if ( module->asyncMachineFrameSlots[i].value == value ) return 1;
    for ( i = 0; i < module->asyncLiveSlotCount; ++i )
        if ( module->asyncLiveSlots[i].value == value ) return 1;
    for ( i = 0; i < module->asyncFrameActionCount; ++i )
        if ( module->asyncFrameActions[i].value == value ) return 1;
    for ( i = 0; i < module->asyncSuspensionCount; ++i )
        if ( module->asyncSuspensions[i].inputValue == value ||
             module->asyncSuspensions[i].resultValue == value ) return 1;
    for ( i = 0; i < module->generatorFrameSlotCount; ++i )
        if ( module->generatorFrameSlots[i].value == value ) return 1;
    for ( i = 0; i < module->generatorLiveSlotCount; ++i )
        if ( module->generatorLiveSlots[i].value == value ) return 1;
    for ( i = 0; i < module->generatorFrameActionCount; ++i )
        if ( module->generatorFrameActions[i].value == value ) return 1;
    for ( i = 0; i < module->generatorSuspensionCount; ++i )
        if ( module->generatorSuspensions[i].itemValue == value ) return 1;
    for ( i = 0; i < module->instantiationCount; ++i )
        if ( module->instantiations[i].receiver == value ) return 1;
    return 0;
}

static int xl6IrCgenResultStorageOmitted(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    const XL6_IrType* type;
    if ( module == NULL || instruction == NULL ||
         instruction->result == XL6_IR_VALUE_INVALID ||
         xl6IrCgenResultHasMaterialUse(module, instruction) ) return 0;
    if ( instruction->kind == XL6_IR_INSTR_LOAD )
        return xl6IrValueOwnershipGet(module, instruction->result) ==
            XL6_IR_OWNERSHIP_BORROW;
    type = xl6IrTypeGet(&module->types, instruction->type);
    if (instruction->kind == XL6_IR_INSTR_CONST && type != NULL &&
        type->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL)
        return 1;
    return type != NULL &&
        type->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL &&
        xl6IrValueOwnershipGet(module, instruction->result) ==
            XL6_IR_OWNERSHIP_COPY &&
        xl6IrCallInstructionErrorPhysicalAbi(module, instruction) ==
            XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER;
}

static int xl6IrCgenIsEntryParameter(
    const XL6_IrModule* module, XL6_SymbolId symbol, size_t parameterIndex)
{
    return module->abi.entryKind == XL6_IR_MODULE_ENTRY_XLANG_MAIN &&
           module->abi.entrySymbol == symbol && parameterIndex == 0;
}

static XL6_IrParameterAbi xl6IrCgenStorageParameterAbi(
    const XL6_IrModule* module, const XL6_IrStorage* storage,
    size_t* outParameter)
{
    size_t functionIndex;
    if ( outParameter != NULL ) *outParameter = SIZE_MAX;
    if ( module == NULL || storage == NULL ||
         storage->kind != XL6_IR_STORAGE_PARAMETER )
        return XL6_IR_PARAMETER_ABI_INVALID;
    for ( functionIndex = 0; functionIndex < module->functionCount;
          ++functionIndex ) {
        const XL6_IrFunction* function = &module->functions[functionIndex];
        const XL6_IrCallTarget* target;
        const XL6_IrType* closureSignature = NULL;
        size_t parameter;
        if ( function->declaration != storage->owner ) continue;
        if (function->kind == XL6_IR_FUNCTION_ARGUMENT_DEFAULT) {
            for (parameter = 0; parameter < function->parameterCount; ++parameter)
                if (module->functionParameters[function->firstParameter + parameter] == storage->symbol) {
                    const XL6_IrType* type = xl6IrTypeGet(&module->types, storage->type);
                    if (outParameter) *outParameter = parameter;
                    return !storage->cellType && type && type->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL
                        ? XL6_IR_PARAMETER_ABI_VALUE : XL6_IR_PARAMETER_ABI_BORROW;
                }
            continue;
        }
        if (function->kind == XL6_IR_FUNCTION_CLASS_FINI) {
            if (function->parameterCount != 1 ||
                module->functionParameters[function->firstParameter] != storage->symbol) continue;
            if (outParameter != NULL) *outParameter = 0;
            return XL6_IR_PARAMETER_ABI_BORROW;
        }
        target = xl6IrCallTargetGet(module, function->symbol);
        if ( target == NULL && function->kind == XL6_IR_FUNCTION_NAMED_ADAPTER ) {
            size_t closureIndex;
            for ( closureIndex = 0; closureIndex < module->closureTargetCount;
                  ++closureIndex ) {
                const XL6_IrClosureTarget* closure =
                    &module->closureTargets[closureIndex];
                if ( (closure->kind == XL6_IR_CLOSURE_TARGET_NAMED_ADAPTER ||
                      closure->kind == XL6_IR_CLOSURE_TARGET_BOUND_METHOD_ADAPTER ||
                      closure->kind == XL6_IR_CLOSURE_TARGET_RESULT_ADAPTER) &&
                     closure->targetSymbol == function->symbol ) {
                    closureSignature = xl6IrTypeGet(
                        &module->types, closure->signatureType);
                    break;
                }
            }
        }
        if ( (target == NULL && closureSignature == NULL) ||
             (target != NULL &&
              (target->parameterAbis == NULL ||
               target->parameterCount != function->parameterCount)) ||
             (closureSignature != NULL &&
              (closureSignature->parameterAbis == NULL ||
               closureSignature->paramCount != function->parameterCount)) )
            return XL6_IR_PARAMETER_ABI_INVALID;
        for ( parameter = 0; parameter < function->parameterCount; ++parameter )
            if ( module->functionParameters[function->firstParameter + parameter] ==
                     storage->symbol ) {
                if ( outParameter != NULL ) *outParameter = parameter;
                return target != NULL ? target->parameterAbis[parameter]
                    : closureSignature->parameterAbis[parameter];
            }
        return XL6_IR_PARAMETER_ABI_INVALID;
    }
    return XL6_IR_PARAMETER_ABI_INVALID;
}

static int xl6IrCgenParameterAbiIsIndirect(XL6_IrParameterAbi abi)
{
    return abi == XL6_IR_PARAMETER_ABI_INOUT ||
           abi == XL6_IR_PARAMETER_ABI_OUT;
}

/* The canonical language place can differ from an ordinary extern's fixed C
 * text argument. Both SSA calls and prepared dynamic witnesses use this map. */
static const char* xl6IrCgenDirectPlaceSuffix(
    const XL6_IrModule* module, const XL6_IrCallTarget* target, size_t parameter)
{
    const XL6_IrType* type = xl6IrTypeGet(&module->types, target->parameterTypes[parameter]);
    return type != NULL && type->cAbi == XL6_IR_C_ABI_MANAGED_STRING &&
        target->parameterPhysicalAbis[parameter]!=XL6_IR_CALL_PARAMETER_PHYSICAL_TEXT_VIEW_BORROW &&
        (target->kind == XL6_IR_CALL_TARGET_EXTERN_C || target->kind == XL6_IR_CALL_TARGET_NATIVE_FACTORY) &&
        target->runtimeBridge == XL6_IR_RUNTIME_BRIDGE_NONE ? ".Data" : "";
}

static const char* xl6IrCgenNativeSlotTypeExpr(XL6_IrNativeSlotAbi);
static const char* xl6IrCgenSequenceTransferAbiToken(XL6_IrRuntimeResourcePayloadAbi);
static int xl6IrCgenEmitNativeServices(XL6_Output* out,const XL6_IrCallTarget* target)
{
    const unsigned mask=target->nativeServicesRequired;
    const unsigned runtime=mask&~XL6_IR_CALL_NATIVE_SERVICE_EXECUTION_SOURCE_V1;
    /* Orthogonal service views keep their existing physical ABI. When both
     * are required, runtime services precede execution services; neither is
     * stored implicitly in an object or inferred from its class spelling. */
    if((mask&~(XL6_IR_CALL_NATIVE_SERVICE_EXECUTION_SOURCE_V1|
        XL6_IR_CALL_NATIVE_SERVICE_EXECUTOR_V1|XL6_IR_CALL_NATIVE_SERVICE_DEADLINE_V1))||
        (!runtime&&!(mask&XL6_IR_CALL_NATIVE_SERVICE_EXECUTION_SOURCE_V1))||
        (runtime&&runtime!=XL6_IR_CALL_NATIVE_SERVICE_EXECUTOR_V1&&runtime!=(XL6_IR_CALL_NATIVE_SERVICE_EXECUTOR_V1|
        XL6_IR_CALL_NATIVE_SERVICE_DEADLINE_V1)))return 0;
    if(runtime){
        xl6OutputPuts("(XL6_RuntimeServicesV1){ .executor = xlir_continuation_executor",out);
        if(runtime&XL6_IR_CALL_NATIVE_SERVICE_DEADLINE_V1)xl6OutputPuts(", .deadline = xlir_deadline_source",out);
        xl6OutputPuts(" }",out);
    }
    if(mask&XL6_IR_CALL_NATIVE_SERVICE_EXECUTION_SOURCE_V1){
        if(runtime)xl6OutputPuts(", ",out);
        xl6OutputPuts("(XL6_ExecutionServicesV1){ xlir_execution_source }",out);
    }
    return !xl6OutputHasFailed(out);
}

static int xl6IrCgenEmitNativeContext(XL6_Output* out,const XL6_IrModule* module,const XL6_IrCallTarget* target)
{
    if(xl6IrNativeContextIsClassCallback(target->nativeContextAbi)){
        XL6_IrNativeClassCallbackPlan plan={0};
        if(!xl6IrNativeClassCallbackPlanBuild(module,target,&plan))return 0;
        if(target->nativeContextAbi==XL6_IR_CALL_NATIVE_CONTEXT_CLASS_PREDICATE_V1){
            xl6OutputPuts("(XL6_NativeClassResultContextV1){{",out);
            xl6IrCgenEmitCStringLiteral(out,plan.argumentField->name);
            xl6OutputPrintf(out,", %lu, %s()}, %s, &xlir_native_result_schema_t%u}",
                (unsigned long)strlen(plan.argumentField->name),plan.argumentField->nativeHandlePolicyCName,
                module->abi.codeOwnerAbi==XL6_IR_MODULE_CODE_OWNER_BIND_BEFORE_INIT?
                    "(xlir_code_owner.size != 0 ? &xlir_code_owner : NULL)":"NULL",(unsigned)plan.argument);
            return !xl6OutputHasFailed(out);
        }
        const XL6_IrClassIdentityPlan* result=xl6IrClassIdentityPlanGet(module,plan.result);
        if(!result)return 0;
        xl6OutputPuts("(XL6_NativeClassCallbackContextV1){{{",out);
        xl6IrCgenEmitCStringLiteral(out,plan.argumentField->name);
        xl6OutputPrintf(out,", %lu, %s()}, %s, &xlir_native_result_schema_t%u}, {",
            (unsigned long)strlen(plan.argumentField->name),plan.argumentField->nativeHandlePolicyCName,
            module->abi.codeOwnerAbi==XL6_IR_MODULE_CODE_OWNER_BIND_BEFORE_INIT?
                "(xlir_code_owner.size != 0 ? &xlir_code_owner : NULL)":"NULL",(unsigned)plan.argument);
        xl6IrCgenEmitCStringLiteral(out,plan.resultField->name);
        xl6OutputPrintf(out,", %lu, %s()}, UINT64_C(0x%016llX)}",
            (unsigned long)strlen(plan.resultField->name),plan.resultField->nativeHandlePolicyCName,
            (unsigned long long)result->identity);
        return !xl6OutputHasFailed(out);
    }
    if(target->nativeContextAbi==XL6_IR_CALL_NATIVE_CONTEXT_NULLARY_VOID_ARRAY_V1){
        const XL6_IrType* array=xl6IrTypeGet(&module->types,target->nativeContextType);
        const XL6_IrType* callback=array&&array->paramCount==1&&array->params?xl6IrTypeGet(&module->types,array->params[0]):NULL;
        if(!array||!callback)return 0;
        xl6OutputPrintf(out,"(XL6_NullaryVoidArrayContextV1){0x%016llXULL, 0x%016llXULL}",
            (unsigned long long)array->typeValueId,(unsigned long long)callback->typeValueId);
        return !xl6OutputHasFailed(out);
    }
    if(target->nativeContextAbi==XL6_IR_CALL_NATIVE_CONTEXT_CLASS_RESULT_V1) {
        const XL6_IrClassField* field=xl6IrNativeClassResultContextField(module,target);
        if(!field||!field->nativeHandlePolicyCName)return 0;
        xl6OutputPuts("(XL6_NativeClassResultContextV1){{",out);
        xl6IrCgenEmitCStringLiteral(out,field->name);
        xl6OutputPrintf(out,", %lu, %s()}, %s, &xlir_native_result_schema_t%u}",
            (unsigned long)strlen(field->name),field->nativeHandlePolicyCName,
            module->abi.codeOwnerAbi==XL6_IR_MODULE_CODE_OWNER_BIND_BEFORE_INIT?
                "(xlir_code_owner.size != 0 ? &xlir_code_owner : NULL)":"NULL",(unsigned)target->nativeContextType);
        return !xl6OutputHasFailed(out);
    }
    if(target->nativeContextAbi==XL6_IR_CALL_NATIVE_CONTEXT_CLASS_FIELD_V1) {
        const XL6_IrClassField* field=xl6IrNativeClassContextField(module,target);
        if(!field || !field->nativeHandlePolicyCName)return 0;
        xl6OutputPuts("(XL6_NativeClassFieldContextV1){",out);
        xl6IrCgenEmitCStringLiteral(out,field->name);
        xl6OutputPrintf(out,", %lu, %s()}",(unsigned long)strlen(field->name),field->nativeHandlePolicyCName);
        return !xl6OutputHasFailed(out);
    }
    if(target->nativeContextAbi==XL6_IR_CALL_NATIVE_CONTEXT_CLASS_ARRAY_V1) {
        const XL6_IrClassField* field=xl6IrNativeClassArrayContextField(module,target);
        const XL6_IrType* owner=xl6IrTypeGet(&module->types,target->nativeContextType);
        const XL6_IrType* element=owner && owner->params ? xl6IrTypeGet(&module->types,owner->params[0]) : NULL;
        const char* slot=owner ? xl6IrCgenNativeSlotTypeExpr(owner->sequenceLayout.slotAbi) : NULL;
        if(!field || !element || !slot || !field->nativeHandlePolicyCName)return 0;
        xl6OutputPrintf(out,"(XL6_NativeClassArrayContextV1){{0x%016llXULL, 0x%016llXULL, 3, sizeof(xvalue*), %s}, ",
            (unsigned long long)owner->typeValueId,(unsigned long long)element->typeValueId,slot);
        xl6IrCgenEmitCStringLiteral(out,field->name);
        xl6OutputPrintf(out,", %lu, %s()}",(unsigned long)strlen(field->name),field->nativeHandlePolicyCName);
        return !xl6OutputHasFailed(out);
    }
    if(target->nativeContextAbi==XL6_IR_CALL_NATIVE_CONTEXT_CHANNEL_SCHEMA_V1) {
        XL6_IrTypeId schemaId=0;
        if(!xl6IrChannelConstructionRecipe(module,target->nativeContextType,&schemaId,NULL))return 0;
        const XL6_IrType* owner=xl6IrTypeGet(&module->types,target->nativeContextType);
        const XL6_IrType* schema=xl6IrTypeGet(&module->types,schemaId);
        const XL6_IrType* element=xl6IrTypeGet(&module->types,owner->params[0]);
        XL6_IrNativeCallValuePlan value={0};
        if (!xl6IrNativeCallValuePlanBuild(module,target,&value)) return 0;
        const char* type=xl6IrCgenNativeCallValueEncoded(&value)?"xvalue*":xl6IrCgenType(module,owner->params[0]);
        const char* slot=xl6IrCgenNativeSlotTypeExpr(schema->sequenceLayout.slotAbi);
        const char* transfer=xl6IrCgenSequenceTransferAbiToken(schema->sequenceLayout.transferAbi);
        if(!type || !slot || !transfer || !element)return 0;
        xl6OutputPrintf(out,"(XL6_SequenceLayoutV1){0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s}",
            (unsigned long long)owner->typeValueId,(unsigned long long)element->typeValueId,transfer,type,slot);
        return !xl6OutputHasFailed(out);
    }
    if(target->nativeContextAbi!=XL6_IR_CALL_NATIVE_CONTEXT_FUTURE_VALUE_V1)return 0;
    XL6_IrNativeCallValuePlan value={0};
    if (!xl6IrNativeCallValuePlanBuild(module,target,&value)) return 0;
    const XL6_IrType* type=xl6IrTypeGet(&module->types,target->nativeContextType);
    const char* name=xl6IrCgenNativeCallValueEncoded(&value)?"xvalue*":
        type?xl6IrCgenType(module,target->nativeContextType):NULL;
    const char* kind=NULL;
    switch(target->nativeContextPayloadAbi) {
    case XL6_IR_ASYNC_RESULT_VOID:kind="XL6_FUTURE_VALUE_VOID";break;
    case XL6_IR_ASYNC_RESULT_COPY_BOOL:case XL6_IR_ASYNC_RESULT_COPY_I64:
    case XL6_IR_ASYNC_RESULT_COPY_U64:case XL6_IR_ASYNC_RESULT_COPY_TYPE_ID:
    case XL6_IR_ASYNC_RESULT_COPY_F64:case XL6_IR_ASYNC_RESULT_COPY_TAGGED:
    case XL6_IR_ASYNC_RESULT_COPY_F32:case XL6_IR_ASYNC_RESULT_COPY_TIME:
    case XL6_IR_ASYNC_RESULT_COPY_RAW_POINTER:case XL6_IR_ASYNC_RESULT_COPY_CHAR:
    case XL6_IR_ASYNC_RESULT_COPY_C_SCALAR:
    case XL6_IR_ASYNC_RESULT_COPY_UNION:
        kind="XL6_FUTURE_VALUE_TRIVIAL";break;
    case XL6_IR_ASYNC_RESULT_OWNED_STRING:kind="XL6_FUTURE_VALUE_STRING";break;
    case XL6_IR_ASYNC_RESULT_RETAINED_XVALUE:kind="XL6_FUTURE_VALUE_XVALUE";break;
    case XL6_IR_ASYNC_RESULT_RETAINED_ERROR:kind="XL6_FUTURE_VALUE_ERROR";break;
    case XL6_IR_ASYNC_RESULT_RETAINED_CLOSURE:kind="XL6_FUTURE_VALUE_CLOSURE";break;
    case XL6_IR_ASYNC_RESULT_RETAINED_FUTURE:kind="XL6_FUTURE_VALUE_FUTURE";break;
    case XL6_IR_ASYNC_RESULT_RETAINED_GENERATOR:kind="XL6_FUTURE_VALUE_GENERATOR";break;
    case XL6_IR_ASYNC_RESULT_OWNED_NATIVE_VALUE:kind="XL6_FUTURE_VALUE_NATIVE";break;
    default:return 0;
    }
    /* A void Future has a logical null TypeId but no material C value slot.
     * Its descriptor still carries identity; no C type name is required. */
    if(!type || !kind || (!name && target->nativeContextPayloadAbi!=XL6_IR_ASYNC_RESULT_VOID))return 0;
    xl6OutputPrintf(out,"(XL6_FutureValueProfileV1){ sizeof(XL6_FutureValueProfileV1), %s, ",kind);
    if(target->nativeContextPayloadAbi==XL6_IR_ASYNC_RESULT_VOID)xl6OutputPuts("0",out);
    else xl6OutputPrintf(out,"sizeof(%s)",name);
    xl6OutputPrintf(out,", 0x%016llXULL, ",(unsigned long long)type->typeValueId);
    if(target->nativeContextPayloadAbi==XL6_IR_ASYNC_RESULT_OWNED_NATIVE_VALUE) {
        const XL6_IrNativeValuePlan* native=xl6IrNativeValuePlanForType(type);
        if(!native || !native->captureProfileSymbol)return 0;
        xl6OutputPrintf(out,"%s()",native->captureProfileSymbol);
    } else xl6OutputPuts("NULL",out);
    xl6OutputPuts(" }",out);return !xl6OutputHasFailed(out);
}

/* The same verified physical mapping is rendered for SSA operands, named
 * adapters and dispatch witnesses. `place` already denotes the logical value;
 * a native-class field witness supplies its resolved raw projection instead. */
static int xl6IrCgenEmitCallPlace(XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrCallTarget* target, size_t parameter, const char* place)
{
    if (!target || parameter >= target->parameterCount || !target->parameterPhysicalAbis || !place) return 0;
    XL6_IrCallParameterPhysicalAbi abi = target->parameterPhysicalAbis[parameter];
    const XL6_IrType* type = xl6IrTypeGet(&module->types, target->parameterTypes[parameter]);
    switch (abi) {
    case XL6_IR_CALL_PARAMETER_PHYSICAL_SYNC_C_CALLBACK: {
        const XL6_ForeignParameterContract* row=xl6IrForeignParameterGet(module,target,parameter);
        if(!row)return 0;
        xl6OutputPrintf(out,"native_callback_%lu.invocation.self ? %s_thunk : NULL, native_callback_%lu.invocation.self ? &native_callback_%lu : NULL",
            (unsigned long)parameter,row->callbackTypeCName,(unsigned long)parameter,(unsigned long)parameter);break;
    }
    case XL6_IR_CALL_PARAMETER_PHYSICAL_RETAINED_C_CALLBACK: {
        const XL6_ForeignParameterContract* row=xl6IrForeignParameterGet(module,target,parameter);
        if(!row)return 0;
        xl6OutputPrintf(out,"native_callback_%lu ? %s_thunk : NULL, native_callback_%lu, native_callback_%lu ? &native_callback_owner_%lu : NULL",
            (unsigned long)parameter,row->callbackTypeCName,(unsigned long)parameter,(unsigned long)parameter,(unsigned long)parameter);break;
    }
    case XL6_IR_CALL_PARAMETER_PHYSICAL_FOREIGN_SPAN_BORROW: {
        const XL6_ForeignParameterContract* row=xl6IrForeignParameterGet(module,target,parameter);
        if(!row)return 0;
        xl6OutputPrintf(out,"(%s)native_span_data_%lu, (%s)native_span_count_%lu",row->pointerCName,
            (unsigned long)parameter,row->countAbi==XL6_FOREIGN_SPAN_COUNT_INT ? "int" : "size_t",(unsigned long)parameter);
        break;
    }
    case XL6_IR_CALL_PARAMETER_PHYSICAL_FOREIGN_REGION_BORROW:{
        const XL6_ForeignRegionContract* row=xl6IrForeignRegionGet(module,target,parameter);if(!row)return 0;
        xl6OutputPrintf(out,"(%s)native_region_data_%lu",row->access==XL6_FOREIGN_REGION_ACCESS_READ ? "const void*":"void*",(unsigned long)parameter);break;
    }
    case XL6_IR_CALL_PARAMETER_PHYSICAL_NATIVE_HANDLE_ACCESS_BORROW:
        xl6OutputPrintf(out,"native_access_%lu.raw",(unsigned long)parameter);break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_TERMINATED_STRING_BORROW:
        xl6OutputPrintf(out, "xlir_cstr_arg_%lu", (unsigned long)parameter); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_BYTES_VIEW_BORROW:
        xl6OutputPrintf(out, "xlir_bytes_arg_%lu", (unsigned long)parameter); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_FOREIGN_VALUE_BORROW: {
        const XL6_ForeignValueContract* row=xl6IrForeignValueGet(module,target,parameter);
        if(!row)return 0;
        xl6OutputPrintf(out,"*((%s)native_view_%lu.raw)",type->cName,(unsigned long)parameter);break;
    }
    case XL6_IR_CALL_PARAMETER_PHYSICAL_FOREIGN_VIEW_BORROW:
        xl6OutputPrintf(out, "(%s)native_view_%lu.raw", type->cName, (unsigned long)parameter); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_CONST_FOREIGN_VIEW_BORROW: {
        const XL6_ForeignPointerQualifierContract* row=xl6IrForeignPointerQualifierGet(module,target,parameter);
        if(!row)return 0;
        xl6OutputPrintf(out,"(%s)native_view_%lu.raw",row->cName,(unsigned long)parameter);break;
    }
    case XL6_IR_CALL_PARAMETER_PHYSICAL_CONST_C_AGGREGATE_BORROW:
        if(type->cAbi==XL6_IR_C_ABI_C_ARRAY)xl6OutputPrintf(out,"(%s).Elements",place);
        else xl6OutputPrintf(out,"&%s",place);
        break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_GENERIC_VALUE_ADDRESS_BORROW:
        xl6OutputPrintf(out, "&%s", place); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_C_SPAN_BORROW:
        if (!xl6IrTypeIsCOwned(type)) return 0;
        xl6OutputPrintf(out, "%s(%s)", type->cAbi == XL6_IR_C_ABI_C_STRING ? "xl6CStringViewV1" : "xl6CBytesViewV1", place); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_GENERIC_ZERO_PAYLOAD:
        xl6OutputPuts("NULL", out); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_CHECKED_RESULT_CLOSURE_BORROW:
        xl6OutputPrintf(out, "(XL6_CheckedResultClosureBorrowV1){%s, xlir_checked_result_t%u, xlir_closure_owner}",
            place, (unsigned)target->parameterTypes[parameter]); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_LANGUAGE_FUNCTION_VALUE:
        xl6OutputPrintf(out, "xlir_language_function_value_t%u(%s)", (unsigned)target->parameterTypes[parameter], place); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_RAW_C_CALLBACK:
        xl6OutputPrintf(out, "(xlir_raw_callback_t%u)(%s != NULL ? %s->raw_callback : NULL)",
            (unsigned)target->parameterTypes[parameter], place, place); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_STATIC_C_CALLBACK:
    case XL6_IR_CALL_PARAMETER_PHYSICAL_TEXT_VIEW_BORROW:
    case XL6_IR_CALL_PARAMETER_PHYSICAL_NATIVE_CLASS_HANDLE_BORROW:
        xl6OutputPuts(place, out); break;
    case XL6_IR_CALL_PARAMETER_PHYSICAL_DIRECT:
    case XL6_IR_CALL_PARAMETER_PHYSICAL_CONST_NATIVE_POINTER_DIRECT:
    case XL6_IR_CALL_PARAMETER_PHYSICAL_CONST_XVALUE_BORROW:
    case XL6_IR_CALL_PARAMETER_PHYSICAL_CHECKED_CLOSURE_BORROW:
        if (xl6IrCgenParameterAbiIsIndirect(target->parameterAbis[parameter]))
            xl6OutputPrintf(out, "(%s*)%s", xl6IrCgenType(module, target->parameterTypes[parameter]), place);
        else xl6OutputPrintf(out, "%s%s", place, xl6IrCgenDirectPlaceSuffix(module, target, parameter));
        break;
    default: return 0;
    }
    return !xl6OutputHasFailed(out);
}
static int xl6IrCgenEmitCallOperand(XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrCallTarget* target, size_t parameter, XL6_IrValueId value)
{
    if (!target || parameter >= target->parameterCount) return 0;
    if (target->parameterPhysicalAbis[parameter] == XL6_IR_CALL_PARAMETER_PHYSICAL_GENERIC_ZERO_PAYLOAD) {
        const XL6_IrInstruction* definition = xl6IrCgenValueDefinition(module, value, NULL);
        if (!xl6IrInstructionIsZeroPayload(module, definition) || definition->type != target->parameterTypes[parameter]) return 0;
    }
    char place[40]; snprintf(place, sizeof(place), "v%u", (unsigned)value);
    return xl6IrCgenEmitCallPlace(out, module, target, parameter, place);
}

static int xl6IrCgenWitnessNativeHandles(XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrCallTarget* target, const char* scope)
{
    int count = 0;
    for (size_t p = 0; p < target->parameterCount; ++p) {
        if (target->parameterPhysicalAbis[p] != XL6_IR_CALL_PARAMETER_PHYSICAL_NATIVE_CLASS_HANDLE_BORROW) continue;
        if (!count++) xl6OutputPuts("    bool native_arguments_ok = true;\n", out);
        const XL6_IrClassField* field = xl6IrCgenNativeClassPhysicalField(module, target, p);
        if (!field) return -1;
        xl6OutputPrintf(out, "    void* native%lu = NULL;\n    if (native_arguments_ok) { xvalue* field = xrtValueObjectGet(", (unsigned long)p);
        if (p) xl6OutputPrintf(out, "a%lu", (unsigned long)(p - 1));
        else xl6OutputPuts("receiver", out);
        xl6OutputPuts(", xlir_literal_view(", out); xl6IrCgenEmitCStringLiteral(out, field->name);
        xl6OutputPrintf(out, ")); if (!field || !%s(field, &native%lu%s)) { native_arguments_ok = false; xrtSetErrorKind(XERR_VALUE); xl6ErrorScopeCaptureFailure(&%s); } }\n",
            field->nativeDestroySymbol ? "xrtValueGetHandle" : "xrtValueGetPointer", (unsigned long)p,
            field->nativeDestroySymbol ? ", NULL, NULL" : "", scope);
    }
    if (count) xl6OutputPuts("    if (native_arguments_ok) {\n", out);
    return count;
}

/* Witness parameters have stable logical names. Raw class-field projections
 * are prepared as nativeN by the witness; all other mappings are identical to
 * the direct SSA call. This renderer emits C expressions, never forwarding code. */
static void xl6IrCgenEmitNativeStatusCheck(XL6_Output* out,const XL6_IrModule* module,
    const XL6_IrCallTarget* target,const char* errors)
{
    (void)module;
    if(target->resultCAbi==XL6_IR_CALL_RESULT_C_ABI_INT_STATUS || target->outputResultAbi==XL6_IR_CALL_OUTPUT_RESULT_INT_STATUS){
        xl6OutputPrintf(out,"    if (native_status != %d) { if (!%s.failed && !xrtGetError()) xl6ForeignStatusFailureV1(native_status, \"%s\"); xl6ErrorScopeCaptureFailure(&%s); }\n",
            target->nativeSuccessCode,errors,target->cName,errors);
    }else xl6OutputPrintf(out,"    if (!native_status) xl6ErrorScopeCaptureFailure(&%s);\n",errors);
}

static int xl6IrCgenPrepareForeignCountedField(XL6_Output* out,const XL6_IrModule* module,
    const XL6_IrCallTarget* target,const XL6_IrValueId* values,const char* errors)
{
    const XL6_ForeignFieldLengthContract* length=xl6IrForeignFieldLengthGet(module,target);
    if(!length)return 1;
    const XL6_IrType* receiver=xl6IrTypeGet(&module->types,target->parameterTypes[0]);
    char place[40];if(values)snprintf(place,sizeof(place),"v%u",(unsigned)values[0]);else strcpy(place,"receiver");
    const char* view=xl6IrCgenBorrowedResultCType(target);
    const char* count=length->countAbi==XL6_FOREIGN_SPAN_COUNT_INT ? "int" : "size_t";
    xl6OutputPrintf(out,"    %s native_field_view = {0};\n    %s native_field_count = (",view,count);
    if(!xl6IrCgenEmitCallPlace(out,module,target,0,place))return 0;
    xl6OutputPrintf(out,")->%s;\n    size_t native_field_bound = _Generic(&((%s)0)->%s,\n"
        "        char (*)[sizeof(((%s)0)->%s)]: sizeof(((%s)0)->%s),\n"
        "        const char (*)[sizeof(((%s)0)->%s)]: sizeof(((%s)0)->%s),\n"
        "        unsigned char (*)[sizeof(((%s)0)->%s)]: sizeof(((%s)0)->%s),\n"
        "        const unsigned char (*)[sizeof(((%s)0)->%s)]: sizeof(((%s)0)->%s), default: SIZE_MAX);\n",
        length->field,receiver->cName,target->cName,
        receiver->cName,target->cName,receiver->cName,target->cName,
        receiver->cName,target->cName,receiver->cName,target->cName,
        receiver->cName,target->cName,receiver->cName,target->cName,
        receiver->cName,target->cName,receiver->cName,target->cName);
    xl6OutputPrintf(out,"    if (%s(size_t)native_field_count > native_field_bound) { xrtSetErrorKind(XERR_RANGE); xl6ErrorScopeCaptureFailure(&%s); }\n"
        "    else { native_field_view.Size=(size_t)native_field_count; native_field_view.Data=(%s)(",
        length->countAbi==XL6_FOREIGN_SPAN_COUNT_INT ? "native_field_count < 0 || " : "",errors,
        target->resultCAbi==XL6_IR_CALL_RESULT_C_ABI_BYTES_VIEW ? "const uint8_t*" : "const char*");
    if(!xl6IrCgenEmitCallPlace(out,module,target,0,place))return 0;
    xl6OutputPrintf(out,")->%s; }\n",target->cName);return !xl6OutputHasFailed(out);
}

static int xl6IrCgenEmitForeignProjectionExpression(XL6_Output* out,const XL6_IrModule* module,
    const XL6_IrCallTarget* target,const XL6_IrValueId* values)
{
    if(xl6IrForeignFieldLengthGet(module,target)){xl6OutputPuts("native_field_view",out);return !xl6OutputHasFailed(out);}
    char place[40];
    if(values)snprintf(place,sizeof(place),"v%u",(unsigned)values[0]);
    else strcpy(place,"receiver");
    bool dereference=target->foreignOperationAbi==XL6_IR_FOREIGN_OPERATION_DEREF_READ || target->foreignOperationAbi==XL6_IR_FOREIGN_OPERATION_DEREF_WRITE;
    xl6OutputPuts(dereference ? "(*(" : "(",out);
    if(!xl6IrCgenEmitCallPlace(out,module,target,0,place))return 0;
    if(dereference)xl6OutputPuts("))",out);else xl6OutputPrintf(out,")->%s",target->cName);
    if(target->foreignOperationAbi==XL6_IR_FOREIGN_OPERATION_FIELD_WRITE || target->foreignOperationAbi==XL6_IR_FOREIGN_OPERATION_DEREF_WRITE){
        xl6OutputPuts(" = ",out);
        if(values)snprintf(place,sizeof(place),"v%u",(unsigned)values[1]);else strcpy(place,"a0");
        if(!xl6IrCgenEmitCallPlace(out,module,target,1,place))return 0;
    }
    return !xl6OutputHasFailed(out);
}

static int xl6IrCgenEmitPreparationRollback(
    XL6_Output*, const XL6_IrModule*, const XL6_IrCallTarget*,
    const XL6_IrValueId*, size_t, const char*, XL6_DiagList*);

static int xl6IrCgenNativeFieldCallBegin(XL6_Output* out,const XL6_IrModule* module,
    const XL6_IrCallTarget* target,const XL6_IrValueId* values,const char* errors,XL6_DiagList* diags)
{
    const XL6_ForeignFieldCallContract* field=xl6IrForeignFieldCallGet(module,target);
    if(!field)return 0;
    const XL6_IrType* receiver=xl6IrTypeGet(&module->types,target->parameterTypes[0]);
    const XL6_ForeignPointerQualifierContract* qualified=xl6IrForeignPointerQualifierGet(module,target,0);
    char place[40];if(values)snprintf(place,sizeof(place),"v%u",(unsigned)values[0]);else strcpy(place,"receiver");
    xl6OutputPrintf(out,"    { %s native_callee_receiver = ",qualified ? qualified->cName:receiver->cName);
    if(!xl6IrCgenEmitCallPlace(out,module,target,0,place))return -1;
    xl6OutputPrintf(out,";\n    xlir_native_callee_s%u native_callee = native_callee_receiver ? native_callee_receiver->%s : NULL;\n"
        "    if (!native_callee) { xrtSetErrorKind(native_callee_receiver ? XERR_UNSUPPORTED : XERR_STATE); xl6ErrorScopeCaptureFailure(&%s);\n",
        (unsigned)target->symbol,field->field,errors);
    bool owned=false;
    for(size_t p=1;p<target->parameterCount;++p)if(target->parameterAbis[p]==XL6_IR_PARAMETER_ABI_OWNED)owned=true;
    if(owned){
        xl6OutputPuts("    xl6_error_result native_callee_cleanup = {false,NULL};\n",out);
        if(!xl6IrCgenEmitPreparationRollback(out,module,target,values,values ? 0:1,"native_callee_cleanup",diags))return -1;
        xl6OutputPuts("    xl6ErrorScopePropagateFailure(native_callee_cleanup);\n",out);
    }
    xl6OutputPuts("    }\n    if (native_callee) {\n",out);
    return 1;
}

#include "src/cgen/xl6_ir_cgen_foreign_region.c"

static int xl6IrCgenEmitWitnessNativeCall(XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrCallTarget* target, const char* result, const char* scope)
{
    XL6_IrNativeCallValuePlan valuePlan = {0};
    if (!xl6IrNativeCallValuePlanBuild(module, target, &valuePlan)) return 0;
    bool encoded = xl6IrCgenNativeCallValueEncoded(&valuePlan);
    char input[40];
    if (valuePlan.inputParameter > 1) snprintf(input, sizeof(input), "a%u", valuePlan.inputParameter - 2);
    else snprintf(input, sizeof(input), "receiver");
    if (!xl6IrCgenNativeCallValueBegin(out, module, &valuePlan, input, scope)) return 0;
    int arrays=xl6IrCgenArraysBegin(out,module,target,NULL,scope);if(arrays<0)return 0;
    int views = xl6IrCgenForeignViewsBegin(out, module, target, NULL, NULL, scope);
    int cstrings = xl6IrCgenPrepareTerminatedStrings(out, module,target, NULL, scope);
    int bytes = xl6IrCgenPrepareBytesViews(out, target, NULL);
    int spans=xl6IrCgenForeignSpansBegin(out,module,target,NULL,scope);
    if(spans<0)return 0;
    int regions=xl6IrCgenForeignRegionsBegin(out,module,target,NULL,scope);
    if(regions<0)return 0;
    int access = xl6IrCgenNativeAccessBegin(out,module,target,NULL,scope);
    if(access<0)return 0;
    int callbacks=xl6IrCgenNativeCallbacksBegin(out,module,target,NULL,scope);
    if(callbacks<0)return 0;
    if(!xl6IrCgenPrepareForeignCountedField(out,module,target,NULL,scope))return 0;
    int packs=xl6IrCgenForeignPacksBegin(out,module,target,NULL,scope);
    if(packs<0)return 0;
    int fieldCallee=xl6IrCgenNativeFieldCallBegin(out,module,target,NULL,scope,NULL);
    if(fieldCallee<0)return 0;
    int probe = xl6IrCgenFactoryProbeBegin(out, module, target, scope);
    const XL6_IrNode* declaration = xl6IrNodeGet(module, target->declaration);
    int factoryOutput=declaration->foreignCall.outputIndexPlusOne && !declaration->foreignCall.valueOutput;
    int storagePrepared=0;
    int valueOutput=target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_NATIVE_OUTPUT_VALUE;
    int outputProbes=0;
    if(valueOutput){
        if(!xl6IrCgenOutputRawDeclare(out,module,target))return 0;
        outputProbes=xl6IrCgenOutputProbesBegin(out,module,target,scope);
        xl6OutputPuts("    ",out);
        if(target->outputResultAbi==XL6_IR_CALL_OUTPUT_RESULT_INT_STATUS)xl6OutputPuts("int native_status = ",out);
    }
    else if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_NATIVE_VIEW_ADMIT) {
        const XL6_IrType* type = xl6IrTypeGet(&module->types, target->returnType);
        if(factoryOutput)storagePrepared=xl6IrCgenFactoryStorageBegin(out,module,target,scope);
        if(!storagePrepared)xl6OutputPrintf(out, factoryOutput ? "    %s native_raw = NULL; int native_status = " : "    %s native_raw = ", type->cName);
    } else if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_STATUS_CHECK)
        xl6OutputPuts(target->resultCAbi==XL6_IR_CALL_RESULT_C_ABI_INT_STATUS ? "    int native_status = " : "    bool native_status = ", out);
    else if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_BORROWED_VALUE_COPY)
        xl6OutputPrintf(out, "    %s borrowed_raw = ", xl6IrCgenBorrowedResultCType(target));
    else if (target->producerErrorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER) {
        /* result names its payload, so the containing carrier is selected by
         * the caller-independent witness convention. */
        size_t size = strlen(result);
        if (size < 6 || strcmp(result + size - 6, ".value")) return 0;
        xl6OutputPrintf(out, "    %.*s = ", (int)(size - 6), result);
    } else if (target->returnType && target->nativeResultAbi == XL6_IR_CALL_NATIVE_RESULT_NONE)
        xl6OutputPrintf(out, "    %s%s = ", result,
            target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_OWNED_STRING_TAKE ? ".Data" : "");
    if(!xl6IrForeignOperationInvokesFunction(target->foreignOperationAbi)){
        if(!xl6IrCgenEmitForeignProjectionExpression(out,module,target,NULL))return 0;
        xl6OutputPuts(";\n",out);
    }else {
    xl6OutputPrintf(out, "%s(", fieldCallee ? "native_callee":target->cName);
    if (target->nativeServicesRequired) {
        if (!xl6IrCgenEmitNativeServices(out, target)) return 0;
        if (target->nativeContextAbi || target->parameterCount) xl6OutputPuts(", ", out);
    }
    if (target->nativeContextAbi) {
        if (!xl6IrCgenEmitNativeContext(out, module, target)) return 0;
        if (target->parameterCount) xl6OutputPuts(", ", out);
    }
    size_t physicalSteps=xl6IrForeignPhysicalStepCount(module,target);
    if(physicalSteps>target->parameterCount+64)return 0;
    for (size_t physical = 0; physical < physicalSteps; ++physical) {
        if (physical) xl6OutputPuts(", ", out);
        XL6_ForeignPhysicalStep step;if(!xl6IrForeignPhysicalStepGet(module,target,physical,&step))return 0;
        size_t p=step.parameter;
        if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_FIXED){
            const XL6_ForeignFixedInputContract* row=xl6IrForeignFixedInputGet(module,target,step.physicalIndex);if(!row)return 0;
            if(row->kind==XL6_FOREIGN_FIXED_MODULE_CODE_OWNER && module->abi.codeOwnerAbi==XL6_IR_MODULE_CODE_OWNER_BIND_BEFORE_INIT)
                xl6OutputPuts("(xlir_code_owner.size ? &xlir_code_owner : NULL)",out);
            else xl6OutputPrintf(out,"(%s)0",row->pointerCName);
            continue;
        }
        if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_ARRAY_GROUP){if(!xl6IrCgenArrayArguments(out,module,target,step.physicalIndex))return 0;continue;}
        if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_PACK){xl6OutputPrintf(out,"&native_pack_%u",step.physicalIndex);continue;}
        if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_OUTPUT){
            if(valueOutput){
                if(xl6IrForeignNativeSequenceGet(module,target) || (!xl6IrForeignOutputRecordGet(module,target) && xl6IrForeignOutputCount(module,target)>1))xl6OutputPrintf(out,"&native_raw.e%lu",(unsigned long)step.ordinal);
                else xl6OutputPuts("&native_raw",out);
            }else xl6OutputPuts(storagePrepared ? "native_raw":"&native_raw",out);
            continue;
        }
        if (encoded && valuePlan.inputParameter == p + 1) xl6OutputPuts("&native_value_input", out);
        else {
            char place[40];
            if (target->parameterPhysicalAbis[p] == XL6_IR_CALL_PARAMETER_PHYSICAL_NATIVE_CLASS_HANDLE_BORROW)
                snprintf(place, sizeof(place), "native%lu", (unsigned long)p);
            else if (p) snprintf(place, sizeof(place), "a%lu", (unsigned long)(p - 1));
            else snprintf(place, sizeof(place), "receiver");
            if (!xl6IrCgenEmitCallPlace(out, module, target, p, place)) return 0;
        }
    }
    if (target->nativeResultAbi == XL6_IR_CALL_NATIVE_RESULT_VALUE_SLOT_V1) {
        if (target->parameterCount || target->nativeContextAbi || target->nativeServicesRequired) xl6OutputPuts(", ", out);
        if (encoded && valuePlan.output) xl6OutputPuts("&native_value_output", out);
        else xl6OutputPrintf(out, "&%s", result);
    }
    xl6OutputPuts(");\n", out);
    }
    if(storagePrepared)xl6OutputPuts("    }\n",out);
    xl6IrCgenNativeCallbacksObserve(out,target,scope);
    if(target->producerErrorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_NULL_RESULT)
        xl6OutputPrintf(out,"    if (%s == NULL) xl6ErrorScopeCaptureFailure(&%s);\n",result,scope);
    if(target->producerErrorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER) {
        size_t bytes=strlen(result);
        xl6OutputPrintf(out,"    if (!%.*s.ok) xl6ErrorScopeCaptureFailure(&%s);\n",(int)(bytes-6),result,scope);
    }
    if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_NATIVE_VIEW_ADMIT)
        xl6IrCgenNativeViewAdmission(out, module, target, NULL, NULL, result, "native_raw", scope, target->outputResultAbi==XL6_IR_CALL_OUTPUT_RESULT_INT_STATUS ? "native_status" : NULL);
    if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_STATUS_CHECK ||
        (valueOutput && target->outputResultAbi==XL6_IR_CALL_OUTPUT_RESULT_INT_STATUS))
        xl6IrCgenEmitNativeStatusCheck(out,module,target,scope);
    if(valueOutput && !xl6IrCgenOutputValuesAdmit(out,module,target,result,scope))return 0;
    if(outputProbes)xl6IrCgenOutputProbesEnd(out,module,target,scope);
    if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_BORROWED_VALUE_COPY)
        xl6IrCgenEmitBorrowedValueAdmission(out, module, target, result, "borrowed_raw", scope);
    if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_OWNED_STRING_TAKE) {
        char failed[80]; snprintf(failed, sizeof(failed), "%s.failed", scope);
        xl6IrCgenEmitOwnedStringAdmission(out, module, target, result, failed);
    }
    for (size_t p = 1; p < target->parameterCount; ++p)
        if (target->parameterAbis[p] == XL6_IR_PARAMETER_ABI_OWNED)
            xl6OutputPrintf(out, "    a%lu = (%s){0};\n", (unsigned long)(p - 1), xl6IrCgenType(module, target->parameterTypes[p]));
    if (probe) xl6IrCgenFactoryProbeEnd(out, scope);
    if(fieldCallee)xl6OutputPuts("    } }\n",out);
    if(packs)xl6IrCgenForeignPacksEnd(out);
    if(callbacks)xl6IrCgenNativeCallbacksEnd(out,target,scope);
    if (access) xl6IrCgenNativeAccessEnd(out,target,scope);
    if(regions)xl6IrCgenForeignRegionsEnd(out,module,target,scope);
    if(spans)xl6IrCgenForeignSpansEnd(out,module,target,scope);
    if (bytes) xl6OutputPuts("    }\n", out);
    if (cstrings) xl6OutputPuts("    } }\n", out);
    if (views) xl6IrCgenForeignViewsEnd(out, target, scope);
    if(arrays)xl6IrCgenArraysEnd(out,module,target,scope);
    if (!xl6IrCgenNativeCallValueEnd(out, module, &valuePlan, result, scope)) return 0;
    return !xl6OutputHasFailed(out);
}

static int xl6IrCgenEmitCFunctionAddress(XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrInstruction* instruction, XL6_DiagList* diags)
{
    if (!xl6IrCFunctionAddressTargetMatches(module, instruction->type, instruction->targetSymbol))
        return xl6IrCgenDiag(diags, module, instruction->origin, "C function address has no exact native entry");
    const XL6_IrCallTarget* target = xl6IrCallTargetGet(module, instruction->targetSymbol);
    if (!target) xl6OutputPrintf(out, "    v%u = NULL;\n", (unsigned)instruction->result);
    else if (target->kind == XL6_IR_CALL_TARGET_INTERNAL)
        xl6OutputPrintf(out, "    v%u = xlir_fn_%u;\n", (unsigned)instruction->result, (unsigned)target->symbol);
    else xl6OutputPrintf(out, "    v%u = %s;\n", (unsigned)instruction->result, target->cName);
    return !xl6OutputHasFailed(out);
}

static int xl6IrCgenEmitNativeStatusOut(XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrInstruction* instruction, XL6_DiagList* diags)
{
    const XL6_IrCallTarget* target = xl6IrCallTargetGet(module, instruction->targetSymbol);
    const XL6_IrNode* declaration = target ? xl6IrNodeGet(module, target->declaration) : NULL;
    if (!declaration || !declaration->foreignCall.outputIndexPlusOne)
        return xl6IrCgenDiag(diags, module, instruction->origin, "native status/output call has no exact declaration");
    xl6OutputPrintf(out, "    v%u = (%s){0};\n    v%u.e0 = %s(",
        (unsigned)instruction->result, xl6IrCgenType(module, instruction->type),
        (unsigned)instruction->result, target->cName);
    size_t output = declaration->foreignCall.outputIndexPlusOne - 1;
    for (size_t i = 0; i <= target->parameterCount; ++i) {
        if (i) xl6OutputPuts(", ", out);
        if (i == output) xl6OutputPrintf(out, "&v%u.e1", (unsigned)instruction->result);
        else {
            size_t parameter = i - (i > output);
            if (!xl6IrCgenEmitCallOperand(out, module, target, parameter,
                module->operands[instruction->firstOperand + parameter])) return 0;
        }
    }
    xl6OutputPuts(");\n", out);
    return !xl6OutputHasFailed(out);
}

/* Ordinary CALL emission is shared by synchronous CFGs and async-machine
 * program blocks.  The verifier has already selected every source/physical
 * ABI; this predicate is the C backend's exact, representation-only boundary
 * and deliberately contains no async-specific whitelist. */
static int xl6IrCgenDirectCallAbiSupported(
    const XL6_IrModule* module, const XL6_IrCallTarget* target,
    const XL6_IrInstruction* instruction)
{
    if ( module == NULL || target == NULL || instruction == NULL ||
         target->kind == XL6_IR_CALL_TARGET_INTERNAL_ASYNC ||
         target->kind == XL6_IR_CALL_TARGET_INTERNAL_GENERATOR ||
         (target->variadicAbi == XL6_IR_CALL_VARIADIC_C
            ? instruction->operandCount < target->parameterCount
            : instruction->operandCount != target->parameterCount) ||
         !xl6IrCgenCallResultAbiIsExact(module, target, instruction) ||
         (target->errorAbi == XL6_IR_ERROR_ABI_NO_RAISE
              ? target->errorPhysicalAbi !=
                    XL6_IR_CALL_ERROR_PHYSICAL_NONE
              : target->errorAbi != XL6_IR_ERROR_ABI_MAY_RAISE ||
                !((target->kind == XL6_IR_CALL_TARGET_INTERNAL &&
                   target->errorPhysicalAbi ==
                       XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER) ||
                  ((target->kind == XL6_IR_CALL_TARGET_EXTERN_C ||
                    target->kind == XL6_IR_CALL_TARGET_NATIVE_FACTORY) &&
                   (target->errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE ||
                    target->errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_NULL_RESULT ||
                    target->errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_XRT_THREAD_ERROR ||
                    target->errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER)))) ||
         (target->errorPhysicalAbi ==
              XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER &&
           xl6IrCgenErrorResultType(module, target->returnType) == NULL) )
        return 0;
    if ( target->kind == XL6_IR_CALL_TARGET_INTERNAL ) return 1;
    return (target->kind == XL6_IR_CALL_TARGET_EXTERN_C ||
            target->kind == XL6_IR_CALL_TARGET_NATIVE_FACTORY) &&
           target->cName != NULL;
}

/* A representation-only view of either verified dispatch table. The domain
 * selects a table and a C symbol prefix, never a different calling convention. */
typedef struct XL6_IrCgenDispatchAbi {
    XL6_IrTypeId receiverType, returnType;
    XL6_IrErrorAbi errorAbi;
    XL6_IrCallErrorPhysicalAbi errorPhysicalAbi;
    const XL6_IrTypeId* parameterTypes;
    const XL6_IrParameterAbi* parameterAbis;
    size_t parameterCount;
    const char* prefix;
} XL6_IrCgenDispatchAbi;

static int xl6IrCgenDispatchCallAbi(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction,
    XL6_IrCgenDispatchAbi* abi)
{
    const XL6_IrInstruction* receiver;
    size_t p;
    if (module == NULL || instruction == NULL || instruction->dispatchSlot == 0 ||
        instruction->targetSymbol != 0 || instruction->immediateText != NULL) return 0;
    if (instruction->kind == XL6_IR_INSTR_VIRTUAL_CALL) {
        const XL6_IrClassDispatchSlot* slot;
        if (instruction->dispatchSlot > module->classDispatchSlotCount) return 0;
        slot = &module->classDispatchSlots[instruction->dispatchSlot - 1];
        abi->receiverType = slot->receiverType; abi->returnType = slot->returnType;
        abi->errorAbi = slot->errorAbi; abi->errorPhysicalAbi = slot->errorPhysicalAbi;
        abi->parameterTypes = slot->parameterTypes; abi->parameterAbis = slot->parameterAbis;
        abi->parameterCount = slot->parameterCount; abi->prefix = "v";
    } else if (instruction->kind == XL6_IR_INSTR_PROTOCOL_CALL) {
        const XL6_IrProtocolDispatchSlot* slot;
        if (instruction->dispatchSlot > module->protocolDispatchSlotCount) return 0;
        slot = &module->protocolDispatchSlots[instruction->dispatchSlot - 1];
        abi->receiverType = slot->protocolType; abi->returnType = slot->returnType;
        abi->errorAbi = slot->errorAbi; abi->errorPhysicalAbi = slot->errorPhysicalAbi;
        abi->parameterTypes = slot->parameterTypes; abi->parameterAbis = slot->parameterAbis;
        abi->parameterCount = slot->parameterCount; abi->prefix = "p";
    } else return 0;
    if (instruction->operandCount != abi->parameterCount + 1 ||
        instruction->firstOperand > module->operandCount ||
        instruction->operandCount > module->operandCount - instruction->firstOperand ||
        instruction->type != abi->returnType ||
        ((instruction->result != XL6_IR_VALUE_INVALID) !=
            (abi->returnType != XL6_IR_TYPE_INVALID || abi->errorAbi == XL6_IR_ERROR_ABI_MAY_RAISE)) ||
        (abi->parameterCount != 0 && (abi->parameterTypes == NULL || abi->parameterAbis == NULL))) return 0;
    receiver = xl6IrCgenValueDefinition(module, module->operands[instruction->firstOperand], NULL);
    /* The module verifier proves nominal receiver compatibility. Derived
     * virtual receivers and protocol receivers share the xvalue* physical ABI;
     * the backend must not substitute TypeId equality for that proof. */
    if (receiver == NULL || xl6IrTypeGet(&module->types, receiver->type) == NULL ||
        xl6IrTypeGet(&module->types, receiver->type)->cAbi != XL6_IR_C_ABI_RUNTIME_XVALUE_PTR ||
        xl6IrTypeGet(&module->types, abi->receiverType) == NULL ||
        xl6IrTypeGet(&module->types, abi->receiverType)->cAbi != XL6_IR_C_ABI_RUNTIME_XVALUE_PTR) return 0;
    if (abi->errorAbi == XL6_IR_ERROR_ABI_MAY_RAISE) {
        if (abi->errorPhysicalAbi != XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER ||
            xl6IrCgenErrorResultType(module, abi->returnType) == NULL) return 0;
    } else if (abi->errorAbi != XL6_IR_ERROR_ABI_NO_RAISE ||
        abi->errorPhysicalAbi != XL6_IR_CALL_ERROR_PHYSICAL_NONE) return 0;
    if (abi->returnType != XL6_IR_TYPE_INVALID && xl6IrCgenType(module, abi->returnType) == NULL) return 0;
    for (p = 0; p < abi->parameterCount; ++p) {
        const XL6_IrInstruction* argument = xl6IrCgenValueDefinition(
            module, module->operands[instruction->firstOperand + p + 1], NULL);
        if (argument == NULL || xl6IrCgenType(module, abi->parameterTypes[p]) == NULL ||
            abi->parameterAbis[p] == XL6_IR_PARAMETER_ABI_INVALID) return 0;
        if (xl6IrCgenParameterAbiIsIndirect(abi->parameterAbis[p])) {
            const XL6_IrType* reference = xl6IrTypeGet(&module->types, argument->type);
            if (argument->kind != XL6_IR_INSTR_STORAGE_ADDRESS || reference == NULL ||
                reference->kind != XL6_IR_TYPE_STORAGE_REF || reference->paramCount != 1 ||
                reference->params[0] != abi->parameterTypes[p]) return 0;
        } else if (argument->type != abi->parameterTypes[p]) return 0;
    }
    return 1;
}

static int xl6IrCgenVirtualCallAbi(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    XL6_IrCgenDispatchAbi abi;
    return instruction != NULL && instruction->kind == XL6_IR_INSTR_VIRTUAL_CALL &&
        xl6IrCgenDispatchCallAbi(module, instruction, &abi);
}

static int xl6IrCgenProtocolCallAbi(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    XL6_IrCgenDispatchAbi abi;
    return instruction != NULL && instruction->kind == XL6_IR_INSTR_PROTOCOL_CALL &&
        xl6IrCgenDispatchCallAbi(module, instruction, &abi);
}

static int xl6IrCgenEmitDispatchCallInstruction(
    XL6_Output* out, const XL6_IrModule* module, const XL6_IrInstruction* instruction, XL6_DiagList* diags)
{
    XL6_IrCgenDispatchAbi abi;
    size_t p;
    if (!xl6IrCgenDispatchCallAbi(module, instruction, &abi))
        return xl6IrCgenDiag(diags, module, instruction->origin, "XLIR C emitter dispatch ABI is unresolved");
    if (abi.errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER)
        xl6OutputPrintf(out, "    %s r%lu = ", xl6IrCgenErrorResultType(module, abi.returnType),
            (unsigned long)(instruction - module->instructions));
    else if (abi.returnType != XL6_IR_TYPE_INVALID)
        xl6OutputPrintf(out, "    v%u = ", (unsigned int)instruction->result);
    else xl6OutputPuts("    ", out);
    xl6OutputPrintf(out, "xlir_%sdispatch_%u(v%u", abi.prefix, (unsigned int)instruction->dispatchSlot,
        (unsigned int)module->operands[instruction->firstOperand]);
    for (p = 0; p < abi.parameterCount; ++p) {
        xl6OutputPuts(", ", out);
        if (xl6IrCgenParameterAbiIsIndirect(abi.parameterAbis[p]))
            xl6OutputPrintf(out, "(%s*)", xl6IrCgenType(module, abi.parameterTypes[p]));
        xl6OutputPrintf(out, "v%u", (unsigned int)module->operands[instruction->firstOperand + p + 1]);
    }
    xl6OutputPuts(");\n", out);
    return !xl6OutputHasFailed(out);
}

/* Launchers and ordinary calls share the explicit result carrier. This one
 * renderer is used by every execution mode; ERROR_TEST alone projects value. */
static int xl6IrCgenLaunchCallAbi(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    const XL6_IrCallTarget* target = xl6IrCallTargetGet(module, instruction->targetSymbol);
    return target != NULL && target->errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER &&
        instruction->result != XL6_IR_VALUE_INVALID && instruction->type == target->returnType &&
        instruction->operandCount == target->parameterCount &&
        ((instruction->kind == XL6_IR_INSTR_ASYNC_START && target->kind == XL6_IR_CALL_TARGET_INTERNAL_ASYNC) ||
         (instruction->kind == XL6_IR_INSTR_GENERATOR_START && target->kind == XL6_IR_CALL_TARGET_INTERNAL_GENERATOR));
}

static int xl6IrCgenEmitLaunchCall(
    XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrInstruction* instruction, XL6_DiagList* diags)
{
    const XL6_IrCallTarget* target = xl6IrCallTargetGet(module, instruction->targetSymbol);
    const char* name; size_t argument;
    if (!xl6IrCgenLaunchCallAbi(module, instruction))
        return xl6IrCgenDiag(diags, module, instruction->origin, "XLIR launch result carrier is unresolved");
    if (target->kind == XL6_IR_CALL_TARGET_INTERNAL_ASYNC) name = "async";
    else if (target->kind == XL6_IR_CALL_TARGET_INTERNAL_GENERATOR) name = "generator";
    else return 0;
    xl6OutputPrintf(out, "    %s r%lu = xlir_%s_start_%u(",
        xl6IrCgenErrorResultType(module, target->returnType),
        (unsigned long)(instruction - module->instructions), name, (unsigned int)target->symbol);
    for (argument = 0; argument < instruction->operandCount; ++argument) {
        if (argument) xl6OutputPuts(", ", out);
        if (!xl6IrCgenEmitCallOperand(out, module, target, argument,
                module->operands[instruction->firstOperand + argument])) return 0;
    }
    xl6OutputPuts(");\n", out); return !xl6OutputHasFailed(out);
}

/* Defined with the other owner operations; both direct and witness calls
 * consume this verified boundary contract, with only physical place mapping
 * differing between SSA operands and adapter parameters. */
static int xl6IrCgenEmitPreparationRollback(
    XL6_Output*, const XL6_IrModule*, const XL6_IrCallTarget*,
    const XL6_IrValueId*, size_t, const char*, XL6_DiagList*);

static int xl6IrCgenEmitDirectCall(
    XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrInstruction* instruction, size_t instructionIndex,
    XL6_DiagList* diags, const char* unresolvedDiagnostic)
{
    const XL6_IrCallTarget* target = instruction != NULL
        ? xl6IrCallTargetGet(module, instruction->targetSymbol) : NULL;
    XL6_IrCallErrorPhysicalAbi errorPhysicalAbi = xl6IrCallInstructionErrorPhysicalAbi(module, instruction);
    size_t argument;
    size_t textCount = 0;
    XL6_IrNativeCallValuePlan nativeValue={0};
    if ( !xl6IrCgenDirectCallAbiSupported(module, target, instruction) )
        return xl6IrCgenDiag(diags, module,
            instruction != NULL ? instruction->origin : XL6_IR_NODE_INVALID,
            unresolvedDiagnostic);
    if (!xl6IrNativeCallValuePlanBuild(module,target,&nativeValue))
        return xl6IrCgenDiag(diags,module,instruction->origin,"XLIR native call has no closed logical/storage value plan");
    bool encoded=xl6IrCgenNativeCallValueEncoded(&nativeValue);
    char nativeScope[48],nativeInput[48],nativeResult[48];
    snprintf(nativeScope,sizeof(nativeScope),"fs%lu",(unsigned long)instructionIndex);
    snprintf(nativeResult,sizeof(nativeResult),"v%u",(unsigned)instruction->result);
    if (nativeValue.inputParameter) snprintf(nativeInput,sizeof(nativeInput),"v%u",
        (unsigned)module->operands[instruction->firstOperand+nativeValue.inputParameter-1]);
    /* A failed scope entry skips the native call, so its owned physical
     * result must be empty on every invocation, not merely at function entry. */
    if ((((target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_OWNED_STRING_TAKE ||
           target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_BORROWED_VALUE_COPY ||
           target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_NATIVE_VIEW_ADMIT ||
           xl6IrForeignCallAdmissionMayRaise(module,target)) &&
          errorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE) ||
         target->preparationFailureAbi == XL6_IR_CALL_PREPARATION_RETIRE_OWNED_REVERSE ||
         target->nativeResultAbi==XL6_IR_CALL_NATIVE_RESULT_VALUE_SLOT_V1) &&
        instruction->result != XL6_IR_VALUE_INVALID &&
        !xl6IrCgenIsControlCarrier(module, instruction) &&
        !xl6IrCgenResultStorageOmitted(module, instruction)) {
        const char* type = xl6IrCgenType(module, instruction->type);
        if (type == NULL) return xl6IrCgenDiag(diags, module, instruction->origin,
            "XLIR preparation failure result has no empty physical representation");
        xl6OutputPrintf(out, "    v%u = (%s){0};\n", (unsigned int)instruction->result, type);
    }
    if ( errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE )
        xl6OutputPrintf(out,
            "    xl6_foreign_error_scope fs%lu = {0}; xl6_foreign_error_result fr%lu = {false, NULL};\n"
            "    if (xl6ForeignCallBegin(&fs%lu)) {\n",
            (unsigned long)instructionIndex, (unsigned long)instructionIndex,
            (unsigned long)instructionIndex);
    for (argument = target->parameterCount; argument < instruction->operandCount; ++argument) {
        const XL6_IrInstruction* value = xl6IrCgenValueDefinition(module,
            module->operands[instruction->firstOperand + argument], NULL);
        if (value == NULL) return 0;
        if (xl6IrCVarargPhysicalAbi(module, value->type) != XL6_IR_C_VARARG_PHYSICAL_C_TEXT_BORROW) continue;
        if (errorPhysicalAbi != XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE)
            return xl6IrCgenDiag(diags, module, instruction->origin,
                "XLIR C text variadic preparation requires a checked foreign outcome");
        xl6OutputPrintf(out, "    const char* ct%lu_%lu = xlir_string_cstr(v%u);\n",
            (unsigned long)instructionIndex, (unsigned long)argument, (unsigned int)value->result);
        ++textCount;
    }
    if (textCount != 0) {
        xl6OutputPuts("    if (", out);
        textCount = 0;
        for (argument = target->parameterCount; argument < instruction->operandCount; ++argument) {
            const XL6_IrInstruction* value = xl6IrCgenValueDefinition(module,
                module->operands[instruction->firstOperand + argument], NULL);
            if (xl6IrCVarargPhysicalAbi(module, value->type) != XL6_IR_C_VARARG_PHYSICAL_C_TEXT_BORROW) continue;
            if (textCount++) xl6OutputPuts(" && ", out);
            xl6OutputPrintf(out, "ct%lu_%lu != NULL", (unsigned long)instructionIndex, (unsigned long)argument);
        }
        xl6OutputPuts(") {\n", out);
    }
    if (!xl6IrCgenNativeCallValueBegin(out,module,&nativeValue,
            nativeValue.inputParameter?nativeInput:NULL,nativeScope)) return 0;
    int arraysPrepared=xl6IrCgenArraysBegin(out,module,target,module->operands+instruction->firstOperand,nativeScope);if(arraysPrepared<0)return 0;
    int viewsPrepared=xl6IrCgenForeignViewsBegin(out,module,target,module->operands+instruction->firstOperand,NULL,nativeScope);
    int cstringsPrepared=xl6IrCgenPrepareTerminatedStrings(out,module,target,module->operands+instruction->firstOperand,nativeScope);
    int bytesPrepared=xl6IrCgenPrepareBytesViews(out,target,module->operands+instruction->firstOperand);
    int spansPrepared=xl6IrCgenForeignSpansBegin(out,module,target,module->operands+instruction->firstOperand,nativeScope);
    if(spansPrepared<0)return 0;
    int regionsPrepared=xl6IrCgenForeignRegionsBegin(out,module,target,module->operands+instruction->firstOperand,nativeScope);
    if(regionsPrepared<0)return 0;
    int accessPrepared=xl6IrCgenNativeAccessBegin(out,module,target,module->operands+instruction->firstOperand,nativeScope);
    if(accessPrepared<0)return 0;
    int callbacksPrepared=xl6IrCgenNativeCallbacksBegin(out,module,target,module->operands+instruction->firstOperand,nativeScope);
    if(callbacksPrepared<0)return 0;
    if(!xl6IrCgenPrepareForeignCountedField(out,module,target,module->operands+instruction->firstOperand,nativeScope))return 0;
    int packsPrepared=xl6IrCgenForeignPacksBegin(out,module,target,module->operands+instruction->firstOperand,nativeScope);
    if(packsPrepared<0)return 0;
    int fieldCallee=xl6IrCgenNativeFieldCallBegin(out,module,target,module->operands+instruction->firstOperand,nativeScope,diags);
    if(fieldCallee<0)return 0;
    int probePrepared=xl6IrCgenFactoryProbeBegin(out,module,target,nativeScope);
    const XL6_IrNode* foreignDeclaration=xl6IrNodeGet(module,target->declaration);
    int factoryOutput=foreignDeclaration->foreignCall.outputIndexPlusOne && !foreignDeclaration->foreignCall.valueOutput;
    int storagePrepared=0;
    int valueOutput=target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_NATIVE_OUTPUT_VALUE;
    int outputProbes=0;
    if(valueOutput){
        if(!xl6IrCgenOutputRawDeclare(out,module,target))return 0;
        outputProbes=xl6IrCgenOutputProbesBegin(out,module,target,nativeScope);
        xl6OutputPuts("    ",out);
        if(target->outputResultAbi==XL6_IR_CALL_OUTPUT_RESULT_INT_STATUS)xl6OutputPuts("int native_status = ",out);
    }
    else if(target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_NATIVE_VIEW_ADMIT){
        const XL6_IrType* type=xl6IrTypeGet(&module->types,target->returnType);
        if(factoryOutput)storagePrepared=xl6IrCgenFactoryStorageBegin(out,module,target,nativeScope);
        if(!storagePrepared)xl6OutputPrintf(out,factoryOutput ? "    %s native_raw = NULL; int native_status = " : "    %s native_raw = ",type->cName);
    }else if(target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_STATUS_CHECK)
        xl6OutputPuts(target->resultCAbi==XL6_IR_CALL_RESULT_C_ABI_INT_STATUS ? "    int native_status = " : "    bool native_status = ",out);
    else if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_BORROWED_VALUE_COPY)
        xl6OutputPrintf(out,"    %s borrowed_raw_%lu = ",
            xl6IrCgenBorrowedResultCType(target),(unsigned long)instructionIndex);
    else if (target->producerErrorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER)
        xl6OutputPrintf(out, "    %s r%lu = ",
            xl6IrCgenErrorResultType(module, target->returnType),
            (unsigned long)instructionIndex);
    else if ( target->nativeResultAbi==XL6_IR_CALL_NATIVE_RESULT_NONE &&
              instruction->result != XL6_IR_VALUE_INVALID &&
              !xl6IrCgenIsControlCarrier(module, instruction) )
        xl6OutputPrintf(out, "    v%u%s = ", (unsigned int)instruction->result,
            target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_OWNED_STRING_TAKE ? ".Data" : "");
    else
        xl6OutputPuts("    ", out);
    if(!xl6IrForeignOperationInvokesFunction(target->foreignOperationAbi)){
        if(!xl6IrCgenEmitForeignProjectionExpression(out,module,target,module->operands+instruction->firstOperand))return 0;
        xl6OutputPuts(";\n",out);
    }else {
    if ( target->kind == XL6_IR_CALL_TARGET_INTERNAL )
        xl6OutputPrintf(out, "xlir_fn_%u(",
                        (unsigned int)instruction->targetSymbol);
    else
        xl6OutputPrintf(out, "%s(", fieldCallee ? "native_callee":target->cName);
    if(target->nativeServicesRequired) {
        if(!xl6IrCgenEmitNativeServices(out,target))return 0;
        if(target->nativeContextAbi || instruction->operandCount)xl6OutputPuts(", ",out);
    }
    if(target->nativeContextAbi!=XL6_IR_CALL_NATIVE_CONTEXT_NONE) {
        if(!xl6IrCgenEmitNativeContext(out,module,target))return 0;
        if(instruction->operandCount)xl6OutputPuts(", ",out);
    } else if (target->nativeArrayResultAbi == XL6_IR_CALL_NATIVE_ARRAY_RESULT_PRIMITIVE_IDS_V1) {
        const XL6_IrType* owner = xl6IrTypeGet(&module->types, target->returnType);
        const XL6_IrType* item = owner && owner->params && owner->paramCount == 1
            ? xl6IrTypeGet(&module->types, owner->params[0]) : NULL;
        if (!owner || !item) return 0;
        xl6OutputPrintf(out, "0x%016llXULL, 0x%016llXULL%s", (unsigned long long)owner->typeValueId,
            (unsigned long long)item->typeValueId, instruction->operandCount ? ", " : "");
    }
    size_t physicalSteps=xl6IrForeignPhysicalStepCount(module,target);
    if(physicalSteps>target->parameterCount+64)return 0;
    for ( size_t physical = 0; physical < physicalSteps+instruction->operandCount-target->parameterCount; ++physical ) {
        if ( physical != 0 ) xl6OutputPuts(", ", out);
        if(physical<physicalSteps){
            XL6_ForeignPhysicalStep step;if(!xl6IrForeignPhysicalStepGet(module,target,physical,&step))return 0;
            argument=step.parameter;
            if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_FIXED){
                const XL6_ForeignFixedInputContract* row=xl6IrForeignFixedInputGet(module,target,step.physicalIndex);if(!row)return 0;
                if(row->kind==XL6_FOREIGN_FIXED_MODULE_CODE_OWNER && module->abi.codeOwnerAbi==XL6_IR_MODULE_CODE_OWNER_BIND_BEFORE_INIT)
                    xl6OutputPuts("(xlir_code_owner.size ? &xlir_code_owner : NULL)",out);
                else xl6OutputPrintf(out,"(%s)0",row->pointerCName);
                continue;
            }
            if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_ARRAY_GROUP){if(!xl6IrCgenArrayArguments(out,module,target,step.physicalIndex))return 0;continue;}
            if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_PACK){xl6OutputPrintf(out,"&native_pack_%u",step.physicalIndex);continue;}
            if(step.kind==XL6_FOREIGN_PHYSICAL_STEP_OUTPUT){
                if(valueOutput){
                    if(xl6IrForeignNativeSequenceGet(module,target) || (!xl6IrForeignOutputRecordGet(module,target) && xl6IrForeignOutputCount(module,target)>1))xl6OutputPrintf(out,"&native_raw.e%lu",(unsigned long)step.ordinal);
                    else xl6OutputPuts("&native_raw",out);
                }else xl6OutputPuts(storagePrepared ? "native_raw":"&native_raw",out);
                continue;
            }
        }else argument=target->parameterCount+physical-physicalSteps;
        if ( argument < target->parameterCount ) {
            if (encoded && nativeValue.inputParameter==argument+1)
                xl6OutputPuts("&native_value_input",out);
            else if ( !xl6IrCgenEmitCallOperand(
                     out, module, target, argument,
                     module->operands[instruction->firstOperand + argument]) )
                return xl6IrCgenDiag(diags, module, instruction->origin,
                    "XLIR C emitter call operand ABI is unresolved");
        } else {
            const XL6_IrInstruction* value = xl6IrCgenValueDefinition(module,
                module->operands[instruction->firstOperand + argument], NULL);
            if (xl6IrCVarargPhysicalAbi(module, value->type) == XL6_IR_C_VARARG_PHYSICAL_C_TEXT_BORROW)
                xl6OutputPrintf(out, "ct%lu_%lu", (unsigned long)instructionIndex, (unsigned long)argument);
            else xl6OutputPrintf(out, "v%u", (unsigned int)value->result);
        }
    }
    if(target->nativeResultAbi==XL6_IR_CALL_NATIVE_RESULT_VALUE_SLOT_V1) {
        if(instruction->operandCount || target->nativeContextAbi || target->nativeServicesRequired)xl6OutputPuts(", ",out);
        if (encoded && nativeValue.output) xl6OutputPuts("&native_value_output",out);
        else xl6OutputPrintf(out,"&v%u",(unsigned)instruction->result);
    }
    xl6OutputPuts(");\n", out);
    }
    if(storagePrepared)xl6OutputPuts("    }\n",out);
    xl6IrCgenNativeCallbacksObserve(out,target,nativeScope);
    if(errorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE &&
        target->producerErrorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER) {
        if(target->returnType)xl6OutputPrintf(out,"    v%u = r%lu.value;\n",(unsigned)instruction->result,(unsigned long)instructionIndex);
        xl6OutputPrintf(out,"    if (!r%lu.ok) xl6ErrorScopeCaptureFailure(&%s);\n",(unsigned long)instructionIndex,nativeScope);
    }
    if(errorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE &&
        target->producerErrorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_NULL_RESULT)
        xl6OutputPrintf(out,"    if (v%u == NULL) xl6ErrorScopeCaptureFailure(&%s);\n",(unsigned)instruction->result,nativeScope);
    if(target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_NATIVE_VIEW_ADMIT){
        char place[40];snprintf(place,sizeof(place),"v%u",(unsigned)instruction->result);
        xl6IrCgenNativeViewAdmission(out,module,target,module->operands+instruction->firstOperand,NULL,
            place,"native_raw",nativeScope,target->outputResultAbi==XL6_IR_CALL_OUTPUT_RESULT_INT_STATUS ? "native_status" : NULL);
    }
    if(target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_STATUS_CHECK ||
        (valueOutput && target->outputResultAbi==XL6_IR_CALL_OUTPUT_RESULT_INT_STATUS))
        xl6IrCgenEmitNativeStatusCheck(out,module,target,nativeScope);
    if(valueOutput){char place[40];snprintf(place,sizeof(place),"v%u",(unsigned)instruction->result);
        if(!xl6IrCgenOutputValuesAdmit(out,module,target,place,nativeScope))return 0;}
    if(outputProbes)xl6IrCgenOutputProbesEnd(out,module,target,nativeScope);
    if (target->resultConversionAbi == XL6_IR_CALL_RESULT_CONVERSION_BORROWED_VALUE_COPY) {
        char place[40],raw[48];
        snprintf(place,sizeof(place),"v%u",(unsigned)instruction->result);
        snprintf(raw,sizeof(raw),"borrowed_raw_%lu",(unsigned long)instructionIndex);
        xl6IrCgenEmitBorrowedValueAdmission(out,module,target,place,raw,nativeScope);
    }
    if(target->resultConversionAbi==XL6_IR_CALL_RESULT_CONVERSION_OWNED_STRING_TAKE) {
        char place[40],failed[64];
        snprintf(place,sizeof(place),"v%u",(unsigned)instruction->result);
        snprintf(failed,sizeof(failed),"fs%lu.failed",(unsigned long)instructionIndex);
        xl6IrCgenEmitOwnedStringAdmission(out,module,target,place,
            errorPhysicalAbi==XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE ? failed : NULL);
    }
    if(probePrepared)xl6IrCgenFactoryProbeEnd(out,nativeScope);
    if(fieldCallee)xl6OutputPuts("    } }\n",out);
    if(packsPrepared)xl6IrCgenForeignPacksEnd(out);
    if(callbacksPrepared)xl6IrCgenNativeCallbacksEnd(out,target,nativeScope);
    if(accessPrepared)xl6IrCgenNativeAccessEnd(out,target,nativeScope);
    if(regionsPrepared)xl6IrCgenForeignRegionsEnd(out,module,target,nativeScope);
    if(spansPrepared)xl6IrCgenForeignSpansEnd(out,module,target,nativeScope);
    if(bytesPrepared)xl6OutputPuts("    }\n",out);
    if(cstringsPrepared)xl6OutputPuts("    } }\n",out);
    if(viewsPrepared)xl6IrCgenForeignViewsEnd(out,target,nativeScope);
    if(arraysPrepared)xl6IrCgenArraysEnd(out,module,target,nativeScope);
    if (!xl6IrCgenNativeCallValueEnd(out,module,&nativeValue,nativeResult,nativeScope)) return 0;
    if (textCount != 0) xl6OutputPuts("    }\n", out);
    if ( errorPhysicalAbi == XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE ) {
        int owned = 0;
        for (argument = 0; argument < target->parameterCount; ++argument)
            if (target->parameterAbis[argument] == XL6_IR_PARAMETER_ABI_OWNED) owned = 1;
        xl6OutputPrintf(out,
            "    fr%lu = xl6ForeignCallEnd(&fs%lu);\n"
            "    } else {",
            (unsigned long)instructionIndex, (unsigned long)instructionIndex);
        if (owned) {
            char outcome[40];
            snprintf(outcome, sizeof(outcome), "fr%lu", (unsigned long)instructionIndex);
            xl6OutputPuts("\n", out);
            if (!xl6IrCgenEmitPreparationRollback(out, module, target,
                    module->operands + instruction->firstOperand, 0, outcome, diags)) return 0;
            xl6OutputPuts("    }\n", out);
        } else xl6OutputPrintf(out, " fr%lu.error = xrtTakeError(); }\n", (unsigned long)instructionIndex);
    }
    return !xl6OutputHasFailed(out);
}

/* FOREIGN_RESULT_ROLLBACK is a closed ownership operation. The IR verifier
 * already proved its call-result source, failure edge and exact destructor;
 * all backends emit the same detach / isolated cleanup / error-restore ABI. */
static int xl6IrCgenEmitForeignResultRollback(
    XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrInstruction* instruction)
{
    const XL6_IrCallTarget* destroy = xl6IrCallTargetGet(module, instruction->targetSymbol);
    XL6_IrValueId raw;
    if (destroy == NULL || destroy->cName == NULL || instruction->operandCount != 1)
        return 0;
    raw = module->operands[instruction->firstOperand];
    xl6OutputPrintf(out,
        "    { void* xlir_owned = v%u; xerror* xlir_original = xrtTakeError();\n"
        "      v%u = NULL;\n"
        "      if (xlir_owned != NULL) {\n"
        "        xl6_foreign_error_scope xlir_cleanup = {0}; xl6_foreign_error_result xlir_discard;\n"
        /* Non-NULL requires a completed factory CALL and therefore an already
         * initialized/bound context. Rebinding that same context cannot need
         * new storage. Like ErrorScopeEnd, OS rebinding failure is an invariant
         * violation, not permission to skip disposal or poison an outer scope. */
        "        if (!xl6ForeignCallBegin(&xlir_cleanup)) abort();\n"
        "        %s(xlir_owned);\n"
        "        xlir_discard = xl6ForeignCallEnd(&xlir_cleanup);\n"
        "        xrtErrorFree(xlir_discard.error);\n"
        "      }\n"
        "      xrtSetErrorTake(xlir_original); }\n",
        (unsigned int)raw, (unsigned int)raw, destroy->cName);
    return !xl6OutputHasFailed(out);
}

static void xl6IrCgenEmitForeignErrorTest(
    XL6_Output* out, size_t sourceIndex, const char* blockPrefix,
    size_t success, size_t failure)
{
    xl6OutputPrintf(out,
        "    if (fr%lu.ok) goto %s%lu; else { xrtSetErrorTake(fr%lu.error); fr%lu.error = NULL; goto %s%lu; }\n",
        (unsigned long)sourceIndex, blockPrefix, (unsigned long)success,
        (unsigned long)sourceIndex, (unsigned long)sourceIndex,
        blockPrefix, (unsigned long)failure);
}

/* Observe a direct or virtual operation before any caller cleanup. Block
 * names differ between execution modes; the physical outcome ABI does not. */
static int xl6IrCgenEmitCallErrorTest(
    XL6_Output* out, const XL6_IrModule* module, const XL6_IrInstruction* source,
    size_t sourceIndex, const char* prefix, size_t success, size_t failure,
    XL6_DiagList* diags)
{
    XL6_IrCallErrorPhysicalAbi physical = xl6IrCallInstructionErrorPhysicalAbi(module, source);
    if (xl6IrCallInstructionErrorAbi(module, source) != XL6_IR_ERROR_ABI_MAY_RAISE)
        return xl6IrCgenDiag(diags, module, source->origin, "XLIR call error test has no canonical outcome ABI");
    if (physical == XL6_IR_CALL_ERROR_PHYSICAL_FOREIGN_SCOPE)
        xl6IrCgenEmitForeignErrorTest(out, sourceIndex, prefix, success, failure);
    else if (physical == XL6_IR_CALL_ERROR_PHYSICAL_SCOPED_BOOL_RESULT)
        xl6OutputPrintf(out,
            "    if (!fr%lu.ok) { xrtSetErrorTake(fr%lu.error); fr%lu.error = NULL; goto %s%lu; }\n"
            "    if (v%u) goto %s%lu; else goto %s%lu;\n",
            (unsigned long)sourceIndex, (unsigned long)sourceIndex, (unsigned long)sourceIndex,
            prefix, (unsigned long)failure, (unsigned int)source->result,
            prefix, (unsigned long)success, prefix, (unsigned long)failure);
    else if (physical == XL6_IR_CALL_ERROR_PHYSICAL_NULL_RESULT) {
        const XL6_IrType* valueType = xl6IrTypeGet(&module->types, source->type);
        xl6OutputPrintf(out, "    if (v%u%s != NULL) goto %s%lu; else goto %s%lu;\n",
            (unsigned int)source->result,
            valueType != NULL && valueType->cAbi == XL6_IR_C_ABI_MANAGED_STRING ? ".Data" : "",
            prefix, (unsigned long)success, prefix, (unsigned long)failure);
    }
    else if (physical == XL6_IR_CALL_ERROR_PHYSICAL_FALSE_RESULT)
        xl6OutputPrintf(out, "    if (v%u) goto %s%lu; else goto %s%lu;\n",
            (unsigned int)source->result, prefix, (unsigned long)success, prefix, (unsigned long)failure);
    else if (physical == XL6_IR_CALL_ERROR_PHYSICAL_STATUS_OUTPUT)
        xl6OutputPrintf(out, "    if (projection_ok_%u) goto %s%lu; else goto %s%lu;\n",
            (unsigned int)source->result, prefix, (unsigned long)success, prefix, (unsigned long)failure);
    else if (physical == XL6_IR_CALL_ERROR_PHYSICAL_XRT_THREAD_ERROR)
        xl6OutputPrintf(out, "    if (xrtGetError() == NULL) goto %s%lu; else goto %s%lu;\n",
            prefix, (unsigned long)success, prefix, (unsigned long)failure);
    else if (physical == XL6_IR_CALL_ERROR_PHYSICAL_RESULT_CARRIER) {
        xl6OutputPrintf(out, "    if (r%lu.ok) { ", (unsigned long)sourceIndex);
        if (source->type != XL6_IR_TYPE_INVALID &&
            !xl6IrCgenResultStorageOmitted(module, source))
            xl6OutputPrintf(out, "v%u = r%lu.value; ", (unsigned int)source->result, (unsigned long)sourceIndex);
        xl6OutputPrintf(out, "goto %s%lu; } else goto %s%lu;\n",
            prefix, (unsigned long)success, prefix, (unsigned long)failure);
    } else return xl6IrCgenDiag(diags, module, source->origin,
        "XLIR call error test has no physical observation ABI");
    return !xl6OutputHasFailed(out);
}

static int xl6IrCgenRetainInstructionAbi(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    const XL6_IrType* type;
    if ( module == NULL || instruction == NULL ) return 0;
    type = xl6IrTypeGet(&module->types, instruction->type);
    return
           instruction->kind == XL6_IR_INSTR_RETAIN &&
           instruction->operandCount == 1 &&
           instruction->firstOperand < module->operandCount &&
           instruction->result != XL6_IR_VALUE_INVALID && type != NULL &&
           (type->cAbi == XL6_IR_C_ABI_CLOSURE_PTR ||
            type->cAbi == XL6_IR_C_ABI_RUNTIME_FUTURE_PTR ||
            type->cAbi == XL6_IR_C_ABI_MANAGED_BYTES ||
            type->cAbi == XL6_IR_C_ABI_RUNTIME_XVALUE_PTR ||
            type->cAbi == XL6_IR_C_ABI_RUNTIME_ERROR_PTR);
}

static int xl6IrCgenEmitRetainInstruction(
    XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrInstruction* instruction)
{
    const XL6_IrType* type;
    XL6_IrValueId source;
    if ( out == NULL ||
         !xl6IrCgenRetainInstructionAbi(module, instruction) ) return 0;
    type = xl6IrTypeGet(&module->types, instruction->type);
    source = module->operands[instruction->firstOperand];
    if ( type->cAbi == XL6_IR_C_ABI_CLOSURE_PTR )
        xl6OutputPrintf(out,
            "    v%u = xlir_closure_retain(v%u);\n",
            (unsigned int)instruction->result, (unsigned int)source);
    else if ( type->cAbi == XL6_IR_C_ABI_RUNTIME_FUTURE_PTR )
        xl6OutputPrintf(out,
            "    v%u = v%u != NULL ? xrtFutureRef(v%u) : NULL;\n",
            (unsigned int)instruction->result,
            (unsigned int)source, (unsigned int)source);
    else if ( type->cAbi == XL6_IR_C_ABI_RUNTIME_XVALUE_PTR ||
              type->cAbi == XL6_IR_C_ABI_MANAGED_BYTES )
        /* RETAIN copies the verified language slot, including absence. XRT's
         * retain API requires a real value shell; NULL is not such a shell.
         * This same mechanical instruction handles normal/async/generator
         * execution and is independent of the slot's producer. */
        xl6OutputPrintf(out,
            "    v%u = v%u != NULL ? xrtValueRetain(v%u) : NULL;\n",
            (unsigned int)instruction->result, (unsigned int)source,
            (unsigned int)source);
    else
        xl6OutputPrintf(out,
            "    v%u = xrtErrorRef(v%u);\n",
            (unsigned int)instruction->result, (unsigned int)source);
    return !xl6OutputHasFailed(out);
}

/* These common xvalue operations have identical semantics in a normal
 * CFG and in an async continuation block.  Keep their ABI test and rendering
 * together so adding an async suspension never creates a second backend
 * interpretation of the same verified instruction. */

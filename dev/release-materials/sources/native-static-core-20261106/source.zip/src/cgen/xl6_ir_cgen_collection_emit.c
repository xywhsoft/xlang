static int xl6IrCgenEmitChannelRuntime(XL6_Output*,const XL6_IrModule*,const XL6_IrInstruction*);
static int xl6IrCgenEmitConcurrentQueueRuntime(XL6_Output*,const XL6_IrModule*,const XL6_IrInstruction*);
static const char* xl6IrCgenContainerProjectionSymbol(const XL6_IrModule* module,const XL6_IrInstruction* instruction)
{
    XL6_IrNativeContainerProjectionAbi family=XL6_IR_NATIVE_PROJECTION_NONE;
    if(!xl6IrNativeContainerProjectionInstructionCompatible(module,instruction) ||
        !xl6IrNativeContainerProjectionTarget(module,instruction->type,NULL,&family,NULL))return NULL;
    switch(family) {
    case XL6_IR_NATIVE_PROJECTION_ARRAY:
    case XL6_IR_NATIVE_PROJECTION_STACK:return "xl6SequenceProjectionWitnessTakeV1";
    case XL6_IR_NATIVE_PROJECTION_LIST:return "xl6ListProjectionWitnessTakeV1";
    case XL6_IR_NATIVE_PROJECTION_SET:return "xl6SetProjectionWitnessTakeV1";
    case XL6_IR_NATIVE_PROJECTION_DICT:return "xl6DictProjectionWitnessTakeV1";
    case XL6_IR_NATIVE_PROJECTION_TREE:return "xl6TreeProjectionWitnessTakeV1";
    case XL6_IR_NATIVE_PROJECTION_DOMAIN:return "xl6ValueDomainProjectionWitnessTakeV1";
    case XL6_IR_NATIVE_PROJECTION_NATIVE_SEQUENCE:return "xl6NativeSequenceAdmitsV1";
    default:return NULL;
    }
}

/* Every queue family, including WaitQueue, consumes one closed native contract.
 * Legacy output-variable calls are rejected by that contract, never emitted. */
static int xl6IrCgenRuntimeSpecialQueueAbi(
    const XL6_IrModule* module,const XL6_IrInstruction* instruction)
{ return xl6IrConcurrentQueueInstructionCompatible(module,instruction); }

static int xl6IrCgenEmitSpecialQueueRuntime(
    XL6_Output* out,const XL6_IrModule* module,const XL6_IrInstruction* instruction)
{
    if(!instruction || !xl6IrCgenSpecialQueueRuntimeOpIs(instruction->runtimeOp))return 0;
    if(!xl6IrConcurrentQueueInstructionCompatible(module,instruction))return -1;
    return xl6IrCgenEmitConcurrentQueueRuntime(out,module,instruction);
}

static int xl6IrCgenRuntimeStackAbi(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    const XL6_IrInstruction* receiver = NULL;
    const XL6_IrInstruction* second = NULL;
    const XL6_IrType* stack = NULL;
    const XL6_IrType* payload = NULL;
    const XL6_IrType* resultType;
    XL6_IrTypeId stackTypeId;
    int creates;
    if (instruction && instruction->runtimeOp>=XL6_IR_RUNTIME_STACK_PUSH_BATCH &&
        instruction->runtimeOp<=XL6_IR_RUNTIME_STACK_PEEK_BATCH_AT)
        return xl6IrStackBatchInstructionCompatible(module,instruction);
    if ( module == NULL || instruction == NULL ||
         instruction->kind != XL6_IR_INSTR_RUNTIME_CALL ||
         !xl6IrCgenStackRuntimeOpIs(instruction->runtimeOp) ||
         instruction->immediateText != NULL ||
         instruction->targetSymbol != 0 ||
         instruction->targetValue != XL6_IR_VALUE_INVALID ||
         instruction->calleeType != XL6_IR_TYPE_INVALID ||
         instruction->runtimeIdentityType != XL6_IR_TYPE_INVALID ||
         instruction->opcode != XL6_IR_OPCODE_INVALID ||
         instruction->firstOperand > module->operandCount ||
         instruction->operandCount >
             module->operandCount - instruction->firstOperand ) return 0;
    creates = instruction->runtimeOp == XL6_IR_RUNTIME_STACK_CREATE;
    if ( !creates && instruction->operandCount != 0 )
        receiver = xl6IrCgenValueDefinition(
            module, module->operands[instruction->firstOperand], NULL);
    stackTypeId = creates ? instruction->type
                          : receiver != NULL ? receiver->type
                                             : XL6_IR_TYPE_INVALID;
    if ( !xl6IrCgenStackTypeAbi(
             module, stackTypeId, &stack, &payload) ||
         instruction->payloadType != stack->params[0] ||
         instruction->runtimeResourcePayloadAbi !=
             stack->sequenceLayout.transferAbi ) return 0;
    resultType = xl6IrTypeGet(&module->types, instruction->type);
    if ( creates )
        return instruction->operandCount == 0 &&
               instruction->result != XL6_IR_VALUE_INVALID;
    if ( receiver == NULL || receiver->type != stackTypeId ) return 0;
    if ( instruction->result == XL6_IR_VALUE_INVALID || resultType == NULL )
        return 0;
    if ( instruction->operandCount > 1 )
        second = xl6IrCgenValueDefinition(
            module, module->operands[instruction->firstOperand + 1], NULL);
    switch ( instruction->runtimeOp ) {
    case XL6_IR_RUNTIME_STACK_PUSH:
        return instruction->operandCount == 2 && second != NULL &&
               second->type == instruction->payloadType &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL &&
               resultType->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL;
    case XL6_IR_RUNTIME_STACK_RESERVE:
        return instruction->operandCount == 2 && second != NULL &&
               xl6IrTypeGet(&module->types, second->type) != NULL &&
               xl6IrTypeGet(&module->types, second->type)->cAbi ==
                   XL6_IR_C_ABI_I64 &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL &&
               resultType->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL;
    case XL6_IR_RUNTIME_STACK_CLONE:
        return instruction->operandCount == 1 &&
               instruction->type == stackTypeId;
    case XL6_IR_RUNTIME_STACK_POP:
    case XL6_IR_RUNTIME_STACK_PEEK:
        return instruction->operandCount == 1 && instruction->type == instruction->payloadType;
    case XL6_IR_RUNTIME_STACK_PEEK_AT:
        return instruction->operandCount == 2 && instruction->type == instruction->payloadType &&
               second != NULL && xl6IrTypeGet(&module->types, second->type) != NULL &&
               xl6IrTypeGet(&module->types, second->type)->cAbi == XL6_IR_C_ABI_I64;
    case XL6_IR_RUNTIME_STACK_TRY_POP:
    case XL6_IR_RUNTIME_STACK_TRY_PEEK:
        return instruction->operandCount == 1 &&
               xl6IrStackTryResultCompatible(module, instruction->type, instruction->payloadType);
    case XL6_IR_RUNTIME_STACK_TRY_PEEK_AT:
        return instruction->operandCount == 2 && second != NULL &&
               xl6IrTypeGet(&module->types, second->type) != NULL &&
               xl6IrTypeGet(&module->types, second->type)->cAbi == XL6_IR_C_ABI_I64 &&
               xl6IrStackTryResultCompatible(module, instruction->type, instruction->payloadType);
    case XL6_IR_RUNTIME_STACK_EQUALS:
        return instruction->operandCount == 2 && second != NULL &&
               second->type == stackTypeId &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL &&
               resultType->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL;
    case XL6_IR_RUNTIME_STACK_TRIM:
    case XL6_IR_RUNTIME_STACK_CLEAR:
        return instruction->operandCount == 1 &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL &&
               resultType->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL;
    case XL6_IR_RUNTIME_STACK_COUNT:
    case XL6_IR_RUNTIME_STACK_CAPACITY:
        return instruction->operandCount == 1 &&
               resultType->cAbi == XL6_IR_C_ABI_I64 &&
               resultType->ownershipAbi == XL6_IR_OWNERSHIP_ABI_TRIVIAL &&
               resultType->integerTarget == XL6_IR_INTEGER_TARGET_SIGNED_64;
    default:
        return 0;
    }
}

static int xl6IrCgenStorageRefTo(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction,
    XL6_IrTypeId targetType)
{
    const XL6_IrType* reference = instruction != NULL
        ? xl6IrTypeGet(&module->types, instruction->type) : NULL;
    return instruction != NULL &&
           instruction->kind == XL6_IR_INSTR_STORAGE_ADDRESS &&
           reference != NULL &&
           reference->kind == XL6_IR_TYPE_STORAGE_REF &&
           reference->cAbi == XL6_IR_C_ABI_STORAGE_REF_PTR &&
           reference->paramCount == 1 && reference->params != NULL &&
           reference->params[0] == targetType;
}

static int xl6IrCgenRuntimeAvlAbi(
    const XL6_IrModule* module, const XL6_IrInstruction* instruction)
{
    const XL6_IrInstruction* operands[4] = { NULL, NULL, NULL, NULL };
    const XL6_IrType* tree = NULL;
    const XL6_IrType* key = NULL;
    const XL6_IrType* value = NULL;
    const XL6_IrType* resultType;
    XL6_IrTypeId treeTypeId;
    size_t i;
    int creates;
    if(instruction && xl6IrTreeQuerySpecRuntime(instruction->runtimeOp))
        return xl6IrTreeQueryInstructionCompatible(module,instruction);
    if ( module == NULL || instruction == NULL ||
         instruction->kind != XL6_IR_INSTR_RUNTIME_CALL ||
         !xl6IrCgenAvlRuntimeOpIs(instruction->runtimeOp) ||
         instruction->immediateText != NULL ||
         instruction->targetSymbol != 0 ||
         instruction->targetValue != XL6_IR_VALUE_INVALID ||
         instruction->calleeType != XL6_IR_TYPE_INVALID ||
         instruction->runtimeIdentityType != XL6_IR_TYPE_INVALID ||
         instruction->opcode != XL6_IR_OPCODE_INVALID ||
         instruction->firstOperand > module->operandCount ||
         instruction->operandCount >
             module->operandCount - instruction->firstOperand ||
         instruction->operandCount > 4 ) return 0;
    for ( i = 0; i < instruction->operandCount; ++i )
        operands[i] = xl6IrCgenValueDefinition(
            module, module->operands[instruction->firstOperand + i], NULL);
    creates = instruction->runtimeOp == XL6_IR_RUNTIME_AVL_TREE_CREATE;
    treeTypeId = creates ? instruction->type
        : operands[0] != NULL ? operands[0]->type : XL6_IR_TYPE_INVALID;
    if ( !xl6IrCgenAvlTypeAbi(
             module, treeTypeId, &tree, &key, &value) ||
         instruction->payloadType != tree->params[1] ||
         instruction->runtimeResourcePayloadAbi !=
             xl6IrCgenChannelPayloadAbi(value) ||
         instruction->runtimeResourceKeyType != tree->params[0] ||
         instruction->runtimeResourceKeyPayloadAbi !=
             xl6IrCgenChannelPayloadAbi(key) ||
         instruction->runtimeResourceKeyOrderAbi !=
             xl6IrAvlKeyOrderAbi(module,treeTypeId) ) return 0;
    resultType = xl6IrTypeGet(&module->types, instruction->type);
    if ( creates )
        return instruction->operandCount == 0 &&
               instruction->result != XL6_IR_VALUE_INVALID;
    if ( operands[0] == NULL || operands[0]->type != treeTypeId ) return 0;
    if ( instruction->runtimeOp == XL6_IR_RUNTIME_AVL_TREE_CLEAR )
        return instruction->operandCount == 1 &&
               instruction->result != XL6_IR_VALUE_INVALID && resultType != NULL &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL;
    if ( instruction->result == XL6_IR_VALUE_INVALID || resultType == NULL )
        return 0;
    switch ( instruction->runtimeOp ) {
    case XL6_IR_RUNTIME_AVL_TREE_SET:
        return instruction->operandCount == 3 && operands[1] != NULL &&
               operands[1]->type == tree->params[0] && operands[2] != NULL &&
               operands[2]->type == tree->params[1] &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL;
    case XL6_IR_RUNTIME_AVL_TREE_CONTAINS:
    case XL6_IR_RUNTIME_AVL_TREE_REMOVE:
        return instruction->operandCount == 2 && operands[1] != NULL &&
               operands[1]->type == tree->params[0] &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL;
    case XL6_IR_RUNTIME_AVL_TREE_TRIM_TO:
        return instruction->operandCount == 2 && operands[1] != NULL &&
               xl6IrTypeGet(&module->types, operands[1]->type) != NULL &&
               xl6IrTypeGet(&module->types, operands[1]->type)->cAbi ==
                   XL6_IR_C_ABI_I64 &&
               resultType->integerTarget == XL6_IR_INTEGER_TARGET_SIGNED_64;
    case XL6_IR_RUNTIME_AVL_TREE_EQUALS:
        return instruction->operandCount == 2 && operands[1] != NULL &&
               operands[1]->type == treeTypeId &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL;
    case XL6_IR_RUNTIME_AVL_TREE_MERGE:
        return instruction->operandCount == 3 && operands[1] != NULL &&
               operands[1]->type == treeTypeId && operands[2] != NULL &&
               xl6IrTypeGet(&module->types, operands[2]->type) != NULL &&
               xl6IrTypeGet(&module->types, operands[2]->type)->cAbi ==
                   XL6_IR_C_ABI_BOOL &&
               resultType->cAbi == XL6_IR_C_ABI_BOOL;
    case XL6_IR_RUNTIME_AVL_TREE_COUNT:
    case XL6_IR_RUNTIME_AVL_TREE_TRIM:
        return instruction->operandCount == 1 &&
               resultType->integerTarget == XL6_IR_INTEGER_TARGET_SIGNED_64;
    case XL6_IR_RUNTIME_AVL_TREE_KEYS:
    case XL6_IR_RUNTIME_AVL_TREE_VALUES:
        return instruction->operandCount == 1 &&
               xl6IrAvlProjectionContract(module,treeTypeId,instruction->type,
                   instruction->runtimeOp==XL6_IR_RUNTIME_AVL_TREE_KEYS,NULL) &&
               resultType->kind == XL6_IR_TYPE_GENERIC_INSTANCE &&
               resultType->collectionAbi == XL6_IR_COLLECTION_ARRAY &&
               resultType->cAbi == XL6_IR_C_ABI_RUNTIME_XVALUE_PTR &&
               resultType->ownershipAbi == XL6_IR_OWNERSHIP_ABI_MANAGED &&
               resultType->typeValueId != 0 && resultType->paramCount == 1 &&
               resultType->params != NULL && resultType->params[0] ==
                   (instruction->runtimeOp == XL6_IR_RUNTIME_AVL_TREE_KEYS
                       ? tree->params[0] : tree->params[1]);
    case XL6_IR_RUNTIME_AVL_TREE_CLONE:
        return instruction->operandCount == 1 &&
               instruction->type == treeTypeId;
    default:
        return 0;
    }
}

/* Shared mechanical ARRAY/STACK factory selection. A target recipe does not
 * authorize source carrier cutover: the caller still verifies its producer.
 * No element traversal, schema reconstruction or generated codec is emitted. */
static const char* xl6IrCgenSequenceTransferAbiToken(XL6_IrRuntimeResourcePayloadAbi transfer)
{
    /* Sequence is not a Channel prelude consumer. Emit the verified private
     * transfer ABI directly, without an unrelated generated macro dependency. */
    switch (transfer) {
    case XL6_IR_RUNTIME_RESOURCE_PAYLOAD_TRIVIAL_COPY: return "1";
    case XL6_IR_RUNTIME_RESOURCE_PAYLOAD_STRING_COPY: return "2";
    case XL6_IR_RUNTIME_RESOURCE_PAYLOAD_XVALUE_RETAIN: return "3";
    case XL6_IR_RUNTIME_RESOURCE_PAYLOAD_FUTURE_REF: return "4";
    case XL6_IR_RUNTIME_RESOURCE_PAYLOAD_NATIVE_VALUE_COPY: return "5";
    default: return NULL;
    }
}
typedef struct XL6_IrCgenValueCollectionTarget {
    const char* layout;
    const char* create;
    const char* project;
    const char* schema;
    const char* importProvider;
} XL6_IrCgenValueCollectionTarget;
/* Closed declarative target table; an unknown family never means Set. */
static const XL6_IrCgenValueCollectionTarget* xl6IrCgenValueCollectionTarget(XL6_IrCollectionAbi family)
{
    static const XL6_IrCgenValueCollectionTarget list={"XL6_ListLayoutV1","xl6ListCreateTakeV1",
        "xl6ListProjectionTakeV1","xl6SequenceListCreateTakeV1","xl6ListImportProviderV1"};
    static const XL6_IrCgenValueCollectionTarget set={"XL6_SetLayoutV1","xl6SetCreateTakeV1",
        "xl6SetProjectionTakeV1","xl6SequenceSetCreateTakeV1","xl6SetImportProviderV1"};
    static const XL6_IrCgenValueCollectionTarget dict={"XL6_DictLayoutV1","xl6DictCreateTakeV1",
        "xl6DictProjectionTakeV1","xl6SequenceDictCreateTakeV1","xl6DictImportProviderV1"};
    switch (family) {
    case XL6_IR_COLLECTION_LIST: return &list;
    case XL6_IR_COLLECTION_SET: return &set;
    case XL6_IR_COLLECTION_DICT: return &dict;
    default: return NULL;
    }
}
static int xl6IrCgenEmitImportProviders(XL6_Output* out,const XL6_IrModule* module,
    const XL6_IrTypeId* types,size_t count)
{
    for (size_t i=0;i<count;++i) {
        const XL6_IrType* type=xl6IrTypeGet(&module->types,types[i]);
        const XL6_IrCgenValueCollectionTarget* target=type ? xl6IrCgenValueCollectionTarget(type->collectionAbi) : NULL;
        if (!type || (!target && type->collectionAbi!=XL6_IR_COLLECTION_ARRAY)) return 0;
        if (i) xl6OutputPuts(",",out);
        if (target) xl6OutputPrintf(out,"%s()",target->importProvider);
        else xl6OutputPuts("NULL",out);
    }
    return !xl6OutputHasFailed(out);
}
static XL6_IrCollectionAbi xl6IrCgenValueCollectionFamily(XL6_IrSequenceLayoutAbi abi)
{
    switch (abi) {
    case XL6_IR_SEQUENCE_LAYOUT_LIST_REFERENCE_V1: return XL6_IR_COLLECTION_LIST;
    case XL6_IR_SEQUENCE_LAYOUT_SET_REFERENCE_V1: return XL6_IR_COLLECTION_SET;
    case XL6_IR_SEQUENCE_LAYOUT_DICT_REFERENCE_V1: return XL6_IR_COLLECTION_DICT;
    default: return XL6_IR_COLLECTION_NONE;
    }
}
static int xl6IrCgenEmitTreeReferenceCreateDepth(XL6_Output*,const XL6_IrModule*,
    XL6_IrTypeId,const char*,size_t);
static int xl6IrCgenEmitQueueReferenceCreateDepth(XL6_Output*,const XL6_IrModule*,
    XL6_IrTypeId,const char*,size_t);
static int xl6IrCgenEmitListTargetCreateDepth(XL6_Output*,const XL6_IrModule*,
    XL6_IrTypeId,const char*,XL6_IrNominalIdentitySetId,size_t,const char*,size_t);
static int xl6IrCgenEmitValueCollectionTargetCreateDepth(XL6_Output*,const XL6_IrModule*,
    XL6_IrTypeId,XL6_IrCollectionAbi,const char*,XL6_IrNominalIdentitySetId,size_t,const char*,size_t);
static int xl6IrCgenEmitSequenceCreateDepth(XL6_Output* out,const XL6_IrModule* module,
    XL6_IrTypeId typeId,const char* result,XL6_IrNominalIdentitySetId admissionSet,size_t depth,
    const char* importChain,size_t importCount,bool projectArrays,bool captureSeed)
{
    const XL6_IrType* sequence=xl6IrTypeGet(&module->types,typeId);
    XL6_IrNominalIdentitySetId expectedSet=XL6_IR_NOMINAL_IDENTITY_SET_INVALID;
    if (depth>64 || !sequence || !xl6IrSequenceConstructionRecipe(module,typeId,sequence->sequenceLayout.role,&expectedSet) ||
        admissionSet!=expectedSet) return -1;
    const XL6_IrSequenceLayout* plan=&sequence->sequenceLayout;
    bool any=plan->abi==XL6_IR_SEQUENCE_LAYOUT_DYNAMIC_VALUE;
    XL6_IrTypeId element=any ? xl6IrArrayAnyElementType(module,typeId) : plan->elementType;
    const XL6_IrType* payload=xl6IrTypeGet(&module->types,element);
    const XL6_IrType* base=any ? payload : xl6IrTypeGet(&module->types,plan->baseElementType);
    const char* descriptor=any ? "xrtTypeValue()" : xl6IrCgenNativeSlotTypeExpr(plan->slotAbi);
    const char* baseDescriptor=xl6IrCgenNativeValueTypeExpr(module,plan->baseElementType);
    const char* payloadType=plan->codecAbi==XL6_IR_SEQUENCE_CODEC_ERROR_VALUE_V1 ||
        plan->codecAbi==XL6_IR_SEQUENCE_CODEC_UNION_VALUE_V1 ||
        plan->codecAbi==XL6_IR_SEQUENCE_CODEC_CLOSURE_VALUE_V1 ? "xvalue*" : xl6IrCgenType(module,element);
    const char* transfer=any ? "3" : xl6IrCgenSequenceTransferAbiToken(plan->transferAbi);
#define XL6_SEQUENCE_CREATE_IDS result,(unsigned)plan->role, \
    (unsigned long long)sequence->typeValueId,(unsigned long long)payload->typeValueId
    switch (plan->abi) {
    case XL6_IR_SEQUENCE_LAYOUT_UNION_VALUE_V1:
        xl6OutputPrintf(out,
            "    %s = xl6SequenceUnionCreateV1(%u, 0x%016llXULL, 0x%016llXULL, 0x%016llXULL, sizeof(%s), %s);\n",
            XL6_SEQUENCE_CREATE_IDS,(unsigned long long)base->typeValueId,
            xl6IrCgenType(module,plan->baseElementType),plan->nullable ? "true" : "false");
        break;
    case XL6_IR_SEQUENCE_LAYOUT_NATIVE_VALUE_V1:
        {
            const XL6_IrNativeValuePlan* native=xl6IrNativeValuePlanForType(payload);
            if (!native || !native->sequenceSymbol || plan->slotAbi!=native->slotAbi) return -1;
            xl6OutputPrintf(out,"    %s = %s(%u, 0x%016llXULL",
                result,native->sequenceSymbol,(unsigned)plan->role,(unsigned long long)sequence->typeValueId);
            if(native->nominalDomainArguments)
                xl6OutputPrintf(out,", 0x%016llXULL, 0x%016llXULL, %s",
                    (unsigned long long)payload->typeValueId,(unsigned long long)base->typeValueId,
                    plan->nullable ? "true" : "false");
            xl6OutputPuts(");\n",out);
        }
        break;
    case XL6_IR_SEQUENCE_LAYOUT_DYNAMIC_VALUE:
        xl6OutputPrintf(out,
            "    %s = xl6SequenceReferenceCreateV1(%u, 0x%016llXULL, 0x%016llXULL, %u, false, 0x%016llXULL);\n",
            XL6_SEQUENCE_CREATE_IDS,(unsigned)XL6_VALUE_ADMIT_ANY,(unsigned long long)base->typeValueId);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_PRIMITIVE_V2:
        if (!descriptor || !payloadType || !transfer) return -1;
        xl6OutputPrintf(out,
            "    %s = xl6SequencePrimitiveCreateV1(%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, %u, %s, 0x%016llXULL);\n",
            XL6_SEQUENCE_CREATE_IDS,transfer,payloadType,descriptor,(unsigned)plan->admissionAbi,
            plan->nullable ? "true" : "false",(unsigned long long)base->typeValueId);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_REFERENCE_V2:
        xl6OutputPrintf(out,
            "    %s = xl6SequenceReferenceCreateV1(%u, 0x%016llXULL, 0x%016llXULL, %u, %s, 0x%016llXULL);\n",
            XL6_SEQUENCE_CREATE_IDS,(unsigned)plan->admissionAbi,plan->nullable ? "true" : "false",
            (unsigned long long)base->typeValueId);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_NOMINAL_V2:
        xl6OutputPrintf(out,
            "    %s = xl6SequenceNominalCreateV1(%u, 0x%016llXULL, 0x%016llXULL, &xlir_nominal_set_%u, %s, 0x%016llXULL);\n",
            XL6_SEQUENCE_CREATE_IDS,(unsigned)admissionSet,plan->nullable ? "true" : "false",
            (unsigned long long)base->typeValueId);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_C_SCALAR_V1:
        if (!descriptor) return -1;
        xl6OutputPrintf(out,
            "    %s = xl6SequenceCScalarCreateV1(%u, 0x%016llXULL, 0x%016llXULL, %s, 0x%016llXULL);\n",
            XL6_SEQUENCE_CREATE_IDS,descriptor,(unsigned long long)base->typeValueId);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_NULLABLE_C_SCALAR_V1:
        if (!descriptor || !baseDescriptor) return -1;
        xl6OutputPrintf(out,
            "    %s = xl6SequenceNullableCScalarCreateV1(%u, 0x%016llXULL, 0x%016llXULL, %s, %s, 0x%016llXULL);\n",
            XL6_SEQUENCE_CREATE_IDS,descriptor,baseDescriptor,(unsigned long long)base->typeValueId);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_NUMERIC_ENUM_V1:
        if (!descriptor) return -1;
        xl6OutputPrintf(out,
            "    %s = xl6SequenceNumericEnumCreateV1(%u, 0x%016llXULL, 0x%016llXULL, %s, %u, %s, 0x%016llXULL);\n",
            XL6_SEQUENCE_CREATE_IDS,descriptor,(unsigned)plan->admissionAbi,
            plan->nullable ? "true" : "false",(unsigned long long)base->typeValueId);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_MUTEX_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_COND_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_RWLOCK_REFERENCE_V1:
        xl6OutputPrintf(out,
            "    %s = xl6SequenceSyncCreateV1(%u, 0x%016llXULL, 0x%016llXULL, 0x%016llXULL, %s, %u);\n",
            result,(unsigned)plan->role,(unsigned long long)sequence->typeValueId,
            (unsigned long long)payload->typeValueId,(unsigned long long)base->typeValueId,
            plan->nullable ? "true" : "false",
            plan->abi==XL6_IR_SEQUENCE_LAYOUT_MUTEX_REFERENCE_V1 ? 1u :
            plan->abi==XL6_IR_SEQUENCE_LAYOUT_COND_REFERENCE_V1 ? 2u : 3u);
        break;
    case XL6_IR_SEQUENCE_LAYOUT_ERROR_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_CALLABLE_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_FUTURE_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_SEMAPHORE_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_THREAD_REFERENCE_V1:
        xl6OutputPrintf(out,
            "    %s = %s(%u, 0x%016llXULL, 0x%016llXULL, 0x%016llXULL, %s);\n",
            result,plan->abi==XL6_IR_SEQUENCE_LAYOUT_ERROR_REFERENCE_V1 ? "xl6SequenceErrorCreateV1" :
                plan->abi==XL6_IR_SEQUENCE_LAYOUT_CALLABLE_REFERENCE_V1 ?
                "xl6SequenceCallableCreateV1" :
                plan->abi==XL6_IR_SEQUENCE_LAYOUT_SEMAPHORE_REFERENCE_V1 ?
                "xl6SequenceSemCreateV1" :
                plan->abi==XL6_IR_SEQUENCE_LAYOUT_THREAD_REFERENCE_V1 ?
                "xl6SequenceThreadCreateV1" : "xl6SequenceFutureCreateV1",
            (unsigned)plan->role,(unsigned long long)sequence->typeValueId,
            (unsigned long long)payload->typeValueId,(unsigned long long)base->typeValueId,
            plan->nullable ? "true" : "false");
        break;
    case XL6_IR_SEQUENCE_LAYOUT_SEQUENCE_REFERENCE_V1:
        {
            XL6_IrNominalIdentitySetId childSet=XL6_IR_NOMINAL_IDENTITY_SET_INVALID;
            char childResult[48];
            if (!xl6IrSequenceConstructionRecipe(module,plan->baseElementType,plan->childRole,&childSet)) return -1;
            snprintf(childResult,sizeof(childResult),"xlir_sequence_schema_%u",(unsigned)(depth+1));
            /* Render the already-verified child recipe, not a layout-only
             * approximation. The resident parent consumes the temporary seed
             * on either path and retains only its immutable owned schema. */
            xl6OutputPrintf(out,"    { xvalue* %s = NULL;\n",childResult);
            if (xl6IrCgenEmitSequenceCreateDepth(out,module,plan->baseElementType,
                childResult,childSet,depth+1,importChain,importCount,projectArrays,true)<0) return -1;
            xl6OutputPrintf(out,
                "    %s = xl6SequenceNestedCreateTakeV2(%u, 0x%016llXULL, 0x%016llXULL, %s, %s); }\n",
                XL6_SEQUENCE_CREATE_IDS,childResult,plan->nullable ? "true" : "false");
        }
        break;
    case XL6_IR_SEQUENCE_LAYOUT_LIST_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_SET_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_DICT_REFERENCE_V1:
        {
            XL6_IrValueCollectionRecipe child={0};
            XL6_IrCollectionAbi family=xl6IrCgenValueCollectionFamily(plan->abi);
            const XL6_IrCgenValueCollectionTarget* target=xl6IrCgenValueCollectionTarget(family);
            char childResult[48];
            if (!target || !xl6IrValueCollectionConstructionRecipe(module,plan->baseElementType,&child) || child.family!=family) return -1;
            snprintf(childResult,sizeof(childResult),"xlir_collection_schema_%u",(unsigned)(depth+1));
            xl6OutputPrintf(out,"    { xvalue* %s = NULL;\n",childResult);
            if (xl6IrCgenEmitValueCollectionTargetCreateDepth(out,module,plan->baseElementType,
                family,childResult,child.admissionIdentitySet,depth+1,importChain,importCount)<0) return -1;
            xl6OutputPrintf(out,
                "    %s = %s(%u, 0x%016llXULL, 0x%016llXULL, %s, %s); }\n",
                result,target->schema,
                (unsigned)plan->role,(unsigned long long)sequence->typeValueId,
                (unsigned long long)payload->typeValueId,childResult,plan->nullable ? "true" : "false");
        }
        break;
    case XL6_IR_SEQUENCE_LAYOUT_TREE_REFERENCE_V1:
        if (xl6IrCgenEmitTreeReferenceCreateDepth(out,module,typeId,result,depth+1)<0) return -1;
        break;
    case XL6_IR_SEQUENCE_LAYOUT_QUEUE_REFERENCE_V1:
        if (xl6IrCgenEmitQueueReferenceCreateDepth(out,module,typeId,result,depth+1)<0) return -1;
        break;
    case XL6_IR_SEQUENCE_LAYOUT_CHANNEL_REFERENCE_V1:
    case XL6_IR_SEQUENCE_LAYOUT_SLOT_MAP_REFERENCE_V1: {
        bool channel=plan->abi==XL6_IR_SEQUENCE_LAYOUT_CHANNEL_REFERENCE_V1;
        XL6_IrTypeId child=channel ? base->messageSchemaType : base->collectionValueSchemaType;
        XL6_IrNominalIdentitySetId childSet=0; char childResult[48];
        if(!xl6IrSequenceConstructionRecipe(module,child,XL6_IR_SEQUENCE_ROLE_ARRAY,&childSet))return -1;
        snprintf(childResult,sizeof(childResult),"xlir_resource_schema_%u",(unsigned)(depth+1));
        xl6OutputPrintf(out,"    { xvalue* %s = NULL;\n",childResult);
        if(xl6IrCgenEmitSequenceCreateDepth(out,module,child,childResult,childSet,depth+1,NULL,0,false,true)<0)return -1;
        xl6OutputPrintf(out,"    %s = %s ? %s(%u, 0x%016llXULL, 0x%016llXULL, 0x%016llXULL, %s, %s) : NULL; }\n",
            result,childResult,channel ? "xl6SequenceChannelCreateTakeV1" : "xl6SequenceSlotMapCreateTakeV1",
            (unsigned)plan->role,(unsigned long long)sequence->typeValueId,(unsigned long long)payload->typeValueId,
            (unsigned long long)base->typeValueId,childResult,plan->nullable ? "true" : "false");
        break;
    }
    default: return -1;
    }
#undef XL6_SEQUENCE_CREATE_IDS
    if (projectArrays && plan->role==XL6_IR_SEQUENCE_ROLE_ARRAY) {
        xl6OutputPrintf(out,
            "    %s = xl6ArrayProjectionTakeV1(%s, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, %s);\n",
            result,result,(unsigned long long)sequence->typeValueId,
            (unsigned long long)payload->typeValueId,transfer,payloadType,descriptor,
            any || plan->transferAbi==XL6_IR_RUNTIME_RESOURCE_PAYLOAD_XVALUE_RETAIN ? "NULL" :
                xl6IrCgenNativeValueConverterExpr(module,plan->elementType));
    }
    if (captureSeed && importChain && depth<importCount) {
        xl6OutputPrintf(out,
            "    %s[%u] = %s ? xl6ArrayEraseV1(%s, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, %s) : NULL;\n",
            importChain,(unsigned)depth,result,result,(unsigned long long)sequence->typeValueId,
            (unsigned long long)payload->typeValueId,transfer,payloadType,descriptor,
            any || plan->transferAbi==XL6_IR_RUNTIME_RESOURCE_PAYLOAD_XVALUE_RETAIN ? "NULL" :
                xl6IrCgenNativeValueConverterExpr(module,plan->elementType));
    }
    return xl6OutputHasFailed(out) ? -1 : 1;
}
#include "src/cgen/xl6_ir_cgen_concurrent_queue_emit.c"
#include "src/cgen/xl6_ir_cgen_channel_emit.c"
#include "src/cgen/xl6_ir_cgen_list_target_emit.c"
static int xl6IrCgenEmitSequenceCreate(XL6_Output* out,const XL6_IrModule* module,
    XL6_IrTypeId typeId,XL6_IrValueId result,XL6_IrNominalIdentitySetId admissionSet)
{
    char target[24]; snprintf(target,sizeof(target),"v%u",(unsigned)result);
    return xl6IrCgenEmitSequenceCreateDepth(out,module,typeId,target,admissionSet,0,NULL,0,false,true);
}
static int xl6IrCgenEmitArrayCreate(XL6_Output* out,const XL6_IrModule* module,
    const XL6_IrInstruction* instruction)
{
    if (!xl6IrArrayCreateRuntimeInstructionCompatible(module,instruction)) return -1;
    char target[24]; snprintf(target,sizeof(target),"v%u",(unsigned)instruction->result);
    return xl6IrCgenEmitSequenceCreateDepth(out,module,instruction->type,target,
        instruction->sequenceAdmissionIdentitySet,0,NULL,0,true,true);
}

/* Explicit data boundary renderer. IR owns the complete chain and physical
 * codecs. Cgen emits only factories, resident projection bindings and ONE
 * import call; no generated item loops, recursive conversion or memo table.
 * Source producer/cast authorization will select this separately from the
 * native target recipe. Validate everything before emitting any C. */
static int xl6IrCgenEmitArrayImportChain(XL6_Output* out,const XL6_IrModule* module,
    XL6_IrTypeId typeId,XL6_IrValueId result,const char* source,bool sourceOwned)
{
    size_t count=0; XL6_IrTypeId types[65]; XL6_IrNominalIdentitySetId set=0;
    if (!source || !xl6IrArrayImportChainRecipe(module,typeId,types,65,&count) ||
        !xl6IrSequenceConstructionRecipe(module,typeId,XL6_IR_SEQUENCE_ROLE_ARRAY,&set)) return -1;
    bool mixed=false;
    for (size_t i=0;i<count;++i)
        if (xl6IrTypeGet(&module->types,types[i])->collectionAbi!=XL6_IR_COLLECTION_ARRAY) mixed=true;
    char target[24]; snprintf(target,sizeof(target),"v%u",(unsigned)result);
    xl6OutputPrintf(out,"    { xvalue* xlir_array_import_seeds[%u] = {0};\n",(unsigned)count);
    if (xl6IrCgenEmitSequenceCreateDepth(out,module,typeId,target,set,0,"xlir_array_import_seeds",count,false,true)<0) return -1;
    if (mixed) {
        xl6OutputPrintf(out,"    const XL6_CollectionImportProviderV1* xlir_array_import_providers[%u] = {",(unsigned)count);
        if (!xl6IrCgenEmitImportProviders(out,module,types,count)) return -1;
        xl6OutputPrintf(out,"};\n    const XL6_CollectionImportPlanV1 xlir_array_import_plan = {sizeof(XL6_CollectionImportPlanV1),"
            "xlir_array_import_providers,XL6_COLLECTION_IMPORT_LANGUAGE_INPUT_V1,0,0,false};\n"
            "    xrtValueRelease(%s);\n    %s = %s(xlir_array_import_seeds,%u,%s,&xlir_array_import_plan); }\n",
            target,target,sourceOwned ? "xl6CollectionImportChainSourceTakeV1" : "xl6CollectionImportChainTakeV1",
            (unsigned)count,source);
        return xl6OutputHasFailed(out) ? -1 : 1;
    }
    xl6OutputPrintf(out,"    xrtValueRelease(%s);\n"
        "    %s = %s(xlir_array_import_seeds, %u, %s); }\n",
        target,target,sourceOwned ? "xl6ArrayImportChainSourceTakeV1" : "xl6ArrayImportChainTakeV1",
        (unsigned)count,source);
    return xl6OutputHasFailed(out) ? -1 : 1;
}

static int xl6IrCgenEmitValueCollectionImportChain(XL6_Output* out,const XL6_IrModule* module,
    XL6_IrTypeId typeId,XL6_IrValueId result,const char* source)
{
    XL6_IrTypeId types[65]; XL6_IrValueCollectionRecipe recipe={0};
    size_t count=0;
    if (!source || !xl6IrValueCollectionConstructionRecipe(module,typeId,&recipe) ||
        !xl6IrCollectionImportChainRecipe(module,typeId,types,65,&count)) return -1;
    char target[24]; snprintf(target,sizeof(target),"v%u",(unsigned)result);
    xl6OutputPrintf(out,"    { xvalue* xlir_list_import_seeds[%u] = {0};\n",(unsigned)count);
    if (xl6IrCgenEmitValueCollectionTargetCreateDepth(out,module,typeId,recipe.family,target,
        recipe.admissionIdentitySet,0,"xlir_list_import_seeds",count)<0) return -1;
    xl6OutputPrintf(out,"    xrtValueRelease(%s);\n"
        "    const XL6_CollectionImportProviderV1* xlir_list_import_providers[%u] = {",target,(unsigned)count);
    if (!xl6IrCgenEmitImportProviders(out,module,types,count)) return -1;
    xl6OutputPrintf(out,"};\n"
        "    const XL6_CollectionImportPlanV1 xlir_list_import_plan = {sizeof(XL6_CollectionImportPlanV1),"
        "xlir_list_import_providers,XL6_COLLECTION_IMPORT_LANGUAGE_INPUT_V1,0,0,false};\n"
        "    %s = xl6CollectionImportChainSourceTakeV1(xlir_list_import_seeds,%u,%s,&xlir_list_import_plan); }\n",
        target,(unsigned)count,source);
    return xl6OutputHasFailed(out) ? -1 : 1;
}

static int xl6IrCgenEmitStackRuntime(
    XL6_Output* out, const XL6_IrModule* module,
    const XL6_IrInstruction* instruction)
{
    const XL6_IrInstruction* receiver;
    const XL6_IrType* stack;
    const XL6_IrType* payload;
    const char* payloadType;
    const char* payloadAbi;
    const char* runtimeType;
    XL6_IrValueId first;
    if(instruction && (instruction->runtimeOp==XL6_IR_RUNTIME_NATIVE_SCALAR_AS_CHECKED ||
        instruction->runtimeOp==XL6_IR_RUNTIME_NATIVE_SCALAR_CONVERT_CHECKED)) {
        if(!xl6IrNativeScalarInstructionCompatible(module,instruction))return -1;
        const XL6_IrType* target=xl6IrTypeGet(&module->types,instruction->type);
        const XL6_IrType* identity=xl6IrTypeGet(&module->types,instruction->runtimeIdentityType);
        unsigned profile=xl6IrNativeScalarProfileForCAbi(identity->cAbi);
        XL6_IrValueId source=module->operands[instruction->firstOperand];
        if(instruction->runtimeOp==XL6_IR_RUNTIME_NATIVE_SCALAR_CONVERT_CHECKED) {
            unsigned input=xl6IrNativeScalarConversionInput(xl6IrTypeGet(&module->types,instruction->payloadType));
            if(input==XL6_SCALAR_INPUT_XVALUE)
                xl6OutputPrintf(out,"    bool projection_ok_%u = xl6ValueConvertNativeScalarV2(v%u, %u, 0x%016llXULL, &v%u);\n",
                    (unsigned)instruction->result,(unsigned)source,profile,
                    (unsigned long long)module->runtimeTypeMap.typeTypeValueId,(unsigned)instruction->result);
            else xl6OutputPrintf(out,"    bool projection_ok_%u = xl6NativeScalarConvertV1(&v%u, %u, %u, &v%u);\n",
                (unsigned)instruction->result,(unsigned)source,input,profile,(unsigned)instruction->result);
        } else if(target->kind==XL6_IR_TYPE_NULLABLE) {
            xl6OutputPrintf(out,"    v%u.hasValue=false; v%u.value=0;\n"
                "    bool projection_ok_%u = xl6ValueTryReadNativeScalarV1(v%u, %u, 0x%016llXULL, &v%u.hasValue, &v%u.value);\n",
                (unsigned)instruction->result,(unsigned)instruction->result,(unsigned)instruction->result,
                (unsigned)source,profile,(unsigned long long)identity->typeValueId,(unsigned)instruction->result,(unsigned)instruction->result);
        } else xl6OutputPrintf(out,"    bool projection_ok_%u = xl6ValueReadNativeScalarV1(v%u, %u, 0x%016llXULL, &v%u);\n",
            (unsigned)instruction->result,(unsigned)source,profile,(unsigned long long)identity->typeValueId,(unsigned)instruction->result);
        return xl6OutputHasFailed(out) ? -1 : 1;
    }
    if(instruction && instruction->runtimeOp==XL6_IR_RUNTIME_F32_AS_CHECKED) {
        if(!xl6IrFloat32AsInstructionCompatible(module,instruction))return -1;
        const XL6_IrType* target=xl6IrTypeGet(&module->types,instruction->type);
        bool nullable=target->kind==XL6_IR_TYPE_NULLABLE;
        const XL6_IrType* base=nullable ? xl6IrTypeGet(&module->types,target->params[0]) : target;
        XL6_IrValueId source=module->operands[instruction->firstOperand];
        if(nullable) {
            xl6OutputPrintf(out,"    v%u.hasValue = false; v%u.value = 0;\n    bool projection_ok_%u = xl6ValueTryReadF32V1(v%u, 0x%016llXULL, &v%u.hasValue, &v%u.value);\n",
                (unsigned)instruction->result,(unsigned)instruction->result,(unsigned)instruction->result,
                (unsigned)source,(unsigned long long)base->xvalueAdmissionTypeValueId,(unsigned)instruction->result,(unsigned)instruction->result);
        } else xl6OutputPrintf(out,"    v%u = 0;\n    bool projection_ok_%u = xl6ValueReadF32V1(v%u, 0x%016llXULL, &v%u);\n",
            (unsigned)instruction->result,(unsigned)instruction->result,(unsigned)source,
            (unsigned long long)base->xvalueAdmissionTypeValueId,(unsigned)instruction->result);
        return xl6OutputHasFailed(out) ? -1 : 1;
    }
    if (instruction && instruction->runtimeOp==XL6_IR_RUNTIME_NATIVE_CONTAINER_PROJECT_CHECKED) {
        XL6_IrNativeContainerProjectionAbi role=XL6_IR_NATIVE_PROJECTION_NONE;
        const char* symbol=xl6IrCgenContainerProjectionSymbol(module,instruction);
        if (!symbol ||
            !xl6IrNativeContainerProjectionTarget(module,instruction->type,NULL,&role,NULL)) return -1;
        if(role==XL6_IR_NATIVE_PROJECTION_NATIVE_SEQUENCE){
            const XL6_IrType* sequence=xl6IrTypeGet(&module->types,instruction->runtimeIdentityType);
            const XL6_IrType* element=xl6IrTypeGet(&module->types,instruction->payloadType);
            unsigned source=(unsigned)module->operands[instruction->firstOperand],result=(unsigned)instruction->result;
            bool nullable=instruction->castAbi==XL6_IR_CAST_XVALUE_TO_NULLABLE_NATIVE_CONTAINER_TRY;
            xl6OutputPrintf(out,"    v%u=NULL; bool projection_ok_%u=true;\n    if(xl6NativeSequenceAdmitsV1(v%u,UINT64_C(0x%016llX),UINT64_C(0x%016llX)))v%u=v%u;\n"
                "    else { xl6_error_scope sequence_cast_cleanup={0};if(!xl6ErrorScopeBeginCleanup(&sequence_cast_cleanup,%s))abort();\n",result,result,source,(unsigned long long)sequence->typeValueId,(unsigned long long)element->typeValueId,result,source,"false");
            if(!nullable)xl6OutputPuts("        xrtSetErrorKind(XERR_TYPE);xl6ErrorScopeCaptureFailure(&sequence_cast_cleanup);\n",out);
            xl6OutputPrintf(out,"        xrtValueRelease(v%u);xl6_error_result sequence_cast_outcome=xl6ErrorScopeEnd(&sequence_cast_cleanup);projection_ok_%u=sequence_cast_outcome.ok;\n",source,result);
            if(nullable)xl6OutputPrintf(out,"        v%u=xrtValueRetain(xrtValueNull());\n",result);
            xl6OutputPrintf(out,"        if(!sequence_cast_outcome.ok)xl6ErrorScopePropagateFailure(sequence_cast_outcome);else xrtErrorFree(sequence_cast_outcome.error);\n    }\n    v%u=NULL;\n",source);
            return xl6OutputHasFailed(out) ? -1:1;
        }
        XL6_IrValueId seed=module->operands[instruction->firstOperand];
        XL6_IrValueId source=module->operands[instruction->firstOperand+1];
        xl6OutputPrintf(out,"    v%u = NULL;\n    bool projection_ok_%u = %s(v%u, ",
            (unsigned)instruction->result,(unsigned)instruction->result,symbol,(unsigned)seed);
        if(role==XL6_IR_NATIVE_PROJECTION_ARRAY || role==XL6_IR_NATIVE_PROJECTION_STACK)
            xl6OutputPrintf(out,"%u, ",role==XL6_IR_NATIVE_PROJECTION_ARRAY ? 1u : 2u);
        xl6OutputPrintf(out,"v%u, %s, &v%u);\n    v%u = NULL;\n",(unsigned)source,
            instruction->castAbi==XL6_IR_CAST_XVALUE_TO_NULLABLE_NATIVE_CONTAINER_TRY ? "true" : "false",
            (unsigned)instruction->result,(unsigned)seed);
        return xl6OutputHasFailed(out) ? -1 : 1;
    }
    if (instruction && instruction->runtimeOp==XL6_IR_RUNTIME_STACK_ERASE) {
        if (!xl6IrStackErasureInstructionCompatible(module,instruction)) return -1;
        const XL6_IrType* sealed=xl6IrTypeGet(&module->types,instruction->runtimeIdentityType);
        const XL6_IrType* element=xl6IrTypeGet(&module->types,instruction->payloadType);
        XL6_IrValueId input=module->operands[instruction->firstOperand];
        const XL6_IrType* source=xl6IrTypeGet(&module->types,xl6IrCgenValueDefinition(module,input,NULL)->type);
        const char* descriptor=xl6IrCgenNativeSlotTypeExpr(sealed->sequenceLayout.slotAbi);
        const char* converter=sealed->sequenceLayout.transferAbi==XL6_IR_RUNTIME_RESOURCE_PAYLOAD_XVALUE_RETAIN
            ? "NULL" : xl6IrCgenNativeValueConverterExpr(module,instruction->payloadType);
        if (!descriptor || !converter) return -1;
        xl6OutputPrintf(out,"    v%u = xl6StackEraseTakeV2(v%u, 0x%016llXULL, 0x%016llXULL, %s, %s->Size, %s, %s, %s, 0x%016llXULL);\n    v%u = NULL;\n",
            (unsigned)instruction->result,(unsigned)input,(unsigned long long)sealed->typeValueId,
            (unsigned long long)element->typeValueId,xl6IrCgenSequenceTransferAbiToken(sealed->sequenceLayout.transferAbi),
            descriptor,descriptor,converter,source->kind==XL6_IR_TYPE_NULLABLE ? "true" : "false",
            (unsigned long long)xl6IrTypeGet(&module->types,instruction->sequenceResultArrayType)->typeValueId,(unsigned)input);
        return xl6OutputHasFailed(out) ? -1 : 1;
    }
    if ( instruction == NULL ||
         !xl6IrCgenStackRuntimeOpIs(instruction->runtimeOp) ) return 0;
    if ( !xl6IrCgenRuntimeStackAbi(module, instruction) ) return -1;
    first = instruction->operandCount != 0
        ? module->operands[instruction->firstOperand] : XL6_IR_VALUE_INVALID;
    receiver = instruction->runtimeOp == XL6_IR_RUNTIME_STACK_CREATE
        ? NULL : xl6IrCgenValueDefinition(module, first, NULL);
    if ( !xl6IrCgenStackTypeAbi(
             module, receiver != NULL ? receiver->type : instruction->type,
             &stack, &payload) ) return -1;
    bool closure=stack->sequenceLayout.codecAbi==XL6_IR_SEQUENCE_CODEC_CLOSURE_VALUE_V1;
    payloadType = closure ? "xvalue*" : xl6IrCgenType(module, instruction->payloadType);
    payloadAbi = xl6IrCgenSequenceTransferAbiToken(
        instruction->runtimeResourcePayloadAbi);
    runtimeType = xl6IrCgenNativeSlotTypeExpr(stack->sequenceLayout.slotAbi);
    if ( payloadType == NULL || payloadAbi == NULL || runtimeType == NULL ) return -1;
#define XL6_IR_CGEN_STACK_COMMON_ARGS                                      \
    (unsigned long long)stack->typeValueId,                                \
    (unsigned long long)payload->typeValueId, payloadAbi, payloadType, runtimeType
    if (instruction->runtimeOp>=XL6_IR_RUNTIME_STACK_PUSH_BATCH &&
        instruction->runtimeOp<=XL6_IR_RUNTIME_STACK_PEEK_BATCH_AT) {
        XL6_IrValueId second=module->operands[instruction->firstOperand+1];
        if (instruction->runtimeOp==XL6_IR_RUNTIME_STACK_PUSH_BATCH) {
            const XL6_IrInstruction* array=xl6IrCgenValueDefinition(module,second,NULL);
            xl6OutputPrintf(out,
                "    v%u = xl6StackPushBatchV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, v%u, 0x%016llXULL);\n",
                (unsigned)instruction->result,(unsigned)first,XL6_IR_CGEN_STACK_COMMON_ARGS,
                (unsigned)second,(unsigned long long)xl6IrTypeGet(&module->types,array->type)->typeValueId);
        } else {
            const XL6_IrType* array=xl6IrTypeGet(&module->types,instruction->type);
            const char* projection=array->sequenceLayout.transferAbi==XL6_IR_RUNTIME_RESOURCE_PAYLOAD_XVALUE_RETAIN
                ? "xl6ArrayReferenceConverterV1()" : xl6IrCgenNativeValueConverterExpr(module,instruction->payloadType);
            if (!projection) return -1;
            xl6OutputPrintf(out,
                "    v%u = xl6StackExtractArrayV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, 0x%016llXULL, ",
                (unsigned)instruction->result,(unsigned)first,XL6_IR_CGEN_STACK_COMMON_ARGS,
                (unsigned long long)array->typeValueId);
            if (instruction->runtimeOp==XL6_IR_RUNTIME_STACK_PEEK_BATCH_AT)
                xl6OutputPrintf(out,"v%u, v%u",(unsigned)second,
                    (unsigned)module->operands[instruction->firstOperand+2]);
            else xl6OutputPrintf(out,"0, v%u",(unsigned)second);
            xl6OutputPrintf(out,", %s, %s);\n",
                instruction->runtimeOp==XL6_IR_RUNTIME_STACK_POP_BATCH ? "true" : "false",projection);
        }
        return xl6OutputHasFailed(out) ? -1 : 1;
    }
    if(closure && (instruction->runtimeOp==XL6_IR_RUNTIME_STACK_POP || instruction->runtimeOp==XL6_IR_RUNTIME_STACK_PEEK ||
        instruction->runtimeOp==XL6_IR_RUNTIME_STACK_PEEK_AT || instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_POP ||
        instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_PEEK || instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_PEEK_AT)) {
        const XL6_IrSequenceLayout* plan=&stack->sequenceLayout;
        const XL6_IrType* base=xl6IrTypeGet(&module->types,plan->baseElementType);
        bool optional=instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_POP || instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_PEEK ||
            instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_PEEK_AT;
        unsigned result=(unsigned)instruction->result;
        xl6OutputPrintf(out,"    v%u = (%s){0};\n    bool projection_ok_%u = xl6StackCallableTakeV1(v%u, 0x%016llXULL, 0x%016llXULL, 0x%016llXULL, %s, ",
            result,xl6IrCgenType(module,instruction->type),result,(unsigned)first,(unsigned long long)stack->typeValueId,
            (unsigned long long)payload->typeValueId,(unsigned long long)base->typeValueId,plan->nullable ? "true" : "false");
        if(instruction->runtimeOp==XL6_IR_RUNTIME_STACK_PEEK_AT || instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_PEEK_AT)
            xl6OutputPrintf(out,"v%u",(unsigned)module->operands[instruction->firstOperand+1]);else xl6OutputPuts("0",out);
        xl6OutputPrintf(out,", %s, xlir_closure_owner, (void (*)(void))xlir_xvalue_closure_entry_t%u, &v%u%s, ",
            instruction->runtimeOp==XL6_IR_RUNTIME_STACK_POP || instruction->runtimeOp==XL6_IR_RUNTIME_STACK_TRY_POP ? "true" : "false",
            (unsigned)plan->baseElementType,result,optional ? ".e1" : "");
        if(optional)xl6OutputPrintf(out,"&v%u.e0",result);else xl6OutputPuts("NULL",out);
        xl6OutputPuts(");\n",out);return xl6OutputHasFailed(out) ? -1 : 1;
    }
    switch ( instruction->runtimeOp ) {
    case XL6_IR_RUNTIME_STACK_CREATE:
        if (xl6IrCgenEmitSequenceCreate(out,module,instruction->type,instruction->result,
            instruction->sequenceAdmissionIdentitySet)<0) return -1;
        break;
    case XL6_IR_RUNTIME_STACK_PUSH:
        if(closure) {
            unsigned item=(unsigned)module->operands[instruction->firstOperand+1];
            const XL6_IrSequenceLayout* plan=&stack->sequenceLayout;
            const XL6_IrType* base=xl6IrTypeGet(&module->types,plan->baseElementType);
            xl6OutputPrintf(out,
                "    { xl6_error_scope stack_scope = {0};\n"
                "      if (!xl6ErrorScopeBegin(&stack_scope)) abort();\n"
                "      xvalue* stack_slot = v%u != NULL ? xlir_closure_to_xvalue_scalar(v%u, xlir_xcall_entry_t%u, 0x%016llXULL) : xrtValueRetain(xrtValueNull());\n"
                "      v%u = stack_slot != NULL && xl6StackPushV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, &stack_slot);\n"
                "      if (!v%u) xl6ErrorScopeCaptureFailure(&stack_scope);\n"
                "      xrtValueRelease(stack_slot);\n"
                "      xl6_error_result stack_outcome = xl6ErrorScopeEnd(&stack_scope);\n"
                "      if (!stack_outcome.ok) xl6ErrorScopePropagateFailure(stack_outcome);\n    }\n",
                item,item,(unsigned)plan->baseElementType,(unsigned long long)base->typeValueId,
                (unsigned)instruction->result,(unsigned)first,XL6_IR_CGEN_STACK_COMMON_ARGS,(unsigned)instruction->result);
            break;
        }
        xl6OutputPrintf(out,
            "    v%u = xl6StackPushV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, &v%u);\n",
            (unsigned int)instruction->result, (unsigned int)first,
            XL6_IR_CGEN_STACK_COMMON_ARGS,
            (unsigned int)module->operands[instruction->firstOperand + 1]);
        break;
    case XL6_IR_RUNTIME_STACK_POP:
    case XL6_IR_RUNTIME_STACK_PEEK:
    case XL6_IR_RUNTIME_STACK_PEEK_AT:
        /* Like a physical return assignment, each evaluation replaces the
         * consumed SSA spelling. It must not feed a stale prior-iteration
         * pointer into the initialized-output native ABI. */
        xl6OutputPrintf(out, "    v%u = (%s){0};\n",
            (unsigned int)instruction->result, payloadType);
        xl6OutputPrintf(out,
            "    bool projection_ok_%u = xl6StackTakeV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, ",
            (unsigned int)instruction->result, (unsigned int)first, XL6_IR_CGEN_STACK_COMMON_ARGS);
        if ( instruction->runtimeOp == XL6_IR_RUNTIME_STACK_PEEK_AT )
            xl6OutputPrintf(out, "v%u", (unsigned int)module->operands[instruction->firstOperand + 1]);
        else xl6OutputPuts("0", out);
        xl6OutputPrintf(out, ", &v%u, %s);\n", (unsigned int)instruction->result,
            instruction->runtimeOp == XL6_IR_RUNTIME_STACK_POP ? "true" : "false");
        break;
    case XL6_IR_RUNTIME_STACK_RESERVE:
        xl6OutputPrintf(out,
            "    v%u = xl6StackReserveV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, v%u);\n",
            (unsigned int)instruction->result, (unsigned int)first,
            XL6_IR_CGEN_STACK_COMMON_ARGS,
            (unsigned int)module->operands[instruction->firstOperand + 1]);
        break;
    case XL6_IR_RUNTIME_STACK_TRY_POP:
    case XL6_IR_RUNTIME_STACK_TRY_PEEK:
    case XL6_IR_RUNTIME_STACK_TRY_PEEK_AT:
        {
            const XL6_IrType* product = xl6IrTypeGet(&module->types, instruction->type);
            int tagged = xl6IrOptionalResultPayloadTagged(module,product->params[1],instruction->payloadType);
            xl6OutputPrintf(out, "    v%u = (%s){0};\n",
                (unsigned int)instruction->result, xl6IrCgenType(module, instruction->type));
            xl6OutputPrintf(out,
                "    bool projection_ok_%u = xl6StackTryTakeV2(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, ",
                (unsigned int)instruction->result, (unsigned int)first, XL6_IR_CGEN_STACK_COMMON_ARGS);
            if ( instruction->runtimeOp == XL6_IR_RUNTIME_STACK_TRY_PEEK_AT )
                xl6OutputPrintf(out, "v%u", (unsigned int)module->operands[instruction->firstOperand + 1]);
            else xl6OutputPuts("0", out);
            xl6OutputPrintf(out, ", &v%u.e1%s, %s, &v%u.e0);\n", (unsigned int)instruction->result,
                tagged ? ".value" : "", instruction->runtimeOp == XL6_IR_RUNTIME_STACK_TRY_POP ? "true" : "false",
                (unsigned int)instruction->result);
            if ( tagged ) xl6OutputPrintf(out, "    v%u.e1.hasValue = v%u.e0;\n",
                (unsigned int)instruction->result, (unsigned int)instruction->result);
        }
        break;
    case XL6_IR_RUNTIME_STACK_CLONE:
        xl6OutputPrintf(out,
            "    v%u = xl6StackCloneV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s);\n",
            (unsigned int)instruction->result, (unsigned int)first,
            XL6_IR_CGEN_STACK_COMMON_ARGS);
        break;
    case XL6_IR_RUNTIME_STACK_EQUALS:
        xl6OutputPrintf(out,
            "    v%u = xl6StackEqualsV1(v%u, v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s);\n",
            (unsigned int)instruction->result, (unsigned int)first,
            (unsigned int)module->operands[instruction->firstOperand + 1],
            XL6_IR_CGEN_STACK_COMMON_ARGS);
        break;
    case XL6_IR_RUNTIME_STACK_TRIM:
        xl6OutputPrintf(out,
            "    v%u = xl6StackTrimV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s);\n",
            (unsigned int)instruction->result, (unsigned int)first,
            XL6_IR_CGEN_STACK_COMMON_ARGS);
        break;
    case XL6_IR_RUNTIME_STACK_CLEAR:
        xl6OutputPrintf(out,
            "    v%u = xl6StackClearV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s);\n",
            (unsigned int)instruction->result, (unsigned int)first, XL6_IR_CGEN_STACK_COMMON_ARGS);
        break;
    case XL6_IR_RUNTIME_STACK_COUNT:
    case XL6_IR_RUNTIME_STACK_CAPACITY:
        xl6OutputPrintf(out,
            "    v%u = xl6StackSizeV1(v%u, 0x%016llXULL, 0x%016llXULL, %s, sizeof(%s), %s, %s);\n",
            (unsigned int)instruction->result, (unsigned int)first,
            XL6_IR_CGEN_STACK_COMMON_ARGS,
            instruction->runtimeOp == XL6_IR_RUNTIME_STACK_CAPACITY
                ? "true" : "false");
        break;
    default:
#undef XL6_IR_CGEN_STACK_COMMON_ARGS
        return 0;
    }
#undef XL6_IR_CGEN_STACK_COMMON_ARGS
    return xl6OutputHasFailed(out) ? -1 : 1;
}

#include "src/cgen/xl6_ir_cgen_tree_emit.c"
